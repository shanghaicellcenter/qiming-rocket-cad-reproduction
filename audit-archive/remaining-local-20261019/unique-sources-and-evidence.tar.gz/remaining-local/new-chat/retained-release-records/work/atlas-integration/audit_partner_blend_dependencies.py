import bpy, json, hashlib
from pathlib import Path

ROOT=Path('/Users/qianqiming/Documents/Codex/2026-10-19/ni')
OUT=Path('/Users/qianqiming/Documents/Codex/2026-10-19/new-chat/work/atlas-integration')
files=[ROOT/'work/rocket-v2/native-selected.blend',
       ROOT/'outputs/rocket/animation/causal-course.blend',
       ROOT/'outputs/rocket/animation/causal-course-clarity.blend',
       ROOT/'work/rocket-v2/source-details-evidence/A7-01-source-card.blend',
       ROOT/'work/rocket-v2/source-details-evidence/A7-16-source-card.blend']
report={'blenderVersion':bpy.app.version_string,'readOnly':True,'savedAnyBlend':False,'files':[]}
for p in files:
    bpy.ops.wm.open_mainfile(filepath=str(p),load_ui=False,use_scripts=False)
    report['files'].append({'file':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),
      'libraries':[{'filepath':x.filepath,'resolved':bpy.path.abspath(x.filepath)}for x in bpy.data.libraries],
      'images':[{'name':x.name,'filepath':x.filepath,'resolved':bpy.path.abspath(x.filepath),
                 'packed':bool(x.packed_file or len(x.packed_files)),'source':x.source,'users':x.users,
                 'sceneMaterialConsumers':[{'object':ob.name,'material':slot.material.name,'node':n.name}
                    for ob in bpy.context.scene.objects for slot in ob.material_slots
                    if slot.material and slot.material.use_nodes
                    for n in slot.material.node_tree.nodes if n.type=='TEX_IMAGE' and n.image==x]}
                 for x in bpy.data.images],
      'movieClips':[x.filepath for x in bpy.data.movieclips],
      'sounds':[{'filepath':x.filepath,'packed':bool(x.packed_file)}for x in bpy.data.sounds],
      'cacheFiles':[x.filepath for x in bpy.data.cache_files],
      'objectCount':len(bpy.data.objects),'meshCount':len(bpy.data.meshes)})
(OUT/'partner-blend-dependency-read-audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print('DEPENDENCY_AUDIT='+json.dumps({'blenderVersion':report['blenderVersion'],'files':len(report['files']),
  'libraryLinks':sum(len(x['libraries'])for x in report['files']),
  'unpackedImages':sum(sum(not im['packed'] and im['source']=='FILE'for im in x['images'])for x in report['files']),
  'savedAnyBlend':False},ensure_ascii=False))
