"""Prepare a concise public cleanup receipt only after actual removal passes."""
from pathlib import Path
import hashlib,json,subprocess
R=Path(__file__).resolve().parents[1]
V=R.parent/'qiming-github-verify-20261019'
P=V/'project'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
d=json.loads((V/'reports/local-cleanup-receipt.json').read_text())
assert d.get('cleanup_complete') is True and len(d['deletions'])==2
assert all(x['removed'] is True and x['symlink_targets_followed'] is False and not Path(x['quarantine']).exists() for x in d['deletions'])
assert d['post_delete_tracked194_exact_sha256'] is True
assert d['post_delete_protected_inputs']['all_passed'] is True
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=P,text=True).strip()=='f4f6105c5a084512912d7f067ec5f818304a73d5'
s={
 'status':'completed_after_actual_published_download_and_runtime_acceptance',
 'finished_utc':d['finished_utc'],
 'repo':'https://github.com/shanghaicellcenter/qiming-rocket-cad-reproduction',
 'release_url':'https://github.com/shanghaicellcenter/qiming-rocket-cad-reproduction/releases/tag/v1.0.0',
 'frozen_release_commit':'82c2a2a255b66556cead58ec3444f81f1757ae68',
 'release_manifest_sha256':'b5122c9f67b948f15e3f476e1bcd01f447593c46a6dff80292bd61994f314877',
 'actual_download_receipt_sha256':sha(V/'reports/actual-download-receipt.json'),
 'final_runtime_acceptance_receipt_sha256':sha(V/'reports/final-acceptance.json'),
 'private_full_cleanup_receipt_sha256':sha(V/'reports/local-cleanup-receipt.json'),
 'public_release_all10_asset_api_rechecked_before_removal':d['pre_delete_public_release_all10_asset_api_verified'],
 'task_owned_original_generated_roots_removed':35,
 'task_owned_actual_download_and_rebuild_copies_removed':True,
 'removed_scope':[{'set':'original_generated_outputs' if i==0 else 'actual_download_and_rebuild_duplicates','reviewed_roots_or_paths':x['reviewed_sources'],'entries_including_mirror_directories':x['entries_with_mirror_parents'],'logical_file_bytes_removed':x['logical_file_bytes'],'symlink_targets_followed':False,'independent_review_sha256':x['independent_report_sha256']} for i,x in enumerate(d['deletions'])],
 'protected_original_source_content_files':392,
 'protected_other_project_independent_copies':103,
 'protected_sources_sha256_rechecked_after_removal':True,
 'primary_git194_frozen_sources_exact_before_later_main_update':True,
 'retained_after_cleanup':'Small Git source checkout, release URLs and manifests, local acceptance reports/screenshots, 22 actual new Blender QA images, and small audit records. Original Desktop project, other project, shared tools and services preserved.',
 'both_unique_quarantine_children_absent':True,
 'unknown_or_unscoped_files_removed':False,
 'processes_killed_during_final_deletion':0,
 'space':d['space'],
 'release_payload_and_frozen_tag_modified_by_cleanup':False
}
dest=P/'verification/v1.0.0/local-cleanup-summary.json';dest.write_text(json.dumps(s,ensure_ascii=False,indent=2)+'\n')
space=s['space'];logical=space['logical_file_bytes_removed']/10**9;delta=space['observed_available_delta_bytes']/10**9
text=f'''# v1.0.0 本地生成副本清理记录

公开发布、全部10附件真实匿名下载、3829文件SHA核对及实际浏览/声画播放/前端与Blender重建验收完成后，已按用户授权清理本任务的大型生成输出和验证副本。

- 原工作区35个明确生成目录/别名已移除。
- 实际下载包、展开的大型文件、恢复影片和前端/Blender重建副本已移除。保留主Git检出的194个冻结源码文件；删除前后逐项SHA相同，之后才更新到含验收记录及验证器修正的main。
- 两批先原子隔离，分别独立复核范围、所有条目指纹与活跃句柄，再只删除精确的两个隔离子目录。删除使用不跟随符号链接目标的目录操作。
- 桌面原项目392文件与另一项目103份独立输入在删除后再次核SHA通过；共用运行时、技能与Blender程序保留。未清理其他项目或未分类文件。
- 轻量源码、哈希清单、验收报告/截图和22张实际重建诊断图继续保留；完整模型、全部图册和影片素材仍由同一公开Release提供。

按逻辑文件大小共移除约 **{logical:.3f} GB**；同一文件系统可用空间在两次采样间净增加约 **{delta:.3f} GB**。前者包括重复/写时复制数据，后者可能受同时运行的其他任务影响，不能把逻辑大小当作精确的独立物理回收量。

冻结Release仍为 commit `82c2a2a255b66556cead58ec3444f81f1757ae68`，清单SHA256仍为 `b5122c9f67b948f15e3f476e1bcd01f447593c46a6dff80292bd61994f314877`。本记录没有改变发布附件或标签。

[机器可读清理摘要](../verification/v1.0.0/local-cleanup-summary.json) · [下载重建实际验收](下载重建验收-v1.0.0.md) · [完整Release](https://github.com/shanghaicellcenter/qiming-rocket-cad-reproduction/releases/tag/v1.0.0)
'''
(P/'docs/本地生成副本清理-v1.0.0.md').write_text(text)
readme=P/'README.md';body=readme.read_text();link='docs/本地生成副本清理-v1.0.0.md'
assert link not in body
readme.write_text(body+'\n已完成发布后的实际下载、离线播放与重建验收，并按授权清理本任务大型本地副本；原始项目和跨项目输入保留。见[本地清理记录]('+link+')。\n')
print(json.dumps({'prepared':True,'changed':['README.md','docs/本地生成副本清理-v1.0.0.md','verification/v1.0.0/local-cleanup-summary.json'],'logical_bytes_removed':space['logical_file_bytes_removed'],'observed_space_delta_bytes':space['observed_available_delta_bytes']},ensure_ascii=False))
