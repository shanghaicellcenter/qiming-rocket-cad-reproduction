# 原生 CAD 被动可视化转换记录

范围：主 R01 源 ZIP。仅进行原始几何、名称、层级、变换和可见性的格式转换；没有读取装配约束或物理数据，没有求解、操作演示、补造设计或改动原件。

- 官方读取器：usd-convert-cad 0.3.0，CPython 3.12 / Linux aarch64，用户自有 Spark 独立 venv。
- 官方 wheel 的 SHA256 与安装缓存实物一致；实际转换没有要求账户、token、商业 entitlement 或试用。
- 原 ZIP SHA256：a7af67f407d2729f70154a7f5b98113c31b8249661527d6a9ed72e67e68b4dd5。
- 源包 119 个 SLDPRT、14 个 SLDASM 全部有非空 USD。额外 13 张 SLDDRW、3 个 TXT 不属于本次三维读取数量。
- `library.coverage.json` 独立逐个读取原 ZIP 内容，核对 133/133 输入哈希和 133/133 本地 USD 哈希，全部一致；没有缺失或额外 CAD basename。
- `library/parts/`：119 个独立零件，保留英文 basename，共约 71.0 MB。
- `library/assemblies/`：13 个其余装配，共约 193.1 MB。
- `vehicle.usdc`：原整箭装配，LOD3，70,328,219 bytes，7,070,568 面，688 个非空网格 occurrence，635 个 component-kind 节点。145 个 points attribute provider 是几何定义计数，不是独立零件数。
- `vehicle-browse.usdc`：同源可选 LOD1，30,735,705 bytes，2,864,600 面；全部 688 网格路径与 LOD3 对应。排除根据输出文件名生成的两层 wrapper 后，654 个 component/group 节点的路径、名字、局部变换和可见性与 LOD3 完全相同，见 `vehicle.lod-comparison.json`。
- 所有转换使用 reference、composition none、filter hide、load-hidden。没有 accurate-tessellation 额外标志。默认单位为 0.0254 m/unit、Y-up，原转换 wrapper 保留。
- 132 个独立文件批量以 3 并发运行，含审计总 164.3 秒。原整箭 LOD3 转换 45.9 秒；LOD1 转换 27.0 秒。
- 所有日志许可错误和缺引用匹配为 0。默认 displayName 和 kind 足以保留导航名称，没有额外读取制造参数 metadata。

审计使用 `Usd.PrimRange(stage.GetPseudoRoot(), Usd.TraverseInstanceProxies())`。本次 reference 输出没有 native instanceable prototype；仍按 occurrence 审计以免未来版本漏计。`vehicle.name-source-map.json` 的名字映射覆盖 112/119 源零件和 13/14 源装配，余下 7 个零件已全部独立转换，不能把整箭视图等同源包完整目录。

每个库文件带 `.conversion.json`、`.validation.json`、`.hierarchy.json` 和日志。完整原生 USD 与库还保留在 Spark：`~/codex-mojave-cad-review-20261019/`；本地文件均在当前 `work/native-cad/`。

限制：非空/哈希/层级检查确认读取与复制，不等同逐件视觉验收，也不能证明原作者 CAD 本身包含其项目的一切实物。主 R01 源 ZIP 以外的后补版本和其他项目文件不在这 133 份 CAD 统计里。
