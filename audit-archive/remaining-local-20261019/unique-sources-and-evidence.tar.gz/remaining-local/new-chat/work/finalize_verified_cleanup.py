"""Remove only the two exact, staged, independently reviewed owned children.
Dry-run is the default. Never delete the project parent, protected sources,
primary Git checkout, reports, shared tools, or follow a symlink target.
"""
from pathlib import Path
import argparse, datetime, json, runpy, shutil, subprocess

ROOT=Path(__file__).resolve().parents[1]
V=ROOT.parent/'qiming-github-verify-20261019'
H=runpy.run_path(str(ROOT/'work/stage_cleanup.py'))
check,sha,save=(H[x] for x in ['check','sha','save'])
plan=json.loads((ROOT/'work/cleanup-plan-current.json').read_text())

def validate_tree(q, groups, base):
 expected={'.'}
 for g in groups:
  source=Path(g['source']);rel=source.relative_to(base)
  for parent in rel.parents:
   if str(parent)!='.':expected.add(parent.as_posix())
  for r in g['items']:
   expected.add((rel/Path(r['relative_path'])).as_posix())
  H['match_fingerprints']({'items':g['items']},q/rel)
 actual=set(H['snapshot'](q))
 check(actual==expected,'Unexpected or missing entries inside exact quarantine child')
 return len(actual)

def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--apply',action='store_true');args=parser.parse_args()
 report={'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'mode':'APPLY_EXACT_REVIEWED_CHILDREN' if args.apply else 'DRY_RUN','deletions':[],'processes_killed':0}
 try:
  check(shutil.rmtree.avoids_symlink_attacks,'Platform deletion must use FD-based symlink-safe rmtree')
  report['final_acceptance']=H['validate_acceptance'](V/'reports/final-acceptance.json')
  report['retained_git_before']=H['clone_proof'](plan)
  report['protected_inputs_before']=H['check_103_and_desktop'](plan)
  api=json.loads(subprocess.check_output(['/opt/homebrew/bin/gh','api','repos/shanghaicellcenter/qiming-rocket-cad-reproduction/releases/tags/v1.0.0'],text=True))
  actual=json.loads((V/'reports/actual-download-receipt.json').read_text())
  check(api['draft'] is False and api['id']==417612933 and api['tag_name']=='v1.0.0','Release no longer publicly published')
  a={x['name']:x for x in api['assets']}
  check(set(a)=={x['name'] for x in actual['assets']},'Remote asset set changed')
  for x in actual['assets']:
   check(a[x['name']]['id']==x['github_asset_id'] and a[x['name']]['size']==x['bytes'] and a[x['name']]['digest']=='sha256:'+x['sha256'] and a[x['name']]['state']=='uploaded','Remote uploaded asset identity changed')
  report['pre_delete_public_release_all10_asset_api_verified']=True
  save(V/'reports/pre-delete-release-api.json',api)
  oldstage=ROOT/'work/cleanup-stage-current.json';newstage=V/'reports/generated-copy-stage.json'
  o=json.loads(oldstage.read_text());n=json.loads(newstage.read_text())
  oldreview=V/'reports/independent/old35-quarantine-review.json';newreview=V/'reports/independent/generated-copy-quarantine-review.json'
  od=json.loads(oldreview.read_text());nd=json.loads(newreview.read_text())
  check(o['post_stage_passed'] is True and n['post_stage_passed'] is True,'A staging check failed')
  check(od['no_concrete_block_to_removing_only_this_exact_child_found'] is True and nd['no_concrete_block_to_removing_only_this_exact_child_found'] is True,'Independent review did not pass')
  for d,j in [(od,oldstage),(nd,newstage)]:
   check(d['stage_journal_sha256']==sha(j) and not d['errors'] and not d['current_active_quarantine_handles'],'Review is stale or blocked')
  oldgroups=[{'source':g['root'],'items':g['items']} for g in H['known_fingerprints'](plan)]
  nf=Path(n['fingerprint_file']);check(sha(nf)==n['fingerprint_sha256']==nd['fingerprint_file_sha256'],'New fingerprint proof changed')
  newdata=json.loads(nf.read_text());newgroups=newdata['groups']
  children=[(o,od,oldgroups,ROOT,ROOT/'.cleanup-quarantine'),(n,nd,newgroups,V,V/'.generated-validation-quarantine')]
  report['reviewed_children']=[]
  for s,d,groups,base,parent in children:
   q=Path(s['quarantine']);H['plain_ancestors'](q,True)
   check(q.parent==parent and q==Path(d['quarantine_child']) and len(q.name.split('-')[-1])==8,'Quarantine child scope differs')
   check(q.is_dir() and not q.is_symlink() and (parent/'owner.json').is_file(),'Owned quarantine child missing')
   owner=json.loads((parent/'owner.json').read_text());check(owner.get('project_root',owner.get('verification_root'))==str(base),'Quarantine parent owner mismatch')
   check(not H['open_handles']([q]),'Active quarantine handle appeared')
   count=validate_tree(q,groups,base)
   check(all(not Path(g['source']).exists() and not Path(g['source']).is_symlink() for g in groups),'Staged source reappeared; preserve and review')
   report['reviewed_children'].append({'quarantine':str(q),'entries_with_mirror_parents':count,'logical_file_bytes':sum(r['bytes'] for g in groups for r in g['items'] if r['kind']=='file'),'independent_report_sha256':sha(oldreview if base==ROOT else newreview),'reviewed_sources':len(groups)})
  report['ready']=True
  if args.apply:
   save(V/'reports/local-cleanup-receipt.json',report)
   for row in report['reviewed_children']:
    q=Path(row['quarantine']);check(not H['open_handles']([q]),'Quarantine reopened before removal')
    shutil.rmtree(q)
    check(not q.exists() and not q.is_symlink(),'Exact quarantine child still exists')
    report['deletions'].append({**row,'removed':True,'removed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'symlink_targets_followed':False})
    save(V/'reports/local-cleanup-receipt.json',report)
   for _,_,groups,_,_ in children:
    check(all(not Path(g['source']).exists() and not Path(g['source']).is_symlink() for g in groups),'A generated source reappeared')
   report['post_delete_retained_git']=H['clone_proof'](plan)
   check(all(sha(V/'project'/x)==h for x,h in newdata['tracked_original_sha256'].items()),'Retained tracked194 bytes differ')
   report['post_delete_tracked194_exact_sha256']=True
   report['post_delete_protected_inputs']=H['check_103_and_desktop'](plan)
   report['post_delete_outside_references']=H['outside_refs'](plan)
   targets=[Path('/Users/qianqiming/Desktop/skill-repos/cclank--cell-architecture-studio/node_modules/stats-gl/node_modules/three'),Path('/Users/qianqiming/Desktop/skill-repos/cclank--cell-architecture-studio/node_modules/esbuild'),Path('/Applications/Blender 5.2.app/Contents/MacOS/Blender')]
   check(all(x.exists() for x in targets),'Protected shared tool target disappeared')
   report['protected_shared_tool_targets_exist']=True
   check((V/'reports/final-acceptance.json').is_file() and (ROOT/'retained-release-records/preserved-receipts-manifest.json').is_file(),'Retained evidence missing')
   raw=subprocess.check_output(['df','-k',str(V)],text=True);avail=int(raw.splitlines()[-1].split()[3])*1024
   before=json.loads((V/'reports/cleanup-space-before.json').read_text())
   report['space']={'before_available_bytes':before['available_bytes'],'after_available_bytes':avail,'observed_available_delta_bytes':avail-before['available_bytes'],'logical_file_bytes_removed':sum(x['logical_file_bytes'] for x in report['deletions']),'df_k_after':raw,'measurement_note':'Logical removed bytes include duplicate APFS/COW copies; observed free-space delta can include concurrent activity and is not an exact isolated physical-reclaim measure.'}
   report['cleanup_complete']=True
   report['protected_original_sources_preserved']=True
   report['unknown_or_unscoped_files_removed']=False
   report['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 except Exception as exc:
  report['error']=str(exc);report['cleanup_complete']=False
 finally:
  save(V/'reports/local-cleanup-receipt.json' if args.apply else V/'reports/local-cleanup-dry-run.json',report)
  print(json.dumps({k:v for k,v in report.items() if k!='final_acceptance'},ensure_ascii=False,indent=2))
 if not report.get('ready') or (args.apply and not report.get('cleanup_complete')):raise SystemExit(1)

if __name__=='__main__':main()
