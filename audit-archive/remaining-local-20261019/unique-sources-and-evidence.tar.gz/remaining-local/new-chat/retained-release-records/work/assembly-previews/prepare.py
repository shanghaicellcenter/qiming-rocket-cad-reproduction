import json,pathlib,hashlib,zipfile
root=pathlib.Path('/Users/qianqiming/Documents/Codex/2026-10-19/new-chat')
base=root/'work/native-cad';out=root/'outputs/mojave-machine/library/assembly-previews'
idx=json.loads((base/'library.index.json').read_text());labels=json.loads((base/'component-labels.json').read_text())['by_basename']
sourcezip=pathlib.Path('/Users/qianqiming/Desktop/火箭设计 中文版/英文原件/Mojave Sphinx CAD - R01.zip')
rows=[]
with zipfile.ZipFile(sourcezip) as z:
 names={pathlib.PurePosixPath(n).name:n for n in z.namelist()}
 for i,r in enumerate([r for r in idx['files'] if r['source_basename'].endswith('.SLDASM')],1):
  usd=base/r['usd_relative'];actual_usd=hashlib.sha256(usd.read_bytes()).hexdigest();actual_cad=hashlib.sha256(z.read(names[r['source_basename']])).hexdigest();assert actual_usd==r['usd_sha256'];assert actual_cad==r['source_sha256']
  val=usd.with_suffix('.validation.json');val=val if val.exists() else base/'vehicle.validation.json'
  v=json.loads(val.read_text())
  rows.append({'id':f'A{i:02d}','source_filename':r['source_basename'],'label_zh':labels.get(r['source_basename'],{}).get('label_zh',r['source_basename']),
   'source_archive':sourcezip.name,'source_archive_sha256':idx['source_zip_sha256'],'source_member':names[r['source_basename']],
   'source_sha256':actual_cad,'source_usd':str(usd),'source_usd_sha256':actual_usd,'expected_mesh_count':v['mesh_count'],
   'expected_triangles':v['face_count'],'source_unit_metres':v['meters_per_unit'],'source_up_axis':v['up_axis'],
   'views':[{'id':view,'filename':f'A{i:02d}-{view}.png'} for view in ['front','side','oblique']]})
config={'output_dir':str(out),'render_width':1280,'render_height':960,'rows':rows,'native_source_count':len(rows),'source_archive':str(sourcezip),'source_archive_sha256':idx['source_zip_sha256']}
(root/'work/assembly-previews/jobs.json').write_text(json.dumps(config,ensure_ascii=False,indent=2));print(json.dumps({'assemblies':len(rows),'planned_images':len(rows)*3,'source_hash_checks':'all passed','out':str(out)},ensure_ascii=False))
