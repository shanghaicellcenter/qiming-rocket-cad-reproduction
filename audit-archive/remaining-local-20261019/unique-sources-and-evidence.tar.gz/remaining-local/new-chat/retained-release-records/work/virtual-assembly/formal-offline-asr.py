"""Independent local ASR of this task's pending formal attempts, no model download."""
from pathlib import Path
import json,os,time,subprocess,re,hashlib,difflib,sys
sys.dont_write_bytecode=True
TASK=Path('/home/qianqiming/codex-mojave-assembly-voice-20261019')
MODEL=Path('/home/qianqiming/.cache/huggingface/hub/models--openai--whisper-large-v3-turbo/snapshots/41f01f3fe87f28c78e2fbf8b568835947dd65ed9')
inc=Path('/home/qianqiming/work/drama-3/.deps/python-dev/usr/include');os.environ['CPATH']=':'.join([str(inc/'python3.12'),str(inc),os.environ.get('CPATH','')]).rstrip(':')
for k,v in {'HF_HUB_OFFLINE':'1','TRANSFORMERS_OFFLINE':'1','OMP_NUM_THREADS':'6','MKL_NUM_THREADS':'6','TOKENIZERS_PARALLELISM':'false','PYTHONDONTWRITEBYTECODE':'1','TRITON_CACHE_DIR':str(TASK/'cache/triton'),'NUMBA_CACHE_DIR':str(TASK/'cache/numba'),'TORCHINDUCTOR_CACHE_DIR':str(TASK/'cache/torchinductor')}.items():os.environ[k]=v
paths=sorted(p for p in (TASK/'formal').glob('*/attempt-*/result.json') if not (p.parent/'asr.json').exists() and (p.parent/'voice.wav').exists())
if not paths:print('No unchecked audio attempts');raise SystemExit(0)
import numpy as np,torch
from transformers import WhisperForConditionalGeneration,WhisperProcessor,pipeline
torch.set_num_threads(6);torch.set_num_interop_threads(1)
mem=int(dict(x.split(':',1) for x in Path('/proc/meminfo').read_text().splitlines())['MemAvailable'].split()[0])*1024
assert mem>13*1024**3,'Insufficient available memory for a separate small ASR model; do not load it'
device='cuda:0' if torch.cuda.is_available() else 'cpu';dtype=torch.float16 if device.startswith('cuda') else torch.float32
processor=WhisperProcessor.from_pretrained(str(MODEL),local_files_only=True)
model=WhisperForConditionalGeneration.from_pretrained(str(MODEL),local_files_only=True,dtype=dtype,attn_implementation='eager').to(device).eval()
asr=pipeline('automatic-speech-recognition',model=model,tokenizer=processor.tokenizer,feature_extractor=processor.feature_extractor,device=device)
norm=lambda s:''.join(re.findall('[\u4e00-\u9fffA-Za-z0-9]',s)).lower()
for p in paths:
    free=int(dict(x.split(':',1) for x in Path('/proc/meminfo').read_text().splitlines())['MemAvailable'].split()[0])*1024
    assert free>9*1024**3,'Available memory too low; stopping only this ASR check'
    expected=json.loads(p.read_text())['text'];src=p.parent/'voice.wav';started=time.monotonic()
    raw=subprocess.run(['/usr/bin/ffmpeg','-nostdin','-v','error','-i',str(src),'-f','f32le','-ac','1','-ar','16000','pipe:1'],capture_output=True,check=True).stdout;audio=np.frombuffer(raw,dtype='<f4').copy()
    result=asr({'raw':audio,'sampling_rate':16000},return_timestamps='word',generate_kwargs={'language':'zh','task':'transcribe','max_new_tokens':192,'do_sample':False});a=norm(expected);b=norm(result['text']);words=[{'start':c['timestamp'][0],'end':c['timestamp'][1],'text':c['text']} for c in result.get('chunks',[])]
    differences=[{'kind':op,'expected':a[i:j],'recognized':b[k:l],'expected_range':[i,j],'recognized_range':[k,l]} for op,i,j,k,l in difflib.SequenceMatcher(None,a,b,autojunk=False).get_opcodes() if op!='equal']
    subtitles=[]
    if a==b and ''.join(norm(w['text']) for w in words)==a:
        cursor=0;positions=[]
        for w in words:
            n=len(norm(w['text']));positions.append((cursor,cursor+n,w));cursor+=n
        cursor=0;sentence_spans=[]
        for sentence in re.findall(r'[^。！？!?；;]+[。！？!?；;]?|[。！？!?；;]',expected):
            n=len(norm(sentence));covered=[w for s,e,w in positions if e>cursor and s<cursor+n]
            boundaries={0,len(a)}|{s for s,e,w in positions}|{e for s,e,w in positions}
            if covered and cursor in boundaries and cursor+n in boundaries:sentence_spans.append({'text':sentence,'start':covered[0]['start'],'end':covered[-1]['end']})
            else:sentence_spans=[];break
            cursor+=n
        subtitles=sentence_spans
    record={'id':p.parent.parent.name,'attempt':int(p.parent.name.split('-')[-1]),'audio_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'engine':'Whisper large-v3-turbo','device':device,'offline':True,'expected':expected,'transcript':result['text'],'duration_seconds':len(audio)/16000,'words':words,'normalized_exact_match':a==b,'reference_text_leak_detected':any(t in result['text'] for t in ['欢迎收听','今天的天气','一起出去走走']),'differences':differences,'similarity':difflib.SequenceMatcher(None,a,b,autojunk=False).ratio(),'subtitle_sentences':subtitles,'subtitle_timing_method':'Expected sentence spans grouped from independent Whisper decoder acoustic token timestamps only when normalized text matches; approximate, no character-averaged time','elapsed_seconds':time.monotonic()-started,'actual_listening':'not performed by this agent; parent perceptual review pending'}
    (p.parent/'asr.json').write_text(json.dumps(record,ensure_ascii=False,indent=2));print(json.dumps({'id':record['id'],'attempt':record['attempt'],'duration':record['duration_seconds'],'match':record['normalized_exact_match'],'differences':differences,'reference_leak':record['reference_text_leak_detected']},ensure_ascii=False),flush=True)
