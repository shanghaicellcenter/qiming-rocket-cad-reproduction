#!/usr/bin/env python3
"""Read-only cross-project dependency inventory. No partner mutations or deletions."""
from pathlib import Path
import ast, base64, collections, datetime, hashlib, json, os, re

HERE=Path(__file__).resolve().parent
PARTNER=Path('/Users/qianqiming/Documents/Codex/2026-10-19/ni')
SOURCE=Path('/Users/qianqiming/Documents/Codex/2026-10-19/new-chat')
PUBLIC=SOURCE/'outputs/启明火箭'

def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
    return h.hexdigest()

def meta(p):
    p=Path(p);d={'path':str(p),'exists':p.exists(),'isSymlink':p.is_symlink(),'resolved':str(p.resolve())}
    if p.is_file():
        s=p.stat();d.update(bytes=s.st_size,sha256=sha(p),device=s.st_dev,inode=s.st_ino)
    elif p.is_dir():d['isDirectory']=True
    return d

def strings(obj,key=''):
    if isinstance(obj,dict):
        for k,v in obj.items():yield from strings(v,key+'.'+k)
    elif isinstance(obj,list):
        for i,v in enumerate(obj):yield from strings(v,key+f'[{i}]')
    elif isinstance(obj,str):yield key,obj

def extract_references(p,text):
    try:
        if p.suffix=='.json':return [(k,s)for k,s in strings(json.loads(text))if str(SOURCE) in s]
        if p.suffix=='.py':return [('literal',n.value)for n in ast.walk(ast.parse(text))if isinstance(n,ast.Constant)and isinstance(n.value,str)and str(SOURCE)in n.value]
    except (ValueError,SyntaxError):pass
    out=[]
    for m in re.finditer(r'"((?:[^"\\]|\\.)*)"|\x27([^\x27\n]*)\x27',text):
        s=m.group(1) if m.group(1)is not None else m.group(2)
        if str(SOURCE)in s:
            try:s=json.loads('"'+s+'"') if m.group(1)is not None else s
            except ValueError:pass
            if len(s)<2000:out.append(('literal',s))
    if not out and 'new-chat' in text:
        out=[(f'line {i}',s[:800])for i,s in enumerate(text.splitlines(),1)if'new-chat'in s]
    return out

def main():
    selected=[];skipped=[]
    for sub in ['outputs/rocket','outputs/rocket-v2','work/rocket-v2']:
        for directory,dirs,files in os.walk(PARTNER/sub,followlinks=False):
            dirs[:]=[x for x in dirs if x not in ['node_modules','vendor','.git']]
            for name in files:
                p=Path(directory)/name
                if p.is_symlink() or p.suffix not in ['.py','.mjs','.js','.json','.md','.html','.toml','.sh']:continue
                if p.stat().st_size>10*1024*1024:skipped.append(str(p.relative_to(PARTNER)));continue
                text=p.read_text(errors='replace')
                if 'new-chat'not in text:continue
                refs=extract_references(p,text)
                if not refs:continue
                rel=str(p.relative_to(PARTNER))
                classification='provenance_only'
                if p.suffix=='.py':classification='future_rebuild_input'
                if name=='native-thumbnail-jobs.json':classification='future_rebuild_input'
                selected.append({'file':rel,'bytes':p.stat().st_size,'sha256':sha(p),'classification':classification,
                                 'references':[{'key':k,'value':s}for k,s in refs]})
    # Directly consumed JSON input to the current course builder lives one level outside requested work scope.
    for p in [PARTNER/'work/rocket/parts.json',PARTNER/'work/rocket/custom-parts.json']:
        refs=extract_references(p,p.read_text())
        if refs:selected.append({'file':str(p.relative_to(PARTNER)),'bytes':p.stat().st_size,'sha256':sha(p),
                                'classification':'embedded_image_provenance_only','references':[{'key':k,'value':s}for k,s in refs]})
    preservation=[]
    base=SOURCE/'work/native-cad'
    for name in ['vehicle.usdc','vehicle.hierarchy.json','component-labels.json','vehicle.name-source-map.json']:
        preservation.append({'role':'native subset reconstruction or identity mapping','consumers':['extract_native_subset.py','audit_part_identity.py','merge_visual_patch.py'],'source':meta(base/name)})
    jobs=json.loads((PARTNER/'work/rocket-v2/native-thumbnail-jobs.json').read_text())
    for job in jobs:
        preservation.append({'role':'native thumbnail rebuild','consumers':['native-thumbnail-jobs.json','render_native_thumbnails.py'],'source':meta(job['usd']),'sourceBasename':job['sourceBasename']})
    for name in ['P087-oblique.png','P072-oblique.png']:
        preservation.append({'role':'two original image inputs for source-detail card rebuild','consumers':['source-details-evidence/render_source_details.py'],'source':meta(PUBLIC/'library/part-previews'/name)})
    evidence=[]
    for name in ['simulation/official-existing-simulation-result.json','simulation/simulation-review-report.md','flight-evidence/evidence-register.json','flight-evidence/证据审查.md']:
        source=PUBLIC/'research'/name;dest=PARTNER/'work/rocket-v2/qa/external-evidence'/source.name
        a,b=meta(source),meta(dest);identical=a.get('sha256')==b.get('sha256')and a.get('sha256')is not None
        evidence.append({'role':'historical evidence page rebuild','source':a,'localCopy':b,'copyBytesMatchNow':identical,
                         'consumerStillReadsOriginalAbsoluteDirectory':True})
        preservation.append({'role':'evidence rebuild; local independent copy exists'if identical else'evidence rebuild input requiring copy','consumers':['build_evidence_page.py'],'source':a,'alreadyCopiedTo':str(dest)if identical else None})
    # Actual standalone partner viewer contains all three model payloads in its own regular HTML file.
    html=PARTNER/'outputs/rocket/native-assembly.html';text=html.read_text();models=[]
    for script_id,src in [('model-browse',PUBLIC/'assembly/vehicle-browse.compact.glb'),('model-precision',PUBLIC/'assembly/vehicle-original.compact.glb'),('model-supplements',PUBLIC/'library/supplements/supplements.glb')]:
        m=re.search(r'<script\b(?=[^>]*\bid=["\x27]'+re.escape(script_id)+r'["\x27])[^>]*>(.*?)</script>',text,re.S)
        raw=base64.b64decode(m.group(1).strip())if m else None
        models.append({'id':script_id,'embedded':raw is not None,'bytes':len(raw)if raw else 0,'embeddedSha256':hashlib.sha256(raw).hexdigest()if raw else None,'original':meta(src),'sameModelBytes':raw is not None and hashlib.sha256(raw).hexdigest()==sha(src)})
    viewer={'html':meta(html),'containsNewChatPath':str(SOURCE)in text,'fileURIs':len(re.findall(r'file://',text)),
            'embeddedModels':models,'record':json.loads((PARTNER/'outputs/rocket/原生装配接入记录.json').read_text()),
            'conclusion':'Independent regular HTML with three byte-identical embedded models; source path in import record is provenance, not runtime input.'}
    silent_record=json.loads((PARTNER/'outputs/rocket-v2/assembly-review/接入与核查状态.json').read_text());silent=PARTNER/silent_record['output'];silent_meta=meta(silent)
    silent_copy={'destination':silent_meta,'recordedSource':silent_record['source'],'recordedSourceSha256':silent_record['sha256'],'destinationMatchesRecordedSha256':silent_meta.get('sha256')==silent_record['sha256'],'sourceExistsNow':Path(silent_record['source']).exists(),'isRejectedOrUnacceptedDraft':True,'conclusion':'An independent unaccepted historical silent preview, not a current source-file dependency or final accepted video.'}
    independent_geometry=[]
    for rel in ['work/rocket-v2/native-selected.blend','outputs/rocket/animation/causal-course.blend','outputs/rocket/animation/causal-course-clarity.blend','outputs/rocket-v2/assets/native-piston.glb','outputs/rocket-v2/assets/native-valve.glb','outputs/rocket-v2/assets/fuel-route.glb']:
        independent_geometry.append(meta(PARTNER/rel))
    report={'createdAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'readOnly':True,'partnerFilesModified':False,
      'scope':{'roots':['outputs/rocket','outputs/rocket-v2','work/rocket-v2'],'alsoReadDirectCourseInputs':['work/rocket/parts.json','work/rocket/custom-parts.json'],'excluded':['binary/image/audio scanning except specifically verified inputs/copies','node_modules/vendor trees','files larger than10MiB except independent native viewer'],'largeTextFilesSkipped':skipped},
      'textFilesContainingCrossProjectReferences':selected,'symlinks':json.loads((HERE/'cross-project-symlinks.json').read_text()),
      'preserveOrRelocateBeforeDeletingSource':preservation,'existingEvidenceCopies':evidence,'independentViewer':viewer,'independentSilentHistory':silent_copy,'independentDerivedGeometry':independent_geometry,
      'processSnapshot':json.loads((HERE/'cross-project-processes.json').read_text()),'openDesignOpenFileSnapshot':json.loads((HERE/'opendesign-open-file-check.json').read_text()),
      'sharedToolsNotEligibleForProjectCleanup':['/Users/qianqiming/Desktop/火箭设计 中文版','/Users/qianqiming/Desktop/skill-repos/AirsupHQ--machine-skill','/Users/qianqiming/.cache/codex-runtimes/codex-primary-runtime/dependencies/node','shared Blender installation or existing bpy environment'],
      'limitations':['No files copied, edited or deleted in the partner project.','No no-dependency claim from process/file-handle absence; browsers may cache resources.','Future rebuild scripts still hardcode source directories until the partner changes and actually verifies them.','This audit is not authorization to delete sources, project outputs, shared tools or runtimes.']}
    # Unique real source files, without double-counting work-path compatibility symlinks.
    unique={p['source']['resolved']:p['source']for p in preservation if p['source'].get('sha256')}
    report['summary']={'matchingTextFiles':len(selected),'allSymlinks':len(report['symlinks']),'symlinksIntoNewChat':sum(x['pointsIntoNewChat']for x in report['symlinks']),
       'nativeUsdTaskFiles':len(jobs),'sourceFilesToPreserveOrRelocate':len(unique),'sourceBytesToPreserveOrRelocate':sum(x['bytes']for x in unique.values()),
       'byteIdenticalEmbeddedModels':sum(x['sameModelBytes']for x in models),'localEvidenceCopiesByteIdentical':sum(x['copyBytesMatchNow']for x in evidence),
       'independentSilentCopyVerified':silent_copy['destinationMatchesRecordedSha256'],'cleanupDependencyReleaseComplete':False}
    blend_path=HERE/'partner-blend-dependency-read-audit.json'
    if blend_path.exists():
        blend=json.loads(blend_path.read_text());active=[];unused=[]
        for f in blend['files']:
            for im in f['images']:
                if im['source']=='FILE'and not im['packed']:
                    item={'blend':f['file'],'image':im['name'],'filepath':im['filepath'],
                          'resolved':str(Path(im['resolved']).resolve()),
                          'sceneMaterialConsumers':im.get('sceneMaterialConsumers',[]),'users':im.get('users')}
                    (active if item['sceneMaterialConsumers'] else unused).append(item)
        report.update(actualBlenderDependencyRead=blend,activeUnpackedImageDependencies=active,unusedImageDatablocks=unused)
        report['summary'].update(actualBlendFilesRead=len(blend['files']),
          linkedBlenderLibraries=sum(len(f['libraries'])for f in blend['files']),
          activeUnpackedImageReferences=len(active),activeUnpackedUniqueFiles=len({x['resolved']for x in active}))
    report['scope']['rootSymlinks']={s:(PARTNER/s).is_symlink()for s in report['scope']['roots']}
    report['optionalLegacyAuditDependency']={
      'consumer':'work/rocket-v2/qa/unverified-visual-candidates/write_candidates.py',
      'input':meta(PUBLIC/'library/preview-index.json'),
      'role':'旧45候选阶段诊断脚本读取170记录索引，不读取全部615图片；当前parts筛选状态已不同，不能称正式可直接重跑的构建步骤。'}
    (HERE/'cross-project-reference-audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(report['summary'],ensure_ascii=False))

if __name__=='__main__':main()
