"""Share only bit-identical native Blender geometry with identical material IDs.
Retains every Object, original hierarchy, source identity, transform and hidden
state. Does not rewrite GLB files being packed by the parent task.
"""
import bpy,numpy as np,json,hashlib,sys
from pathlib import Path
arg=sys.argv[sys.argv.index('--')+1:]
path=Path(arg[0]).resolve();audit_path=Path(arg[1]).resolve()
bpy.ops.wm.open_mainfile(filepath=str(path))
objects=[o for o in bpy.data.objects if o.type=='MESH' and o.get('source_usd_path')]
before=len({o.data for o in objects})
def fetch(collection,field,n,dt):
    ar=np.empty(len(collection)*n,dtype=dt);collection.foreach_get(field,ar);return ar.tobytes()
def fingerprint(me):
    if me.shape_keys:return None
    h=hashlib.sha256()
    def add(x):h.update(x if isinstance(x,bytes) else str(x).encode());h.update(b'\x00')
    add(fetch(me.vertices,'co',3,np.float32))
    add(fetch(me.edges,'vertices',2,np.int32))
    add(fetch(me.loops,'vertex_index',1,np.int32))
    for f,dt in [('loop_start',np.int32),('loop_total',np.int32),('material_index',np.int32),('use_smooth',np.uint8)]:
        add(fetch(me.polygons,f,1,dt))
    add(fetch(me.corner_normals,'vector',3,np.float32))
    formats={'FLOAT':('value',1,np.float32),'INT':('value',1,np.int32),
      'INT8':('value',1,np.int8),'BOOLEAN':('value',1,np.uint8),
      'FLOAT_VECTOR':('vector',3,np.float32),'FLOAT2':('vector',2,np.float32),
      'FLOAT_COLOR':('color',4,np.float32),'BYTE_COLOR':('color',4,np.float32)}
    for a in sorted(me.attributes,key=lambda a:a.name):
        add((a.name,a.domain,a.data_type))
        if a.data_type=='STRING':
            add([v.value for v in a.data]);continue
        if a.data_type not in formats:return None
        field,n,dt=formats[a.data_type];add(fetch(a.data,field,n,dt))
    # Materials must be the exact same existing Blender IDs, not guessed equal
    # colors or a semantic shader approximation.
    add(tuple(m.name_full if m else None for m in me.materials))
    return h.hexdigest()
material_groups={}
for ob in objects:
    if ob.modifiers or ob.vertex_groups:continue
    key=tuple(m.name_full if m else None for m in ob.data.materials)
    material_groups.setdefault(key,[]).append(ob)
cache={};shared=[];skipped=[]
for group in material_groups.values():
    if len(group)<2:continue
    byhash={}
    for ob in group:
        me=ob.data
        if me not in cache:
            try:cache[me]=fingerprint(me)
            except Exception as exc:cache[me]=None;skipped.append({'mesh':me.name,'reason':str(exc)})
        key=cache[me]
        if key is None:continue
        if key in byhash and byhash[key]!=me:
            original_name=me.name
            ob.data=byhash[key]
            shared.append({'object':ob.name,'source_usd_path':ob['source_usd_path'],
              'previous_mesh':original_name,'shared_mesh':ob.data.name,'strict_geometry_sha256':key})
        else:byhash[key]=me
after=len({o.data for o in objects})
report={'input_blend':str(path),'mesh_objects_before':len(objects),'mesh_objects_after':len(objects),
 'unique_mesh_data_before':before,'unique_mesh_data_after':after,'shared_objects':shared,
 'skipped':skipped,'material_equivalence':'Exact same existing Blender material ID slots only',
 'comparison':'Bit-identical positions, edges, loop indices, polygon layout/material indices/smooth flags, corner normals and all supported attributes',
 'objects_joined':False,'transforms_edited':False,'geometry_simplified':False,
 'object_source_metadata_unchanged':True,'glb_rewritten':False}
if shared:
    bpy.context.preferences.filepaths.save_version=0
    bpy.ops.wm.save_as_mainfile(filepath=str(path),compress=True)
    d=json.loads(audit_path.read_text());d['strict_native_mesh_sharing']=report
    audit_path.write_text(json.dumps(d,ensure_ascii=False,indent=2))
path.with_suffix('.strict-sharing.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print('STRICT_NATIVE_SHARING='+json.dumps({k:v for k,v in report.items() if k not in ['shared_objects','skipped']}),flush=True)
