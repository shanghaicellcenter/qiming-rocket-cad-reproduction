from pathlib import Path
import json,hashlib,subprocess,math,datetime
from PIL import Image,ImageChops,ImageDraw,ImageFont
home=Path('/Users/qianqiming/Documents/Codex/2026-10-19/new-chat/work/assembly-film');base=home/'movie-review-qiming';out=base/'final-fin-scope';frames=out/'frames';sheets=out/'sheets'
frames.mkdir(parents=True,exist_ok=True);sheets.mkdir(exist_ok=True)
movie=home/'silent-master-启明火箭.mp4';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();current_sha=sha(movie)
assert current_sha=='0157c12ec68187bc6e8ff6c3cfe06b32331f584f6f2910d3855da8f0bd28250d'
old=json.loads((base/'review.json').read_text());progress=json.loads((home/'capture-progress.json').read_text());chapters=progress['entries'];assert progress['status']=='complete' and len(chapters)==17
changed=[i for i,(a,b) in enumerate(zip(old['chapters'],chapters)) if a['sha256']!=b['sha256']];assert changed==[6,7,8,9],changed
for c in chapters:assert sha(Path(c['path']))==c['sha256']
probe_command=['/opt/homebrew/bin/ffprobe','-v','error','-count_frames','-show_streams','-show_format','-of','json',str(movie)]
probe_run=subprocess.run(probe_command,capture_output=True,text=True);assert probe_run.returncode==0
(out/'ffprobe.json').write_text(probe_run.stdout);probe=json.loads(probe_run.stdout);video=next(s for s in probe['streams'] if s['codec_type']=='video');assert int(video['nb_read_frames'])==6596 and video['width']==1280 and video['height']==720 and video['r_frame_rate']=='30/1'
assert not any(s['codec_type']=='audio' for s in probe['streams'])
decode_command=['/opt/homebrew/bin/ffmpeg','-hide_banner','-v','warning','-xerror','-err_detect','explode','-i',str(movie),'-map','0:v:0','-fps_mode','passthrough','-f','null','-']
decode=subprocess.run(decode_command,capture_output=True,text=True);(out/'strict-decode.log').write_text(decode.stderr);assert decode.returncode==0,decode.stderr
selection=[]
def add(label,n,kind,chapter):selection.append({'label':label,'frame':int(n),'seconds':int(n)/30,'kind':kind,'chapter':chapter})
for i in changed:
 c=chapters[i]
 for phase in (.10,.25,.50,.75,.90,.98):add(f'chapter-{i:02d}-phase-{round(phase*100):02d}',c['source_first_frame']+min(c['frames']-1,round(c['frames']*phase)),'changed-chapter',i)
for i in range(6,11):
 n=chapters[i]['source_first_frame'];add(f'cut-{i:02d}-before',n-1,'changed-boundary',i-1);add(f'cut-{i:02d}-after',n,'changed-boundary',i)
for r in old['frames']:
 if r['kind'] in ('chapter-middle','chapter-returned') and r['chapter'] not in changed:add(r['label'],r['frame'],'preserved-chapter-comparison',r['chapter'])
for phase in (.58,.62,.66,.70,.82,.94):
 c=chapters[15];add(f'chapter-15-detail-{round(phase*100):02d}',c['source_first_frame']+round(c['frames']*phase),'auxiliary-detail',15)
unique=sorted(set(r['frame'] for r in selection));vf='select='+ '+'.join(f'eq(n\\,{n})' for n in unique)
cmd=['/opt/homebrew/bin/ffmpeg','-hide_banner','-v','error','-i',str(movie),'-vf',vf,'-fps_mode','passthrough',str(frames/'extract-%03d.png')]
run=subprocess.run(cmd,capture_output=True,text=True);assert run.returncode==0,run.stderr
extracted=sorted(frames.glob('extract-*.png'));assert len(extracted)==len(unique)
mapping=dict(zip(unique,extracted));preserved=[]
for r in selection:
 im=Image.open(mapping[r['frame']]).convert('RGB');p=frames/(r['label']+'.png');im.save(p);r['image']=str(p.relative_to(base));r['sha256']=sha(p)
 if r['kind']=='preserved-chapter-comparison':
  was=Image.open(base/'frames'/(r['label']+'.png')).convert('RGB');same=ImageChops.difference(was,im).getbbox() is None;assert same,(r['label'],'Unchanged source chapter pixels changed');preserved.append({'label':r['label'],'decoded_pixels_identical_to_previous_review':same})
for p in extracted:p.unlink()
font=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',18);sheet_index=[]
def sheet(name,rows):
 canvas=Image.new('RGB',(1180,44+365*math.ceil(len(rows)/2)),'#e7edf3');d=ImageDraw.Draw(canvas);d.text((14,12),name+' | FIN SCOPE CLARIFIED MASTER',font=font,fill='#172533')
 for j,r in enumerate(rows):
  x=(j%2)*590;y=44+(j//2)*365;im=Image.open(base/r['image']).convert('RGB');im.thumbnail((570,321));d.text((x+10,y+6),f"{r['label']} | f{r['frame']} | {r['seconds']:.3f}s",font=font,fill='#172533');canvas.paste(im,(x+10,y+35))
 p=sheets/(name+'.png');canvas.save(p);sheet_index.append({'image':str(p.relative_to(base)),'sha256':sha(p),'frame_labels':[r['label'] for r in rows],'actual_visual_review':'pending'})
for kind,prefix,size in [('changed-chapter','fin-chapters',8),('changed-boundary','fin-boundaries',8),('auxiliary-detail','stage15-details',6)]:
 group=[r for r in selection if r['kind']==kind]
 for start in range(0,len(group),size):sheet(f'{prefix}-{start//size+1:02d}',group[start:start+size])
assert sha(movie)==current_sha
audit={'created_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'movie':str(movie),'movie_sha256':current_sha,'movie_bytes':movie.stat().st_size,'status':'strict decode passed; incremental visual review pending','is_current_silent_master':True,'audio_and_subtitle_final_acceptance':False,'strict_decode':{'exit_code':decode.returncode,'command':decode_command,'stderr_bytes':len(decode.stderr.encode())},'ffprobe':{'width':1280,'height':720,'fps':'30/1','decoded_frames':6596,'duration_seconds':float(probe['format']['duration']),'audio_stream_count':0},'changed_source_chapters':changed,'other_13_chapter_clip_hashes_unchanged':True,'other_13_chapter_mid_and_return_decoded_pixels_identical':preserved,'prior_visual_report':'review.json','prior_movie_sha256':old['movie_sha256'],'selected_increment_frames':selection,'increment_contact_sheets':sheet_index,'visual_review':'pending','source_master_not_modified_by_review':True}
(base/'current-review.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'current_sha256':current_sha,'strict_decode':True,'changed_chapters':changed,'other13_pixel_comparisons':len(preserved),'increment_sheets':len(sheet_index),'visual':'pending'},ensure_ascii=False))
