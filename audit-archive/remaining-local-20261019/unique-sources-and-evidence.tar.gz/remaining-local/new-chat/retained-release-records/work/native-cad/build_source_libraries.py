"""Passive, source-preserving isolated CAD/STL libraries; no geometry repair/design."""
import argparse,hashlib,json,struct,sys,time
from pathlib import Path
import bpy,numpy as np
from mathutils import Matrix,Vector,Quaternion
from pxr import Usd,UsdGeom

ROOT=Path(__file__).resolve().parent
STAMP=time.monotonic()
def log(phase,**kw):print('LIBRARY_PROGRESS='+json.dumps({'phase':phase,**kw},ensure_ascii=False),flush=True)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def ah(a):return hashlib.sha256(np.asarray(a).tobytes()).hexdigest()
def points(me):
 a=np.empty(len(me.vertices)*3,dtype=np.float32);me.vertices.foreach_get('co',a);return a.reshape(-1,3)
def mat(m):return [[float(x) for x in row] for row in m]
def bbox(a):return {'min':a.min(0).tolist(),'max':a.max(0).tolist(),'size':np.ptp(a,axis=0).tolist()}
def expand_obj(ob):
 p=points(ob.data).astype(np.float64);mw=np.asarray(ob.matrix_world,dtype=np.float64)
 return p@mw[:3,:3].T+mw[:3,3]
def prop(ob,key,value):
 if value is not None:ob[key]=value

def provenance(ob,row):
 for k in ('id','source_filename','source_archive','source_member','source_sha256','source_archive_sha256','revision_group','original_units','unit_is_physical'):
  prop(ob,'source_'+k if k=='id' else k,row.get(k))
 ob['supplement_id']=row['id']
 ob['source_cad_filename']=row['source_filename']
 prop(ob,'source_metres_per_native_unit',row.get('metres_per_native_unit'))
 ob['source_library_not_assembly']=True
 ob['source_unit_status']='declared native USD units' if row.get('unit_is_physical') else 'undeclared STL units; display coordinates only'
 ob['label_zh']='独立原件 '+row['id']
 ob['presentation_id']=row['id']+':'+str(ob.get('source_usd_path',row['source_filename']))
 ob['source_geometry_not_repaired_or_simplified']=True

class ProvenanceHook(bpy.types.USDHook):
 bl_idname='isolated_source_library_provenance'
 bl_label='Isolated original-source library'
 @staticmethod
 def on_import(context):
  for path,ids in context.get_prim_map().items():
   for idblock in ids:
    try:idblock['source_usd_path']=str(path)
    except Exception:pass
  return True

def usd_import(row,coll):
 path=Path(row['input_path']);assert sha(path)==row['input_sha256']
 stage=Usd.Stage.Open(str(path));assert stage
 mpu=float(UsdGeom.GetStageMetersPerUnit(stage));up=str(UsdGeom.GetStageUpAxis(stage))
 assert up in ('Y','Z')
 row['metres_per_native_unit']=mpu
 axis=np.eye(4)
 if up=='Y':axis=np.array([[1,0,0,0],[0,0,-1,0],[0,1,0,0],[0,0,0,1]],dtype=np.float64)
 cache=UsdGeom.XformCache(Usd.TimeCode.Default())
 records={};expected=[]
 # This converter's reference geometry definitions are inactive. TraverseAll
 # would double-count those; active Traverse retains invisible source geometry.
 for prim in Usd.PrimRange(stage.GetPseudoRoot(),Usd.TraverseInstanceProxies()):
  if prim.IsPseudoRoot():continue
  rec={'path':str(prim.GetPath()),'name':prim.GetName(),'display_name':prim.GetDisplayName(),'kind':prim.GetMetadata('kind'),'visible':str(UsdGeom.Imageable(prim).ComputeVisibility()) if prim.IsA(UsdGeom.Imageable) else 'inherited'}
  records[rec['path']]=rec
  if not prim.IsA(UsdGeom.Mesh):continue
  mesh=UsdGeom.Mesh(prim)
  p=np.asarray(mesh.GetPointsAttr().Get(),dtype=np.float32).reshape(-1,3)
  counts=np.asarray(mesh.GetFaceVertexCountsAttr().Get(),dtype=np.int64)
  indices=np.asarray(mesh.GetFaceVertexIndicesAttr().Get(),dtype=np.int64)
  rec.update({'points':len(p),'faces':len(counts),'triangles':int(np.maximum(counts-2,0).sum()),'points_sha256':ah(p),'face_indices_sha256':ah(indices),'face_counts_sha256':ah(counts)})
  w=np.asarray(cache.GetLocalToWorldTransform(prim).GetTranspose(),dtype=np.float64)
  expected.append((p@w[:3,:3].T+w[:3,3])@axis[:3,:3].T)
 if not expected:raise RuntimeError('No active source meshes')
 before=set(bpy.data.objects)
 settings={'filepath':str(path),'scale':1.0,'set_frame_range':False,'import_cameras':False,'import_lights':False,'import_curves':True,'import_volumes':False,'import_shapes':True,'import_meshes':True,'import_skeletons':False,'import_blendshapes':False,'import_points':False,'import_materials':True,'import_subdivision':False,'support_scene_instancing':True,'import_visible_only':False,'create_collection':False,'read_mesh_uvs':True,'read_mesh_colors':True,'read_mesh_attributes':True,'import_guide':True,'import_proxy':True,'import_render':True,'import_usd_preview':True,'property_import_mode':'ALL','validate_meshes':False,'create_world_material':False,'import_defined_only':False,'merge_parent_xform':False,'apply_unit_conversion_scale':False}
 assert 'FINISHED' in bpy.ops.wm.usd_import(**settings)
 objs=[o for o in bpy.data.objects if o not in before]
 bpy.context.view_layer.update()
 audits=[];all_expected=np.concatenate(expected)
 for ob in objs:
  for c in list(ob.users_collection):c.objects.unlink(ob)
  coll.objects.link(ob)
  provenance(ob,row)
  rec=records.get(ob.get('source_usd_path'),{})
  ob['source_usd_visibility']=rec.get('visible','unknown');ob['source_hidden']=rec.get('visible')=='invisible'
  ob['source_usd_document_sha256']=row['input_sha256']
  ob['source_usd_display_name']=rec.get('display_name','')
  report={'object':ob.name,'type':ob.type,'source_usd_path':ob.get('source_usd_path'),'world_matrix_native':mat(ob.matrix_world),'source_hidden':ob['source_hidden']}
  if ob.type=='MESH':
   p=points(ob.data);ob.data.calc_loop_triangles()
   if 'points_sha256' not in rec:raise RuntimeError('Imported mesh has no source USD mapping')
   report.update({'vertices':len(p),'faces':len(ob.data.polygons),'triangles':len(ob.data.loop_triangles),'points_sha256':ah(p),'usd_points_sha256':rec['points_sha256'],'points_exact':ah(p)==rec['points_sha256'],'faces_exact':len(ob.data.polygons)==rec['faces'],'triangles_exact':len(ob.data.loop_triangles)==rec['triangles'],'modifiers':[x.type for x in ob.modifiers]})
   if not all(report[k] for k in ('points_exact','faces_exact','triangles_exact')):raise RuntimeError('Source geometry import mismatch')
  audits.append(report)
 bpy.context.view_layer.update()
 meshes=[o for o in objs if o.type=='MESH']
 actual=np.concatenate([expand_obj(o) for o in meshes])
 error=max(float(np.max(np.abs(actual.min(0)-all_expected.min(0)))),float(np.max(np.abs(actual.max(0)-all_expected.max(0)))))
 tol=max(1e-5,float(np.max(np.ptp(all_expected,axis=0)))*1e-5)
 if error>tol:raise RuntimeError('Source USD world bounds changed')
 return objs,{'source':row,'usd_mesh_count':len(expected),'mesh_count':len(meshes),'face_count':sum(len(o.data.polygons) for o in meshes),'triangle_count':sum(len(o.data.loop_triangles) for o in meshes),'bbox_native_blender_zup':bbox(actual),'source_bbox_native_blender_zup':bbox(all_expected),'bbox_error_native':error,'bbox_matches':error<=tol,'objects':audits,'source_input_hash_unchanged':sha(path)==row['input_sha256'],'source_meters_per_unit':mpu,'source_up_axis':up,'hidden_source_meshes':sum(o.get('source_hidden',False) for o in meshes)}

def stl_import(row,coll):
 p=Path(row['input_path']);raw=p.read_bytes();assert hashlib.sha256(raw).hexdigest()==row['input_sha256']
 n=struct.unpack_from('<I',raw,80)[0]
 if len(raw)!=84+n*50:raise RuntimeError('Expected exact binary STL body')
 dt=np.dtype([('normal','<f4',(3,)),('vertices','<f4',(3,3)),('attribute','<u2')])
 facets=np.frombuffer(raw,dtype=dt,count=n,offset=84)
 coordinates=np.ascontiguousarray(facets['vertices'].reshape(-1,3),dtype=np.float32)
 assert np.isfinite(coordinates).all() and n>0
 me=bpy.data.meshes.new(row['id']+'_ORIGINAL_STL_TRIANGLE_SOUP')
 me.from_pydata(coordinates.tolist(),[],np.arange(n*3).reshape(n,3).tolist());me.update()
 ob=bpy.data.objects.new(row['id']+'_'+p.stem,me);coll.objects.link(ob)
 provenance(ob,row);ob['source_hidden']=False;ob['source_usd_visibility']='not applicable; STL has no visibility metadata'
 ob['source_stl_unit_declaration']='none';ob['source_stl_facets_sha256']=hashlib.sha256(raw[84:]).hexdigest()
 material=bpy.data.materials.get('STL_NEUTRAL_DISPLAY_NO_SOURCE_MATERIAL') or bpy.data.materials.new('STL_NEUTRAL_DISPLAY_NO_SOURCE_MATERIAL')
 material.diffuse_color=(.38,.51,.61,1);material.node_tree.nodes.get('Principled BSDF').inputs['Base Color'].default_value=(.38,.51,.61,1)
 me.materials.append(material)
 me.calc_loop_triangles();actual=points(me)
 if ah(actual)!=ah(coordinates) or len(me.polygons)!=n:raise RuntimeError('Raw STL numerical vertices changed')
 return [ob],{'source':row,'mesh_count':1,'face_count':n,'triangle_count':len(me.loop_triangles),'raw_stl_vertex_sha256':ah(coordinates),'blender_vertex_sha256':ah(actual),'raw_vertices_exact':True,'triangle_order_and_winding_preserved':True,'stl_weld_or_cleanup':False,'bbox_native_blender_zup':bbox(actual),'source_input_hash_unchanged':sha(p)==row['input_sha256'],'hidden_source_meshes':0,'objects':[{'object':ob.name,'type':'MESH','vertices':len(actual),'faces':n,'triangles':len(me.loop_triangles),'world_matrix_native':mat(ob.matrix_world)}]}

def glb_audit(path,groups):
 raw=path.read_bytes();n,kind=struct.unpack_from('<I4s',raw,12);assert kind==b'JSON';g=json.loads(raw[20:20+n]);bd=memoryview(raw)[20+n+8:]
 def position(ai):
  ac=g['accessors'][ai];v=g['bufferViews'][ac['bufferView']];assert ac['componentType']==5126
  return np.ndarray((ac['count'],3),dtype='<f4',buffer=bd,offset=v.get('byteOffset',0)+ac.get('byteOffset',0),strides=(v.get('byteStride',12),4))
 def matrix(node):
  if 'matrix'in node:return np.array(node['matrix']).reshape(4,4).T
  q=node.get('rotation',[0,0,0,1]);m=np.eye(4);m[:3,:3]=np.asarray(Quaternion((q[3],q[0],q[1],q[2])).to_matrix())@np.diag(node.get('scale',[1,1,1]));m[:3,3]=node.get('translation',[0,0,0]);return m
 actual={}
 def walk(i,parent,source_id=None):
  node=g['nodes'][i];mw=parent@matrix(node);ext=node.get('extras',{});source_id=ext.get('supplement_id',source_id)
  if 'mesh'in node:
   assert source_id in groups
   rec=actual.setdefault(source_id,{'mesh_count':0,'triangle_count':0,'positions':[],'source_names':set(),'hidden_meshes':0})
   rec['mesh_count']+=1;rec['source_names'].add(ext.get('source_filename'));rec['hidden_meshes']+=bool(ext.get('source_hidden'))
   for prim in g['meshes'][node['mesh']]['primitives']:
    p=position(prim['attributes']['POSITION']).astype(np.float64);rec['positions'].append(p@mw[:3,:3].T+mw[:3,3])
    rec['triangle_count']+=g['accessors'][prim['indices']]['count']//3 if 'indices'in prim else len(p)//3
  for child in node.get('children',[]):walk(child,mw,source_id)
 for root in g['scenes'][g.get('scene',0)]['nodes']:walk(root,np.eye(4))
 reports=[]
 for key,group in groups.items():
  item=group['row'];audit=group['audit'];r=actual[key];p=np.concatenate(r.pop('positions'));r['source_names']=sorted(r['source_names'])
  b=audit['bbox_native_blender_zup'];lo=np.array(b['min']);hi=np.array(b['max']);scale=item.get('metres_per_native_unit') or 1.0
  elo=np.array([lo[0],lo[2],-hi[1]])*scale;ehi=np.array([hi[0],hi[2],-lo[1]])*scale
  err=max(float(np.abs(p.min(0)-elo).max()),float(np.abs(p.max(0)-ehi).max()));tol=max(1e-7,float(np.max(ehi-elo))*2e-5)
  r.update({'id':key,'source_filename':item['source_filename'],'bbox_gltf_yup':bbox(p),'bbox_max_abs_error':err,'bbox_matches':err<=tol,'triangles_match':r['triangle_count']==audit['triangle_count'],'mesh_count_matches':r['mesh_count']==audit['mesh_count']})
  if not all(r[k] for k in ('bbox_matches','triangles_match','mesh_count_matches')):raise RuntimeError('GLB export source geometry mismatch: '+key)
  reports.append(r)
 return {'path':str(path),'sha256':sha(path),'bytes':path.stat().st_size,'item_count':len(reports),'node_count':len(g['nodes']),'mesh_count':sum(r['mesh_count'] for r in reports),'triangles':sum(r['triangle_count'] for r in reports),'all_item_bounds_meshes_triangles_match':True,'items':reports,'unit_policy':'CAD items have independent metres adaptors. STL numerical coordinates retained with unit_is_physical=false. This library has no assembly placement.'}

def main():
 argv=sys.argv[sys.argv.index('--')+1:] if '--'in sys.argv else []
 ap=argparse.ArgumentParser();ap.add_argument('--mode',choices=['supplements','parts'],default='supplements');ap.add_argument('--review',action='store_true');args=ap.parse_args(argv)
 assert bpy.app.version[:2]>=(5,2),bpy.app.version_string
 for o in list(bpy.data.objects):bpy.data.objects.remove(o,do_unlink=True)
 for c in list(bpy.data.collections):bpy.data.collections.remove(c)
 scene=bpy.context.scene;scene.name='INDEPENDENT_SOURCE_LIBRARY_NOT_AN_ASSEMBLY';scene.unit_settings.system='NONE'
 bpy.utils.register_class(ProvenanceHook)
 if args.mode=='supplements':
  out=ROOT/'supplement-library';rows=json.loads((out/'manifest.json').read_text())['items'];name='supplements'
 else:
  out=ROOT/'original-part-library';out.mkdir(exist_ok=True);name='original-part-library'
  data=json.loads((ROOT/'native-source-readiness.json').read_text())['records'];rows=[]
  for x in data:
   if x['revision_group']!='main-R01' or x['format']!='SLDPRT':continue
   rows.append({'id':f'P{len(rows)+1:03d}','format':'USD_FROM_NATIVE','source_filename':Path(x['relative_path']).name,'source_archive':x['archive'],'source_member':x['relative_path'],'source_sha256':x['source_sha256'],'source_archive_sha256':x['source_archive_sha256'],'input_path':str(ROOT/x['usd_relative']),'input_sha256':x['usd_sha256'],'original_units':'USD declared units and native world transforms retained','metres_per_native_unit':.0254,'unit_is_physical':True,'revision_group':'main-R01'})
  assert len(rows)==119
  raw_collection=bpy.data.collections.new('RAW_SOURCE_STL_VARIANTS');scene.collection.children.link(raw_collection)
  for x in json.loads((ROOT/'all-stl-source-audit.json').read_text())['records']:
   rows.append({'id':f'RAW{len(rows)-118:02d}','format':'BINARY_STL','source_filename':Path(x['zip_member']).name,'source_archive':x['archive'],'source_member':x['zip_member'],'source_sha256':x['sha256'],'input_path':x['local_stl'],'input_sha256':x['sha256'],'original_units':'STL unit declaration absent; original numeric triangle vertices retained','metres_per_native_unit':None,'unit_is_physical':False,'revision_group':'raw-exchange-variant'})
 groups={};audits=[]
 for row in rows:
  coll=bpy.data.collections.new(row['id']+' | '+row['source_filename']);provenance(coll,row)
  if args.mode=='parts' and row['format']=='BINARY_STL':raw_collection.children.link(coll)
  else:scene.collection.children.link(coll)
  objs,audit=usd_import(row,coll) if row['format']=='USD_FROM_NATIVE' else stl_import(row,coll)
  groups[row['id']]={'row':row,'objects':objs,'collection':coll,'audit':audit};audits.append(audit)
  # Separate scenes offer immediate isolated access without moving source roots.
  isolated=bpy.data.scenes.new(row['id']+' | '+row['source_filename']);isolated.collection.children.link(coll)
  isolated.unit_settings.system='METRIC' if row['unit_is_physical'] else 'NONE';isolated.unit_settings.scale_length=row.get('metres_per_native_unit') or 1.0
  isolated['source_filename']=row['source_filename'];isolated['source_library_not_assembly']=True
  log('Source imported and audited',id=row['id'],name=row['source_filename'],meshes=audit['mesh_count'],triangles=audit['triangle_count'])
 report={'mode':args.mode,'blender_version':bpy.app.version_string,'source_count':len(rows),'native_part_count':sum(r['format']=='USD_FROM_NATIVE' for r in rows),'raw_stl_variant_count':sum(r['format']=='BINARY_STL' for r in rows),'all_source_hashes_unchanged':all(a['source_input_hash_unchanged'] for a in audits),'mesh_count':sum(a['mesh_count'] for a in audits),'faces':sum(a['face_count'] for a in audits),'triangles':sum(a['triangle_count'] for a in audits),'items':audits,'scope':'Source-only isolated library. Every source retains own local geometry and world transforms; no assembly arrangement or inferred geometry.'}
 notes=bpy.data.texts.new('README_SOURCE_LIBRARIES')
 notes.write('Choose a scene by source ID/name for an isolated original item. Master is a directory, not an assembly. Native CAD coordinates, transforms, and declared units retained. RAW_SOURCE_STL_VARIANTS are unitless exact source numerical triangle vertices; not physical-scale comparison. No geometry repaired, simplified or inferred. Source provenance in custom properties and audit JSON.\n')
 blend=out/(name+'.blend');bpy.ops.wm.save_as_mainfile(filepath=str(blend),compress=True)
 report['blend']={'path':str(blend),'sha256':sha(blend),'bytes':blend.stat().st_size}
 (out/(name+'.audit.json')).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 log('Native blend checkpoint',path=str(blend),bytes=blend.stat().st_size)
 if args.mode=='supplements':
  # GLB-only unit parents. Native .blend was saved before this adaptation.
  states={o:(o.hide_viewport,o.hide_render,o.hide_get()) for o in scene.objects}
  roots=[]
  for key,group in groups.items():
   root=bpy.data.objects.new(key+'_INDEPENDENT_SOURCE_UNIT_ADAPTOR',None);scene.collection.objects.link(root);provenance(root,group['row'])
   scale=group['row'].get('metres_per_native_unit') or 1.0;root.scale=(scale,scale,scale);root['source_adaptor_only']=True
   root['display_metres_per_coordinate']=scale;root['display_scale_is_physical']=group['row']['unit_is_physical']
   for ob in group['objects']:
    if ob.parent is None:roots.append((ob,ob.matrix_basis.copy()));ob.parent=root
  for c in bpy.data.collections:c.hide_viewport=False;c.hide_render=False
  for ob in scene.objects:ob.hide_viewport=False;ob.hide_render=False;ob.hide_set(False)
  bpy.context.view_layer.update()
  glb=out/(name+'.glb')
  options={'filepath':str(glb),'export_format':'GLB','use_selection':False,'use_visible':False,'use_renderable':False,'use_active_scene':True,'export_extras':True,'export_yup':True,'export_apply':False,'export_animations':False,'export_gpu_instances':False,'export_hierarchy_flatten_objs':False,'export_hierarchy_full_collections':False,'export_draco_mesh_compression_enable':False,'export_meshopt_compression_enable':False}
  valid={p.identifier for p in bpy.ops.export_scene.gltf.get_rna_type().properties};options={k:v for k,v in options.items() if k in valid}
  assert 'FINISHED'in bpy.ops.export_scene.gltf(**options)
  report['glb']=glb_audit(glb,groups)
  for ob,basis in roots:ob.parent=None;ob.matrix_basis=basis
  for o in list(scene.objects):
   if o.get('source_adaptor_only'):bpy.data.objects.remove(o,do_unlink=True)
  for ob,(hv,hr,hs) in states.items():ob.hide_viewport=hv;ob.hide_render=hr;ob.hide_set(hs)
  bpy.context.view_layer.update()
  (out/(name+'.audit.json')).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
  log('GLB checkpoint verified',path=str(glb),items=report['glb']['item_count'],triangles=report['glb']['triangles'])
 if args.review:
  sys.path.append('/Users/qianqiming/.codex/skills/scenario-blender-expert/scripts');import bx_review
  sheets=[]
  for key,group in groups.items():
   if args.mode=='parts' and key not in ('P001','P060','P119','RAW01'):continue
   meshes=[o for o in group['objects'] if o.type=='MESH']
   # Review linked copies with source world matrices; hidden data also reviewed.
   copies=[]
   for ob in meshes:
    copy=ob.copy();copy.data=ob.data;copy.parent=None;copy.matrix_world=ob.matrix_world.copy();copy.hide_viewport=False;copy.hide_render=False;copies.append(copy)
   sheet=bx_review.review(copies,str(out/'review'/key),views=('front','threequarter','low'),modes=('silhouette','matcap'),res=320)
   sheets.append({'id':key,'source_filename':group['row']['source_filename'],'sheet':sheet})
   for ob in copies:bpy.data.objects.remove(ob,do_unlink=True)
  report['review_sheets']=sheets
 report['elapsed_seconds']=time.monotonic()-STAMP
 (out/(name+'.audit.json')).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 log('Complete',mode=args.mode,source_count=len(rows),audit=str(out/(name+'.audit.json')),elapsed_seconds=report['elapsed_seconds'])

if __name__=='__main__':main()
