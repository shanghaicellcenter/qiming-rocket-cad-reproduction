"""Local acceptance harness; production scripts/inputs come from actual GitHub recovery."""
from pathlib import Path
import datetime as dt
import hashlib
import json
import os
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
PROJECT = ROOT/'project'
OUT = ROOT/'reports/blender'
PROFILE = ROOT/'deny-original-inputs.sb'
BLENDER = Path('/Applications/Blender 5.2.app/Contents/MacOS/Blender')
COMMIT = '82c2a2a255b66556cead58ec3444f81f1757ae68'
PREFIX = ['/usr/bin/sandbox-exec','-f',str(PROFILE)]
ENV = dict(os.environ)
ENV.pop('PYTHONPATH', None)
ENV.pop('PYTHONHOME', None)
ENV.update(PYTHONNOUSERSITE='1', PYTHONDONTWRITEBYTECODE='1',
           BLENDER_USER_CONFIG=str(OUT/'user-config'))


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(8*1024*1024), b''):
            h.update(block)
    return h.hexdigest()


def save(path, data):
    path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')


def run(name, args):
    start = time.monotonic()
    print('BLENDER_ACCEPTANCE_START '+name,flush=True)
    with (OUT/(name+'.log')).open('w') as log:
        subprocess.run(PREFIX+list(map(str,args)),cwd=PROJECT,env=ENV,
                       stdout=log,stderr=subprocess.STDOUT,check=True)
    elapsed = time.monotonic()-start
    print('BLENDER_ACCEPTANCE_COMPLETE '+name+' '+str(round(elapsed,3))+' seconds',flush=True)
    return {'phase':name,'seconds':elapsed,'log':str(OUT/(name+'.log'))}


def snapshot_inputs():
    # This function is invoked by an already sandboxed Python subprocess.
    tracked = subprocess.check_output(['git','ls-files','-z'],cwd=PROJECT,env=ENV).decode().split('\0')
    paths = {PROJECT/p for p in tracked if p}
    paths.update(PROJECT/p for p in [
        'outputs/启明火箭/assembly/vehicle-browse.blend',
        'outputs/启明火箭/assembly/vehicle-browse.audit.json',
        'outputs/启明火箭/native-cad/vehicle-browse.usdc',
        'outputs/virtual-assembly/virtual-assembly.blend',
        'outputs/virtual-assembly/assembly-stages.json',
        'outputs/virtual-assembly/alignment-qc.json',
    ])
    rows = []
    for p in sorted(paths):
        assert p.exists(),p
        rows.append({'path':str(p.relative_to(PROJECT)),
                     'bytes':p.stat().st_size,'sha256':sha(p),
                     'symlink':str(p.readlink()) if p.is_symlink() else None})
    return rows


def main():
    receipt_path = ROOT/'reports/actual-download-receipt.json'
    if not receipt_path.exists():
        print('WAITING_FOR_REAL_DOWNLOAD_RECEIPT',flush=True)
        return 3
    receipt = json.loads(receipt_path.read_text())
    if not all(receipt.get(k) is True for k in ('download_passed','verify_passed','restore_passed')):
        print('WAITING_FOR_REAL_DOWNLOAD_VERIFY_AND_RESTORE',flush=True)
        return 3
    assert subprocess.check_output(PREFIX+['git','rev-parse','HEAD'],cwd=PROJECT,env=ENV,text=True).strip()==COMMIT
    summary = {'status':'running','startedAtUTC':dt.datetime.now(dt.timezone.utc).isoformat(),
               'actualDownloadReceipt':str(receipt_path),'actualDownloadReceiptSha256':sha(receipt_path),
               'repoCommit':COMMIT,'original_input_denial_used':True,
               'sandboxProfile':str(PROFILE),'sandboxProfileSha256':sha(PROFILE),
               'QAHelperNotProductionInput':True,'productionScriptsFromActualGitHubProject':True,
               'productionOriginalSourceInputsPreserved':False,'phases':[]}
    save(OUT/'blender-acceptance.json',summary)
    probe = r'''
import json,os,pathlib
paths=['/Users/qianqiming/Documents/Codex/2026-10-19/new-chat','/Users/qianqiming/Documents/Codex/2026-10-19/ni','/Users/qianqiming/Desktop/火箭设计 中文版','/Users/qianqiming/Desktop/skill-repos/scenario-labs--blender-expert-skills']
rows=[]
for p in paths:
 try:os.listdir(p);rows.append({'path':p,'denied':False})
 except PermissionError as e:rows.append({'path':p,'denied':True,'error':str(e)})
assert all(x['denied'] for x in rows),rows
print(json.dumps(rows,ensure_ascii=False))
'''
    summary['phases'].append(run('00-denial-probe',[sys.executable,'-c',probe]))
    summary['denialProbe']=json.loads((OUT/'00-denial-probe.log').read_text())
    # Snapshot hashes themselves are also computed inside the same read isolation.
    before_script = "import runpy,json; d=runpy.run_path("+repr(str(Path(__file__)))+"); print(json.dumps(d['snapshot_inputs'](),ensure_ascii=False))"
    summary['phases'].append(run('01-input-sha-before',[sys.executable,'-c',before_script]))
    before = json.loads((OUT/'01-input-sha-before.log').read_text())
    save(OUT/'input-sha-before.json',before)
    summary['phases'].append(run('02-prepare',[sys.executable,PROJECT/'prepare_blender_rebuild.py','--root',PROJECT,'--blender',BLENDER]))
    summary['phases'].append(run('03-plan',[sys.executable,PROJECT/'rebuild/virtual-assembly/plan_assembly_stages.py']))
    blender_args = [BLENDER,'--background','--factory-startup','--disable-autoexec','--python-exit-code','1','--python']
    summary['phases'].append(run('04-build',blender_args+[PROJECT/'rebuild/virtual-assembly/build_virtual_assembly.py']))
    save(OUT/'blender-acceptance.json',summary)
    rebuilt = PROJECT/'rebuilt/virtual-assembly/virtual-assembly.blend'
    assert rebuilt.is_file()
    rebuilt_sha = sha(rebuilt)
    summary['phases'].append(run('05-saved-file-verify',blender_args+[PROJECT/'rebuild/virtual-assembly/verify_virtual_assembly.py']))
    summary['phases'].append(run('06-independent-source-compare',blender_args+[OUT/'independent_source_compare.py','--','--root',PROJECT,'--report',OUT/'independent-source-compare.json']))
    assert sha(rebuilt)==rebuilt_sha
    summary['phases'].append(run('07-input-sha-after',[sys.executable,'-c',before_script]))
    after = json.loads((OUT/'07-input-sha-after.log').read_text())
    assert before==after,'Downloaded original production inputs changed'
    save(OUT/'input-sha-after.json',after)
    independent=json.loads((OUT/'independent-source-compare.json').read_text())
    motion=json.loads((PROJECT/'rebuild/virtual-assembly/saved-file-motion-qc.json').read_text())
    alignment=json.loads((PROJECT/'rebuild/virtual-assembly/alignment-qc.json').read_text())
    assert independent['status']=='passed'
    assert all(v==0 for v in independent['final_max_abs_errors'].values())
    assert len(independent['stage_end_checks'])==15
    assert motion['final_local_world_matrix_error']==0
    assert alignment['final_alignment']['all_local_matrices_numerically_exact']
    assert alignment['final_alignment']['all_world_matrices_numerically_exact']
    renders=[Path(x['path'])for x in motion['rendered_samples']]
    assert len(renders)==7 and all(x.is_file() for x in renders)
    summary.update(status='numeric-and-render-production-passed-awaiting-visual-review',
        completedAtUTC=dt.datetime.now(dt.timezone.utc).isoformat(),
        productionOriginalSourceInputsPreserved=True,
        originalInputFilesRehashed=len(before),sourceobjects=1980,mesh=688,tri=2864600,
        groups=15,final_local_world_error=0,all15_group_terminal_errors_zero=True,
        savedBlend={'path':str(rebuilt),'bytes':rebuilt.stat().st_size,'sha256':rebuilt_sha},
        independentQA={'path':str(OUT/'independent-source-compare.json'),'sha256':sha(OUT/'independent-source-compare.json')},
        motionQA={'path':str(PROJECT/'rebuild/virtual-assembly/saved-file-motion-qc.json'),'sha256':sha(PROJECT/'rebuild/virtual-assembly/saved-file-motion-qc.json')},
        actualNewRenders=[{'path':str(x),'bytes':x.stat().st_size,'sha256':sha(x)}for x in renders],
        actualVisualReviewCompleted=False)
    save(OUT/'blender-acceptance.json',summary)
    print('BLENDER_ACCEPTANCE_NUMERIC_AND_NEW_RENDERS_PASSED; VISUAL_REVIEW_STILL_REQUIRED',flush=True)
    return 0


if __name__=='__main__':
    try:
        result=main()
    except Exception as error:
        report=OUT/'blender-acceptance.json'
        if report.exists():
            summary=json.loads(report.read_text())
            summary.update(status='failed',errorType=type(error).__name__,error=str(error))
            save(report,summary)
        raise
    sys.exit(result)
