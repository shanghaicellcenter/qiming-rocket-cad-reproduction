from pathlib import Path
R=Path('/Users/qianqiming/Documents/Codex/2026-10-19/new-chat/outputs/mojave-machine')
(R/'阅读我.md').write_text('''# Mojave Sphinx · 中文原件检视与虚拟归位

从 [打开项目.html](打开项目.html) 开始。所有模型来自桌面「火箭设计 中文版」实际源文件，使用 AirsupHQ Machine Skill 与本地 Blender 制作。原目录392个内容文件的字节数与SHA256最后复查全部未变。

## 看整箭、查原件

[整箭原件检视.html](整箭原件检视.html) 可离线打开。拖动旋转，滚轮缩放；单击选择，双击隔离放大，Esc返回整箭。目录支持中文、原名与源路径搜索。可切浏览级/精细级，临时剖切、外壳透视、分开或显示源隐藏件。

[逐件高清图册](library/逐件原件预览.html) 包含**170条源文件记录、510张实际渲染图**：119个原生零件、36个原STL、14个装配、1个单独修订件，每条3视图。零件/STL图为768×768，装配/修订件图为1280×960。可搜索、切换视角、放大和打开原尺寸。全部PNG经实际浏览器解码，全部视图已按完整图框总览实际审看。

170不是物理零件总数。不同格式变体分别记录；原BOM172行还含原料、耗材、包装与地面设备，不能把文件数、源实例数与BOM行数等同。

## 虚拟归位与质量核对

[可编辑虚拟归位动画](../virtual-assembly/virtual-assembly.blend) 分15组，互斥并完整覆盖688个源网格实例。保留独立原样场景与展示动画场景；共享源网格，只给展示控制器添加动画。原3个隐藏网格默认保持隐藏。

保存重开后，最终1980个源对象局部/世界矩阵与原参考逐项数值差0；15组各自归位终点也通过。运动中17个抽查帧的源transform通道无动画，存在浮点求值差的地方已原样记录。展示偏移路径不等于实体装配可达性、无碰撞路径或已解配合约束。详见[对齐QC](../virtual-assembly/alignment-qc.json)、[保存后运动QC](../virtual-assembly/saved-file-motion-qc.json)。

逐段讲解影片与配音仍在最终生成/核对，完成前不将其算入已验收影片。

## 可编辑文件

- [精细级整箭 Blender](assembly/vehicle-original.blend)：688源网格，7,070,568面。
- [浏览级整箭 Blender](assembly/vehicle-browse.blend)：同688源网格，2,864,600面。
- [原件库 Blender](library/source-part-library/original-part-library.blend)：119原生零件+36原STL，155源记录、187网格、2,927,202面；每条有独立场景与源身份。
- [独立补库](library/supplements/)：10条原件，含未在主箭名称匹配的源件、独立修订件和两个STL-only件，逐件独立取景，不补造装配位置。
- [原生转换库](native-cad/)：134个非空原生CAD转换、两级整箭USD、36个原字节STL、来源与覆盖记录。
- [主页面源码](source/assembly-viewer/REBUILD.md)：实际模型输入、固定版本依赖与离线重建说明。

主页面导航有655个组件/组节点。688源网格经多材质拆分成为706个浏览器渲染网格；两者不是零件总数。原CAD曲面已三角化，不能称为数学无损。compact GLB只共享相同字节存储，节点/几何/材质绑定均保留；两级是上游不同三角化，各自对其源USD核对。

## 仿真与真实试验的证据

[OpenRocket实跑报告](research/simulation/simulation-review-report.md)：在Spark隔离运行官方24.12，实际重算原包中的ORK+精确匹配ENG一次，未改输入或调参。产生1分支/872点，无abort，软件到达ground事件；仍有1条高速回收事件警告。该简化飞行模型有28个参数节点，并未对完整CAD做结构、接触或动力系统验证。

[作者实测与飞行证据审查](research/flight-evidence/证据审查.md)：官方指南、仓库与官网可核对不同实物/构型的地面试车、飞行、失败和修订史。它证明该设计家族有真实实物历史，不能把不同版本累计次数当作最终R01同配置全部成功。HCR-5105涉及已知接口泄漏修订，单列保留；本次检索未建立修订后固定配置的完整原始复验数据链。

## 明确保留的源边界

原作5种Mass Volume形体在整箭中有6实例，表示质量/体积和收纳关系，未建织物、绳结或展开动力学。源中未表达的布线、材料认证、内部结构和配置不会凭想象补出。源树含命名为钻孔辅助塞的工具件，按源保留并不宣称它应随实物飞行。

35个STEP、13个SLDDRW与3个DXF逐项登记；这轮未独立重读这些格式，不把同名当作几何等价已证。完整221条CAD格式记录与现状见[coverage.json](research/coverage.json) / [coverage.csv](research/coverage.csv)。

原始工程与派生几何署名Half Cat Rocketry，见[许可](LICENSE-Half-Cat.txt)。Machine/Three.js署名与许可保留在源码目录。早期[十件STL页面](mojave-machine.html)及其24秒影片保留为历史版本，不代表当前覆盖。
''')
(R/'复现验收.md').write_text('''# 复现验收

本轮已完成源CAD实际转换、完整主装配中文检视、170源记录高清图册、15组虚拟归位与原仿真模型实跑。逐段配音影片仍在导出和音频核对，完成后追加实测身份；不将队列/安装或单张截图当作成片完成。

| 检查对象 | 实际结果 | 证据 |
|---|---|---|
| 用户原件 | 392内容文件字节与SHA256均未变 | research/source-unchanged-final-check.json |
| 原生CAD | 133主包+1独立修订，共134个非空USD；输入/输出哈希核对 | native-cad/native-source-readiness.json |
| 原STL | 36文件，144,516原三角面；原字节保留 | native-cad/all-stl-source-audit.json |
| 主整箭 | 688源网格，LOD3 7,070,568面 / LOD1 2,864,600面 | assembly/vehicle-*.audit.json |
| 源节点与显隐 | 655组件/组导航；706渲染网格；3源隐藏默认隐藏 | research/browser-review/ |
| 可编辑静态Blender | 保存重开，688网格点/索引逐项与各自USD一致，1980节点求值后矩阵差0 | assembly/post-visibility-source-geometry-qc.json |
| 独立原件库 | 155记录、187网格、2,927,202面；保存重开核对通过 | library/source-part-library/ |
| 高清预览 | 170记录×3=510图，465张768×768 +45张1280×960 | library/preview-index.json |
| 图片视觉/链接 | 全图框总览实际目视，无发现空白/截断；510张浏览器解码、筛选/搜索/切图/弹窗/原图均通过 | library/gallery-check.json、part-previews/visual-review.json、assembly-previews/index.json |
| 离线检视页 | root17项检查通过；搬迁后file协议实测、零外网/JS异常 | research/browser-review/ |
| 四轮视觉与回归 | 实际看整箭/剖视/分开/电子舱/尾翼/隐藏片等；发现并修复复位取景裁切和隐藏薄片低对比，修正后重看 | research/browser-review/视觉与离线核对.md |
| 虚拟归位 | 15组互斥全覆盖688源网格；终态1980源对象local/world数值差0 | ../virtual-assembly/alignment-qc.json |
| 动画保存重开 | 17运动帧核对、最终再次归零；原transform通道未加动画 | ../virtual-assembly/saved-file-motion-qc.json |
| 原仿真实跑 | official OpenRocket24.12，原ORK/ENG指纹匹配；实际simulate一次、872点、无abort；保留1条警告 | research/simulation/ |
| 作者实物史 | 官方书/仓库/官网53条证据登记，成功、失败与版本均分开 | research/flight-evidence/ |

图片视觉检查是在完整图片总览及关键原尺寸抽查中完成，不声称510张全部逐像素或所有背面表面人工检查。灰色检视材质、选中高亮、临时透视均用于读图，不是源材质认证。

CAD曲面已三角化；两级非Mesh层级和变换相同，24个Mesh叶节点在上游三角化中的局部矩阵有差异，各自源USD已核对，不宣称两级叶矩阵字节全同。

这些检查证明数字来源、覆盖、几何保留、观察可用和既有软件模型确实执行。它们不替代原生配合、实体公差、碰撞可达性、密封、材料、结构、热/流体、控制系统或新造实箭的可靠性验证。原BOM172行与CAD文件数并非同一种计数；35 STEP、13 SLDDRW、3 DXF未在本轮独立重读，逐项状态已登记。

HCR-5105为单独来源修订件，未默混主R01。作者不同序列号/构型有真实试验及失败史，不能以累计次数宣称最终R01全部成功或新造实物已认证。具体能证明和不能证明的范围已在各报告紧邻证据说明。
''')
print('updated delivery reading and acceptance docs')
