import bpy,json
from pathlib import Path
p=Path('work/github-publication/derived/public-tree/outputs/启明火箭/source/component-illustrations/manual/A3-01.blend').resolve()
bpy.ops.wm.open_mainfile(filepath=str(p),load_ui=False,use_scripts=False)
for i in bpy.data.images:
 if i.source=='FILE':
  print('PROBE_BEFORE',i.name,i.filepath,bpy.path.abspath(i.filepath),i.has_data,list(i.size),len(i.pixels))
  i.reload()
  print('PROBE_AFTER',i.name,i.has_data,list(i.size),len(i.pixels),list(i.pixels[:4]))
