"""Presentation-only review of already exported original source geometry.
Does not modify source mesh data, scene transforms, native blend files, or GLBs.
"""
import bpy,json,math,sys
from pathlib import Path
from mathutils import Vector,Quaternion
arg=sys.argv[sys.argv.index('--')+1:]
blend=Path(arg[0]).resolve();audit=Path(arg[1]).resolve();out=Path(arg[2]).resolve();out.mkdir(parents=True,exist_ok=True)
kind=arg[3] if len(arg)>3 else 'vehicle'
d=json.loads(audit.read_text())
bpy.ops.wm.open_mainfile(filepath=str(blend))
sc=bpy.context.scene
lo=Vector(d['blender_world_bbox_native']['min']);hi=Vector(d['blender_world_bbox_native']['max'])
center=(lo+hi)*.5;size=max(hi-lo)
studio=bpy.data.collections.new('REVIEW_STUDIO_NOT_ORIGINAL_COMPONENTS');sc.collection.children.link(studio)
def mat(name,col,metal,rough):
    ma=bpy.data.materials.new(name);ma.diffuse_color=(*col,1);ma.use_nodes=True
    bs=ma.node_tree.nodes.get('Principled BSDF');bs.inputs['Base Color'].default_value=(*col,1)
    bs.inputs['Metallic'].default_value=metal;bs.inputs['Roughness'].default_value=rough
    return ma
floor_mat=mat('REVIEW_GROUND',(.078,.10,.125),.05,.6)
world=bpy.data.worlds.new('REVIEW_WORLD');world.use_nodes=True
world.node_tree.nodes['Background'].inputs['Color'].default_value=(.10,.14,.18,1)
world.node_tree.nodes['Background'].inputs['Strength'].default_value=.25;sc.world=world
def area(name,rel,power,scale):
    da=bpy.data.lights.new(name,'AREA');da.energy=power*size*size;da.shape='RECTANGLE'
    da.size=scale[0]*size;da.size_y=scale[1]*size
    ob=bpy.data.objects.new(name,da);studio.objects.link(ob);ob.location=center+Vector(rel)*size
    ob.rotation_euler=(center-ob.location).to_track_quat('-Z','Y').to_euler();ob['presentation_only']=True
area('REVIEW_KEY',(-.8,-1.4,2),110,(2.5,1.8))
area('REVIEW_RIM',(1.1,1.2,1.6),130,(2,1.2))
area('REVIEW_FILL',(.8,-1.8,.3),30,(2,2))
bpy.ops.mesh.primitive_plane_add(size=size*20,location=(0,0,lo.z-size*.01))
floor=bpy.context.object;floor.name='REVIEW_FLOOR_NOT_SOURCE'
for c in list(floor.users_collection):c.objects.unlink(floor)
studio.objects.link(floor);floor.data.materials.append(floor_mat);floor['presentation_only']=True
cd=bpy.data.cameras.new('REVIEW_CAMERA');cam=bpy.data.objects.new('REVIEW_CAMERA',cd);studio.objects.link(cam)
cd.type='ORTHO';cd.clip_end=max(size*100,1000);sc.camera=cam
sc.render.engine='CYCLES';sc.cycles.samples=24;sc.cycles.use_denoising=True
sc.cycles.max_bounces=4;sc.cycles.diffuse_bounces=2;sc.cycles.glossy_bounces=3
sc.render.resolution_x=1800;sc.render.resolution_y=1200;sc.render.resolution_percentage=100
sc.render.image_settings.file_format='PNG';sc.render.image_settings.color_mode='RGBA'
sc.render.film_transparent=False;sc.view_settings.view_transform='AgX';sc.view_settings.exposure=-.5
try:sc.view_settings.look='AgX - Medium High Contrast'
except TypeError:pass
def camera(target,direction,scale,roll=0):
    direction=Vector(direction).normalized();cam.location=target+direction*size*3
    q=(target-cam.location).to_track_quat('-Z','Y')
    cam.rotation_euler=(q@Quaternion(Vector((0,0,1)),math.radians(roll))).to_euler()
    cd.ortho_scale=scale
def fit_bbox(target,direction,roll=0):
    camera(target,direction,size*1.5,roll)
    right=cam.rotation_euler.to_matrix()@Vector((1,0,0))
    up=cam.rotation_euler.to_matrix()@Vector((0,1,0))
    pts=[Vector((x,y,z))-target for x in (lo.x,hi.x) for y in (lo.y,hi.y) for z in (lo.z,hi.z)]
    w=max(abs(p.dot(right)) for p in pts)*2
    h=max(abs(p.dot(up)) for p in pts)*2
    cd.ortho_scale=max(w,h*sc.render.resolution_x/sc.render.resolution_y)*1.10
def render(name):
    sc.render.filepath=str(out/name);bpy.ops.render.render(write_still=True)
    print('REVIEW_RENDER='+sc.render.filepath,flush=True)
if kind=='fin':
    fit_bbox(center,(1.4,-3,1.1),10);render('01_actual_native_fin.png')
else:
    fit_bbox(center,(1.5,-2.6,1.1),52);render('01_original_vehicle_assembly.png')
    tail=center.copy();tail.z=lo.z+(hi.z-lo.z)*.15
    camera(tail,(1.1,-2.6,.9),size*.43,22);render('02_source_tail_exterior.png')
    nose=center.copy();nose.z=lo.z+(hi.z-lo.z)*.89
    camera(nose,(1.4,-2.6,.8),size*.34,22);render('03_source_nose_exterior.png')
summary={'input_blend':str(blend),'source_mesh_occurrences':d['blender_mesh_occurrences_expanded'],
 'source_mesh_transforms_edited':False,'source_geometry_edited':False,'source_visibility_respected':True,
 'studio_geometry_exported':False,'engine':'Cycles CPU','samples':24,'outputs':[str(p) for p in out.glob('*.png')]}
(out/'render-review.json').write_text(json.dumps(summary,indent=2))
print('REVIEW_COMPLETE='+json.dumps(summary),flush=True)
