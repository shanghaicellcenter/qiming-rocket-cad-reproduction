"""Check original USD polygon connectivity against imported native Blender.
Read only geometry; update only the JSON audit report.
"""
import bpy,numpy as np,json,sys
from pathlib import Path
from pxr import Usd,UsdGeom
arg=sys.argv[sys.argv.index('--')+1:]
blend,usd,audit=[Path(x).resolve() for x in arg]
bpy.ops.wm.open_mainfile(filepath=str(blend))
stage=Usd.Stage.Open(str(usd));rows=[]
for ob in bpy.data.objects:
    if ob.type!='MESH' or not ob.get('source_usd_path'):continue
    prim=stage.GetPrimAtPath(ob['source_usd_path'])
    if not prim or not prim.IsA(UsdGeom.Mesh):continue
    mesh=UsdGeom.Mesh(prim)
    src_counts=np.asarray(mesh.GetFaceVertexCountsAttr().Get(),dtype=np.int64)
    src_indices=np.asarray(mesh.GetFaceVertexIndicesAttr().Get(),dtype=np.int64)
    counts=np.empty(len(ob.data.polygons),dtype=np.int64)
    indices=np.empty(len(ob.data.loops),dtype=np.int64)
    ob.data.polygons.foreach_get('loop_total',counts);ob.data.loops.foreach_get('vertex_index',indices)
    exact=bool(np.array_equal(counts,src_counts) and np.array_equal(indices,src_indices))
    same_sets=exact
    if not exact and len(indices)==len(src_indices) and bool(np.all(counts==3)) and bool(np.all(src_counts==3)):
        same_sets=bool(np.array_equal(np.sort(indices.reshape(-1,3),axis=1),np.sort(src_indices.reshape(-1,3),axis=1)))
    rows.append({'source_usd_path':ob['source_usd_path'],'polygon_counts_equal':bool(np.array_equal(counts,src_counts)),
      'face_vertex_indices_exact_match':exact,'triangle_vertex_sets_equal':same_sets})
result={'mesh_objects_checked':len(rows),'all_face_vertex_indices_exact_match':all(r['face_vertex_indices_exact_match'] for r in rows),
  'all_triangle_vertex_sets_equal':all(r['triangle_vertex_sets_equal'] for r in rows),'meshes':rows}
data=json.loads(audit.read_text());data['usd_blender_topology_check']=result
audit.write_text(json.dumps(data,ensure_ascii=False,indent=2))
print('SOURCE_TOPOLOGY='+json.dumps({k:v for k,v in result.items() if k!='meshes'}),flush=True)
if not result['all_triangle_vertex_sets_equal']:raise RuntimeError('Source triangle connectivity differs')
