"""Collect only this task's completed original-speed audio and ASR evidence."""
from pathlib import Path
import subprocess,json,hashlib,re,wave

folder=Path(__file__).resolve().parent;audio_dir=folder/'audio';audio_dir.mkdir(exist_ok=True)
request=json.loads((folder/'formal-jobs.json').read_text());manifest_path=folder/'narration-audio-manifest.json'
manifest=json.loads(manifest_path.read_text())
remote_script='''from pathlib import Path
import json
p=Path('/home/qianqiming/codex-mojave-assembly-voice-20261019')
rows=[]
for r in sorted((p/'formal').glob('*/attempt-*/result.json')):
 d=json.loads(r.read_text());a=r.parent/'asr.json'
 rows.append({'result':d,'asr':json.loads(a.read_text()) if a.exists() else None})
s=p/'formal-status.json';g=p/'formal-guard-result.json'
print(json.dumps({'rows':rows,'status':json.loads(s.read_text()) if s.exists() else None,'guard':json.loads(g.read_text()) if g.exists() else None},ensure_ascii=False))
'''
r=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=8','spark','python3','-'],input=remote_script,text=True,capture_output=True,check=True);data=json.loads(r.stdout)
(folder/'formal-remote-status.json').write_text(json.dumps(data,ensure_ascii=False,indent=2))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
tracks=[];all_attempts=[]
for job in request:
    candidates=[v for v in data['rows'] if v['result']['id']==job['id']]
    if not candidates:
        tracks.append({'id':job['id'],'text':job['text'],'status':'pending_generation','audio_local_path':None,'wav_path':None,'duration_seconds':None,'audio_sha256':None,'subtitle_sentences':None});continue
    for c in candidates:
        result=c['result'];assert result['text']==job['text'];a=c['asr'];attempt=result['attempt']
        if result.get('audio'):
            assert result['audio'].startswith('/home/qianqiming/codex-mojave-assembly-voice-20261019/formal/')
            target=audio_dir/f"{job['id']}-attempt-{attempt:02d}.wav"
            if not target.exists() or sha(target)!=result['audio_sha256']:
                subprocess.run(['scp','-q','spark:'+result['audio'],str(target)],check=True)
            assert sha(target)==result['audio_sha256'];c['local_audio']=str(target.resolve())
            with wave.open(str(target)) as w:
                duration=w.getnframes()/w.getframerate();assert w.getnchannels()==1 and w.getsampwidth()==2 and w.getframerate()==result['sample_rate'];assert abs(duration-result['duration_seconds'])<1/w.getframerate()
                c['pcm_validation']={'status':'passed','channels':w.getnchannels(),'sample_width_bytes':w.getsampwidth(),'sample_rate':w.getframerate(),'sample_frames':w.getnframes(),'decoded_duration_seconds':duration}
        (audio_dir/f"{job['id']}-attempt-{attempt:02d}.json").write_text(json.dumps(c,ensure_ascii=False,indent=2))
    # Prefer exact ASR, then best text coverage; keep every attempt and every difference.
    def rank(c):
        a=c['asr'] or {};result=c['result'];return (bool(result.get('eos')),bool(a.get('normalized_exact_match')),not bool(a.get('reference_text_leak_detected')),a.get('similarity',0),result['attempt'])
    best=max(candidates,key=rank);result=best['result'];a=best['asr'];track={'id':job['id'],'text':job['text'],'selected_attempt':result['attempt'],'audio_local_path':best.get('local_audio'),'wav_path':best.get('local_audio'),'duration_seconds':result.get('duration_seconds'),'audio_sha256':result.get('audio_sha256'),'sample_rate':result.get('sample_rate'),'eos':result.get('eos'),'speed_or_pitch_modified':False,'all_attempts':[c['result']['attempt'] for c in candidates],'actual_listening':'pending parent perceptual review'}
    if a:
        track.update({'status':'ASR exact text match; listening pending' if a['normalized_exact_match'] and result.get('eos') else 'ASR differences require review','independent_asr':a,'subtitle_sentences':a['subtitle_sentences'],'subtitle_timing_method':a['subtitle_timing_method']})
    else:track.update({'status':'generated; independent ASR pending','subtitle_sentences':None})
    tracks.append(track);all_attempts.extend(candidates)
manifest['tracks']=tracks;manifest['remote_batch_status']=data['status'];manifest['guard_result']=data['guard'];manifest['generated_track_count']=sum(t['audio_local_path'] is not None for t in tracks);manifest['total_actual_audio_duration_seconds']=sum(t['duration_seconds'] or 0 for t in tracks);manifest['asr_checked_track_count']=sum('independent_asr' in t for t in tracks);manifest['asr_normalized_exact_count']=sum(t.get('independent_asr',{}).get('normalized_exact_match',False) for t in tracks);manifest['status']='generation/independent ASR in progress; parent listening pending';manifest['sample_audio']=str((folder.parents[1]/'outputs/mojave-machine/media/中文旁白声线样音_待试听.wav').resolve()) if folder.parent.name=='work' else str((folder.parent/'mojave-machine/media/中文旁白声线样音_待试听.wav').resolve())
manifest_path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
print(json.dumps({k:manifest[k] for k in ['generated_track_count','asr_checked_track_count','asr_normalized_exact_count','total_actual_audio_duration_seconds','remote_batch_status']},ensure_ascii=False))
