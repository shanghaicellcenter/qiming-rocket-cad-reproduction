"""Independent acoustic sentence spans from each real FireRed generation unit."""
from pathlib import Path
import json,os,sys,time,subprocess,re,hashlib,difflib
sys.dont_write_bytecode=True
TASK=Path('/home/qianqiming/codex-mojave-assembly-voice-20261019');RUN=TASK/'firered'
MODEL=Path('/home/qianqiming/.cache/huggingface/hub/models--openai--whisper-large-v3-turbo/snapshots/41f01f3fe87f28c78e2fbf8b568835947dd65ed9')
inc=Path('/home/qianqiming/work/drama-3/.deps/python-dev/usr/include');os.environ['CPATH']=':'.join([str(inc/'python3.12'),str(inc),os.environ.get('CPATH','')]).rstrip(':')
for k,v in {'HF_HUB_OFFLINE':'1','TRANSFORMERS_OFFLINE':'1','OMP_NUM_THREADS':'6','MKL_NUM_THREADS':'6','TOKENIZERS_PARALLELISM':'false','PYTHONDONTWRITEBYTECODE':'1','TRITON_CACHE_DIR':str(TASK/'cache/triton'),'NUMBA_CACHE_DIR':str(TASK/'cache/numba')}.items():os.environ[k]=v
tracks=json.loads((RUN/'results.json').read_text());assert len(tracks)==17
import numpy as np,torch
from transformers import WhisperForConditionalGeneration,WhisperProcessor,pipeline
mem=lambda:next(int(l.split()[1])/2**20 for l in Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:'))
assert mem()>13,'Insufficient free memory for independent ASR; no load'
torch.set_num_threads(6);torch.set_num_interop_threads(1);device='cuda:0' if torch.cuda.is_available() else 'cpu';dtype=torch.float16 if device.startswith('cuda') else torch.float32
processor=WhisperProcessor.from_pretrained(str(MODEL),local_files_only=True);model=WhisperForConditionalGeneration.from_pretrained(str(MODEL),local_files_only=True,dtype=dtype,attn_implementation='eager').to(device).eval();asr=pipeline('automatic-speech-recognition',model=model,tokenizer=processor.tokenizer,feature_extractor=processor.feature_extractor,device=device)
norm=lambda s:''.join(re.findall('[\u4e00-\u9fffA-Za-z0-9]',s)).lower()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for track in tracks:
    output=RUN/'tracks'/track['id']/'asr.json'
    if output.exists() and json.loads(output.read_text()).get('audio_sha256')==track['audio_sha256']:continue
    assert mem()>9,'Low memory; stopping only own ASR process';start=time.monotonic();reviews=[];subtitles=[];wordrows=[]
    for unit in track['units']:
        src=Path(unit['file']);assert sha(src)==unit['audio_sha256'];raw=subprocess.run(['/usr/bin/ffmpeg','-nostdin','-v','error','-i',str(src),'-f','f32le','-ac','1','-ar','16000','pipe:1'],capture_output=True,check=True).stdout;audio=np.frombuffer(raw,dtype='<f4').copy()
        result=asr({'raw':audio,'sampling_rate':16000},return_timestamps='word',generate_kwargs={'language':'zh','task':'transcribe','max_new_tokens':192,'do_sample':False});words=[{'start':c['timestamp'][0],'end':c['timestamp'][1],'text':c['text']} for c in result.get('chunks',[])];a=norm(unit['text']);b=norm(result['text']);diff=[{'kind':op,'expected':a[i:j],'recognized':b[k:l]} for op,i,j,k,l in difflib.SequenceMatcher(None,a,b,autojunk=False).get_opcodes() if op!='equal'];offset=unit['start_seconds']
        for w in words:wordrows.append({**w,'start':offset+w['start'] if w['start'] is not None else None,'end':offset+w['end'] if w['end'] is not None else None,'source_unit':unit['index']})
        usable=bool(words and words[0]['start'] is not None and words[-1]['end'] is not None)
        span={'text':unit['text'],'recognized_text':result['text'],'source_unit':unit['index'],'unit_audio_sha256':unit['audio_sha256'],'generation_unit_start':offset,'generation_unit_end':unit['end_seconds'],'start':offset+max(0,words[0]['start']) if usable else None,'end':offset+min(unit['duration_seconds'],words[-1]['end']) if usable else None,'timing_kind':'independent Whisper acoustic span, offset by actual PCM unit position' if usable else 'acoustic interval unavailable; generation boundaries retained separately','normalized_exact_match':a==b,'differences':diff}
        subtitles.append(span);reviews.append({'unit':unit['index'],'expected':unit['text'],'transcript':result['text'],'words_relative_to_unit':words,'differences':diff,'normalized_exact_match':a==b,'similarity':difflib.SequenceMatcher(None,a,b,autojunk=False).ratio(),'audio_sha256':unit['audio_sha256']})
    transcript=''.join(r['transcript'] for r in reviews);a=norm(track['text']);b=norm(transcript);record={'id':track['id'],'audio_sha256':track['audio_sha256'],'engine':'Independent offline Whisper large-v3-turbo','device':device,'offline':True,'expected':track['text'],'transcript':transcript,'normalized_exact_match':a==b,'similarity':difflib.SequenceMatcher(None,a,b,autojunk=False).ratio(),'reference_text_leak_detected':any(t in transcript for t in ['欢迎收听','今天的天气','别急着记零件','为什么还能','答案藏在中间']),'units':reviews,'words':wordrows,'subtitle_sentences':subtitles,'subtitle_timing_method':'Each requested sentence has its own original PCM file. Independent Whisper acoustic token spans are offset using measured PCM concatenation boundaries. No character-based time averaging. Target and recognized text remain separately recorded.','all_sentences_have_acoustic_times':all(s['start'] is not None and s['end'] is not None for s in subtitles),'elapsed_seconds':time.monotonic()-start,'actual_listening':'not performed by this agent; parent perceptual review pending'}
    output.write_text(json.dumps(record,ensure_ascii=False,indent=2));print(json.dumps({'id':track['id'],'match':record['normalized_exact_match'],'differences':[{'unit':u['unit'],'differences':u['differences']} for u in reviews if u['differences']],'reference_leak':record['reference_text_leak_detected'],'acoustic_times':record['all_sentences_have_acoustic_times']},ensure_ascii=False),flush=True)
