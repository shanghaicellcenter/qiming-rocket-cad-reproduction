"""Read-only source verification of a single non-pressure exterior STL.
No original file is modified; outputs remain in work/ for review only.
"""
import bpy, bmesh, json, sys
from pathlib import Path
from mathutils import Vector
HERE=Path(__file__).resolve().parent
for ob in list(bpy.data.objects): bpy.data.objects.remove(ob,do_unlink=True)
sc=bpy.context.scene
sc.name="SOURCE_STL_NOSE_SECTION1_REVIEW"
sc.unit_settings.system="NONE"
sc["source_geometry_unchanged"]=True
sc["stl_units"]="not declared by STL; no engineering unit conversion applied"
sc["scope"]="single original non-pressure exterior nose component only"
source=HERE/"source-safe-nose-section1.stl"
bpy.ops.wm.stl_import(filepath=str(source))
ob=bpy.context.object
ob.name="SOURCE_NSCN_SC1_Nose_Exterior"
ob["provenance"]=json.loads((HERE/"source-safe-nose-manifest.json").read_text())["entry"]
ob["source_geometry"]=True
ob["not_a_complete_assembly"]=True
original_vertices=[tuple(v.co) for v in ob.data.vertices]
original_faces=[tuple(p.vertices) for p in ob.data.polygons]
# Smooth shading changes normals only. No remesh, repair, bevel, scale or part
# reconstruction is applied. The original triangulation remains untouched.
for p in ob.data.polygons: p.use_smooth=True
ma=bpy.data.materials.new("Presentation_White_Only_Material_Not_Source_Claim")
ma.diffuse_color=(.78,.79,.76,1)
ma.use_nodes=True
bs=ma.node_tree.nodes.get("Principled BSDF")
bs.inputs["Base Color"].default_value=(.78,.79,.76,1)
bs.inputs["Roughness"].default_value=.28
bs.inputs["Metallic"].default_value=.02
ob.data.materials.append(ma)
bpy.context.view_layer.update()
corners=[ob.matrix_world@Vector(c) for c in ob.bound_box]
lo=Vector(tuple(min(p[i] for p in corners) for i in range(3)))
hi=Vector(tuple(max(p[i] for p in corners) for i in range(3)))
center=(lo+hi)*.5
size=max(hi-lo)
# Lighting uses relative bounds so it never requires an engineering dimension.
world=bpy.data.worlds.new("Source_Test_Studio")
world.use_nodes=True
world.node_tree.nodes["Background"].inputs["Color"].default_value=(.10,.13,.17,1)
world.node_tree.nodes["Background"].inputs["Strength"].default_value=.30
sc.world=world
def area(name,rel,power,sz):
    data=bpy.data.lights.new(name,"AREA");data.energy=power*size*size;data.shape="DISK";data.size=sz*size
    lamp=bpy.data.objects.new(name,data);sc.collection.objects.link(lamp)
    lamp.location=center+Vector(rel)*size
    lamp.rotation_euler=(center-lamp.location).to_track_quat("-Z","Y").to_euler()
area("Review_Key",(-1.4,-1.6,2.3),550,2.5)
area("Review_Rim",(1.6,.9,1.5),700,2)
area("Review_Fill",(.7,-1.4,.2),110,1.5)
data=bpy.data.cameras.new("Review_Camera")
cam=bpy.data.objects.new("Review_Camera",data);sc.collection.objects.link(cam)
cam.location=center+Vector((1.5,-2.5,1.3))*size
cam.rotation_euler=(center-cam.location).to_track_quat("-Z","Y").to_euler()
data.type="ORTHO";data.ortho_scale=size*1.4;data.clip_end=size*30
sc.camera=cam
sc.render.engine="CYCLES"
sc.cycles.samples=24;sc.cycles.use_denoising=True
sc.cycles.max_bounces=3
sc.render.resolution_x=1000;sc.render.resolution_y=800;sc.render.resolution_percentage=100
sc.render.image_settings.file_format="PNG"
sc.render.film_transparent=True
sc.view_settings.view_transform="AgX"
sc.render.filepath=str(HERE/"source-safe-nose-section1-review.png")
bpy.ops.render.render(write_still=True)
sys.path.append("/Users/qianqiming/.codex/skills/scenario-blender-expert/scripts")
import bx_audit, bx_review
audit=bx_audit.audit(ob)
verdict=bx_audit.verdict(audit,deforming=False)
sheet=bx_review.review([ob],str(HERE/"source-safe-nose-sheet"),views=("front","right","threequarter","low"),modes=("silhouette","matcap"),res=300)
unchanged=(original_vertices==[tuple(v.co) for v in ob.data.vertices] and original_faces==[tuple(p.vertices) for p in ob.data.polygons])
result={"blender_version":bpy.app.version_string,"source_geometry_unchanged":unchanged,
        "vertices":len(ob.data.vertices),"triangles":len(ob.data.polygons),
        "audit":audit,"verdict_non_deforming":verdict,
        "render":sc.render.filepath,"review_sheet":sheet,
        "limitations":["Single source component only; not an assembly.","STL does not declare units; no real-world unit claim.","Material and studio are presentation choices.","No original file modified; source triangulation unaltered."]}
(HERE/"source-safe-nose-import-audit.json").write_text(json.dumps(result,ensure_ascii=False,indent=2))
bpy.context.window.scene=sc
bpy.ops.wm.save_as_mainfile(filepath=str(HERE/"source-safe-nose-section1-test.blend"))
print("SAFE_IMPORT_RESULT="+json.dumps(result,ensure_ascii=False))
