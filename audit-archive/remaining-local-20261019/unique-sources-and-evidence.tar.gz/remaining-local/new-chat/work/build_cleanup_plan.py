"""Write an exact conditional cleanup plan; does not delete, move or stop processes."""
from pathlib import Path
import json,stat,os,hashlib,datetime,subprocess
ROOT=Path(__file__).resolve().parents[1];W=ROOT/'work';PUB=W/'github-publication';VERIFY=ROOT.parent/'qiming-github-verify-20261019';NI=ROOT.parent/'ni';e=json.loads((W/'cleanup-inventory-evidence.json').read_text());allrows={r['path']:r for r in e['root_children']+e['publication_children']}
relative_dirs=['outputs/启明火箭','outputs/virtual-assembly','work/assembly-film','work/assembly-previews','work/atlas-integration','work/cad-research','work/final-entrance-review','work/flight-evidence','work/history','work/legacy-source-audit','work/machine-review-rounds','work/machine-runtime','work/mojave-anatomy','work/mojave-display','work/native-cad','work/portable-recorder-smoke','work/safe-stl','work/simulation-review','work/source-drawings','work/source-format-review','work/task-plan-history','work/virtual-assembly']
relative_dirs+=['work/github-publication/'+n for n in ['derived','portable-blender-smoke','release-assets','release-assets-history','restore-smoke-complete','restore-smoke-input','staging-history','nonrelease-backups','browser-review','preview-docs','__pycache__','repo-stage']]
candidates=[]
for rel in relative_dirs:
 p=ROOT/rel
 if not p.exists() and not p.is_symlink():continue
 assert not p.is_symlink(),p
 r=allrows.get(str(p))
 if r is None:
  logical=count=0;stack=[p]
  while stack:
   q=stack.pop();st=q.lstat()
   if stat.S_ISLNK(st.st_mode):continue
   if stat.S_ISDIR(st.st_mode):stack.extend(q.iterdir())
   elif stat.S_ISREG(st.st_mode):logical+=st.st_size;count+=1
  r={'logical_bytes_without_following_symlinks':logical,'regular_files':count,'symlinks':[]}
 gates=['actual_current_release_public_and_all_downloaded_bytes_verified','actual_isolated_restoration_browser_media_and_rebuild_acceptance','preserve_receipts_before_removal','no_active_open_file_in_this_candidate','recheck_lstat_and_references_before_action']
 if rel.endswith('/repo-stage'):gates+=['retain_verified_fresh_clone_HEAD82c2a2a2_and_all194_tracked_files_plus_git']
 candidates.append({'path':str(p),'relative_path':rel,'action_after_acceptance':'remove_task_generated_tree_without_following_symlinks','logical_bytes_snapshot':r['logical_bytes_without_following_symlinks'],'regular_files_snapshot':r['regular_files'],'symlink_count_snapshot':len(r['symlinks']),'unique_actual_recoverable_bytes':None,'gates':gates})
alias=ROOT/'outputs/mojave-machine'
if alias.is_symlink():candidates.append({'path':str(alias),'relative_path':'outputs/mojave-machine','action_after_acceptance':'unlink_alias_itself_only','logical_bytes_snapshot':0,'regular_files_snapshot':0,'symlink_count_snapshot':1,'raw_link_target':os.readlink(alias),'gates':['actual_download_recovery_accepted','do_not_follow_link']})
# Retain small original evidence before removing known working trees. Runtime
# packages, duplicated public image/model metadata and old staging trees are not
# part of this small receipt set. The actual Git checkout is kept separately.
text_suffixes={'.md','.json','.csv','.txt','.log','.py','.js','.mjs','.sh','.sb','.srt','.ass'}
exclude_prefixes=['work/machine-runtime/node_modules','work/github-publication/derived','work/github-publication/staging-history','work/github-publication/repo-stage','work/github-publication/portable-blender-smoke','work/github-publication/nonrelease-backups']
keep=[]
for base in [W,ROOT/'outputs/启明火箭']:
 stack=[base]
 while stack:
  p=stack.pop();s=p.lstat();rel=p.relative_to(ROOT).as_posix()
  if stat.S_ISLNK(s.st_mode):continue
  if any(rel==x or rel.startswith(x+'/') for x in exclude_prefixes):continue
  if stat.S_ISDIR(s.st_mode):
   # Public detailed records remain in Release; keep only root reading/acceptance notes.
   if base.name=='启明火箭' and p!=base:continue
   stack.extend(p.iterdir());continue
  if not stat.S_ISREG(s.st_mode):continue
  mandatory=p.name in {'release-manifest.json','assets.json','SHA256SUMS','remote-publication-receipt.json','remote-validation-owner.json','local-archive-stream-audit.json','migration-review.json','delivery-completion-audit.json'}
  if (p.suffix.lower() in text_suffixes and s.st_size<=256*1024) or mandatory:
   # Avoid recursively retaining this plan and its generated preserving list.
   if p.name.startswith(('cleanup-','prepare_cleanup_','build_cleanup_','cleanup_preflight')):continue
   keep.append({'source':str(p),'relative_target':rel,'bytes_snapshot':s.st_size,'sha256_snapshot':hashlib.sha256(p.read_bytes()).hexdigest(),'mandatory':mandatory})
# Exact independent copies are checked again now, not merely trusted by label.
m=json.loads((W/'cross-project-release-review/migration-review.json').read_text());checks=[]
for r in m['source_checks']:
 p=NI/r['localPath'];assert p.is_file() and not p.is_symlink() and p.resolve().is_relative_to(NI)
 digest=hashlib.sha256(p.read_bytes()).hexdigest();checks.append({'source_path_released':r['originalSource'],'independent_local_path_to_keep':str(p),'sha256':digest,'passed':digest==r['sha256']})
assert len(checks)==103 and all(r['passed'] for r in checks)
# Retained clone and its tracked paths must not be removed as a directory.
clone=VERIFY/'project';tracked=subprocess.check_output(['git','-C',str(clone),'ls-files','-z']).decode().split('\0');tracked=[x for x in tracked if x];head=subprocess.check_output(['git','-C',str(clone),'rev-parse','HEAD'],text=True).strip();assert head=='82c2a2a255b66556cead58ec3444f81f1757ae68'
manifest=json.loads((PUB/'release-manifest.json').read_text());untracked_release=[r['path'] for r in manifest['files'] if r['path'] not in set(tracked)]
receipt=json.loads((PUB/'remote-publication-receipt.json').read_text())
upload_pids=sorted({r['pid'] for r in e['active_open_paths'] if r['command']=='gh' and r['fd']!='cwd'})
plan={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'purpose':'Prepare exact local generated-copy cleanup only; no deletion/move/kill/public-tree mutation performed','cleanup_allowed_now':False,'current_release_repo':'https://github.com/shanghaicellcenter/qiming-rocket-cad-reproduction','tag':'v1.0.0','commit':head,'release_manifest_sha256':hashlib.sha256((PUB/'release-manifest.json').read_bytes()).hexdigest(),'remote_publication_state_at_snapshot':receipt['publication_state'],'authorization_scope':'Parent verified direct user authorization to publish Anatomy/Machine project and then delete local generated copies after actual public download/rebuild/play validation. This plan does not authorize unrelated files, original input or shared environments.','snapshot_is_not_space_reclaim_guarantee':True,'candidate_current_logical_bytes_no_symlink_double_count':sum(r['logical_bytes_snapshot'] for r in candidates),'candidate_current_regular_files':sum(r['regular_files_snapshot'] for r in candidates),'candidate_directory_count':len(candidates),'candidate_roots_exact':candidates,'permanently_protected_paths':[str(Path('/Users/qianqiming/Desktop/火箭设计 中文版')),str(NI),'/Users/qianqiming/Desktop/skill-repos','/Users/qianqiming/.codex','/Users/qianqiming/.agents','/Applications/Blender 5.2.app','/Applications/Blender.app'],'remote_spark_resources_protected_not_in_local_cleanup':['/home/qianqiming/codex-mojave-cad-review-20261019','/home/qianqiming/work/drama-3/rocket-v2-20261019-tts/shared-voice','Any shared Breeze/ASR/model/runtime/service installation'],'retained_git_checkout':{'root':str(clone),'head':head,'tracked_files':tracked,'tracked_count':len(tracked),'retain_git_directory':True,'policy':'Retain the fresh actual public clone, .git and all194 tracked source files. Never remove this entire project or its outputs directory; release payload overlaps tracked source paths.'},'retained_receipts_plan':{'destination':str(ROOT/'retained-release-records'),'files':keep,'snapshot_files':len(keep),'snapshot_logical_bytes':sum(r['bytes_snapshot'] for r in keep),'verification_reports_directory_to_keep':str(VERIFY/'reports'),'verification_owner_and_sandbox_to_keep':[str(VERIFY/'owner.json'),str(VERIFY/'deny-original-inputs.sb')],'final_public_URLs_assets_SHA256_and_acceptance_report_required':True,'images':'Retain the2 current real preview images already tracked in the small Git checkout; optional actual-download screenshots stay in verification reports. No need to retain binary render work backups.'},'verification_generated_data_plan':{'root':str(VERIFY),'snapshot_current_assets_logical_bytes':next((r['logical_bytes_without_following_symlinks'] for r in e['root_children'] if r['path']==str(VERIFY/'assets')),0),'delete_after_acceptance_exact_named_roots':[str(VERIFY/'assets'),str(VERIFY/'runtime-links'),str(VERIFY/'restored-lecture'),str(VERIFY/'project/rebuilt')],'release_payload_untracked_paths_only':untracked_release,'release_internal_aliases_untracked_only':manifest['symlinks'],'tracked_paths_to_exclude':tracked,'expected_added_payload_logical_bytes_before_overlap':manifest['full_logical_bytes'],'expected_download_archives_bytes':2085957420,'unknown_untracked_files':'Keep and report; do not blanket-delete the verification root or all untracked files. Reinventory final actual restored/rebuilt locations after acceptance.'},'process_and_reference_evidence':{'source':'work/cleanup-inventory-evidence.json','active_open_paths':e['active_open_paths'],'lsof_errors':e['lsof_error_line_count'],'known_task_preview_server':{'pid':12387,'port':58926,'directory':str(ROOT/'outputs/启明火箭'),'instruction':'Owner must close this task preview server after actual validation if it still owns the same port/directory. Do not kill shared Chrome/Codex/Python processes.'},'uploader_at_snapshot':{'pids':upload_pids,'command':'gh','state':'actually opened current Release tar files; wait normal completion before removing upload assets'},'root_cwd_users':'Several Chrome/Codex helper processes have cwd at new-chat; preserve the parent project directory. They are not evidence of an open model file and must not be killed as part of this plan.','external_sibling_symlinks_targeting_project':e['external_sibling_symlinks_targeting_our_root'],'external_code_hits_classified':[{'path':r['path'],'line_numbers':r['line_numbers'],'classification':'sourceEvidence sourceImage provenance fields; P087/P072 copies independently preserved in ni; scoped JS/MJS/HTML consumer search found none and8 packed card scenes passed independent deny-original reopen review' if r['path'].endswith(('data.js','course-data.js')) else 'Sandbox deny-original path and sentinel evidence, not a runtime dependency'} for r in e['external_sibling_program_reference_hits']],'all103_current_independent_copy_hashes_rechecked':True,'independent_copy_checks':checks,'do_not_generalize103_release_to_unknown_paths':True},'required_final_acceptance':['Release is actually public; final URLs/tag/commit/asset-size+SHA receipt saved','Fresh actual GitHub clone and all actual Release downloads verified, including3829 files and original392 input snapshot','Full local audio/visual restoration from independent packages passed original HTML SHA, video/audio packet SHA and full decode','Actual offline browser playback/chapters/seeking and actual Blender/model/rebuild validation passed without original new-chat/ni/Desktop input access','Retain final reports/URLs/manifests and194-file small Git checkout before deleting generated copies','Recheck active file handles, exact paths, symlink boundaries and103 independent copies at execution time; unknown/unrelated files remain protected'],'execution_sequence':['Run read-only cleanup_preflight.py after actual recovery acceptance; copy small receipt list into retained-release-records','Owner closes only the positively identified task preview server; uploader and all validation writers reach normal terminal state','Reinventory final verification-generated paths, exclude all Git tracked paths, and stage only exact allowlisted generated roots without following symlinks','Recheck no unexpected files/active handles/references, then parent executes authorized removal; this preparation tool does not delete','Record actual df available bytes before/after, absent removed paths, intact Desktop originals/ni/shared tools, retained Git and reports. Report measured df difference rather than logical-byte sum.'],'actual_reclaimed_bytes':None,'deletions_performed':0,'public_tree_mutations_performed':0}
(W/'cleanup-plan-current.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n')
gib=plan['candidate_current_logical_bytes_no_symlink_double_count']/1024**3
md=f'''# 本地生成副本清理计划（只准备，尚未删除）

当前已列明{len(candidates)}个精确候选根，合计{plan['candidate_current_logical_bytes_no_symlink_double_count']:,}逻辑字节（{gib:.2f}GiB），不沿符号链接计数。这里不是保证能释放的磁盘空间：APFS共享块/克隆可能使实际df回收量不同。最终必须报df前后实测差。

GitHub公开仓库：{plan['current_release_repo']}；commit `{head}`，tag `v1.0.0`。当前仍为上传过程快照，清理资格为false；不以本地分包校验代替实际公开下载恢复。下载、播放与重建继续由根任务执行，本计划不阻塞它们。

保留桌面原始392资料、整个ni、skill-repos、.codex/.agents与Blender/公共运行时；Spark共享模型/TTS/reader环境也不在本地清理范围。103精确跨项目输入的ni独立副本已本次逐项重核SHA全部通过，这项解除仅适用于列出的103路径。另8来源卡本地独立打包的审查记录继续保留，不推广为其他依赖解除。

保留实际新clone `{clone}` 的`.git`与194个tracked文件；只保留这一小源码仓库，旧上传repo-stage可在该clone再次核验后移除。禁止整删新clone的outputs目录，因为其中也有Git tracked源码。下载包、展开的大型未tracked模型、恢复媒体与rebuilt目录只能按Release清单精确排除tracked路径后清理；未知文件保留。

先将{len(keep)}份小文本/脚本/QA与清单（当前{sum(r['bytes_snapshot'] for r in keep):,}字节）保存在 `{ROOT/'retained-release-records'}`，保留新验证root的reports、owner与sandbox证据。最终公开URL/附件API摘要/实际下载SHA/恢复验收记录必须补齐后再动大目录。两张当前真实预览图已在小Git仓库中，不需要保留所有渲染备份。

本次lsof实际GH上传PID为{upload_pids}，仍打开分包；Python预览服务PID12387仍服务58926端口。待其正常完成/由owner关闭该任务预览服务，再重新检查活句柄；不得杀共享Chrome、Codex或无关Python。外部兄弟项目回指本项目的symlink为0。剩余4个代码命中分别是3个sourceImage历史溯源字段和一个拒读sandbox哨兵，P087/P072独立复制已再次核实，未见浏览代码把sourceImage当运行时图片输入。

候选精确路径、每项字节数、103副本核对及验收门槛见cleanup-plan-current.json。准备脚本没有删除/移动/kill功能，不修改public树。最终实际操作需再次运行read-only预检，保留小记录后，按精确allowlist执行；不使用针对整个工作区或verifyroot的通配删除。
'''
(W/'cleanup-plan-current.md').write_text(md)
print(json.dumps({'candidates':len(candidates),'candidate_logical_bytes':plan['candidate_current_logical_bytes_no_symlink_double_count'],'candidate_GiB':gib,'receipt_files':len(keep),'receipt_bytes':sum(r['bytes_snapshot'] for r in keep),'tracked_keep':len(tracked),'rechecked103':True,'cleanup_allowed_now':False},ensure_ascii=False))
# Exact known-path fingerprints make a later appearance/change explicit, instead
# of silently treating every new file under a generated folder as disposable.
fingerprints=[]
for c in candidates:
 root=Path(c['path']);stack=[root];items=[]
 while stack:
  p=stack.pop();s=p.lstat();kind='symlink' if stat.S_ISLNK(s.st_mode) else 'directory' if stat.S_ISDIR(s.st_mode) else 'file' if stat.S_ISREG(s.st_mode) else 'other'
  row={'relative_path':p.relative_to(root).as_posix(),'kind':kind,'device':s.st_dev,'inode':s.st_ino,'mtime_ns':s.st_mtime_ns,'bytes':s.st_size if kind=='file' else 0}
  if kind=='symlink':row['raw_target']=os.readlink(p)
  items.append(row)
  if kind=='directory':stack.extend(p.iterdir())
 fingerprints.append({'root':str(root),'items':sorted(items,key=lambda r:r['relative_path'])})
fp=W/'cleanup-known-path-fingerprints.json';fp.write_text(json.dumps({'created_utc':plan['created_utc'],'no_symlinks_followed':True,'candidates':fingerprints},ensure_ascii=False,indent=2)+'\n');plan['known_path_fingerprints']={'path':str(fp),'sha256':hashlib.sha256(fp.read_bytes()).hexdigest(),'entries':sum(len(r['items']) for r in fingerprints),'policy':'Default preflight blocks newly appeared or changed candidate files. Refresh only after reviewing changes and redoing acceptance/reference checks.'};(W/'cleanup-plan-current.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n')
for r in plan['process_and_reference_evidence']['external_code_hits_classified']:
 r['file_sha256_at_snapshot']=hashlib.sha256(Path(r['path']).read_bytes()).hexdigest()
desktop=W/'desktop392-protection-check.json'
if desktop.exists():plan['desktop392_protection_evidence']={'path':str(desktop),'sha256':hashlib.sha256(desktop.read_bytes()).hexdigest(),'all392_passed':json.loads(desktop.read_text())['all392_original_bytes_and_sha256_match_frozen_original_manifest']}
(W/'cleanup-plan-current.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n')
