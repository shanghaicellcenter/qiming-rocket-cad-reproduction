import bpy,json,numpy as np
from pathlib import Path
p=Path('/Users/qianqiming/Documents/Codex/2026-10-19/new-chat/work/native-cad/vehicle-blender')
a=json.loads((p/'vehicle-original.audit.json').read_text())
bpy.ops.wm.open_mainfile(filepath=str(p/'vehicle-original.blend'))
by={o.get('source_usd_path'):o for o in bpy.context.scene.objects if o.get('source_usd_path')}
for phase in ('saved_hidden','temporary_visible'):
 if phase=='temporary_visible':
  for o in by.values():o.hide_viewport=False
  bpy.context.view_layer.update()
 diffs=[]
 for r in a['blender_objects']:
  o=by[r['source_usd_path']]
  le=float(np.abs(np.asarray(o.matrix_local)-np.asarray(r['matrix_local'])).max());we=float(np.abs(np.asarray(o.matrix_world)-np.asarray(r['matrix_world'])).max())
  if le or we:diffs.append({'p':o['source_usd_path'],'hidden':bool(o.get('source_hidden')),'local':le,'world':we,'actual_world':[list(x) for x in o.matrix_world]})
 print(phase,'differences',len(diffs),json.dumps(diffs[:5]))
