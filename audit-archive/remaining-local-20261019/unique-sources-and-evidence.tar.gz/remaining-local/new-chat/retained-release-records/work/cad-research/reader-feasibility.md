# DGX Spark 原生 SolidWorks 读取可行性（只读调研）

范围：将用户已有 CAD 做非功能、非操作性的外观可视化转换；不增加推进/高压设计、制造信息或操作仿真。仅查本地技能、官方文档与包索引；未安装/下载 wheel 正文，未接受付费或试用，未上传任何用户 CAD，未连接 Spark 执行命令。

## 结论

**有具体可用的 Linux aarch64 原生读取发行包，不能以 Mac 无 parser 结束。** 当前官方文档与公共 PyPI 都是 `usd-convert-cad==0.3.0`，原生支持 `.sldprt/.sldasm`。Mac 没有该 wheel；Spark 的 Linux aarch64 是官方列出的平台。文档没有把 SolidWorks 列入 ARM 不支持项；ARM 排除项是 AutoCAD/Revit。[官方 README](https://github.com/NVIDIA-Omniverse/usd-convert-cad#requirements)、[平台限制](https://github.com/NVIDIA-Omniverse/usd-convert-cad/blob/main/LIMITATIONS.md#platform-support)。

**技术可安装路径已证实，实际原文件读取仍未验证。** 本次没有安装或 reader test，不能写“Spark 已读通”。首个测试只应使用项目中已确认无危险内部结构的外观零件，成功且视觉复核后再考虑更多外观部件。

## 真实发行包与获取

官方 PyPI JSON 和 simple 索引均返回此文件：

```text
usd_convert_cad-0.3.0-cp312-cp312-manylinux_2_35_aarch64.whl
128,203,738 bytes = 128.20 MB = 122.26 MiB（压缩下载大小）
SHA256 1df28edbfeeb734e2acf2e87f80c295414225c847e6b18640a14089e7b9f61d6
Python >=3.12,<3.13
Requires-Dist: 未声明（JSON 为 null）
```

[PyPI 项目](https://pypi.org/project/usd-convert-cad/)、[版本元数据 JSON](https://pypi.org/pypi/usd-convert-cad/0.3.0/json)、[wheel 公开地址](https://files.pythonhosted.org/packages/ae/a7/e69189090b3d7ddc9d79cc792496bfc7218134a92380682246eb1a451cf7/usd_convert_cad-0.3.0-cp312-cp312-manylinux_2_35_aarch64.whl)。

已对上面的文件地址做**不带认证信息的 HTTP HEAD**，实际 HTTP200、Content-Length128203738、Accept-Ranges:bytes；未读取 wheel 正文。获取不需要登录、NGC token 或私有镜像。仓库 README 的 NVIDIA extra-index 是后备示例，当前公共 PyPI 已有目标包，**不需要先申请 NVIDIA_API_KEY**。

实际解压安装占用没有官方数字，本研究未下载 wheel 读取 ZIP 或安装，因此**未知**；不能把128.20MB称作完整安装占用。元数据原件已保存 `work/cad-research/usd-convert-cad-pypi.json`、`usd-convert-cad-simple.html`。

## 官方命令（本研究均未执行）

以下沿用官方独立 wheel 技能的环境/CLI命令，只将版本固定为文档实测0.3.0并将输入指定为安全外观零件：

```sh
python3.12 -m venv .venv
source .venv/bin/activate
python -m pip install usd-convert-cad==0.3.0
usd-convert-cad --help
python -c "import usd_convert_cad; print(usd_convert_cad.__version__)"
usd-convert-cad -i safe-exterior.sldprt -o safe-exterior.usdc
```

命令依据：[官方 CAD-to-USD 技能](https://github.com/NVIDIA-Omniverse/usd-convert-cad/blob/main/skills/omniverse-cad-to-usd/SKILL.md#instructions)。文件名 `safe-exterior.sldprt` 是测试占位符，必须由父任务先选定真实安全外观件，不能把其当已存在路径。这里不使用 `--read-constraints`、`--convert-physics-data` 或任何仿真服务。

成功标准由官方实现合同明确：进程退出0，打印 `Successfully converted: <output>`，预期 USD 文件确实存在；随后还要打开 USD，确认非空网格、外观、坐标与原外观件相符。安装成功和 `--help` 成功都不等于读入原CAD成功。[实现合同](https://github.com/NVIDIA-Omniverse/usd-convert-cad/blob/main/skills/omniverse-cad-to-usd/SKILL.md#implementation-contract)。

安装之前的只读目标机核对可查 `uname -m`、`python3.12 --version`、`ldd --version`。这些是本文建议的系统诊断，不是已经运行的 Spark 结果。

## 系统依赖和转换边界

- **精确平台下限：** wheel 标签是 CPython3.12、Linux aarch64、manylinux_2_35；由标签可推出 glibc 至少2.35。Spark 实际系统/解释器未在此任务检查，不能只凭名称认定全部满足。
- **独立运行：** wheel 自带 OpenUSD/pxr 和 CAD conversion runtime，不需要 Omniverse Kit、单独 `usd-core`/pxr、Kit扩展注册表、Docker或Content Agents。应隔离环境，避免已有pxr冲突。[官方安装说明](https://github.com/NVIDIA-Omniverse/usd-convert-cad/blob/main/README.md#getting-started)。
- **底层引擎：** NVIDIA发行包使用 HOOPS Exchange 2026.7.0、OpenUSD25.11、OpenUSD Exchange3.0。[官方 third-party 表](https://github.com/NVIDIA-Omniverse/usd-convert-cad/blob/main/THIRD_PARTY_NOTICES.md#direct-dependencies)。
- **原生库要求：** HOOPS 官方 Linux运行时表列glibc2.28、libstdc++.so.6.0.25；本 wheel 的glibc2.35要求更严格，应优先满足wheel标签。文档没有给这个wheel一份额外apt包清单，未在此研究中验证其全部ELF动态依赖，不编造apt安装命令。[HOOPS官方平台表](https://docs.techsoft3d.com/hoops/exchange/start/supported-platforms.html)。
- **转换与渲染分开：** 官方独立wheel前置条件没有要求CUDA/GPU、RTX渲染或Content Agent。Spark满足NVIDIA平台条件，但这不等于本次已做性能或实际转换验证。
- **输出是可视化mesh：** 原生B-rep会被三角化成UsdGeomMesh，不能无损回写CAD；源抑制分支、缺失外部引用或reader未暴露的结构可能缺失。不能仅凭得到USD声称“全部真实部件完整复现”。[官方数据映射](https://github.com/NVIDIA-Omniverse/usd-convert-cad/blob/main/docs/concept_mapping.md#what-is-not-preserved)。
- **材质保留有限：** 官方说明完整PBR仅针对glTF输入；SolidWorks等CAD通常只保留基础颜色/分配，后续展示材质应单独处理并明确是视觉重建。[已知限制](https://github.com/NVIDIA-Omniverse/usd-convert-cad/blob/main/LIMITATIONS.md#material-preservation)。

## 费用、许可与 token：能确认的和不能确认的

1. **能确认：** wheel在公共PyPI直接公开，独立CLI安装/转换流程没有账户、API key或usage token配置。HOOPS的商业SDK许可由NVIDIA持有并随产品提供，官方没有要求用户先另购一份HOOPS SDK。[NVIDIA许可证](https://github.com/NVIDIA-Omniverse/usd-convert-cad/blob/main/LICENSE.md)、[HOOPS Core许可说明](https://docs.omniverse.nvidia.com/kit/docs/omni.kit.converter.hoops_core/latest/LICENSE.html)。
2. **不应误读：** Apache-2.0/CC-BY-4.0只指技能/文档，**不是**整个原生CAD converter的开源许可。转换器受NVIDIA Software License Agreement及AI Product Terms约束；LICENSE明写下载或使用即同意条款。
3. **仍未被官方项目文档消除的不确定性：** README保留“专有CAD格式可能需要converter licensing”提示，没有这个具体发行包的单独“无限制、免费商业生产使用”声明。综合公开PyPI分发、无需token与NVIDIA已许可HOOPS，**可判断有无账户的本地技术路径；不能据此保证所有商业用途免费或保证绝不出现原生license错误**。
4. NVIDIA现行AI Product Terms区分公开无成本Community Products、Enterprise和开发者非生产用途；软件库分类与具体使用权不能仅由“pip可下载”决定。[NVIDIA AI Product Terms](https://www.nvidia.com/en-us/agreements/enterprise-software/product-specific-terms-for-ai-products/)。本研究没有接受任何付费/试用，没有请求key，没有尝试绕过许可。

因此当前阻碍是**尚未实装/读取测试，以及具体使用许可未作额外确认**，不是“找不到ARM原生SW软件”。若未来测试出现license/entitlement错误，应保留原始stderr并停止，不能自动购买、开试用、填token或改许可。

## 与本地CAD-to-SimReady技能的衔接

已读 `/Users/qianqiming/Desktop/skill-repos/openai--plugins/plugins/nvidia/skills/omniverse-cad-to-simready/SKILL.md`。该技能明确：conversion-only是有效最小范围，设置 `property_assignment_intent=skip`，不要部署Content Agents；preflight需要跳过Content Agents。它也说明 `uv sync` 不会自动安装全部CAD转换runtime。

本研究是**只读可行性检查**，没有运行会安装/部署的preflight或服务。真正获授权做纯转换时，应走官方独立wheel和转换reference，并检查最小USD有效性；不应因大技能的默认端到端模式去请求NVIDIA_API_KEY、部署材质/物理服务或添加刚体/约束。整个后续外观转换仍保持非功能展示边界。
