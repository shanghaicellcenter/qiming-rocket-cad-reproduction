import bpy,json,sys,hashlib
from pathlib import Path
import numpy as np
args=sys.argv[sys.argv.index('--')+1:]
audit_path=Path(args[0]);audit=json.loads(audit_path.read_text())
checks=[]
for item in audit['items']:
 for rec in item['objects']:
  ob=bpy.data.objects.get(rec['object']);assert ob is not None,rec['object']
  assert ob.get('source_filename')==item['source']['source_filename']
  if rec['type']!='MESH':continue
  assert ob.type=='MESH'
  a=np.empty(len(ob.data.vertices)*3,dtype=np.float32);ob.data.vertices.foreach_get('co',a)
  expected=rec.get('points_sha256') or item.get('raw_stl_vertex_sha256')
  same=hashlib.sha256(a.tobytes()).hexdigest()==expected
  assert same
  assert len(ob.data.polygons)==rec['faces']
  actual=np.asarray(ob.matrix_world);original=np.asarray(rec['world_matrix_native']);assert np.allclose(actual,original,atol=1e-8)
  checks.append({'source_id':item['source']['id'],'object':ob.name,'vertices':len(ob.data.vertices),'faces':len(ob.data.polygons),'points_hash_exact':same,'world_transform_retained':True})
result={'blend':bpy.data.filepath,'reopened':True,'source_count':audit['source_count'],'mesh_count':len(checks),'faces':sum(x['faces'] for x in checks),'scene_count':len(bpy.data.scenes),'all_saved_points_faces_transforms_match':True,'raw_stl_parent_collection':bpy.data.collections.get('RAW_SOURCE_STL_VARIANTS') is not None,'checks':checks}
p=audit_path.with_name(audit_path.stem.replace('.audit','')+'.reload-verification.json');p.write_text(json.dumps(result,indent=2)+'\n')
print('LIBRARY_RELOAD='+json.dumps({k:v for k,v in result.items() if k!='checks'}),flush=True)
