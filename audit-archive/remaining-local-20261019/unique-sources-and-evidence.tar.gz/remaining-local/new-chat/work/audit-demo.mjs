// Generic visualization API test: a hollow sleeve and a separate end ring.
// Arbitrary display units; no engineering or project dimensions.
import { writeFileSync } from "node:fs";
import * as k from "/Users/qianqiming/Desktop/skill-repos/wheresryan22--anatomy/kit/iso-kit.mjs";
import * as G from "/Users/qianqiming/Desktop/skill-repos/wheresryan22--anatomy/kit/lathe.mjs";
import * as A from "/Users/qianqiming/Desktop/skill-repos/wheresryan22--anatomy/kit/audit.mjs";

const W = 260, H = 220;
const F = G.frameOf([0, 0, 0], [0, 0, 1], [1, 0, 0], [0, 1, 0]);
const P = k.fitProjection(
  [[-12,-12,0],[12,12,0],[-12,-12,68],[12,12,68]],
  W, H, { pad: 24, azimuth: 45, elevation: 30 },
);
const ORDER = ["end-ring"];
const wrappedMiddle = process.argv.includes("--wrapped-middle");
const SPRING = { stagger: 0.035, stiffness: 64, damping: 14.2, substeps: 4 };
const R = A.recorder(P, { order: ORDER, spring: SPRING });

function putRing({ piece, name, s0, s1, ri, ro, move, ground = false }) {
  const paths = G.ringBand(s0, s1, ri, ro, F, P);
  const shape = R.solid(A.ring(F, s0, s1, ri, ro, { name, ground }));
  R.put({
    piece, name, at: [0, 0, (s0 + s1) / 2], move,
    svg: k.solidSvg(paths, { tone: piece === "sleeve" ? "mid" : "hi" }),
    shapes: [shape],
  });
}

// The ring is on the sleeve's top face: surfaces touch, volumes do not overlap.
putRing({ piece: "sleeve", name: "demo.sleeve", s0: 0, s1: 32,
  ri: 6, ro: 8, move: [0,0,0], ground: true });
putRing({ piece: "end-ring", name: "demo.end-ring",
  s0: wrappedMiddle ? 14 : 32, s1: wrappedMiddle ? 18 : 36,
  ri: wrappedMiddle ? 8 : 6, ro: 11, move: [0,0,28] });

const started = Date.now();
A.settle(R, P);
R.items.sort((a,b) => a.key - b.key);
console.log(`settle wall time: ${((Date.now()-started)/1000).toFixed(3)} s`);
const html = k.pageHtml({
  title: "Generic hollow sleeve audit demo", theme: "light", width: 440,
  body: k.plateHtml({ fig: "API TEST", title: "Sleeve and end ring",
    hint: "Static API proof", readout: "arbitrary display units",
    caption: "Two generic display pieces; this is not an engineering model.",
    body: k.figureSvg({ width: W, height: H,
      label: "Generic hollow sleeve with a separate end ring",
      body: R.items.map(item => k.groupSvg(item.svg, {
        "data-piece": item.piece, "data-k": item.key,
      })),
    }),
  }),
});
writeFileSync(new URL(wrappedMiddle ? "audit-demo-wrapped.html" : "audit-demo.html", import.meta.url), html);
const result = A.auditOrExit(R, P);
if (result) console.log(`total wall time: ${((Date.now()-started)/1000).toFixed(3)} s`);
