from pathlib import Path
import json,hashlib,re

root=Path(__file__).resolve().parents[2];folder=root/'work/virtual-assembly'
source_path=folder/'assembly-stages.json';stage_data=json.loads(source_path.read_text());qc_path=folder/'alignment-qc.json';qc=json.loads(qc_path.read_text())['final_alignment']
register=json.loads((root/'work/flight-evidence/evidence-register.json').read_text())
book_url=next(e['sourceurl'] for e in register['entries'] if e['id']=='ID-01')
book_local=Path('/Users/qianqiming/Desktop/火箭设计 中文版/中文文档/01-HCR-5100 建造集成与发射指南-中文版.md')

content=[
('贮箱：分开存放的空间','长筒里分别存放两类工作介质，隔离件把它们分开。先看这组共同的外形，再把原有的阀组单独介绍。','贮箱的高层作用是储存和分隔两类工作介质。源书将它描述为叠置贮箱；本段只解释空间分区，不演示流体、活塞运行或装填。','2.3.2 推进剂贮箱；图2.8、2.9','储存／分隔，不演示工作过程',['实体密封、承压能力和介质相容性未验证。']),
('推力室：能量释放的位置','下面这组是推力室。它是释放能量、让气体向后排出的部位；这一段只把原结构放回位置，帮助理解它和贮箱的关系。','推力室是火箭中释放能量并排出气体的部位，排气与推力的关系是基本作用原理。这里展示既有部件的空间关系，不产生火焰、喷流、温度或性能数值。','1.3.3 推力室组件；2.3.4 推力室组件；图2.17','静态源结构，不运行',['实体热负荷、结构强度、密封与工作可靠性未验证。']),
('第一组舵机阀：结构的对应关系','这一组把电驱动部件与阀体联系起来。先看支架、连接件和阀体的相对位置，画面保留原结构，不让阀门动作。','源书描述的舵机阀由驱动部件、阀体及中间连接结构组成；连接结构传递运动。此处只看源结构实例的组成和相对位置，不描述开启、加压或点火流程。','2.3.3 流体系统·主推进剂阀','原结构实例A，阀门不动作',['实体驱动行程、力矩、电控功能和阀体密封未验证。']),
('第二组舵机阀：同设计的另一实例','第二组阀来自同一个原设计，却位于另一处。我们保留各自的源实例路径，让你看清相同结构怎样出现在不同位置。','两组来自同一原SLDASM定义，在整箭源树中是不同实例。源文件共同身份不等于同一个空间对象；本段强调实例身份与原位置。','2.3.3 流体系统·主推进剂阀','原结构实例B，身份与位置独立',['两个实体阀的一致性、各自驱动和密封状态未验证。']),
('管路与随附原件：连接大部件','现在把管路、接头和随附原件放回原处。它们联系起大部件，原有的弯曲走向与接口位置，也随着源模型一起保留。','源书把管路归为流体系统。该视觉分组另含源树中未由前述组覆盖的随附原件；它不是新定义的单一工程子系统，也不演示其中任何运行过程。','2.3.1 推进系统；2.3.3 流体系统','按源补集归组，保持原走向',['实体连接的泄漏、弯曲受力、承压和各随附件功能未验证。']),
('尾翼一：翼面如何连到结构','尾翼从气流中受到作用力，支架把这些作用传给箭体结构。先归位第一组，看看翼面与长支架怎样相连。','源书说明尾翼固定在推力结构支架上。高层原理是翼面受到空气作用，而连接结构传递作用力；这里只能观察源几何的连接关系。','2.3.5 推进系统结构连接；图2.20','展示受力关系，未验证稳定性',['实体紧固、材料强度、气动载荷和稳定性未验证。']),
('尾翼二：相同组件的另一方向','第二组尾翼转到箭体的另一侧。外形相同，位置却不同；保留这些真实实例，才能看清翼面围绕箭体的分布。','这一组是源Fin Bracket Assembly的第二实例，身份由原路径确定。环绕分布来自原坐标，不由影片按对称外观补造。','2.3.5 推进系统结构连接；图2.20','保留源实例2',['实体安装角度与接触、紧固状态未测；不作稳定性结论。']),
('尾翼三：继续看环绕关系','第三组继续归位。现在可以把不同方向的翼面与同一段箭体联系起来，理解外形分布，而不是把它们看成重复图片。','第三实例按自身源位置归位。影片解释多个真实实例的空间关系，没有用同一张截图代替，也没有新增对称复制件。','2.3.5 推进系统结构连接；图2.20','保留源实例3',['实体装配误差、连接刚度和空气作用未测。']),
('尾翼四：完整保留四个实例','第四组归位后，四组翼面和支架的原始分布就清楚了。它们共同参与传递空气作用，但画面本身不能证明飞行稳定。','四组均来自整箭源树的真实实例。几何分布可以对照原CAD；稳定性需要独立的气动、质量分布与实际验证，不能由归位画面推出。','2.3.5 推进系统结构连接；2.5 飞行分析仅作验证范围线索','四源实例齐全，未验证气动稳定性',['没有因四组外观归位而执行或通过气动稳定性、载荷或飞行验证。']),
('电子舱：模块与上下段的连接','电子舱既容纳电子模块，也连接上下两段箭体。画面保留原模块与托板的位置；源模型没有表达的布线，不凭想象补出。','源书将电子舱描述为回收电子件的容纳空间，也用作上下箭体之间的连接筒。此处说明物理位置与承载关系，不演示电路、控制或火工功能。','2.3.6 箭体与回收系统·电子舱；图2.23、2.25','原模块／原托板，不补布线',['实体电路、接线、电源、传感器与控制功能未验证。']),
('回收组：认清原作的简化模型','回收组在原图里是五种简化模型，共六个实例。它们表示收纳空间与部件关系，并不是已经展开的伞，也不是织物细节。','本段几何身份以原CAD的MassVolume命名为依据：两类伞、两类保护件与连接绳的五种定义，连接绳出现两次。源书说明回收系统的减速和连接角色，但这些几何没有表达织物、绳结、折叠或展开动力学。','2.3.6 箭体与回收系统·减速伞、主伞、减震绳；源CAD MassVolume命名','源MassVolume：5种定义／6实例',['实体织物、绳索、收纳与展开可靠性未验证；未新造布伞或绳结。']),
('下段外壳：围住内部空间','下段外壳围住内部的回收空间，并连接电子舱与下方结构。筒壁回到原位置后，内外部件之间的层次就更容易理解。','源书把下段箭体描述为减速伞容纳空间，并说明它与电子舱及下部接口相接。本段按单个源外壳边界展示位置，不把筒壁扩大、缩短或补厚。','2.3.6 箭体与回收系统·下段箭体管','按源外壳边界归位',['实体接触、配合间隙、材料和连接承载未验证。']),
('上段外壳：连接电子舱与鼻锥','上段外壳包围上部的回收空间，两端分别与电子舱和鼻锥相接。这里按照原件边界归位，保留它与相邻组件的原始关系。','源书描述上段箭体容纳主伞，并与电子舱及鼻锥相接。该段只显示原边界和原位置，不把相邻件合并为一个新外壳。','2.3.6 箭体与回收系统·上段箭体管','保留上段原件边界',['实体配合、连接受力与回收分离功能未验证。']),
('鼻锥：前端外形与内部源结构','鼻锥让箭体前端形成连续外形，内部保留源件已有的连接结构与空间。它由多个原件组成，不能用一个光滑外壳代替。','源书说明鼻锥封闭箭体前端，并提供内部空间及回收连接身份。这里保留源多段结构和已建模内部件，不把外部曲面当作完整内部细节。','2.3.6 箭体与回收系统·头锥；图2.28','多段原件与原内部结构',['实体气动阻力、层间强度、连接承载与回收功能未验证。']),
('连接件与辅助件：对齐全部源节点','最后归位连接件与原树保留的辅助件。所有源节点回到原坐标，完成数字模型的对照；辅助件是否随实物飞行，需要另核。','剩余组由整箭源网格的精确集合补集确定，含连接件、导向件，以及原树中保留的钻孔辅助塞。该辅助件的源命名表明其工具身份；按源保留不等于宣称它应随箭飞行。','2.3.6 箭体与回收系统；原CAD源名与完整集合补集','包含源树保留的辅助件',['实体完整配置、工具移除状态、装配约束和实物可靠性未认证。']),
]
def han(s):return len(re.findall(r'[\u4e00-\u9fff]',s))
intro='接下来，我们按原始设计图逐组归位，看清部件之间的关系。这是数字模型的讲解顺序，不是实物施工步骤，也不代表已经通过实物检验。'
outro='所有源节点都已回到原坐标，几何核对通过。它证明数字展示与原模型对齐；实体的接触、密封、强度和飞行可靠性，还需要各自的验证。'
rows=[]
for s,c in zip(stage_data['stages'],content):
    title,text,principle,section,tag,not_done=c;count=han(text);assert 30<=count<=60,(s['id'],count)
    r={'stage_id':s['id'],'title_zh':title,'narration_zh':text,'han_character_count':count,'principle_zh':principle,'short_screen_note_zh':tag,
        'source_mesh_occurrences':s['mesh_count'],'source_hidden_mesh_occurrences':s['source_hidden_mesh_count'],'source_subtree_paths':s['source_subtree_paths'],
        'source_cad_filenames':sorted(set(s['source_subtree_cad_files'].values())),
        'geometric_qc_done':[f"本阶段{s['mesh_count']}个源网格实例已在互斥、完整分区中核对；网格实例数不是实物零件数。",'归位时源对象局部与世界矩阵逐项数值差为0；这是数字坐标对照，不是实体公差。','沿用原网格数据和源显隐记录，未补造、加厚或简化本阶段源几何。'],
        'geometric_qc_measurement':s['geometric_qc_result'],'physical_qc_not_done':not_done,
        'source_references':[{'id':'HCR-5100-R01','kind':'supplied primary guidebook, verified against official Git blob','url':book_url,'section':section,'local_translation':str(book_local),'claim_scope':'仅本段高层部件身份、角色和关系，不提取制造或运行步骤。'},{'id':'STAGE-'+s['id'],'file':'assembly-stages.json','stage_id':s['id']},{'id':'ALIGNMENT-QC','file':'alignment-qc.json','scope':'本段与终态数字几何对齐结果'}],
        'existing_visual_time_reference_only':{'start':s['start_seconds'],'end':s['end_seconds']},'formal_audio_status':'not generated; internal source-claim review pending'}
    if s['id']=='15':r['source_cad_filenames']=sorted({v['source_cad_filename'] for v in s['mesh_source_records'] if v.get('source_cad_filename')})
    rows.append(r)
result={'schema_version':1,'status':'draft for parent internal source-claim review; formal TTS not started','language':'zh-CN','title_zh':'从原件到整箭：十五组源CAD视觉归位','scope_zh':'原CAD静态部件的视觉归位与高层原理讲解；不是实物制造、施工、操作或认证。','source_lod':stage_data['lod'],'source_triangle_count':stage_data['source_triangle_count'],'source_stage_file_sha256':hashlib.sha256(source_path.read_bytes()).hexdigest(),'source_alignment_qc_file_sha256':hashlib.sha256(qc_path.read_bytes()).hexdigest(),
    'intro':{'title_zh':'先说明我们在看什么','narration_zh':intro,'han_character_count':han(intro)},'stages':rows,'outro':{'title_zh':'几何对齐证明了什么','narration_zh':outro,'han_character_count':han(outro)},
    'global_geometric_qc':{k:v for k,v in qc.items() if k!='objects'},'not_claimed':['实物装配配合或无碰撞可达性','密封、材料、强度、运行或飞行可靠性','原BOM每行物料具有独立CAD','MassVolume具备织物细节或展开动力学','辅助件属于最终飞行配置'],
    'timing_policy':'以每段实际生成音频测量的时长为准重新计时；不按汉字均分，也不把当前6秒片段当作正式时长。','delivery_style':'自然、平静、清楚地解释；句间留真实停顿；不变速，不模仿或自称特定真人。','total_han_character_count':han(intro)+han(outro)+sum(r['han_character_count'] for r in rows)}
(folder/'narration-draft.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
md=['# 十五段虚拟归位：旁白、原理与核对草稿','', '这是供内部核对源事实的草稿；正式全片音频尚未生成。讲解次序跟随真实CAD分区，只解释部件关系。影片中的平移与归位属于读图安排，不给出实物制造或操作步骤。','',f"原分区完整且互斥，覆盖 {stage_data['source_mesh_count']} 个源网格实例。终态实测 {qc['source_objects_checked']} 个源对象的局部与世界矩阵最大逐项数值差均为 0；这个结果是数字坐标一致性，不是实体公差、配合、密封或可靠性认证。源隐藏记录继续保留。影片输入是上游转换器的LOD1三角化版本，完整源层级与实例仍保留；高细节LOD3另有交付，二者均不称数学无损曲面。",'', '## 片头','',intro,'','片头与片尾集中说明范围，关键阶段只留简短字幕。正式时长将取自实际语音，不按字数推定。','']
for r in rows:
    md += [f"## {r['stage_id']}　{r['title_zh']}",'',f"**旁白（{r['han_character_count']}汉字）：**{r['narration_zh']}",'',f"**原理：**{r['principle_zh']}",'',f"**短字幕：**{r['short_screen_note_zh']}",'','**已做几何核对：**'+ ' '.join(r['geometric_qc_done']),'','**未做实体核对：**'+' '.join(r['physical_qc_not_done']),'',f"**依据：**[HCR-5100 R01 原书]({book_url})，{r['source_references'][0]['section']}；[源分区](assembly-stages.json) 第{r['stage_id']}组；[对齐实测](alignment-qc.json)。",'']
md += ['## 片尾','',outro,'','## 给剪辑与配音的交接','', '每段自然讲完再换组；可在句间留空，让观众辨认真实源部件。当前动画的六秒分段只是既有画面参考，不约束配音。待内部核对源事实与样音后，再生成正式音频，以真实音频时长重新安排影片。','', '四组尾翼按源实例编号分别出现；电子舱不补布线；回收组为五种定义、六实例的MassVolume；最后一组包含源树保留的钻孔辅助塞，不能把它笼统说成随箭飞行零件。HCR-5105 修订件保持独立资料身份，不默默装入这部主R01归位影片。','']
(folder/'逐段原理与核对.md').write_text('\n'.join(md))
print(json.dumps({'stages':len(rows),'mesh_occurrences':sum(r['source_mesh_occurrences'] for r in rows),'han_counts':[r['han_character_count'] for r in rows],'total_han':result['total_han_character_count'],'intro_han':han(intro),'outro_han':han(outro),'formal_audio':'not started'},ensure_ascii=False))
