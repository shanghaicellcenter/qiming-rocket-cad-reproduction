"""Refresh media facts only; keep earlier independently checked geometry evidence."""
from pathlib import Path
import datetime, hashlib, json, re, wave

root = Path(__file__).resolve().parent.parent
audit_path = root/'work/delivery-completion-audit.json'
md_path = audit_path.with_suffix('.md')
data = json.loads(audit_path.read_text())
if data.get('current_movie'):
    raise SystemExit('Final A/V audit already exists. Use refresh-completion-after-final-av.py; do not restore the historical raw-candidate snapshot.')
read = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
voice_root = root/'work/assembly-film/breeze-prep/collected'
voice = read(voice_root/'breeze-candidate-manifest.json')
asr_root = root/'work/assembly-film/breeze-prep/asr-text-review/results'
tracks = []
for clip in voice['clips']:
    wav = Path(clip['wav_file'])
    wav = wav if wav.is_absolute() else voice_root/wav
    assert sha(wav) == clip['wav_sha256']
    with wave.open(str(wav)) as w:
        duration = w.getnframes()/w.getframerate()
        assert w.getnframes()>0 and w.getnchannels()==clip['channels']
    asr_path = asr_root/clip['id']/(clip['id']+'.asr.json')
    asr = read(asr_path) if asr_path.is_file() else None
    if asr is not None:
        assert asr['input_wav_sha256'] == clip['wav_sha256']
    tracks.append(dict(id=clip['id'],wav_sha256=clip['wav_sha256'],duration_seconds=duration,
        actual_wav_header_checked=True,eligible_for_final_movie=clip.get('eligible_for_final_movie',False),
        asr_file_present=asr is not None,asr_file=str(asr_path) if asr is not None else None,
        asr_sha256=sha(asr_path) if asr is not None else None,asr_input_wav_sha_matches=asr is not None,
        asr_word_records_present=bool(asr and asr.get('words')),
        asr_semantic_or_listening_pass_claimed_by_this_audit=False))
assert len(tracks) == 17
data['voice_candidates'] = dict(engine=voice['engine'],actual_nonempty_wav_files=len(tracks),
    total_original_duration_seconds=sum(t['duration_seconds'] for t in tracks),
    eligible_for_final_movie=voice['eligible_for_final_movie'],asr_records_locally_present=sum(t['asr_file_present'] for t in tracks),
    actual_asr_root=str(asr_root),asr_count_basis='actual dedicated ASR files parsed and input WAV SHA matched; candidate manifest ASR pointers are not used',
    asr_presence_does_not_imply_semantic_or_listening_acceptance=True,
    count_correction='Prior snapshot counted 0 from unpopulated candidate-manifest ASR pointers; corrected using actual dedicated ASR directory.',tracks=tracks)
silent_path = root/'work/assembly-film/movie-review-qiming/current-review.json'
silent = read(silent_path)
assert sha(Path(silent['movie'])) == silent['movie_sha256'] and isinstance(silent['visual_review'],dict)
data['current_silent_movie'] = dict(sha256=silent['movie_sha256'],strict_decode_passed=silent['strict_decode']['exit_code']==0,
    video=silent['ffprobe'],visual_review_complete_for_documented_samples=True,final_voiced_movie_accepted=False)
for record in data['observed_evidence_files']:
    if Path(record['path']).resolve() == silent_path.resolve():
        record.update(bytes=silent_path.stat().st_size,sha256=sha(silent_path))
items = data['remaining_items'] + data.get('evidence_boundaries',[])
data['remaining_items'] = [r for r in items if r['id'] in ('final_audio','final_av_mux','bom62_images')]
data['evidence_boundaries'] = [r for r in items if r['id'] in ('slddrw_native','physical_all_details','real_world_usable')]
assert len(data['remaining_items'])==3 and len(data['evidence_boundaries'])==3
data['snapshot_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
data['incremental_update_scope'] = 'Only actual 17 candidate WAV headers/hashes, available dedicated ASR JSON and source WAV hashes, current silent review, and pending-vs-boundary classification refreshed. Prior geometry/image verification was not rerun.'
data['overall_status'] = 'Provided source geometry/imagery and current silent picture master verified; three core pending deliveries: final audio acceptance, retimed narrated/subtitled movie, and BOM supplemental image integration. Native SLDDRW failure, unmodeled source detail and physical certification are separate evidence boundaries.'
audit_path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')

text = md_path.read_text()
text = re.sub(r'核对时间：[^。]+。',f"核对时间：{data['snapshot_utc']}。",text,count=1)
text = re.sub(r'^\|逐步视频\|.*$',f"|逐步视频|静音基底SHA `{silent['movie_sha256']}`，6596帧、1280×720、30fps、219.866667秒；完整严格解码与分章/边界抽查通过。06—09整组范围说明及第09章“随后”说明已增量复核；其余16章32张中间/返回帧像素与上版相同。|0音轨，尚未验收最终原速中文旁白、按实际声长重定时、字幕与合音版。|",text,flags=re.M)
n = data['voice_candidates']['asr_records_locally_present']
text = re.sub(r'^\|中文旁白\|.*$',f"|中文旁白|17个Breeze候选WAV实际存在、逐项SHA和WAV头通过，总原速时长{data['voice_candidates']['total_original_duration_seconds']:.3f}秒；实际专用目录发现{n}/17份ASR，逐份JSON可解析且输入WAV SHA匹配。|候选清单eligible_for_final_movie仍为{str(voice['eligible_for_final_movie']).lower()}；ASR文件存在不代表语义、真实声学分句、字幕映射或试听验收完成。|",text,flags=re.M)
if '当前交付待办只有三项' not in text:
    text = text.replace('当前还没有把任何有声影片写成完成。','当前交付待办只有三项：最终音频验收、重定时合音字幕成片、62条BOM补图实际接入与核对。另有三项证据边界单列：SLDDRW原生读取失败、源资料未表达的实物细节、缺乏本复现的实体工作/飞行认证。目录和格式转换成功不会自动消除这些边界。\n\nASR按实际路径`work/assembly-film/breeze-prep/asr-text-review/results/<id>/<id>.asr.json`计数，原候选manifest中暂空的ASR指针不作数量依据；此前0份的快照已更正。本次只刷新实际媒体与ASR状态，没有重复核验未变的615张图片和几何。\n\n当前还没有把任何有声影片写成完成。')
md_path.write_text(text)
print(json.dumps(dict(silent_sha=silent['movie_sha256'],actual_asr_files=n,asr_expected=17,voice_eligible=voice['eligible_for_final_movie'],core_pending=3,evidence_boundaries=3),ensure_ascii=False))
