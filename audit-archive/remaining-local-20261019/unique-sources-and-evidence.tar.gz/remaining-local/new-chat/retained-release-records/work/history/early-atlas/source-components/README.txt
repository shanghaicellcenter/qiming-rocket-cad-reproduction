SOURCE-ORIGINAL PASSIVE COMPONENT ATLAS — NOT A COMPLETE ROCKET REPRODUCTION

The ten model objects use original native STL triangulation, without geometry
repair, simplification, replacement primitives or inferred internal parts.
Only passive nose-cone, avionics structure and exterior bracket-tip components
were extracted through a strict allowlist. Original ZIP archives are untouched.

All component-relative proportions are retained, including relative scale among
the ten objects. The grid placement, surface shading, materials, lights, platforms
and cameras are presentation choices. Source STL does not declare units; no
engineering unit conversion is made. True assembly transforms are unavailable.

SOURCE_NATIVE_GEOMETRY_UNALTERED is a hidden collection of original coordinates.
DISPLAY_GRID_SOURCE_MESHES shares that mesh data and adds display translation.
Studio objects, labels and platforms are not original project parts.

The aerodynamic fin itself is SLDPRT-only in the inspected source. The displayed
fin bracket tip is a different component and is explicitly labelled as such.
Airframe, sled, pressure, propulsion, pyrotechnic and other unsupported or excluded
components are absent. No full assembly, operation, engineering performance or
manufacturability is asserted. Mesh defects of source STL remain documented.
