"""Independent signal audit of final AAC against approved, unsped processed PCM.

This checks source identity, exact combined-WAV placement, AAC timing/correlation,
and per-track head/middle/tail drift. It does not claim human listening acceptance.
"""
from pathlib import Path
import argparse, datetime, hashlib, json, math, subprocess, wave
import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_text())

def wav_pcm(path):
    with wave.open(str(path), 'rb') as f:
        assert (f.getnchannels(), f.getsampwidth(), f.getframerate()) == (1, 2, 24000), str(path)
        frames = f.getnframes()
        raw = f.readframes(frames)
    assert len(raw) == frames*2
    return np.frombuffer(raw, dtype='<i2').copy(), raw

def correlation(reference, decoded, expected_start, maximum_lag=2400):
    """Normalized FFT correlation; positive lag means decoded sound is later."""
    x = reference.astype(np.float64)/32768.0
    n = len(x)
    assert n > 256
    first = expected_start-maximum_lag
    last = expected_start+n+maximum_lag
    y = np.zeros(n+2*maximum_lag, dtype=np.float64)
    a, b = max(0,first), min(len(decoded),last)
    if b>a:
        y[a-first:b-first] = decoded[a:b].astype(np.float64)/32768.0
    centered = x-x.mean()
    energy = float(centered@centered)
    assert energy>1e-12, 'Reference must contain a nonconstant sound.'
    fft_n = 1 << (len(y)+n-2).bit_length()
    product = np.fft.rfft(y,fft_n)*np.fft.rfft(centered[::-1],fft_n)
    numerator = np.fft.irfft(product,fft_n)[n-1:len(y)]
    sums = np.concatenate(([0.0],np.cumsum(y)))
    squares = np.concatenate(([0.0],np.cumsum(y*y)))
    variance = np.maximum(0,(squares[n:]-squares[:-n])-(sums[n:]-sums[:-n])**2/n)
    denominator = np.sqrt(energy*variance)
    values = np.divide(numerator,denominator,out=np.full_like(numerator,-1.0),where=denominator>1e-12)
    best = int(np.argmax(values))
    lag = best-maximum_lag
    aligned = y[best:best+n]
    gain = float(np.sqrt(np.mean(aligned*aligned))/max(1e-12,np.sqrt(np.mean(x*x))))
    return dict(normalized_correlation=float(values[best]),lag_samples=lag,lag_seconds=lag/24000,
                rms_gain_db=20*math.log10(max(gain,1e-12)))

def self_test():
    rng = np.random.default_rng(8213)
    x = (rng.normal(size=48000)*2200).clip(-16000,16000).astype('<i2')
    origin, shift = 5000, 17
    y = np.zeros(70000,dtype='<i2')
    y[origin+shift:origin+shift+len(x)] = x
    result = correlation(x,y,origin)
    assert result['lag_samples']==shift and result['normalized_correlation']>0.999999
    wrong = rng.normal(size=70000).astype(np.float64)
    wrong = (wrong*2200).astype('<i2')
    assert correlation(x,wrong,origin)['normalized_correlation']<0.1
    print(json.dumps(dict(self_test='passed',known_offset_samples=shift,recovered=result,actual_movie_tested=False)))

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--movie',type=Path,default=ROOT/'outputs/启明火箭/media/逐步虚拟归位讲解.mp4')
    p.add_argument('--combined-wav',type=Path,default=ROOT/'outputs/启明火箭/media/逐步虚拟归位旁白.wav')
    p.add_argument('--timeline',type=Path,default=HERE/'final-timeline.json')
    p.add_argument('--manifest',type=Path,default=ROOT/'work/virtual-assembly/narration-audio-manifest.json')
    p.add_argument('--out',type=Path,default=HERE/'movie-audio-review')
    p.add_argument('--self-test',action='store_true')
    args = p.parse_args()
    if args.self_test:
        self_test();return
    for file in (args.movie,args.combined_wav,args.timeline,args.manifest):
        assert file.is_file(),str(file)
    manifest,timeline = read(args.manifest),read(args.timeline)
    assert manifest['eligible_for_final_movie'] is True
    assert len(manifest['tracks'])==len(timeline['clips'])==17 and timeline['fps']==30
    combined, combined_raw = wav_pcm(args.combined_wav)
    assert len(combined)==timeline['frames']*800
    assert abs(len(combined)/24000-timeline['duration'])<1/24000
    args.out.mkdir(parents=True,exist_ok=True)
    probe = subprocess.run(['/opt/homebrew/bin/ffprobe','-v','error','-show_streams','-show_format','-of','json',str(args.movie)],capture_output=True,text=True,check=True)
    (args.out/'ffprobe.json').write_text(probe.stdout)
    audio = [r for r in json.loads(probe.stdout)['streams'] if r['codec_type']=='audio']
    assert len(audio)==1 and audio[0]['codec_name']=='aac'
    decoded_path = args.out/'final-aac-decoded-24k-mono.pcm'
    command = ['/opt/homebrew/bin/ffmpeg','-y','-hide_banner','-v','error','-xerror','-err_detect','explode','-i',str(args.movie),'-map','0:a:0','-ac','1','-ar','24000','-c:a','pcm_s16le','-f','s16le',str(decoded_path)]
    decoded_run = subprocess.run(command,capture_output=True,text=True)
    (args.out/'decode.log').write_text(decoded_run.stderr)
    assert decoded_run.returncode==0,decoded_run.stderr
    decoded = np.fromfile(decoded_path,dtype='<i2')
    checks = []
    for track,clip in zip(manifest['tracks'],timeline['clips']):
        assert track['id']==clip['id']
        path = Path(track['wav_path'])
        assert sha(path)==track['wav_sha256']==clip['wav_sha256']
        pcm,raw = wav_pcm(path)
        origin = round(clip['audio_start']*24000)
        assert abs(len(pcm)/24000-clip['audio_duration'])<1/24000
        assert combined_raw[origin*2:(origin+len(pcm))*2]==raw,('Combined PCM changed or wrong track',track['id'])
        begin,end = round(clip['start']*24000),round(clip['end']*24000)
        assert not np.any(combined[begin:origin]) and not np.any(combined[origin+len(pcm):end])
        whole = correlation(pcm,decoded,origin)
        active = np.flatnonzero(np.abs(pcm.astype(np.int32))>=33)
        assert len(active)>0
        width = min(18000,len(pcm))
        starts = dict(head=max(0,min(int(active[0]),len(pcm)-width)),
                      middle=max(0,min((int(active[0])+int(active[-1])-width)//2,len(pcm)-width)),
                      tail=max(0,min(int(active[-1])+1-width,len(pcm)-width)))
        windows = {name:correlation(pcm[start:start+width],decoded,origin+start) for name,start in starts.items()}
        lag_range = max(r['lag_samples'] for r in windows.values())-min(r['lag_samples'] for r in windows.values())
        passed = whole['normalized_correlation']>=.98 and abs(whole['lag_samples'])<=480 and abs(whole['rms_gain_db'])<=.5 and lag_range<=48 and all(r['normalized_correlation']>=.97 for r in windows.values())
        checks.append(dict(id=track['id'],processed_wav_sha256=sha(path),actual_processed_pcm_samples=len(pcm),combined_sample_start=origin,
                           combined_pcm_exactly_matches_processed_wav=True,lead_tail_exact_digital_silence=True,
                           whole_track=whole,head_middle_tail=windows,head_to_tail_lag_range_samples=lag_range,
                           head_to_tail_lag_range_seconds=lag_range/24000,objective_signal_checks_passed=passed))
    all_lags=[r['whole_track']['lag_samples'] for r in checks]
    drift=max(all_lags)-min(all_lags)
    difference=len(decoded)-len(combined)
    passed=all(r['objective_signal_checks_passed'] for r in checks) and drift<=48 and abs(difference)<=1024
    result=dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),movie=str(args.movie.resolve()),movie_sha256=sha(args.movie),combined_wav_sha256=sha(args.combined_wav),timeline_sha256=sha(args.timeline),canonical_manifest_sha256=sha(args.manifest),
                sample_rate=24000,combined_pcm_samples=len(combined),decoded_aac_pcm_samples=len(decoded),encoded_decoded_length_difference_samples=difference,
                encoded_decoded_length_difference_seconds=difference/24000,cross_track_lag_range_samples=drift,
                tolerance=dict(aac_frame_padding_samples=1024,whole_track_correlation_minimum=.98,head_middle_tail_correlation_minimum=.97,
                               absolute_lag_max_seconds=.020,within_and_across_track_lag_range_max_seconds=.002,rms_gain_difference_max_db=.5),
                tracks=checks,objective_signal_checks_passed=passed,human_listening_performed=False,
                scope='Checks decoded encoded-AAC signal against exact placed processed PCM. Compression tolerance is explicit; no voice naturalness, pronunciation, or human acceptance claim.',
                decode_command=command,decoded_pcm_sha256=sha(decoded_path))
    (args.out/'encoded-audio-review.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(dict(tracks=len(checks),objective_signal_checks_passed=passed,decoded_minus_reference_samples=difference,cross_track_lag_range_samples=drift,human_listening_performed=False)))
    assert passed,'Inspect encoded-audio-review.json; do not infer acceptance from audio-stream presence.'

if __name__=='__main__':
    main()
