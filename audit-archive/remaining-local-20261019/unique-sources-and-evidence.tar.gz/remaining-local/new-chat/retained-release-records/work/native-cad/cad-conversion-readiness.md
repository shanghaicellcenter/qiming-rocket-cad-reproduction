# 原生 CAD 转换实测与交付准备

当前结果：主 R01 的 133 份原生 CAD 加独立修订的 1 份原生 CAD，合计 **134/134 源记录**完成非空 USD 转换。源内容、回传输出及版本身份分别核对，全部通过。环境与远端库保留，后续停止新增转换。此结论是读取、文件完整性和层级一致性结论；视觉验收由主展示流程另行完成。

## 实际运行环境与安装来源

- 用户自有 DGX Spark，Linux aarch64，Python 3.12.3，glibc 2.39。
- 隔离环境：`/home/qianqiming/codex-mojave-cad-review-20261019/venv`，实际文件大小约 585.9 MB。未作全局安装。
- 官方包版本：`usd-convert-cad==0.3.0`，wheel 为 `usd_convert_cad-0.3.0-cp312-cp312-manylinux_2_35_aarch64.whl`，128,203,738 bytes。
- wheel SHA256：`1df28edbfeeb734e2acf2e87f80c295414225c847e6b18640a14089e7b9f61d6`。
- 真实首次安装从机器已配置的清华 PyPI 镜像取得包；随后仅官方 PyPI 索引的核对命令显示该版本已安装。安装缓存中实际 wheel body 的哈希、字节数与官方 PyPI 发布记录完全相同，证据在 `wheel-origin-verification.json`，没有把“官方索引复核”冒充首次下载来源。
- 本次真实运行未要求账户、付费、试用、API key 或额外 entitlement；没有创建这些内容、绕过许可检查或申请试用。此事实不等于对其他用途作商业许可保证。读取器及其嵌入 CAD 库仍依原官方许可。
- 官方 CLI 帮助已保存在 `help.txt`。采用其内置 USD runtime；Linux 进程按官方包设置的动态库路径重新执行一次后读取 USD，没有安装另一套 pxr 覆盖。

## 读取验证与完整库

| 阶段 | 实际结果 | 审计结果 |
| --- | --- | --- |
| 安全外观尾翼 fin 读取测试 | 7,792 bytes，304 面，转换 3.668 秒 | 1 非空网格、10 prim；输入前后哈希一致 |
| 原整箭 assembly，LOD3 | 70,328,219 bytes，7,070,568 面，转换 45.872 秒 | 688 非空 mesh occurrence、635 component-kind 节点、3,428 prim |
| 主 R01 独立零件库 | 119/119 SLDPRT，共约 71.0 MB | 全部非空；每件源/输出哈希核对 |
| 主 R01 其余装配库 | 13/13 SLDASM，共约 193.1 MB | 全部非空；每件源/输出哈希核对 |
| 独立修订原生件 | 1/1 SLDPRT，45,580 bytes、2,696 面，转换 5.859 秒 | 1 非空网格、10 prim；独立版本目录，未覆盖主包 |
| 同源可选 LOD1 整箭 | 30,735,705 bytes，2,864,600 面，转换 27.028 秒 | 688 非空 mesh occurrence；源组件层级及变换一致 |

主 R01 共 119 SLDPRT + 14 SLDASM = 133 份源 CAD。119 + 13 个独立转换作业以 3 并发完成，含 USD 审计总 164.263 秒。fin 是同源读通验证，已在 119 零件库中，不重复计数；LOD1 是整箭的另一个曲面三角化精度选项，也不增加源 CAD 件数。

完整主库位于本地 `library/parts/` 和 `library/assemblies/`；原整箭为 `vehicle.usdc`。主库文件、日志和审计总约 277.6 MB。修订件位于 `patches/HCR-5105/`；即使同名也不与主 R01 混合。全部原 ZIP、环境、读取脚本和输出同时保留在 Spark 的 `~/codex-mojave-cad-review-20261019/`，未改动用户原始本地文件。

## 精度、单位与层级

所有细节版转换使用官方 CLI 的 `--tess-lod 3 --instancing-style reference --composition-style none --filter-style hide --load-hidden`。LOD1 仅将 `--tess-lod` 设为 1；没有替换 LOD3。没有请求装配约束、物理数据、求解或操作仿真，没有补造新几何。

原件是 CAD B-rep，经读取器转为 USD 曲面网格；这些三角面不是原 STL 的三角面。LOD3 代表本次明确选择的读取器细节选项，不是对原 CAD 曲面与三角网格绝对相等的声明。LOD1 比完整版本更粗，需在界面明确说明。

USD 声明单位为 0.0254 m/unit、Y-up，转换器的单位 wrapper 与原局部变换保留。`vehicle.lod-comparison.json` 排除仅随输出文件名改变的前两层 wrapper 后，核对到 654 个源 component/group 节点的路径、名字、局部变换、可见性与 688 网格 occurrence 路径完全一致。两版同一个源 assembly 哈希一致。

审计用 `Usd.PrimRange(stage.GetPseudoRoot(), Usd.TraverseInstanceProxies())` 防止漏过实例代理。实际输出使用非 instanceable reference，native instance/prototype 数为 0。145 个 points attribute provider 是复用几何定义计数；688 个 mesh occurrence 是网格数量；二者都不是工程独立零件数量，也不代替 CAD occurrence/component 名称层级。默认 USD 的 displayName、kind 和 reference 信息足以做名称导航，没有为此提取制造参数。

## 身份覆盖与边界

- `library.coverage.json`：独立逐个读取主 R01 原 ZIP，133/133 源 CAD 字节哈希与转换记录匹配，133/133 本地 USD 哈希与输出 manifest 匹配；没有缺失或额外 basename。
- `native-source-readiness.json`：使用 **archive + relative_path** 身份连接全项目 221 个 CAD 文件记录中的全部 134 个 native 记录，含 120 SLDPRT 和 14 SLDASM；主包 133、修订包 1，全部有对应非空 USD。剩余 87 条为 STEP/STL/SLDDRW/DXF 等其他格式记录；不是新增的 87 个实体零件。
- `library.index.json`：主 R01 的 133 条相对 USD 路径与源/输出哈希，可供逐件库使用；修订映射在上述完整 native readiness JSON。
- `patches/HCR-5105/independent-verification.json`：修订原 ZIP、源 member 和本地 USD 哈希独立一致。
- 所有作业日志中许可错误、缺引用匹配为 0。日志无缺引用并不证明原作者的 CAD 自身无遗漏，也不等于装配正确性验证。
- 按原文件名做 provenance 对照时，整箭名称映射覆盖 112/119 主包源零件和 13/14 源装配。其余夹具、模板或未名称匹配的源件均已独立转换。因此总览 assembly 与整个源目录应分别提供浏览入口。
- 源 BOM 共 172 行，含原料、包装采购单位、耗材和 GSE 等；BOM 行数不能等同可视化实体数量、mesh 数量或装配 occurrence 数量，不能按行数补造零件。
- 源文件名标为 `Mass Volume` 的部件本来就是源作者给的体积/质量占位或简化形体。本流程忠实保留它们，没有新增简化，也不把它们宣称为实物每个细部已经建模。

## 原始哈希与复现材料

- 主 R01 ZIP：`a7af67f407d2729f70154a7f5b98113c31b8249661527d6a9ed72e67e68b4dd5`。
- 整箭 LOD3 USD：`93be117e7bdd28f2ccba30a532f8c9eb728fdf0857d63e8d12c24dd4b21d1d58`。
- 整箭 LOD1 USD：`dc1a1c6a7d205bd09ce5cfc448cc7537731f2556d10e2b297935f5549d83f3c1`。
- 独立修订 ZIP：`812c5d508c2e7f2815dd2df641a7b85bc72bd4668f210aa3aafc6648999f1fb2`。
- 独立修订 USD：`fb8a21a7aa17392a9eebd4658738fae4bbff2d09e0521a2a8cb5a88100361fe1`。

逐件 `.conversion.json` 保存原输入/输出路径、实际命令、输入前后哈希、输出哈希和耗时；`.hierarchy.json` 保存可视化层级/变换；`.validation.json` 保存网格审计。安装、转换及回传已结束，保留环境和库以便核验与复现。后续无需重新安装读取器或再次转换才能使用现有 USD。
