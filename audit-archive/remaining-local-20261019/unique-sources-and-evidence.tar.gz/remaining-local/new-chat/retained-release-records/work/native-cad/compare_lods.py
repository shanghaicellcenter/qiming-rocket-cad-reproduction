"""Compare source hierarchy and transforms of detail/browse USD audit snapshots."""
import json
from pathlib import Path

root = Path(__file__).resolve().parent

def load(stem, kind):
    return json.loads((root / f"{stem}.{kind}.json").read_text())

def canonical(path):
    # The converter names the two output wrapper roots from the output stem.
    return "/".join(path.split("/")[3:])

detail = load("vehicle", "validation")
browse = load("vehicle-browse", "validation")
dh = load("vehicle", "hierarchy")["prims"]
bh = load("vehicle-browse", "hierarchy")["prims"]

def components(rows):
    return {canonical(p["path"]): {k: p[k] for k in ("display_name", "kind", "local_transform", "visible")}
            for p in rows if p["kind"] in ("component", "group") and canonical(p["path"])}

dc, bc = components(dh), components(bh)
dm = {canonical(p["path"]) for p in detail["meshes"]}
bm = {canonical(p["path"]) for p in browse["meshes"]}
result = {
    "detail_lod": 3, "browse_lod": 1,
    "same_input_sha256": load("vehicle", "conversion")["input_sha256_after"] == load("vehicle-browse", "conversion")["input_sha256_after"],
    "same_units": detail["meters_per_unit"] == browse["meters_per_unit"],
    "same_up_axis": detail["up_axis"] == browse["up_axis"],
    "same_component_group_paths": set(dc) == set(bc),
    "excluded_output_wrapper_note": "The first two converter-generated prims depend on output basename; they are excluded from source CAD component comparisons.",
    "same_component_group_names_local_transforms_visibility": dc == bc,
    "detail_component_group_nodes": len(dc), "browse_component_group_nodes": len(bc),
    "same_mesh_occurrence_paths": dm == bm,
    "detail_mesh_occurrences": len(dm), "browse_mesh_occurrences": len(bm),
    "detail_face_count": detail["face_count"], "browse_face_count": browse["face_count"],
    "detail_bytes": detail["bytes"], "browse_bytes": browse["bytes"],
    "detail_only_component_group_paths": sorted(set(dc) - set(bc)),
    "browse_only_component_group_paths": sorted(set(bc) - set(dc)),
    "different_component_group_values": [p for p in sorted(set(dc) & set(bc)) if dc[p] != bc[p]],
    "detail_only_mesh_paths": sorted(dm - bm), "browse_only_mesh_paths": sorted(bm - dm),
    "scope": "LOD1 is an optional tessellation variant of the same original CAD; it does not replace LOD3 and is not a claim of equal surface accuracy.",
}
(root / "vehicle.lod-comparison.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
