"""Exact original STL component atlas; NOT a complete rocket reproduction.

Allowlisted passive exterior and avionics components only. Source mesh vertices
and triangle counts are preserved. Display placement/materials are independent
presentation choices; no original assembly transforms are asserted.
Factory Blender 5.2, local only. No CAD/pressure/propulsion archive is imported.
"""
import bpy,bmesh,json,math,sys,hashlib
from pathlib import Path
from mathutils import Vector
ROOT=Path('/Users/qianqiming/Documents/Codex/2026-10-19/new-chat')
WORK=ROOT/'work/mojave-display'
OUT=ROOT/'outputs/mojave-machine/source-components'
RENDERS=OUT/'renders'
for d in (WORK,OUT,RENDERS):d.mkdir(parents=True,exist_ok=True)
INDEX=ROOT/'work/safe-geometry-index.json'
index=json.loads(INDEX.read_text())
PASS=int(sys.argv[sys.argv.index('--review-pass')+1]) if '--review-pass' in sys.argv else 2
BLEND_WORK=WORK/'safe-component-atlas-stage.blend'

def mat(name,col,metal=0,rough=.38):
    m=bpy.data.materials.new(name);m.diffuse_color=(*col,1);m.use_nodes=True
    b=m.node_tree.nodes.get('Principled BSDF')
    b.inputs['Base Color'].default_value=(*col,1)
    b.inputs['Metallic'].default_value=metal;b.inputs['Roughness'].default_value=rough
    return m

def setcam(cam,loc,target,scale):
    cam.location=loc
    cam.rotation_euler=(Vector(target)-cam.location).to_track_quat('-Z','Y').to_euler()
    cam.data.type='ORTHO';cam.data.ortho_scale=scale;cam.data.clip_end=10000

def render(sc,path,cam=None,res=(1600,1000),samples=32,engine='CYCLES'):
    if cam:sc.camera=cam
    sc.render.engine=engine
    if engine=='CYCLES':
        sc.cycles.samples=samples;sc.cycles.use_denoising=True;sc.cycles.max_bounces=4
        sc.cycles.diffuse_bounces=2;sc.cycles.glossy_bounces=3
    sc.render.resolution_x=res[0];sc.render.resolution_y=res[1];sc.render.resolution_percentage=100
    sc.render.image_settings.file_format='PNG';sc.render.image_settings.color_mode='RGBA'
    sc.render.film_transparent=False
    sc.render.filepath=str(path)
    bpy.ops.render.render(write_still=True,scene=sc.name)

if PASS==2:
    for ob in list(bpy.data.objects):bpy.data.objects.remove(ob,do_unlink=True)
    sc=bpy.context.scene;sc.name='Original_STL_Component_Atlas'
    sc.unit_settings.system='NONE'
    sc['status']='10 source-original passive components; not a complete rocket assembly'
    sc['source_units']='STL does not declare units. Unconverted native coordinates.'
    sc['placement']='Display grid only; authoritative original assembly placement unavailable.'
    source_col=bpy.data.collections.new('SOURCE_NATIVE_GEOMETRY_UNALTERED')
    display_col=bpy.data.collections.new('DISPLAY_GRID_SOURCE_MESHES')
    studio_col=bpy.data.collections.new('STUDIO_NOT_SOURCE_COMPONENTS')
    for c in (source_col,display_col,studio_col):sc.collection.children.link(c)
    colors={'white':(.61,.64,.64),'red':(.26,.012,.02),'polymer':(.13,.17,.20),'metal':(.45,.53,.59)}
    materials={k:mat('Display_'+k,v,.62 if k=='metal' else .06,.29 if k in ('white','red') else .37) for k,v in colors.items()}
    original=[]
    for p in index['parts']:
        bpy.ops.wm.stl_import(filepath=p['local_stl'])
        ob=bpy.context.object
        assert len(ob.data.polygons)==p['triangles'],f"Triangle count changed: {p['id']}"
        ob.name='SOURCE_'+p['id']
        for c in list(ob.users_collection):c.objects.unlink(ob)
        source_col.objects.link(ob)
        ob['source_original']=True;ob['source_sha256']=p['sha256'];ob['source_zip_member']=p['zip_member']
        ob['source_unit_status']=p['unit_status'];ob['geometry_modified']=False
        ob['source_id']=p['id'];ob['not_complete_assembly']=True
        for f in ob.data.polygons:f.use_smooth=True
        if hasattr(ob.data,'set_sharp_from_angle'):ob.data.set_sharp_from_angle(angle=math.radians(38))
        ob.data.materials.append(materials[p['display_material']])
        original.append(ob)
    source_col.hide_render=True
    source_col.hide_viewport=True
    maxdim=max(max(p['native_bbox_size']) for p in index['parts'])
    cell=maxdim*1.55
    sc['display_cell']=cell;sc['display_maxdim']=maxdim
    objects=[]
    for i,(p,source) in enumerate(zip(index['parts'],original)):
        cp=source.copy();cp.data=source.data;cp.name='DISPLAY_'+p['id']
        display_col.objects.link(cp)
        lo=Vector(p['native_bbox_min']);hi=Vector(p['native_bbox_max']);c=(lo+hi)*.5
        col=i%5;row=i//5
        px=(col-2)*cell;py=(.5-row)*cell
        cp.location=Vector((px-c.x,py-c.y,-lo.z+maxdim*.035))
        cp['placement_status']='Presentation-only translation; no mesh rotation or scale; source coordinates retained in mesh data.'
        cp['source_bbox_min']=list(lo);cp['source_bbox_max']=list(hi)
        p['blender_vertices']=len(cp.data.vertices)
        p['blender_triangles']=len(cp.data.polygons)
        p['display_translation']=list(cp.location)
        p['display_scale']=[1,1,1]
        p['source_topology_preserved']=len(cp.data.polygons)==p['triangles']
        bm=bmesh.new();bm.from_mesh(cp.data)
        p['source_mesh_checks']={'boundary_edges':sum(e.is_boundary for e in bm.edges),
          'nonmanifold_nonboundary_edges':sum((not e.is_manifold and not e.is_boundary) for e in bm.edges),
          'loose_vertices':sum(not v.link_edges for v in bm.verts),
          'zero_area_faces':sum(f.calc_area()<1e-12 for f in bm.faces)}
        bm.free();objects.append(cp)
    # Ground and simple platforms are deliberately outside the source collection.
    groundmat=mat('Studio_Deep_Slate',(.085,.108,.127),.05,.58)
    padmat=mat('Studio_Pad',(.115,.145,.166),.09,.43)
    ink=mat('Studio_Label',(.51,.58,.60),0,.6)
    def relink(ob):
        for c in list(ob.users_collection):c.objects.unlink(ob)
        studio_col.objects.link(ob);ob['presentation_only']=True
    bpy.ops.mesh.primitive_plane_add(size=cell*30,location=(0,0,-maxdim*.03))
    floor=bpy.context.object;floor.name='Studio_Floor';relink(floor);floor.data.materials.append(groundmat)
    names=['01  NOSE / SECTION 1','02  NOSE / SECTION 2','03  NOSE / SHOULDER','04  NOSE / TIP',
      '05  BATTERY HOLDER','06  CENTERING RING','07  COUPLER / HALF','08  SLED MOUNT','09  SWITCHBAND','10  FIN BRACKET TIP']
    # Native relative scale is retained between every component on the grid.
    for i in range(10):
        px=(i%5-2)*cell;py=(.5-i//5)*cell
        bpy.ops.mesh.primitive_cube_add(size=1,location=(px,py,-maxdim*.008))
        pad=bpy.context.object;pad.name=f'Studio_Platform_{i+1:02d}';relink(pad)
        pad.dimensions=(cell*.90,cell*.88,maxdim*.025)
        bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
        be=pad.modifiers.new('Studio_Pad_Soft_Edge','BEVEL');be.width=maxdim*.018;be.segments=3
        pad.data.materials.append(padmat)
        text=bpy.data.curves.new(f'Label_{i+1:02d}','FONT');text.body=names[i]
        text.size=maxdim*.034;text.align_x='LEFT';text.extrude=0
        tob=bpy.data.objects.new(f'Studio_Label_{i+1:02d}',text);studio_col.objects.link(tob)
        tob.location=(px-cell*.415,py-cell*.37,maxdim*.012)
        tob.data.materials.append(ink);tob['presentation_only']=True
    world=bpy.data.worlds.new('Studio_World');world.use_nodes=True
    world.node_tree.nodes['Background'].inputs['Color'].default_value=(.12,.16,.20,1)
    world.node_tree.nodes['Background'].inputs['Strength'].default_value=.30;sc.world=world
    def area(name,rel,power,sz,color):
        data=bpy.data.lights.new(name,'AREA');data.energy=power*maxdim*maxdim
        data.shape='RECTANGLE';data.size=sz[0]*maxdim;data.size_y=sz[1]*maxdim;data.color=color
        lamp=bpy.data.objects.new(name,data);studio_col.objects.link(lamp)
        lamp.location=Vector(rel)*maxdim
        lamp.rotation_euler=(Vector((0,0,maxdim*.3))-lamp.location).to_track_quat('-Z','Y').to_euler()
        lamp['presentation_only']=True
    area('Studio_Key',(-1,-3,6),340,(7,4),(1,.92,.82))
    area('Studio_Rim',(1,3,4),380,(9,2),(.78,.88,1))
    area('Studio_Fill',(4,-2,2.8),70,(4,3),(.91,.97,1))
    cd=bpy.data.cameras.new('Atlas_Camera');cam=bpy.data.objects.new('Atlas_Camera',cd)
    sc.collection.objects.link(cam);cam['presentation_only']=True
    setcam(cam,(0,-maxdim*9,maxdim*9),(0,0,maxdim*.24),cell*5.55)
    sc.camera=cam
    sc.view_settings.view_transform='AgX';sc.view_settings.exposure=0
    try:sc.view_settings.look='AgX - Medium High Contrast'
    except TypeError:pass
    # Round 2: layout and geometry gate, not a finished beauty render.
    sc.display.shading.light='MATCAP';sc.display.shading.color_type='MATERIAL'
    mats=[x.name for x in bpy.context.preferences.studio_lights if x.type=='MATCAP']
    if mats:sc.display.shading.studio_light=next((x for x in mats if 'studio' in x),mats[0])
    sc.display.shading.background_type='WORLD';sc.world.color=(.16,.16,.16)
    sc.display.shading.show_shadows=True;sc.display.shading.show_cavity=True
    render(sc,WORK/'round02_atlas_geometry.png',res=(1600,1000),engine='BLENDER_WORKBENCH')
    index['source_geometry_loaded']=True
    index['native_relative_scale_retained_in_atlas']=True
    index['atlas_source_triangle_count']=sum(len(o.data.polygons) for o in objects)
    INDEX.write_text(json.dumps(index,ensure_ascii=False,indent=2))
    bpy.ops.wm.save_as_mainfile(filepath=str(BLEND_WORK))
    print('ATLAS_RESULT='+json.dumps({'round':2,'mesh_count':len(objects),'triangles':index['atlas_source_triangle_count'],'render':str(WORK/'round02_atlas_geometry.png')},ensure_ascii=False))
elif PASS in (3,4):
    bpy.ops.wm.open_mainfile(filepath=str(BLEND_WORK))
    sc=bpy.context.scene;cam=sc.camera
    maxdim=sc['display_maxdim'];cell=sc['display_cell']
    objects=[bpy.data.objects['DISPLAY_'+p['id']] for p in index['parts']]
    if PASS==3:
        # Round 3 uses the intended neutral studio materials. No geometry edits.
        render(sc,WORK/'round03_atlas_beauty.png',res=(1600,1000),samples=32)
        # Close-ups establish that small parts are actual geometry, not labels.
        p=index['parts'][4];ob=objects[4]
        center=ob.location+(Vector(p['native_bbox_min'])+Vector(p['native_bbox_max']))*.5
        size=max(p['native_bbox_size'])
        setcam(cam,center+Vector((1.4,-2.5,1.6))*size,center,size*1.8)
        render(sc,WORK/'round03_battery_holder_closeup.png',res=(1000,800),samples=32)
        p=index['parts'][9];ob=objects[9]
        center=ob.location+(Vector(p['native_bbox_min'])+Vector(p['native_bbox_max']))*.5
        size=max(p['native_bbox_size'])
        setcam(cam,center+Vector((1.5,-2.3,1.7))*size,center,size*1.8)
        render(sc,WORK/'round03_fin_bracket_tip_closeup.png',res=(1000,800),samples=32)
        setcam(cam,(0,-maxdim*9,maxdim*9),(0,0,maxdim*.24),cell*5.55)
        bpy.ops.wm.save_as_mainfile(filepath=str(BLEND_WORK))
        print('ATLAS_RESULT='+json.dumps({'round':3,'renders':[str(WORK/'round03_atlas_beauty.png'),str(WORK/'round03_battery_holder_closeup.png'),str(WORK/'round03_fin_bracket_tip_closeup.png')]}))
    else:
        # Compare original binary STL triangle coordinates directly to imported
        # mesh triangles. This verifies more than a matching face count.
        import numpy as np,struct
        dtype=np.dtype([('normal','<f4',3),('vertices','<f4',(3,3)),('attribute','<u2')])
        for p,ob in zip(index['parts'],objects):
            raw=Path(p['local_stl']).read_bytes()
            expected=np.frombuffer(raw,dtype=dtype,offset=84,count=p['triangles'])['vertices']
            actual=np.array([[tuple(ob.data.vertices[v].co) for v in f.vertices] for f in ob.data.polygons],dtype=np.float32)
            p['source_triangle_coordinate_array_unchanged']=bool(np.array_equal(expected,actual))
            p['source_triangle_coordinates_sha256']=hashlib.sha256(expected.astype('<f4').tobytes()).hexdigest()
            p['blender_triangle_coordinates_sha256']=hashlib.sha256(actual.astype('<f4').tobytes()).hexdigest()
            assert p['source_triangle_coordinate_array_unchanged'],f"Imported coordinate arrays changed: {p['id']}"
        # Final refinement selected after round 3 visual inspection. The global
        # exposure is the only brightness control, preserving light balance.
        sc.view_settings.exposure=-.25
        # The round-4 review caught a projected overlap between the front coupler
        # and a rear nose segment. A higher atlas camera resolves the overlap.
        setcam(cam,(0,-maxdim*9,maxdim*18),(0,0,maxdim*.24),cell*5.35)
        render(sc,RENDERS/'01_original_components_atlas.png',res=(2000,1300),samples=64)
        for n,(p,ob) in enumerate(zip(index['parts'],objects)):
            # Isolate the selected source object and its platform for a clear
            # component image. Presentation hiding does not change mesh data.
            for other in objects:other.hide_render=(other!=ob)
            for j in range(10):
                bpy.data.objects[f'Studio_Platform_{j+1:02d}'].hide_render=(j!=n)
                bpy.data.objects[f'Studio_Label_{j+1:02d}'].hide_render=(j!=n)
            c=ob.location+(Vector(p['native_bbox_min'])+Vector(p['native_bbox_max']))*.5
            size=max(p['native_bbox_size'])
            setcam(cam,c+Vector((1.4,-2.4,1.6))*size,c,size*1.75)
            render(sc,RENDERS/f'{n+2:02d}_{p["id"]}.png',res=(1200,1000),samples=48)
        for other in objects:other.hide_render=False
        for j in range(10):
            bpy.data.objects[f'Studio_Platform_{j+1:02d}'].hide_render=False
            bpy.data.objects[f'Studio_Label_{j+1:02d}'].hide_render=False
        # An oblique group view shows the source mesh surfaces under highlights.
        setcam(cam,(-maxdim*4,-maxdim*8,maxdim*8),(0,0,maxdim*.24),cell*5.6)
        render(sc,RENDERS/'12_oblique_components.png',res=(2000,1300),samples=64)
        setcam(cam,(0,-maxdim*9,maxdim*18),(0,0,maxdim*.24),cell*5.35)
        # Export native source data in a display grid; studio objects are omitted.
        bpy.ops.object.select_all(action='DESELECT')
        for ob in objects:ob.select_set(True)
        bpy.context.view_layer.objects.active=objects[0]
        glb=OUT/'original-safe-components-atlas.glb'
        bpy.ops.export_scene.gltf(filepath=str(glb),export_format='GLB',use_selection=True,
          export_extras=True,export_yup=True,export_animations=False,export_apply=False)
        notes='''SOURCE-ORIGINAL PASSIVE COMPONENT ATLAS — NOT A COMPLETE ROCKET REPRODUCTION

The ten model objects use original native STL triangulation, without geometry
repair, simplification, replacement primitives or inferred internal parts.
Only passive nose-cone, avionics structure and exterior bracket-tip components
were extracted through a strict allowlist. Original ZIP archives are untouched.

All component-relative proportions are retained, including relative scale among
the ten objects. The grid placement, surface shading, materials, lights, platforms
and cameras are presentation choices. Source STL does not declare units; no
engineering unit conversion is made. True assembly transforms are unavailable.

SOURCE_NATIVE_GEOMETRY_UNALTERED is a hidden collection of original coordinates.
DISPLAY_GRID_SOURCE_MESHES shares that mesh data and adds display translation.
Studio objects, labels and platforms are not original project parts.

The aerodynamic fin itself is SLDPRT-only in the inspected source. The displayed
fin bracket tip is a different component and is explicitly labelled as such.
Airframe, sled, pressure, propulsion, pyrotechnic and other unsupported or excluded
components are absent. No full assembly, operation, engineering performance or
manufacturability is asserted. Mesh defects of source STL remain documented.
'''
        tx=bpy.data.texts.get('README_SOURCE_GEOMETRY') or bpy.data.texts.new('README_SOURCE_GEOMETRY')
        tx.clear();tx.write(notes)
        src=bpy.data.texts.get('build_safe_component_atlas.py') or bpy.data.texts.new('build_safe_component_atlas.py')
        src.clear();src.write(Path(__file__).read_text())
        bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'original-safe-components-atlas.blend'))
        (OUT/'README.txt').write_text(notes)
        index['atlas']={'blend':str(OUT/'original-safe-components-atlas.blend'),'glb':str(glb),
          'source_mesh_objects':10,'native_triangles':70064,'source_mesh_data_shared_with_display':True,
          'source_vertices_unscaled':True,'presentation_rotation_applied':False,
          'render_engine':'Cycles CPU','blender_version':bpy.app.version_string,
          'view_transform':sc.view_settings.view_transform,'look':sc.view_settings.look,'exposure':sc.view_settings.exposure,
          'visual_review_rounds':['1 single source nose STL silhouette and matcap audit',
            '2 ten-component layout in matcap', '3 studio atlas and two smaller-component closeups',
            '4 final atlas, all ten component images and oblique atlas'],
          'not_a_complete_assembly':True}
        INDEX.write_text(json.dumps(index,ensure_ascii=False,indent=2))
        (OUT/'source-geometry-audit.json').write_text(json.dumps(index,ensure_ascii=False,indent=2))
        print('ATLAS_RESULT='+json.dumps({'round':4,'atlas':index['atlas'],'checks':{'all_source_triangle_counts_preserved':all(p['source_topology_preserved'] for p in index['parts'])}},ensure_ascii=False))
else:raise ValueError('Use review-pass 2, 3, or 4.')
