from pathlib import Path
import subprocess,json,hashlib,os,datetime,time
v=Path(__file__).resolve().parent;p=v/"project";out=v/"frontend-rebuild";reports=v/"reports/frontend";reports.mkdir(exist_ok=True)
d=json.loads((v/"reports/actual-download-receipt.json").read_text());assert d["download_passed"] and d["verify_passed"] and d["restore_passed"]
assert not out.exists();subprocess.run(["cp","-cR",str(p),str(out)],check=True)
node="/Users/qianqiming/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node"
env=os.environ.copy();env.update({"MACHINE_NODE_MODULES":str(v/"runtime-links/node_modules"),"MACHINE_PLAYWRIGHT_MODULE":"file:///Users/qianqiming/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs","MACHINE_CHROMIUM_EXECUTABLE":"/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"})
prefix=["/usr/bin/sandbox-exec","-f",str(v/"deny-original-inputs.sb"),node]
def run(args,log):
 t=time.monotonic()
 with (reports/log).open("w") as f:subprocess.run(prefix+args,cwd=out,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
 return time.monotonic()-t
def sha(q):
 h=hashlib.sha256()
 with q.open("rb") as f:
  while b:=f.read(4194304):h.update(b)
 return h.hexdigest()
base=out/"outputs/启明火箭";manifest=json.loads((p/"release-manifest.json").read_text());expected={r["path"]:r["sha256"] for r in manifest["files"]}
r={"created_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"actual_downloaded_sources_and_geometry_used":True,"original_input_denial_used":True,"installed_dependencies_reused_no_clean_install_claimed":True,"passed":False}
r["main_build_seconds"]=run([str(base/"source/assembly-viewer/build.mjs"),"--output",str(base/"整箭原件检视-rebuilt.html")],"main-build.log")
r["main_rebuilt_sha256"]=sha(base/"整箭原件检视-rebuilt.html");r["main_byte_exact_to_downloaded"]=r["main_rebuilt_sha256"]==expected["outputs/启明火箭/整箭原件检视.html"]
r["silent_build_seconds"]=run([str(base/"source/assembly-film/build.mjs"),"--silent"],"silent-build.log");silent=base/"逐步虚拟归位-silent-rebuilt.html";os.link(base/"逐步虚拟归位.html",silent);r["silent_rebuilt_sha256"]=sha(silent);r["silent_byte_exact_to_downloaded"]=r["silent_rebuilt_sha256"]==expected["outputs/启明火箭/逐步虚拟归位.html"]
r["voice_build_seconds"]=run([str(base/"source/assembly-film/build.mjs")],"voice-build.log");r["fullvoice_rebuilt_sha256"]=sha(base/"逐步虚拟归位.html");r["fullvoice_byte_exact_to_master"]=r["fullvoice_rebuilt_sha256"]=="42df32ff769517f160a4d1fa9333bf20d6195c2873a6cf7117985fe9a4dc1ff3"
run([str(v/"reports/rebuilt-main-check.mjs"),str(base/"整箭原件检视-rebuilt.html"),str(reports/"rebuilt-main.png"),str(reports/"rebuilt-main-browser.json")],"main-browser.log")
run([str(p/"browser_smoke.mjs"),"--silent",str(silent),"--complete",str(base/"逐步虚拟归位.html"),"--out",str(reports/"film-browser")],"film-browser.log")
r["main_browser_passed"]=json.loads((reports/"rebuilt-main-browser.json").read_text())["passed"];r["film_browser_passed"]=json.loads((reports/"film-browser/browser-smoke.json").read_text())["silent_and_complete_actual_play_seek_chapter_passed"];r["passed"]=r["main_browser_passed"] and r["film_browser_passed"] and r["main_byte_exact_to_downloaded"] and r["silent_byte_exact_to_downloaded"] and r["fullvoice_byte_exact_to_master"];r["downloaded_original_git_sources_unchanged"]=subprocess.run(["git","diff","--quiet","HEAD","--"],cwd=p).returncode==0
(reports/"frontend-rebuild-review.json").write_text(json.dumps(r,ensure_ascii=False,indent=2)+"\n");print(json.dumps(r,ensure_ascii=False));assert r["passed"] and r["downloaded_original_git_sources_unchanged"]
