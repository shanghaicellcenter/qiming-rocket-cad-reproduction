from pathlib import Path
import json,hashlib,struct,re,wave,datetime,xml.etree.ElementTree as ET
from PIL import Image
root=Path('/Users/qianqiming/Documents/Codex/2026-10-19/new-chat');project=root/'outputs/启明火箭';virtual=root/'outputs/virtual-assembly'
existing_audit=root/'work/delivery-completion-audit.json'
if existing_audit.is_file() and json.loads(existing_audit.read_text()).get('current_movie'):
 raise SystemExit('Historical full-audit generator is frozen after final A/V acceptance. Use the incremental final-media audit; do not overwrite it with candidate-era states.')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
observed=[]
def evidence(p,kind):
    p=p.resolve();d={'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p),'kind':kind};observed.append(d);return d

coverage_path=project/'research/coverage.json';coverage=read(coverage_path);evidence(coverage_path,'source-format coverage index, independently checked against files below')
native=[r for r in coverage['records'] if r['format'] in ('SLDPRT','SLDASM')];assert len(native)==134
native_checks=[]
for row in native:
 p=(coverage_path.parent/row['usd_relative']).resolve();assert p.is_file() and sha(p)==row['usd_sha256']
 with p.open('rb') as f:magic=f.read(8)
 assert magic==b'PXR-USDC',p
 native_checks.append({'format':row['format'],'usd_relative':str(p.relative_to(project)),'hash_and_usdc_signature_passed':True,'source_sha256':row['source_sha256']})

stls=[r for r in coverage['records'] if r['format']=='STL'];assert len(stls)==36;stl_tris=0
for row in stls:
 p=(coverage_path.parent/row['stl_relative']).resolve();assert sha(p)==row['source_sha256']
 with p.open('rb') as f:f.read(80);n=struct.unpack('<I',f.read(4))[0]
 assert p.stat().st_size==84+n*50 and n==row['source_triangles'];stl_tris+=n
assert stl_tris==144516

def glb_stats(p):
 with p.open('rb') as f:
  magic,version,total=struct.unpack('<4sII',f.read(12));assert magic==b'glTF' and version==2 and total==p.stat().st_size
  size,typ=struct.unpack('<II',f.read(8));assert typ==0x4E4F534A;g=json.loads(f.read(size))
 nodes=[n for n in g['nodes'] if 'mesh'in n];tri=0
 for n in nodes:
  for primitive in g['meshes'][n['mesh']]['primitives']:
   assert primitive.get('mode',4)==4
   accessor=primitive.get('indices',primitive['attributes']['POSITION']);tri+=g['accessors'][accessor]['count']//3
 return {'gltf_nodes':len(g['nodes']),'mesh_node_occurrences':len(nodes),'triangle_occurrences':tri,'bytes':p.stat().st_size,'sha256':sha(p)}
glbs={name:glb_stats(project/'assembly'/name) for name in ['vehicle-original.compact.glb','vehicle-browse.compact.glb']}
assert glbs['vehicle-original.compact.glb']['mesh_node_occurrences']==688 and glbs['vehicle-original.compact.glb']['triangle_occurrences']==7070568
assert glbs['vehicle-browse.compact.glb']['mesh_node_occurrences']==688 and glbs['vehicle-browse.compact.glb']['triangle_occurrences']==2864600

preview_path=project/'library/preview-index.json';preview=read(preview_path);assert len(preview['records'])==170
image_count=0
for row in preview['records']:
 assert len(row['views'])==3
 for view in row['views'].values():
  p=project/'library'/view['image'];assert sha(p)==view['sha256']
  with Image.open(p) as im:im.verify()
  image_count+=1
assert image_count==510;evidence(preview_path,'170 source records; 510 actual PNG payloads independently hash-verified and decoded')

exchange=read(project/'native-cad/exchange-source/actual-read-summary.json');step=read(project/'library/exchange-source/step-library.audit.json');assert len(step['items'])==35
for item in step['items']:
 p=project/'native-cad/exchange-source/usd'/(item['id']+'.usdc');assert sha(p)==item['usd_sha256']
 with p.open('rb') as f:assert f.read(8)==b'PXR-USDC'
step_render=read(project/'library/exchange-source/saved-reopen-and-render-audit.json');assert len(step_render['rows'])==105
for row in step_render['rows']:
 p=Path(row['image']);p=p if p.is_absolute() else project/'library/exchange-source'/p
 assert p.is_file() and sha(p)==row['sha256']
 with Image.open(p) as im:im.verify()
step_blend=project/'library/exchange-source/STEP来源库.blend';assert sha(step_blend)==step_render['saved_blend_sha256']
evidence(project/'native-cad/exchange-source/actual-read-summary.json','format-reader evidence; independently verified USD/PNG/SVG payloads')
dxfs=read(project/'library/exchange-source/dxf/dxf-index.json');assert len(dxfs['records'])==3;svg_checks=[]
for row in dxfs['records']:
 for space,d in row['spaces'].items():
  if not d.get('svg'):continue
  p=project/'library/exchange-source/dxf'/d['svg'];assert sha(p)==d['svg_sha256'];x=ET.parse(p).getroot();assert x.tag.endswith('svg') and x.attrib.get('viewBox')
  geometry=sum(el.tag.split('}')[-1] in ('circle','line','polyline','polygon','path','ellipse','rect') for el in x.iter());assert geometry>0
  visible_text=' '.join(el.text or '' for el in x.iter() if el.tag.split('}')[-1]=='text')
  assert not re.search(r'Mojave[\s_-]*Sphinx|MojaveSphinx|\bSphinx\b',visible_text,re.I)
  svg_checks.append({'id':row['id'],'space':space,'svg':str(p.relative_to(project)),'sha256':sha(p),'nonempty_geometry':True})
assert len(svg_checks)==4
draw_native=read(project/'native-cad/exchange-source/drawings-native/native-drawing-read-results.json');assert len(draw_native['records'])==13
assert all(r['return_code']==1 and not r['output_exists'] and r['source_sha256_after']==r['source_sha256'] for r in draw_native['records'])

papers=read(project/'library/source-drawings/index.json');assert len(papers['rows'])==13 and sha(Path(papers['source_pdf']))==papers['source_pdf_sha256']
for row in papers['rows']:
 p=project/'library/source-drawings'/row['image'];assert sha(p)==row['image_sha256'] and row['display_title_replacement']['outside_title_rectangles_pixels_identical']
title_audit=read(project/'library/source-drawings/title-display-audit.json');assert title_audit['all_pages_outside_title_name_rectangles_pixel_identical']

stages_path=virtual/'assembly-stages.json';stages=read(stages_path);paths=[p for s in stages['stages'] for p in s['mesh_source_paths']]
assert len(stages['stages'])==15 and len(paths)==len(set(paths))==688
qc=read(virtual/'alignment-qc.json')['final_alignment'];assert qc['source_objects_checked']==1980 and qc['max_local_matrix_abs_error']==0 and qc['max_world_matrix_abs_error_source_units']==0
motion=read(virtual/'saved-file-motion-qc.json');virtual_blend=virtual/'virtual-assembly.blend';assert sha(virtual_blend)==motion['saved_blend_sha256'] and motion['final_local_world_matrix_error']==0
qc_text_path=virtual/'逐环节质量核对说明.md';qc_text=qc_text_path.read_text();headings=re.findall(r'^## (\d{2}) · ',qc_text,re.M);assert headings==[f'{i:02d}' for i in range(1,16)]
sections=re.split(r'^## \d{2} · ',qc_text,flags=re.M)[1:];assert all(len(s)>300 for s in sections)
ui_qc=read(root/'work/assembly-film/audio-ui-draft-review/checks.json');assert len(ui_qc['checks'])==38 and all(c['pass'] for c in ui_qc['checks'])
evidence(qc_text_path,'actual substantive 15-stage principle/QC document');evidence(stages_path,'15 raw source-path partitions independently counted at 688 unique mesh paths')

sim_path=project/'research/simulation/official-existing-simulation-result.json';sim=read(sim_path);s=sim['simulations'][0]
assert sim['actual_existing_simulation_execution_count']==1 and s['actual_simulation_executed'] and sim['source_files_unchanged']
sim_evidence={k:s[k] for k in ['status_after_execution','has_errors_after_execution','result_reached_ground_event','result_abort_event_present','result_branch_count','result_point_count']};sim_evidence['warning_count']=len(s['warnings']);sim_evidence['parametric_tree_nodes']=sim['parametric_component_tree_node_count'];evidence(sim_path,'actual official-core execution report, with no performance parameters copied into this audit')
flight_path=project/'research/flight-evidence/evidence-register.json';flight=read(flight_path);evidence(flight_path,'primary-source evidence register, not physical acceptance of this reconstruction')

voice_root=root/'work/assembly-film/breeze-prep/collected';voice=read(voice_root/'breeze-candidate-manifest.json');assert len(voice['clips'])==17;voice_checks=[]
asr_root=root/'work/assembly-film/breeze-prep/asr-text-review/results'
for clip in voice['clips']:
 p=Path(clip['wav_file']);p=p if p.is_absolute() else voice_root/p;assert sha(p)==clip['wav_sha256']
 with wave.open(str(p)) as w:dur=w.getnframes()/w.getframerate();assert w.getnframes()>0 and w.getnchannels()==clip['channels']
 asr_path=asr_root/clip['id']/(clip['id']+'.asr.json');asr=read(asr_path) if asr_path.is_file() else None
 if asr is not None:assert asr['input_wav_sha256']==clip['wav_sha256']
 voice_checks.append({'id':clip['id'],'wav_sha256':sha(p),'duration_seconds':dur,'actual_wav_header_checked':True,'eligible_for_final_movie':clip.get('eligible_for_final_movie',False),'asr_file_present':asr is not None,'asr_file':str(asr_path) if asr is not None else None,'asr_sha256':sha(asr_path) if asr is not None else None,'asr_input_wav_sha_matches':asr is not None,'asr_semantic_or_listening_pass_claimed_by_this_audit':False})
silent_path=root/'work/assembly-film/movie-review-qiming/current-review.json';silent=read(silent_path);assert sha(Path(silent['movie']))==silent['movie_sha256']
evidence(silent_path,'independent current silent-master review; no final voiced/subtitled acceptance')

# Count only image references; do not extract or reorganize engineering text.
source_project=Path('/Users/qianqiming/Desktop/火箭设计 中文版');guide_images=[]
for md in source_project.rglob('*.md'):
 text=md.read_text(errors='replace');refs=re.findall(r'!\[[^\]]*\]\(([^)]+)\)',text)
 if len(refs)>300:guide_images.append({'source_markdown':str(md),'image_references':len(refs),'unique_image_references':len(set(refs)),'all_referenced_files_exist':all((md.parent/r.split(' "')[0]).exists() for r in refs)})

current_media=[str(p.relative_to(project)) for p in (project/'media').glob('*') if p.is_file()]
result={
 'snapshot_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'project_display_name':'启明火箭','project_root':str(project),'read_only_input_audit':True,
 'overall_status':'source geometry/imagery and silent picture master verified; final narrated/subtitled media and BOM supplemental images remain pending; native SLDDRW read is an explicit unsupported format gap',
 'counting':{'source_format_records':221,'native_3d_source_records':134,'original_stl_records':36,'step_3d_source_records':35,'all_3d_source_records':205,'main_gallery_records':170,'main_gallery_views':510,'independent_step_records':35,'independent_step_views':105,'all_3d_preview_views':615,'dxf_source_records':3,'dxf_model_views':3,'dxf_paper_views':1,'source_pdf_drawing_pages_separate':13,'failed_native_slddrw_records':13,'source_bom_rows_not_physical_part_count':172},
 'actual_payload_checks':{'native_134_usd_sha256_and_magic_passed':True,'native_records':native_checks,'stl_36_source_sha256_binary_length_triangle_counts_passed':True,'stl_source_triangles':stl_tris,'actual_main_glb_stats':glbs,'main_510_png_hash_and_decode_passed':True,'step_35_usd_sha_and_magic_passed':True,'step_105_png_sha_and_decode_passed':True,'step_saved_blend_sha_matches_reopen_audit':True,'dxf_svg_checks':svg_checks,'slddrw_13_reader_results_have_no_output':True,'source_pdf_sha_unchanged':papers['source_pdf_sha256'],'pdf_13_png_payload_hashes_and_recorded_title_rectangles_passed':True},
 'principles_qc':{'substantive_stage_sections':15,'document_bytes':qc_text_path.stat().st_size,'actual_partition_mesh_paths':len(paths),'unique_partition_mesh_paths':len(set(paths)),'original_object_count':1980,'final_local_and_world_matrix_difference':0,'saved_blend_sha_rechecked':True,'qc_drawer_report_checks':38,'qc_drawer_all_reported_passed':True,'this_audit_reran_qc_drawer_ui':False,'physical_mates_contact_path_or_load_solver_executed':False},
 'original_guide_images':guide_images,
 'simulation':{'actual_original_software_model_run':True,'evidence':sim_evidence,'input_model_unchanged':True,'full_cad_physics_or_new_design_solver':False},
 'physical_evidence':{'primary_evidence_entries':len(flight['entries']),'strongest_supported':flight['strongest_supported_conclusion'],'not_supported':flight['not_supported'],'raw_fixed_revision_post_repair_validation_chain_established':False},
 'current_silent_movie':{'sha256':silent['movie_sha256'],'strict_decode_passed':silent['strict_decode']['exit_code']==0,'video':silent['ffprobe'],'visual_review_complete_for_documented_samples':isinstance(silent['visual_review'],dict),'final_voiced_movie_accepted':False},
 'voice_candidates':{'engine':voice['engine'],'actual_nonempty_wav_files':len(voice_checks),'total_original_duration_seconds':sum(x['duration_seconds'] for x in voice_checks),'eligible_for_final_movie':voice['eligible_for_final_movie'],'asr_records_locally_present':sum(x['asr_file_present'] for x in voice_checks),'actual_asr_root':str(asr_root),'asr_count_basis':'actual dedicated ASR files parsed and input WAV SHA matched; candidate manifest ASR pointers are not used','asr_presence_does_not_imply_semantic_or_listening_acceptance':True,'tracks':voice_checks},
 'current_public_media_files':current_media,
 'remaining_items':[
  {'id':'final_audio','status':'pending','gap':'17段Breeze候选WAV已实际存在并校验；本地清单仍不可用于成片。独立ASR、真实声学分句、目标字幕映射与听感验收需由最终音频证据关闭。'},
  {'id':'final_av_mux','status':'pending','gap':'现有219.866667秒为已核静音基底，最终按原速音频时长重定时、合音、字幕及完整A/V解码/声画核对尚未由本快照验收。'},
  {'id':'bom62_images','status':'pending_external_delivery','gap':'新增BOM补图62条由已授权关联会话制作；本地最终交付尚无已接入并逐图验收的快照，不计入615张三维预览。'}
 ],
 'evidence_boundaries':[
  {'id':'slddrw_native','status':'explicit_format_gap','gap':'13个SLDDRW逐一实际读取失败且无输出。13页PDF展示副本不能替代原生图纸语义、视图、配置和引用解析。'},
  {'id':'physical_all_details','status':'not_supported_by_available_source','gap':'现有源质量/体积占位、未给出的布线/内部细节/软性回收件、全部配置与实体BOM不能凭转换补造；205是三维来源记录，不是完整实物零件总数。'},
  {'id':'real_world_usable','status':'not_certified','gap':'原作者公开实物历史与原作者简化软件模型的一次运行不构成本次数字复现、新造实物或HCR5105修订后固定构型的工作/飞行可靠性认证。'}
 ],
 'observed_evidence_files':observed,'future_increment_policy':'Only update final-media, ASR/subtitle and BOM delivery states when their actual final payloads exist and are independently checked. Do not reopen already verified source geometry without a changed input hash.'}
(root/'work/delivery-completion-audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
md=f'''# 启明火箭交付差距快照

核对时间：{result['snapshot_utc']}。本轮只读实际模型、图片、阶段数据、音频和证据文件；没有改README、主入口、coverage或任何母片。

已能支持的结论是：**现有源几何和图片已形成完整可查的数字交付，静音画面基底已通过核对；有声字幕成片和BOM新增补图仍待最终载荷验收。** 13个原生图纸仍有明确格式读取缺口，不能把“所有实物细节已完整复原、真实可飞”当成已证明。

|目标|实际核到的当前文件|仍需区分的边界|
|---|---|---|
|所有源三维部件|134个原生CAD转换均实测USD签名/哈希；36个原STL原字节/二进制长度/三角面计数通过；35个STEP已得非空USD并复核哈希。整箭GLB实测688源网格实例、两级分别7,070,568和2,864,600面。|205是来源记录；含装配、独立修订与格式变体，不是205种物理零件。BOM172行还含原料、耗材、包装和地面设备。|
|所有检视图片|主图册170条/510张与独立STEP35条/105张，合计205条/615张；本轮逐项复核全部615个PNG哈希并实际解码。|新增BOM62补图尚待本地快照和逐图验收，不纳入615。|
|图纸与平面来源|13页PDF展示PNG当前哈希通过、原PDF SHA不变；名称框外像素一致的原审计保留。3个DXF有3个模型空间SVG及1个纸空间视图，4个SVG实际解析非空且哈希通过。|DXF的通用三维reader失败，但ASCII实体另行解析成功；纸空间不是新零件。13个SLDDRW逐一reader失败无输出，PDF不能冒充原生读通。|
|15环节原理与QC|实际15节完整说明存在，阶段原路径实测互斥覆盖688；1980对象最终局部/世界差0；保存的Blender哈希与重开审计一致。另读到QC抽屉38项实际交互报告全通过，本轮没有重复跑UI。|这是视觉归位与数字坐标核对，不是实物施工顺序、碰撞可达性、配合/载荷或飞行验证。|
|逐步视频|静音基底SHA `{silent['movie_sha256']}`，6596帧、1280×720、30fps、219.866667秒；完整严格解码与分章/边界抽查通过。06—09整组范围说明及第09章“随后”说明已增量复核；其余16章中间/返回帧像素与上版相同。|0音轨，尚未验收最终原速中文旁白、按实际声长重定时、字幕与合音版。|
|中文旁白|17个Breeze候选WAV实际存在、逐项SHA和WAV头通过，总原速时长{result['voice_candidates']['total_original_duration_seconds']:.3f}秒；实际专用目录发现{result['voice_candidates']['asr_records_locally_present']}/17份ASR，逐份JSON可解析且输入WAV SHA匹配。|候选清单eligible_for_final_movie仍为false；ASR文件存在不代表语义、真实声学分句、字幕映射或试听验收完成。|
|实际仿真|官方OpenRocket实际重算作者原有模型一次，输入未改，1分支/872点，UPTODATE，无abort，有1条恢复高速警告。|模型只有28个参数组件，未把完整CAD变成物理仿真，也没有因此证明实体配合、承载或动力系统。|
|实物证据|原作者一手资料的{len(flight['entries'])}条证据登记实际存在，可支持设计家族有地面与飞行实物史，同时有失败和修订。|不能把不同型号/构型累计次数、官方自述或片段视频当成这份复现的可靠性认证；未建立修订后固定配置的完整原始复验链。|

原书图片另列：本轮仅统计原Markdown图片引用并核对实际引用文件存在，不重绘原图，也不把原书插图与615张CAD检视图混计。现有源MassVolume、未表达内部结构和未给定细节均按源边界保留。

当前交付待办只有三项：最终音频验收、重定时合音字幕成片、62条BOM补图实际接入与核对。另有三项证据边界单列：SLDDRW原生读取失败、源资料未表达的实物细节、缺乏本复现的实体工作/飞行认证。目录和格式转换成功不会自动消除这些边界。

ASR按实际路径`work/assembly-film/breeze-prep/asr-text-review/results/<id>/<id>.asr.json`计数，原候选manifest中暂空的ASR指针不作数量依据；此前0份的快照已更正。

当前还没有把任何有声影片写成完成。最终媒体到位后，只增量核对音轨、字幕、实际时长、完整解码与关键画面对齐；没有输入哈希变化时不重复重做已通过的几何或图片。

详细独立载荷检查、路径与哈希见同目录`delivery-completion-audit.json`。当前静音画面细项见`assembly-film/movie-review-qiming/current-review.json`。
'''
(root/'work/delivery-completion-audit.md').write_text(md)
print(json.dumps({'all_3d_source_records':205,'actual_png_hash_decode_count':615,'dxf_svgs':len(svg_checks),'native_drawing_reader_failures':13,'stage_paths':len(paths),'voice_actual_wavs':len(voice_checks),'voice_asr_present':result['voice_candidates']['asr_records_locally_present'],'voice_final_eligible':voice['eligible_for_final_movie'],'remaining_items':len(result['remaining_items'])},ensure_ascii=False))
