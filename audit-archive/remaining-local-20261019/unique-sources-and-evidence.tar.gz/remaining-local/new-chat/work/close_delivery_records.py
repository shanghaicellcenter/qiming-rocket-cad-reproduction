"""Close task handoff records after actual deletion and public readback."""
from pathlib import Path
import datetime, hashlib, json, shutil, subprocess
R=Path(__file__).resolve().parents[1]
V=R.parent/'qiming-github-verify-20261019'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,d):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
cleanup=json.loads((V/'reports/local-cleanup-receipt.json').read_text())
readback=json.loads((V/'reports/cleanup-publication-readback.json').read_text())
assert cleanup['cleanup_complete'] is True and readback['passed'] is True
assert readback['public_main_commit']=='aaefdca9361d99fba0f238ef93ba79c867cf71c5'
assert all(not Path(x['quarantine']).exists() for x in cleanup['deletions'])
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
repo='https://github.com/shanghaicellcenter/qiming-rocket-cad-reproduction'
release=repo+'/releases/tag/v1.0.0'
summary={
 'task':'启明火箭：Machine Skill + Blender 源CAD数字复现',
 'status':'complete',
 'updated_utc':now,
 'publication_state':'public_release_actually_downloaded_rebuilt_runtime_verified_and_owned_generated_copies_removed',
 'repo_url':repo,'release_url':release,'tag':'v1.0.0',
 'release_actual_published':True,'actual_download_performed':True,
 'frozen_release_commit':'82c2a2a255b66556cead58ec3444f81f1757ae68',
 'current_public_main_commit':readback['public_main_commit'],
 'release_manifest_sha256':'b5122c9f67b948f15e3f476e1bcd01f447593c46a6dff80292bd61994f314877',
 'frozen_payload':{'files':3829,'logical_bytes':2562813496,'internal_aliases':2,'release_assets':10,'assets_all10_actual_public_network_download_and_sha_passed':True},
 'core_outputs':{'actual_source3D_preview_images':615,'source3D_records':205,'component_records':206,'BOM_rows':172,'custom_rows':34,'editable_illustration_scenes':62,'virtual_return_groups':15,'source_mesh_occurrences':688,'source_objects':1980,'final_local_world_error':0,'narrated_film_seconds':201.7,'narrated_film_frames':6051,'narration_whole_paragraphs':17,'burned_caption_blocks':41},
 'actual_validation':{'old_inputs_os_read_denied':True,'all3829_file_sha256':True,'all392_original_snapshot_sha256':True,'actual_browser_and_media_playback':True,'actual_frontend3_HTML_byte_exact_rebuild':True,'actual_Blender_rebuild_reopen_and_visual_review':True,'new_Blender_diagnostic_images_retained':22,'Git_main_QA_selector_fix_published_and_actual_readback_verified':True},
 'actual_download_receipt':{'path':str(V/'reports/actual-download-receipt.json'),'sha256':sha(V/'reports/actual-download-receipt.json')},
 'final_runtime_acceptance':{'path':str(V/'reports/final-acceptance.json'),'sha256':sha(V/'reports/final-acceptance.json')},
 'local_cleanup':{'complete':True,'scope':'Only this task owned generated outputs and actual-download/rebuild duplicates; small sources and audit records retained','original_generated_roots_removed':35,'exact_quarantine_children_removed':2,'logical_file_bytes_removed':cleanup['space']['logical_file_bytes_removed'],'observed_available_delta_bytes':cleanup['space']['observed_available_delta_bytes'],'observed_delta_not_isolated_physical_reclaim':True,'receipt_path':str(V/'reports/local-cleanup-receipt.json'),'receipt_sha256':sha(V/'reports/local-cleanup-receipt.json')},
 'protected_inputs':{'desktop_original_root':'/Users/qianqiming/Desktop/火箭设计 中文版','desktop_original_content_files':392,'other_project_independent_inputs':103,'all_actual_sha256_rechecked_after_deletion':True,'other_project_root_and_shared_skills_runtimes_models_services_preserved':True},
 'public_runtime_proof':repo+'/blob/main/docs/下载重建验收-v1.0.0.md',
 'public_cleanup_proof':repo+'/blob/main/docs/本地生成副本清理-v1.0.0.md',
 'remaining_required_work':[],
 'material_limits':['13 native SLDDRW source readers failed; actual source originals and separate 13 PDF page previews preserved, without claiming editable native drawing conversion.','Original simplified MassVolume/hidden faces/unmodeled details retained; no invented missing physical geometry.','OpenRocket actually ran original unmodified ORK+ENG with872 points and1 retained recovery warning; digital alignment and family flight evidence do not certify newly built hardware.','Breeze speech remains separate research/noncommercial audio; visual/source and MIT helper licenses preserved individually.','Runtime verification reused declared installed dependencies; no claim of clean-machine install, repeated native CAD conversion, repeated TTS generation, or all17 subjective human listening.']
}
history=R/'retained-release-records/history-before-completion';history.mkdir(parents=True,exist_ok=True)
for rel in ['work/github-publication/handoff.json','work/github-publication/remote-publication-receipt.json','work/live-execution.json','work/task_plan.md']:
 p=R/rel
 if p.exists():
  dest=history/Path(rel).name
  if not dest.exists():shutil.copy2(p,dest)
for p in [R/'work/github-publication/handoff.json',R/'work/github-publication/remote-publication-receipt.json',R/'work/live-execution.json',R/'retained-release-records/final-delivery-summary.json']:
 save(p,summary)
receipts=R/'retained-release-records/final-cleanup-receipts';receipts.mkdir(parents=True,exist_ok=True)
names=['local-cleanup-receipt.json','cleanup-publication-readback.json','final-acceptance.json','actual-download-receipt.json','generated-copy-stage.json']
for name in names:
 src=V/'reports'/name;shutil.copy2(src,receipts/name);assert sha(src)==sha(receipts/name)
for name in ['old35-quarantine-review.json','generated-copy-quarantine-review.json']:
 src=V/'reports/independent'/name;shutil.copy2(src,receipts/name);assert sha(src)==sha(receipts/name)
text=f'''# 启明火箭：数字复现与交付完成

用户指定的 AirsupHQ Machine Skill 与本地 Blender 专家工作流已实际应用。完整交付已公开发布、从公开Release全部真实下载并验收，授权的大型本地生成副本已实际清理；本页取代先前的待生成/待发布状态。历史工作记录另存于 retained-release-records/history-before-completion/。

## 已完成的实际输出

- 392个原始内容文件保留原字节；源CAD、BOM、修订件、来源身份与许可均登记。
- 205份三维来源各3视图，共615张实际渲染图，浏览器逐张解码通过；包含35 STEP实际读入、105图。3 DXF实际实体解析及4张图已提供。
- 图册206条资料（172 BOM +34定制）、208图引用完整；62份可编辑说明图场景已实际重开与字体轮廓化审查。
- 整箭1980源对象、688源网格，3源隐藏件保留；15组虚拟归位完整覆盖，最终每对象local/world矩阵差0。
- 201.7秒/6051帧正式影片、17整段原速旁白、41字幕与同步交互页均完成。浏览、拖动、章节、实际无静音播放、声画解码与关键画面验收通过。
- 原OpenRocket模型及匹配发动机数据不改，已实际仿真产生872点；保留1条高速回收警告及53项作者来源证据。

## 实际发布与重建验证

- GitHub：{repo}
- 完整Release：{release}
- 冻结tag commit：82c2a2a255b66556cead58ec3444f81f1757ae68。
- 冻结交付3829文件、2,562,813,496逻辑字节；manifest SHA256 b5122c9f67b948f15e3f476e1bcd01f447593c46a6dff80292bd61994f314877。
- 10个已发布附件真实匿名网络下载、全SHA通过；原工作区/桌面输入/伙伴目录被操作系统拒读时，完整浏览、音视频播放、三份HTML字节一致重建及Blender实际重建/重开/渲染全部通过。
- QA脚本PDF空灯箱占位图选择器问题已诚实保留原失败并修复在Git main；精确一行修正被实际运行与远端回读验证。未篡改冻结载荷或标签。

## 已执行的本地清理

原35个生成根及重新下载/恢复/重建的大型验证副本，先分别隔离、独立核查，再仅删除两个精确隔离子目录。桌面原392文件、另一项目103份独立输入和保留Git194冻结源码删除后逐项SHA通过；随后将小型Git检出更新到main。

逻辑文件共移除15,621,658,045字节；文件系统可用空间两次采样净增加12,421,693,440字节，含并发任务影响，不视为独立精确回收。保留轻量源码、全部验收报告/截图、22张实际重建诊断图、哈希与发布凭据。主Git公开main为 {readback['public_main_commit']}。

## 明确的结果边界

13份原生SLDDRW读取真实失败，保留原件、错误日志和独立13页PDF预览，未宣称成功转换。源未表达的伞布/绳结/布线或独立件装配位不凭空补造。数字归位、简化仿真与作者家族飞行史不认证新造实体。声音以研究/非商业独立包提供；原CAD/视觉GPL及各helper MIT许可分别保留。未声称全新机器安装、再次CAD转换、再次TTS合成或用户逐段听完17轨。

剩余必做工作：无。完成时间：{now}。
'''
(R/'work/task_plan.md').write_text(text)
with (R/'work/progress.md').open('a') as f:
 f.write('\n'+now+'：全部数字复现交付完成。公开Release实际10附件下载/3829SHA/HTML恢复和播放/前端与Blender重建全部通过；授权的旧35根及实际下载验证副本已精确隔离、独立复核并真实删除，原392+ni103后验SHA全通过；保留轻量源码及验收记录。清理记录已实际push与API回读，main '+readback['public_main_commit']+'，冻结tag82与manifestb512不变。无剩余必做步骤。\n')
status=subprocess.check_output(['git','status','--porcelain=v1','-uno'],cwd=V/'project',text=True)
assert not status.strip(),status
save(V/'reports/retained-git-final-state.json',{'utc':now,'head':readback['public_main_commit'],'branch':'main','remote_main_actual_api_verified':True,'tracked_files':len(subprocess.check_output(['git','ls-files','-z'],cwd=V/'project').split(b'\0'))-1,'tracked_clean':True,'frozen_tag_unchanged':True,'large_generated_copies_removed':True})
print(json.dumps({'status':'complete','handoff_updated':True,'public_main_commit':readback['public_main_commit'],'remaining_required_work':[]},ensure_ascii=False))
