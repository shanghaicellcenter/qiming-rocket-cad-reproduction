import { chromium } from '/Users/qianqiming/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { pathToFileURL } from 'node:url';
import path from 'node:path';

const root = '/Users/qianqiming/Documents/Codex/2026-10-19/new-chat';
const dir = path.join(root, 'outputs/mojave-machine/library');
const file = path.join(dir, '逐件原件预览.html');
const shots = path.join(dir, 'gallery-review');
await mkdir(shots, { recursive: true });
const browser = await chromium.launch({
  executablePath: '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
  headless: true,
  args: ['--disable-background-networking', '--no-first-run', '--disable-default-apps'],
});
const context = await browser.newContext({ viewport: { width: 1440, height: 1100 }, deviceScaleFactor: 1 });
const page = await context.newPage();
const jsErrors = [], consoleErrors = [], failedRequests = [], externalRequests = [];
context.on('request', request => {
  if (/^https?:|^wss?:/.test(request.url())) externalRequests.push(request.url());
});
await context.route(/^https?:|^wss?:/, route => route.abort('blockedbyclient'));
page.on('pageerror', error => jsErrors.push(String(error)));
page.on('console', message => { if (message.type() === 'error') consoleErrors.push(message.text()); });
page.on('requestfailed', request => failedRequests.push({ url: request.url(), failure: request.failure()?.errorText }));
const report = { tested_at_utc: new Date().toISOString(), url: pathToFileURL(file).href, browser: browser.version(), browser_mode: 'isolated headless Chromium; no existing user tabs', viewport: { width: 1440, height: 1100 } };
const assert = (value, message) => { if (!value) throw new Error(message); };
const state = async () => page.evaluate(() => ({ count: document.querySelector('.count').textContent, ids: [...document.querySelectorAll('.card')].map(x => x.dataset.card) }));
const decode = async selector => {
  await page.locator(selector).evaluate(async img => { await img.decode(); if (!img.naturalWidth || !img.naturalHeight) throw new Error('Empty image'); });
};
try {
  await page.goto(report.url, { waitUntil: 'load' });
  await page.waitForFunction(() => window.previewEvidence?.sourceRecords === 170);
  report.evidence = await page.evaluate(() => window.previewEvidence);
  const data = await page.evaluate(() => window.previewData);
  assert(data.length === 170 && report.evidence.allImages === 510, 'Wrong source/image inventory');
  report.initial = await state();
  assert(report.initial.ids.length === 170, 'Initial gallery does not show 170 cards');
  await decode('.card:first-child img');
  await page.screenshot({ path: path.join(shots, 'gallery-home.png') });

  // Decode every original file inside Chromium; retain per-view identity and actual dimensions.
  report.image_decodes = await page.evaluate(async () => {
    const jobs = window.previewData.flatMap(row => Object.entries(row.views).map(([view, value]) => ({ id: row.id, kind: row.kind, view, url: value.image, expected: row.resolution })));
    const result = [];
    for (let offset = 0; offset < jobs.length; offset += 12) {
      result.push(...await Promise.all(jobs.slice(offset, offset + 12).map(async job => {
        const image = new Image(); image.src = job.url;
        try {
          await image.decode();
          return { ...job, resolved_url: image.src, width: image.naturalWidth, height: image.naturalHeight, passed: image.naturalWidth === job.expected[0] && image.naturalHeight === job.expected[1] && image.naturalWidth > 0 };
        } catch (error) { return { ...job, passed: false, error: String(error) }; }
      })));
    }
    return result;
  });
  assert(report.image_decodes.length === 510 && report.image_decodes.every(x => x.passed), 'Some gallery images did not decode');
  report.filters = [];
  for (const [kind, expected] of [['native', 119], ['stl', 36], ['assembly', 14], ['patch', 1]]) {
    await page.locator('#kind').selectOption(kind);
    const value = await state();
    const ids = data.filter(x => x.kind === kind).map(x => x.id);
    assert(value.ids.length === expected && JSON.stringify(value.ids) === JSON.stringify(ids), `Filter ${kind} failed`);
    report.filters.push({ kind, expected, actual: value.ids.length, ids: value.ids, passed: true });
  }
  await page.locator('#kind').selectOption('');
  report.searches = [];
  const original = data.find(x => x.id === 'P088').name;
  for (const query of ['P039', '尾翼', original, 'NO_MATCH_20261019_GALLERY']) {
    await page.locator('#search').fill(query);
    const value = await state();
    const ids = data.filter(x => (x.title + ' ' + x.name + ' ' + x.id).toLowerCase().includes(query.toLowerCase())).map(x => x.id);
    assert(JSON.stringify(value.ids) === JSON.stringify(ids), `Search ${query} failed`);
    report.searches.push({ query, actual: value.ids.length, expected: ids.length, ids: value.ids, passed: true });
  }
  // Combined filtering/searching must preserve the exact source category.
  await page.locator('#kind').selectOption('stl');
  await page.locator('#search').fill('尾翼');
  const combined = await state();
  const combinedIds = data.filter(x => x.kind === 'stl' && (x.title + ' ' + x.name + ' ' + x.id).includes('尾翼')).map(x => x.id);
  assert(JSON.stringify(combined.ids) === JSON.stringify(combinedIds), 'Combined search/filter failed');
  report.combined_filter_search = { ids: combined.ids, passed: true };
  await page.locator('#kind').selectOption('');
  await page.locator('#search').fill('');

  report.card_views = []; report.dialogs = [];
  for (const [id, screenshot] of [['P009', 'gallery-thread-dialog.png'], ['P088', 'gallery-thin-fin-dialog.png'], ['A01', 'gallery-assembly-dialog.png'], ['A15', null]]) {
    const row = data.find(x => x.id === id);
    await page.locator('#kind').selectOption(row.kind);
    await page.locator('#search').fill(id);
    assert((await state()).ids.join(',') === id, `ID ${id} is not isolated`);
    const card = page.locator(`[data-card="${id}"]`);
    for (const view of ['front', 'side', 'oblique']) {
      await card.locator(`[data-view="${view}"]`).click();
      await decode(`[data-card="${id}"] img`);
      const src = await card.locator('img').getAttribute('src');
      const active = await card.locator('.views .on').getAttribute('data-view');
      assert(src === row.views[view].image && active === view, `${id} card view ${view} failed`);
      report.card_views.push({ id, view, src, passed: true });
    }
    await card.locator('.picture').click();
    assert(await page.locator('dialog').evaluate(x => x.open), 'Dialog did not open');
    const modal = { id, views: [], original_size_links: [], passed: true };
    for (const view of ['front', 'side', 'oblique']) {
      await page.locator(`.modal-views [data-view="${view}"]`).click();
      await decode('dialog img');
      const actual = await page.locator('dialog').evaluate(x => ({ title: x.querySelector('h2').textContent, src: x.querySelector('img').getAttribute('src'), link: x.querySelector('#open-image').getAttribute('href'), detail: x.querySelector('.detail').textContent, code: x.querySelector('code').textContent, active: x.querySelector('.modal-views .on').dataset.view }));
      assert(actual.title === row.title && actual.src === row.views[view].image && actual.link === row.views[view].image && actual.active === view && actual.code.includes(row.views[view].sha256) && actual.detail.startsWith(id + ' · '), `${id} dialog ${view} has incorrect source/view/hash`);
      const popupPromise = page.waitForEvent('popup');
      await page.locator('#open-image').click();
      const popup = await popupPromise;
      await popup.waitForLoadState('load');
      const raw = await popup.locator('img').evaluate(async image => { await image.decode(); return { width: image.naturalWidth, height: image.naturalHeight, url: location.href }; });
      assert(raw.width === row.resolution[0] && raw.height === row.resolution[1] && raw.url === new URL(row.views[view].image, report.url).href, 'Original size link failed');
      modal.original_size_links.push({ view, ...raw, passed: true });
      await popup.close();
      modal.views.push({ view, ...actual, passed: true });
    }
    if (screenshot) {
      await page.screenshot({ path: path.join(shots, screenshot) });
      modal.screenshot = `gallery-review/${screenshot}`;
    }
    await page.locator('#close').click();
    assert(!(await page.locator('dialog').evaluate(x => x.open)), 'Dialog did not close');
    report.dialogs.push(modal);
  }
  await page.locator('#kind').selectOption('');
  await page.locator('#search').fill('');
  assert((await state()).ids.length === 170, 'Gallery did not restore');
  report.final_state = await state();
  report.jsErrors = jsErrors; report.consoleErrors = consoleErrors;
  report.failedRequests = failedRequests; report.externalRequests = externalRequests;
  report.images = report.image_decodes.length;
  report.readable = report.image_decodes.filter(x => x.passed).length;
  report.errors = [];
  report.passed = report.readable === 510 && !jsErrors.length && !consoleErrors.length && !failedRequests.length && !externalRequests.length;
  assert(report.passed, 'Unexpected browser errors or external request');
  const bytes = await readFile(file); report.gallery_sha256 = createHash('sha256').update(bytes).digest('hex');
  report.screenshots = [];
  for (const name of ['gallery-home.png', 'gallery-thread-dialog.png', 'gallery-thin-fin-dialog.png', 'gallery-assembly-dialog.png']) {
    const bytes = await readFile(path.join(shots, name));
    report.screenshots.push({ file: `gallery-review/${name}`, bytes: bytes.length, sha256: createHash('sha256').update(bytes).digest('hex') });
  }
  await writeFile(path.join(dir, 'gallery-check.json'), JSON.stringify(report, null, 2) + '\n');
  console.log(JSON.stringify({ passed: report.passed, sourceRecords: data.length, imagesDecoded: report.readable, filters: report.filters.map(x => [x.kind, x.actual]), cardSwitches: report.card_views.length, dialogViewChecks: report.dialogs.reduce((n,x) => n+x.views.length, 0), originalSizeLinkChecks: report.dialogs.reduce((n,x) => n+x.original_size_links.length, 0), externalRequests, jsErrors, screenshots: report.screenshots.map(x => x.file) }));
} catch (error) {
  report.passed = false; report.error = String(error); report.jsErrors = jsErrors;
  report.consoleErrors = consoleErrors; report.failedRequests = failedRequests; report.externalRequests = externalRequests;
  await writeFile(path.join(dir, 'gallery-check.json'), JSON.stringify(report, null, 2) + '\n');
  throw error;
} finally { await browser.close(); }
