"""Acceptance-only sheets from newly rebuilt still renders, never historical PNGs."""
from pathlib import Path
import hashlib
import json
from PIL import Image, ImageDraw

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'reports/blender'
PROJECT=ROOT/'project'
summary=json.loads((OUT/'blender-acceptance.json').read_text())
assert summary['status']=='numeric-and-render-production-passed-awaiting-visual-review'
assert summary['repoCommit']=='82c2a2a255b66556cead58ec3444f81f1757ae68'

def sheet(paths,name,cols=3):
    width,height=480,326
    result=Image.new('RGB',(width*cols,height*((len(paths)+cols-1)//cols)),(224,229,228))
    draw=ImageDraw.Draw(result)
    rows=[]
    for i,p in enumerate(paths):
        assert p.resolve().is_relative_to((PROJECT/'rebuild/virtual-assembly').resolve())
        with Image.open(p) as source:
            source.load()
            assert source.size==(1440,900),source.size
            image=source.convert('RGB');image.thumbnail((480,300))
            x=(i%cols)*width+(width-image.width)//2;y=(i//cols)*height+26
            result.paste(image,(x,y))
            draw.text(((i%cols)*width+9,(i//cols)*height+7),p.stem,fill=(20,40,45))
            rows.append({'path':str(p),'width':source.width,'height':source.height,
                         'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
    destination=OUT/name
    result.save(destination)
    return {'sheet':str(destination),'sheetSha256':hashlib.sha256(destination.read_bytes()).hexdigest(),
            'decodedNewFrames':rows}

motion=[Path(x['path'])for x in summary['actualNewRenders']]
stage=sorted((PROJECT/'rebuild/virtual-assembly/review-frames').glob('*_returned.png'))
assert len(motion)==7 and len(stage)==15
report={'savedFileMotion':sheet(motion,'newly-reopened-motion-7.png'),
        'returnedSourceGroups':sheet(stage,'newly-built-source-groups-15.png'),
        'actualVisualReviewCompleted':False}
(OUT/'new-render-decode-sheets.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'new_frames_decoded':22,'sheets':[report['savedFileMotion']['sheet'],report['returnedSourceGroups']['sheet']]}))
