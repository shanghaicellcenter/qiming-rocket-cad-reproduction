from pathlib import Path
import json,hashlib,shutil,wave,datetime
R=Path(__file__).resolve().parents[2];W=R/'work/assembly-film';O=R/'outputs/启明火箭/source/audio';m=json.loads((R/'work/virtual-assembly/narration-audio-manifest.json').read_text());assert m['eligible_for_final_movie'] is True and len(m['tracks'])==17
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert m['source_narration_sha256']==sha(R/'work/virtual-assembly/narration-draft.json')
O.mkdir(parents=True,exist_ok=True);rows=[];files=[]
def copy(source,relative,expected=None):
 source=Path(source);assert source.is_file(),source;h=sha(source);assert not expected or h==expected,(source,h,expected);dest=O/relative;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,dest);assert sha(dest)==h;files.append({'path':relative,'bytes':dest.stat().st_size,'sha256':h});return relative
for t in m['tracks']:
 ident=t['id'];row={k:v for k,v in t.items() if not k.endswith('_path') and k not in ['wav_path','raw_wav_path']};row['processed_wav_relative']=copy(t['wav_path'],f'processed/{ident}.wav',t['wav_sha256']);row['raw_wav_relative']=copy(t['raw_wav_path'],f'raw/{ident}.wav',t['raw_wav_sha256'])
 assert t.get('asr_json_path'),('Missing actual ASR evidence',ident)
 asr=json.loads(Path(t['asr_json_path']).read_text());assert asr['input_wav_sha256']==t['raw_wav_sha256'],('ASR/raw audio mismatch',ident)
 row['asr_json_relative']=copy(t['asr_json_path'],f'asr/{ident}.json',t.get('asr_json_sha256'))
 rows.append(row)
for name in ['pilot-leveling-contract.json','profile.snapshot.json','history/two-paragraph-rewording.json']:
 p=W/'breeze-prep'/name
 if p.is_file():copy(p,'audit/'+p.name)
for p in sorted((W/'breeze-prep/license-evidence').glob('*')):
 if p.is_file():copy(p,'license-evidence/'+p.name)
for name in ['final-stream-check.json','audio-ui-final-review/checks.json','finalization-interface-review.json']:
 p=W/name
 if p.is_file():copy(p,'audit/'+p.name)
public={k:v for k,v in m.items() if k!='tracks' and not k.endswith('_path')};public.update(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),tracks=rows,files=files,paths_relative_to='this manifest folder',source_narration_relative='../../../virtual-assembly/逐段讲稿与来源.json',voice_direction_approval='User approved the leveled whole-paragraph pilot; this does not claim individual human listening acceptance of every delivered track.')
(O/'narration-audio-manifest.json').write_text(json.dumps(public,ensure_ascii=False,indent=2)+'\n')
(O/'声音来源与核对.md').write_text('''# 声音来源与核对

旁白由Spark上已有的本地Breeze2生成，每段一次生成，使用相同的自有AI合成男声参考。用户确认了整段试听的声音和音量方向。没有克隆真人声音，没有使用Higgsfield或LibTV。

raw/保留17段原始WAV，processed/为17段按已确认试听方向处理的WAV。轻柔压缩及每段固定增益仅调整响度，不改音高、音速、采样率或采样数；最终合并和编码不再次均衡。asr/保存实际原始音频的独立识别结果，文字字幕与原讲稿对应，时码来自实际语音。转写的同音字歧义和两个段落的最小改写在audit/中保留。自动文字和信号检查不代表真人已逐段接受所有听感。

全部音频身份、时长、采样数、原始/处理SHA见narration-audio-manifest.json。最终合并WAV、MP3、MP4和SRT放在 ../../media/，播放按实际音频时钟同步。此处不附模型权重，也不承诺相同机器外重新TTS可逐采样重现；离线网页与影片可直接用已交付WAV重建。

来源README明确区分Apache2.0源码许可与模型权重、衍生模型及自托管输出的研究/非商业范围。实际读取的README、LICENSE与哈希记录保存在license-evidence/；另见[Breeze官方仓库](https://github.com/breezeblue-ai/breeze-tts)。本工程CAD与文档来源另见Half Cat Rocketry许可，不能将两种来源的许可合并理解。
''')
print(json.dumps({'tracks':len(rows),'copied_files':len(files),'manifest':str(O/'narration-audio-manifest.json')},ensure_ascii=False))
