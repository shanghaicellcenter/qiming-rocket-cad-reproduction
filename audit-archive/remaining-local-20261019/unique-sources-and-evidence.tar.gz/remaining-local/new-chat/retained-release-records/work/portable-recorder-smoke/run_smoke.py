from pathlib import Path
import datetime, hashlib, json, os, shutil, subprocess, time

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
PROJECT=ROOT/'outputs/启明火箭'
SOURCE=PROJECT/'source/assembly-film'
PAGE=PROJECT/'逐步虚拟归位.html'
RECORDER=PROJECT/'source/vendor/machine/scripts/record.mjs'
timeline=json.loads((SOURCE/'final-timeline.json').read_text())
intro=timeline['clips'][0]
assert intro['id']=='intro' and intro['frames']==404
node=os.environ.get('MACHINE_NODE') or shutil.which('node')
assert node
# Match dependency-discovery behavior in delivered render_movie.py.
discovered=[]
for module in [SOURCE/'node_modules/playwright/index.mjs',SOURCE.parent/'node_modules/playwright/index.mjs']:
    if module.is_file():
        os.environ.setdefault('MACHINE_PLAYWRIGHT_MODULE',module.as_uri())
        discovered.append(str(module));break
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
identity={str(p.relative_to(PROJECT)):sha(p) for p in [PAGE,RECORDER,SOURCE/'render_movie.py',SOURCE/'final-timeline.json']}
destination=HERE/'intro-portable.mp4'
command=[node,str(RECORDER),str(PAGE),str(destination),'--w','1280','--h','720','--ss','1','--fps','30','--from','0.0','--to',str(404/30)]
record=dict(status='recording actual delivered intro only',started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),command=command,cwd=str(PROJECT),inputs=identity,
    dependency_discovery_paths=discovered,explicit_playwright_module_environment=os.environ.get('MACHINE_PLAYWRIGHT_MODULE'),
    chromium_executable_environment=os.environ.get('MACHINE_CHROMIUM_EXECUTABLE'),
    scope='Only intro404frames; no full movie rerender, upload, source edit, or deletion.')
(HERE/'progress.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
start=time.perf_counter()
with (HERE/'record.log').open('wb') as log:
    proc=subprocess.Popen(command,cwd=PROJECT,stdout=log,stderr=subprocess.STDOUT)
    record['pid']=proc.pid
    (HERE/'progress.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(dict(status=record['status'],pid=proc.pid,command=command)),flush=True)
    code=proc.wait()
record.update(exit_code=code,elapsed_seconds=time.perf_counter()-start,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='recorder finished; independent validation pending' if code==0 else 'recorder failed')
assert all(sha(PROJECT/relative)==expected for relative,expected in identity.items()),'Delivered input changed during smoke test.'
(HERE/'progress.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(exit_code=code,elapsed_seconds=record['elapsed_seconds'],status=record['status'])),flush=True)
assert code==0
