"""Increment the independent completion audit after actual final A/V QA only."""
from pathlib import Path
import datetime, hashlib, json

R=Path(__file__).resolve().parent.parent
P=R/'outputs/启明火箭'
H=R/'work/assembly-film'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
audit_path=R/'work/delivery-completion-audit.json'
data=read(audit_path)
visual_path=H/'movie-review-final/review.json'
audio_path=H/'movie-audio-review/encoded-audio-review.json'
visual,audio=read(visual_path),read(audio_path)
assert isinstance(visual['visual_review'],dict) and audio['objective_signal_checks_passed']
movie=Path(visual['movie'])
assert sha(movie)==visual['movie_sha256']==audio['movie_sha256']
canonical_path=R/'work/virtual-assembly/narration-audio-manifest.json'
canonical=read(canonical_path)
draft_path=R/'work/virtual-assembly/narration-draft.json'
draft=read(draft_path)
assert canonical['eligible_for_final_movie'] is True and canonical['source_narration_sha256']==sha(draft_path)
paragraphs=[draft['intro'],*draft['stages'],draft['outro']]
tracks=[]
for track,paragraph,signal in zip(canonical['tracks'],paragraphs,audio['tracks']):
    assert track['id']==signal['id'] and track['wav_sha256']==signal['processed_wav_sha256']
    assert track['text_sha256']==hashlib.sha256(paragraph['narration_zh'].encode()).hexdigest()
    asr_path=Path(track['asr_json_path']);asr=read(asr_path)
    assert sha(asr_path)==track['asr_json_sha256'] and asr['input_wav_sha256']==track['raw_wav_sha256']
    tracks.append(dict(id=track['id'],wav_path=track['wav_path'],wav_sha256=track['wav_sha256'],
                       duration_seconds=track['duration_seconds'],eligible_for_final_movie=track['eligible_for_final_movie'],
                       actual_wav_header_and_pcm_placement_checked=True,asr_file_present=True,
                       asr_file=str(asr_path),asr_sha256=sha(asr_path),asr_input_raw_wav_sha_matches=True,
                       text_sha256=track['text_sha256'],independent_asr_content_review_passed=track['independent_asr_content_review_passed'],
                       human_listened_to_this_track=track['human_listened_to_this_track']))
assert len(tracks)==17
previous_silent=data.pop('current_silent_movie',data.get('prior_silent_basis',{}))
previous_silent.pop('final_voiced_movie_accepted',None)
previous_silent['scope']='Historical silent source basis only; current narrated film is independently checked below.'
data['prior_silent_basis']=previous_silent
data['source_geometry_and_image_checks_reused_without_repetition']=True
data['previous_source_payload_audit_snapshot_utc']=data.get('previous_source_payload_audit_snapshot_utc',data['snapshot_utc'])
data['snapshot_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
data['voice_candidates']=dict(status='current selected canonical processed audio; old raw candidate manifest is not final input',engine=canonical['engine'],
    actual_nonempty_wav_files=17,total_original_duration_seconds=sum(t['duration_seconds']for t in tracks),
    eligible_for_final_movie=True,asr_records_locally_present=17,canonical_manifest_path=str(canonical_path),
    canonical_manifest_sha256=sha(canonical_path),source_narration_sha256=canonical['source_narration_sha256'],
    human_approved_voice_direction=canonical['human_approved_voice_direction'],human_listened_to_all17_tracks=canonical['human_listened_to_all17_tracks'],
    objective_encoded_signal_checks_passed=True,asr_presence_does_not_alone_imply_listening_acceptance=True,tracks=tracks)
data['current_movie']=dict(path=str(movie),sha256=visual['movie_sha256'],bytes=movie.stat().st_size,
    video=visual['probe'],strict_av_decode_passed=True,srt_caption_rows=41,all_srt_texts_and_times_match_final_timeline=True,
    visual_review_contact_sheets=20,visual_review_unique_sample_frames=121,
    all17_chapter_first_middle_returned_and16_boundary_pairs_reviewed=True,
    encoded_audio_objective_signal_checks_passed=True,minimum_whole_track_ncc=visual['encoded_audio_signal_review']['minimum_whole_track_ncc'],
    minimum_head_middle_tail_ncc=visual['encoded_audio_signal_review']['minimum_head_middle_tail_ncc'],
    audio_track_lag_samples=0,aac_decoded_extra_padding_samples=audio['encoded_decoded_length_difference_samples'],
    processed_pcm_placement_exact_tracks=17,subjective_listening_performed_by_this_audit=False,
    user_final_acceptance_claimed=False,auxiliary_view_note='Stage15 source backing-plug view is already visible in sample0.10s before final sentence acoustic anchor; anticipatory cut, no phoneme-exact claim.')
closing={'final_audio','final_av_mux'}
closed=[r for r in data.get('closed_items',[]) if r['id'] not in closing]
for row in data['remaining_items']:
    if row['id'] not in closing:continue
    row=dict(row)
    row.update(status='actual_objective_media_qc_passed',closed_utc=data['snapshot_utc'])
    row['gap']='17 selected canonical processed tracks and encoded AAC objectively verified; subjective all-track listening is not claimed.' if row['id']=='final_audio' else 'Actual201.7s/6051frame narrated subtitle MP4 strict decode,41SRT rows and documented visual samples independently passed.'
    closed.append(row)
data['closed_items']=closed
data['remaining_items']=[r for r in data['remaining_items'] if r['id'] not in closing]
for row in data['remaining_items']:
    if row['id']=='bom62_images':
        row.update(status='pending_actual_static_snapshot',gap='额外BOM补图仍待实际最终静态快照与逐图核对；原计划条目数与最新伙伴报图数须按实到清单区分，不预先计入615张CAD预览。')
snapshot_path=R/'work/original-project-snapshot-review.json'
snapshot=read(snapshot_path)
data['original_project_snapshot']=dict(actual_content_files=392,actual_logical_bytes=347662025,zip_containers=6,
    all_current_snapshot_and_desktop_content_sha_match_initial_manifest=True,readme_and_landing_links_exist=True,
    independent_report=str(snapshot_path),independent_report_sha256=sha(snapshot_path))
media=[]
for path in sorted((P/'media').iterdir()):
    if path.is_file():media.append(dict(path=str(path.relative_to(P)),bytes=path.stat().st_size,sha256=sha(path)))
data['current_public_media_files']=media
for p,kind in [(visual_path,'Actual final A/V strict decode and documented121frame/20sheet visual review'),(audio_path,'Actual decoded final AAC versus17canonical processed tracks and exact combined PCM'),(canonical_path,'Current selected17-track canonical voice manifest'),(snapshot_path,'Independent392-file original-project snapshot verification')]:
    data['observed_evidence_files']=[e for e in data['observed_evidence_files'] if Path(e['path'])!=p]
    data['observed_evidence_files'].append(dict(path=str(p.resolve()),bytes=p.stat().st_size,sha256=sha(p),kind=kind))
data['overall_status']='Provided source geometry and images,392-file original snapshot,15-stage principle/QC material, and actual narrated/subtitled movie passed documented objective checks. Extra BOM imagery still awaits an actual final static snapshot. Native SLDDRW failure, source-unmodeled details and lack of physical certification remain separate evidence boundaries.'
data['incremental_update_scope']='Only actual final media,canonical17audio/ASR identities,and original-project snapshot evidence refreshed. Prior615image/geometry checks retained; no source CAD or public entry files modified.'
audit_path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
audit_path.with_suffix('.md').write_text(f'''# 启明火箭交付差距快照

核对时间：{data['snapshot_utc']}。本次增量检查实际成片、17轨音频/ASR身份与原始工程快照；没有重复未变的615图和几何，没有改README、入口、coverage或媒体。

现有源几何、检视图、15段原理/QC与虚拟归位、392文件原始工程快照，以及实际中文配音字幕影片已形成可查交付。额外BOM补图仍待最终静态快照接入验收；不把源未表达的实物细节或真实工作/飞行可靠性写成已证明。

|目标|本次可确认的状态|证据边界|
|---|---|---|
|所有源三维部件|原134个原生CAD、36个原STL、35个STEP均有实际三维输出；既有独立核查保留。整箭688源网格实例，两级7,070,568/2,864,600面。|205是来源记录，含装配、修订及格式变体，不是205种物理零件；BOM172行另含原料、耗材、包装及地面设备。|
|检视图片|主库170条/510图，加STEP35条/105图，共205来源/615张三视图；此前全部PNG实际哈希与解码通过。|额外BOM补图暂不混入615；待实际清单区分条目和图数。|
|图纸与平面来源|13页PDF展示图与原源SHA保留；3DXF有3模型空间SVG和1纸空间视图。|13SLDDRW逐项原生reader失败，无输出；PDF展示不等于原生解析。|
|15环节原理与QC|实际15节说明，15互斥阶段覆盖688；1980源对象最终局部/世界矩阵差0，已保存重开核查。|属于视觉归位和数字坐标核对；未证明实体施工次序、装配路径、配合、载荷或飞行。|
|原始工程快照|实际392文件、347,662,025逻辑字节、6ZIP容器；逐项与桌面源、初始及新manifest字节/SHA一致，README和入口链接有效。|仅排除2Finder元数据；清单和说明不混入392。写时复制的逻辑字节数不等于新增实际磁盘占用。|
|实际有声字幕影片|SHA`{visual['movie_sha256']}`；1280×720、30fps、6051帧、201.7秒，完整严格A/V解码通过。41条SRT与时间表逐项一致。|实际看完20接触表/121唯一帧，覆盖17章首中尾、16边界、41字幕中点及近景；不称逐帧人工观看。|
|真实17轨音频对照|总原速175.28秒，canonical已放行；17processed WAV在combined中PCM逐字节一致。最终AAC全轨偏移0，跨轨漂移0，最低相关性0.999905，首中尾最低0.999754；额外672采样在1024填充容差内。|该信号核查支持无错轨/变速/截尾迹象；没有声称人工试听全部17轨、声音自然度或用户最终验收通过。|
|实际仿真|官方OpenRocket重算作者原有未改模型一次，1分支/872点，无abort，有1警告；证据报告保留。|28个参数组件不等于完整CAD物理仿真，不认证实体配合或动力系统。|
|实物证据|53条一手记录可支持设计家族有实物试验/飞行历史，也存在失败和修订。|不等于本次复现或修订后固定构型的可靠性认证；完整原始复验链尚未建立。|

08真实隔套、09四侧整体、15连接环及源辅助塞与对应讲解同时可见。15辅助塞在最后一句声学锚点前0.10秒样本已出现，属于略提前的画面切换，未声称逐音素同步。所有抽查未见选中主体裁切、空白、前章不透明残留或字幕缺字。

当前核心交付待办仅余额外BOM补图的实际快照与验收。SLDDRW读取失败、源未表达细节、本复现无实物认证是三项证据边界，目录和转换成功不会自动消除它们。原MassVolume占位、未给出的软性回收细节和布线按源保留。

逐项证据见delivery-completion-audit.json；最终影片审查见assembly-film/movie-review-final/review.json及核查.md；AAC逐轨数值见assembly-film/movie-audio-review/encoded-audio-review.json。当前影片和音频均未被本次核查修改。
''')
print(json.dumps(dict(movie_sha=visual['movie_sha256'],objective_final_av=True,canonical_tracks=len(tracks),raw_duration_seconds=data['voice_candidates']['total_original_duration_seconds'],remaining=[r['id']for r in data['remaining_items']],boundaries=len(data['evidence_boundaries']),all_track_subjective_listening_claimed=False),ensure_ascii=False))
