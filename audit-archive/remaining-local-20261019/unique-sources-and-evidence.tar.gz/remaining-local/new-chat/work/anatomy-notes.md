# Anatomy 可视化实现笔记

用途范围：非功能数字展示，只处理外观、展示组件、交互和视觉 QA。所有几何使用任意展示单位；本笔记不包含可制造的推进或高压系统参数、配方及操作流程。

已读本地技能：`/Users/qianqiming/Desktop/skill-repos/wheresryan22--anatomy/SKILL.md`，以及 `references/craft.md`、`references/kit.md`、`references/verify.md` 的相关实现和检查部分。以下签名另以实际导出源码核对。

## 推荐结构

- 用 `examples/dial-indicator/build.mjs` 作干净骨架：Node 构建 → SVG 字符串 → `plateHtml` → `pageHtml`，无需 React 或额外依赖。
- 组件选择、爆炸动画、动态绘制顺序参考 `examples/raptor-engine/build.mjs` 的项目包装和 `live.js` 的 `select()`、`place()`；只移植通用展示逻辑，不复制该示例的推进、发火、仪表模拟或相应控制。
- 建立 `components` 展示元数据：稳定 ID、中文名、外观说明、来源引用、可见性、展示平移向量。把展示说明放在 SVG 外侧的可选中按钮和说明区。
- 静态几何只构建一次。每个几何绘制项目保存所属组件、运动所属组件、深度键和展示平移向量。不要把全体前后交织几何硬合为单个组件 `<g>`，否则不能正确逐项排序。

## 导入与准确 API

```js
import * as k from "<anatomy-root>/kit/iso-kit.mjs";
import * as G from "<anatomy-root>/kit/lathe.mjs";
import * as A from "<anatomy-root>/kit/audit.mjs";
import { kitScript } from "<anatomy-root>/scripts/inline-kit.mjs";
```

相机和坐标：

```js
k.fitProjection(points, width, height, {
  pad = 24, headroom = 0, azimuth = 45, elevation = 30
} = {})
k.iso([x, y, z], P)
k.depthOf([x, y, z], P)                 // 大值更近；升序绘制
k.axisVector(P, [dx, dy, dz])           // 世界向量 → 屏幕向量
k.translateAlong(P, [dx, dy, dz])       // 返回 SVG translate 字符串
```

`fitProjection` 的 `points` 应同时覆盖装配态和展开态的全部展示边界，避免展开后越界。纵向主体是 z 轴，相机方位角只改变观察方向，不能代替真实 3D 旋转。

圆柱、纵向壳体和尖顶外观：

```js
G.frameOf(o, a, u, v)                  // 返回 {o,a,u,v}
G.frameAlong(o, a)
G.solidOf(profile, F, P, options = {})
G.disc(s0, s1, r, F, P, options = {})
G.ringBand(s0, s1, rIn, rOut, F, P, options = {})
G.bandsOf(profile, cuts, F, P, {
  slope, radius, steps, rows = 6,
  rims = "none", fill = "auto", samples = 72
} = {})
k.cylinder(cx, cy, radius, z, height, P, steps = 32, bevel = 0)
k.solidSvg(paths, {
  tone = "hi", crease = "faint", halo = false,
  lit = false, flat = false, className, inner = ""
} = {})
```

使用 `G.frameOf([0,0,z0], [0,0,1], [1,0,0], [0,1,0])` 令模型竖直。`profile` 为展示用 `[s,r]` 或 `[s,r,1]` 点列；第三位 `1` 表示平滑。直筒外观可用 `cylinder`，曲面外观用 `solidOf`；大曲面采用同一条解析展示曲线的 `radius(s)`、`slope(s)`，防止手填点造成色调台阶。长物体若需与周围项目交错排序，用 `bandsOf`；返回 `{bands, sidesOf, radius, slope, steps, s0, s1}`，每个 band 含 `paths`、`profile`、`seam`。

没有现成的“纵向半剖”或“组件选择”API。`lathe` 也没有直接的角度扇区范围参数。优先把外壳按展示组件移开，露出抽象展示块；若做半剖，需自己绘制展示遮罩和切边，不应误称真实制造剖面。任意厚度仅用于画面可读性。

SVG 分组与独立页面：

```js
k.groupSvg(children, extra = {})
k.figureSvg({
  width, height, label, body,
  standalone = false, className
})
k.plateHtml({
  fig, title, hint, readout = "", keys = [], caption, body
})
k.pageHtml({
  title, theme = "dark", body, script = "", width = 650
})
kitScript()                           // 返回可内联的核心 kit 源码
```

`groupSvg` 的额外属性可写 `{class: "part", "data-part": id, tabindex: 0}`。`figureSvg({standalone: "light"})` 可输出自带样式的独立 SVG。HTML 用 `pageHtml({script: kitScript() + liveCode, ...})`，页面与核心运行库全内联；页面模板默认 `lang="en"`，中文交付应在构建输出中改为 `zh-CN`。避免在 `liveCode` 再声明与核心库同名的顶层符号。

## 选中和爆炸视图

- 示例不是调用库内置 `select`；`select(id)` 是 `live.js` 自定义函数。遍历绘制项目，以 `data-piece` 判断高亮，写入/移除 `data-on`；外侧 `button[data-part]` 同步高亮并更新说明区。
- 几何项目的语义所属和运动所属可分开：`data-piece` 用于高亮；`data-ride` 用于随哪个展示组件运动。二者应以真实的展示关系定义。
- 对每个项目预存 `data-m="dx,dy,dz"`。动画进度 `share` 在 0～1，设置 `transform = k.translateAlong(P, move.map(v => v * share))`。
- 爆炸视图是展示布局，不是拆装工艺。组件用温和、时间驱动的缓动展开；只用“展开”“收拢”“查看组件”等展示控制。
- 每帧排序参考 `place()`：`baseDepth + depthOf(move,P) * share`。顺序变化时把元素重新加入 `DocumentFragment` 并追加回同一容器。若存在互相遮挡循环，需拆分项目或调整展示布局，不能只调偏置。
- 外侧按钮支持 click、focus、pointerenter；键盘方向键选择，Home/End 首尾，Escape 清除。为按钮补 `aria-pressed`，说明区用 `aria-live="polite"`。减少动态偏好时直接呈现最终姿态；离屏暂停。

## QA 方法

1. 构建明暗两版，分别检查装配、展开、选中和中间动画姿态。几何图至少在桌面与 390 px 宽显示；确认标题、说明、按钮及最长组件名没有截断。
2. `scripts/capture.mjs` 可用 `--width 390`、`--reduced`、`--hover fx,fy`、`--key ArrowRight`、`--zoom x,y,w,h`、`--zoom-scale 4`。默认裁剪 `.iso-plate`；若关键交互位于卡外，要另截完整页面或指定选择器。
3. `scripts/drive.mjs` 使用动作 JSON，支持 `click`、`key`、`until`、`shot`、`sheet`、`lines`、`eval`。用 `until` 等待页面中 `data-*` 或 readout 达到展开态；不要猜动画等待时间。
4. 对全图做 4 倍网格裁图并逐张查看，重点看尖顶连续性、壳体分段、外观拼缝、外壳与展示块的前后顺序、尾部外观、选中轮廓。线应有合理端点；曲面色调连续，不出现透明穿帮。
5. `node <root>/scripts/lines.mjs page.html --out shots/lines.png`，明暗、收拢、展开都应为 `line ends: 0`。不要用 `free:true` 掩盖断头的装饰线；该标记只用于确实允许自由端点的文字替代线、指针等。
6. 若使用 `A.recorder(P,{order,spring})` 记录圆柱/旋转体等真实绘制形状，构建时 `A.settle(R,P)`，最后 `A.auditOrExit(R,P)`，以 `--audit` 获得遮挡/穿插审查。必须让记录形状覆盖实际绘图，不可用小代理形状骗过审查。审查通过只代表展示几何检查，不是工程或功能验证。
7. 尽量只用 SVG，不引入 WebGL 或 beta 3D，能减少不必要的性能与 QA 负担。若未来要求自由 360° 观察或更复杂半剖，交给单独的展示用 Blender 模型更稳妥，仍不填充制造细节。

## 关键源码定位

- `kit/iso-kit.mjs`：`translateAlong` 362 行、`fitProjection` 393 行、`groupSvg` 528 行、`figureSvg` 531 行、`plateHtml` 552 行、`pageHtml` 561 行。
- `kit/lathe.mjs`：`frameAlong` 39 行、`frameOf` 47 行、`lathe` 531 行、`disc` 813 行、`ringBand` 826 行、`solidOf` 839 行。
- `examples/raptor-engine/live.js`：`select` 107 行、`place` 140 行；绘制项目序列包装在 `build.mjs` 883 行，外侧组件按钮在 922 行。

## 审计最小正确用法与实测

独立验证脚本为本目录 `audit-demo.mjs`。它只画两个通用、任意展示单位的部件：空心套筒与顶端外环；二者端面接触但体积不重叠，外环沿轴线在展示态移开。没有推进、流体或点火设计。

```js
const ORDER = ["end-ring"];
const SPRING = { stagger: .035, stiffness: 64, damping: 14.2, substeps: 4 };
const R = A.recorder(P, { order: ORDER, spring: SPRING });
const shape = R.solid(A.ring(F, s0, s1, ri, ro, { name, ground: true }));
R.put({ piece, name, at, move, svg, shapes: [shape] });
A.settle(R, P);                         // 记录真实形状后求绘制深度
R.items.sort((a,b) => a.key-b.key);     // 生成 DOM 的顺序
// 从 R.items 生成 HTML，并把同一 ORDER / SPRING 放入动画数据。
A.auditOrExit(R, P);                   // 仅带 --audit 才执行
```

- **必须两步记录：**`R.solid(A.ring(...))` 将形状加入接触/穿插审查集合，`R.put({shapes:[shape]})` 将该真实形状绑定给绘制项目及其组件位移。只向 `R.put` 传未用 `R.solid` 记录的 shape，会漏掉部分检查；只 `R.solid` 而不给绘制项目绑定，则深度检查缺少实际绘图关联。
- **空心形状必须真的空心：** `G.ringBand` 对应 `A.ring` 或 `A.lathe`，不能用实心 `A.disc` 代替。`G.solidOf` 对应 `A.solid`。显示厚度与审计厚度必须一致。
- **允许组多个形状，但有代价：** 一个 `R.put` 可带多个真实 `shapes`，其 `svg` 也可包含多个几何；然而该 item 只有一个深度键，其内部不能与别的 item 交错绘制。语义组件最好通过共同的 `piece` / `ride` 组织，保留各绘制 item 为平级 DOM 项目，便于排序。不要把整根长壳与所有外部环各自硬合一组。
- **`ground` 的含义：** 默认仅 `meta.ground === true` 或名字以 `stand.` 开头的形状是接触图根。示例仅固定套筒设 `ground:true`，外环通过端面接触连接。给每个悬浮部件都设 ground 能绕过支撑要求，但那只是在声明展示锚点，不能作为物理支撑已验证的证据。
- **支撑检查限制：** 实际 `A.audit` 调用 `supports(R.solids,R.tubes,{ground})`，检查的是装配静态接触图；没有逐帧检查展开态的支撑。展开态故意悬浮不因此报 support 错误。逐帧检查主要覆盖穿插和绘制深度，不是刚体动力学、稳定性、应力或装配可行性验证。
- **动画必须对应：** 默认状态来自 `ORDER` 与 `SPRING` 的打开、关闭和反转回放，包括 prefix states。若网页实际用另一套缓动、直接拖动或组件分布，不可把默认审计当作该网页动画的充分检查；需要提供对应 `states` / `frames` 并明确抽样范围。
- **预览不可当全审计：** 可临时 `A.settle(R,P,{states:[0,1]})` 加快首屏预览，但 `auditOrExit` 会复用 `R.settled` 的深度状态，即使它打印 `audit passed` 也未检查完整中间深度；最终必须默认 `A.settle(R,P)` 重算，或者声明精确自定义状态范围和限制。

本机实际结果：

```text
node work/audit-demo.mjs --audit
2 solids · 2 items · 51 depth states · 23 overlaps · 1 order rules
audit passed
settle 0.056 s; total 0.079 s
```

另有明确负例：`--wrapped-middle` 让外环在长筒中段环绕。两个体积仍不穿插，支撑与 clearance 为零问题，但两个完整几何项目的前后关系互相交错，审计实际得到 `depth order: 22 problems`、`audit failed: 22 problems`，退出码 1（总 0.145 s）。这证明必须切分壳体或分绘环前/后部；调深度偏置不能解决此类 cycle。

**费用风险：** 两件 demo 很快不代表约 100 形体、16 个运动组也快。默认深度栅格间隔为 0.25 viewBox 单位，成本受投影面积、重叠范围、组数和运动状态数量影响。技能源文档给出的 478 item / 1119 深度状态案例，每次求 key 约一分钟，完整审查约三分钟；这是源文档案例，不是本任务实测。较大投影、大量套接圆环和内部壳体容易耗时并产生无法整体排序的 cycle。应先把复杂套接结构切成可排序展示块，再跑完整审查；任何 reduced-state / quick 检查必须如实标为部分检查。
