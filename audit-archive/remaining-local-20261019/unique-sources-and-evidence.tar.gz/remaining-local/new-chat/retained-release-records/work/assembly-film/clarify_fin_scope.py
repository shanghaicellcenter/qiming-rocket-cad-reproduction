from pathlib import Path
import json,os,hashlib
R=Path('/Users/qianqiming/Documents/Codex/2026-10-19/new-chat');W=R/'work/assembly-film';p=json.loads((R/'outputs/virtual-assembly/assembly-stages.json').read_text());a=json.loads((R/'outputs/virtual-assembly/alignment-qc.json').read_text());q={x['stage_id']:x for x in a['stage_alignment']};rows=[]
for i,s in enumerate(p['stages'][5:9],1):
 paths=s['mesh_source_paths'];root=os.path.commonpath(paths);assert len(paths)==35 and 'FinBracketAssembly'+str(i)+'_' in root
 row={'stage_id':s['id'],'side_instance_index':i,'source_subtree':root,'mesh_occurrences':len(paths),'source_objects_compared':q[s['id']]['checked_source_objects'],'scope_zh':f'本段归位第{i}侧完整翼支架总成，不是只移动标题中强调的单件。','focus_zh':['翼面','直角支架','隔套','四侧共同分布'][i-1]};assert row['source_objects_compared']==110;rows.append(row)
(R/'outputs/virtual-assembly/四侧翼支架分组核对.json').write_text(json.dumps({'source':'assembly-stages.json and alignment-qc.json','stages':rows,'all_four_subtrees_disjoint':len(set().union(*(set(s['mesh_source_paths']) for s in p['stages'][5:9])))==140},ensure_ascii=False,indent=2)+'\n')
f=W/'source/film.js';s=f.read_text();anchor="function qcPanel(s)"
assert anchor in s
s=s.replace(anchor,"const sideScope={5:'第一侧整组归位 · 重点看翼面',6:'第二侧整组归位 · 重点看直角支架',7:'第三侧整组归位 · 重点看隔套',8:'第四侧整组归位 · 后半段看四侧分布'};\nfunction screenNote(i){return (sideScope[i]?sideScope[i]+'。':'')+NARRATION.stages[i].short_screen_note_zh;}\n"+anchor,1)
s=s.replace("isStage?s.short_screen_note_zh:ci===0?", "isStage?screenNote(i):ci===0?",1)
s=s.replace("NARRATION.stages[i].short_screen_note_zh+(inspectInside?", "screenNote(i)+(inspectInside?",1)
# Source counts are accessible audit detail; the observable relationship leads the dialog.
s=s.replace("<p><strong>已通过的数字核对</strong><br>","<details><summary>已通过的数字核对 · 展开记录</summary><p>",1)
s=s.replace("这个0表示数字位置与源模型一致。</p><p><strong>判断实体质量", "这个0表示数字位置与源模型一致。</p></details><p><strong>判断实体质量",1)
s=s.replace("d.querySelector('div').innerHTML=`<p><strong>看哪里", "d.querySelector('div').innerHTML=`${sideScope[lastChapter-1]?'<p><strong>'+esc(sideScope[lastChapter-1])+'</strong><br>本段移动一侧完整翼支架总成；章节标题说明观察重点。</p>':''}<p><strong>看哪里",1)
f.write_text(s)
# Explicitly archive only the four generated capture outputs affected by this display clarification.
h=W/'history/pre-fin-scope-clarification';h.mkdir(parents=True,exist_ok=True)
for i in range(6,10):
 src=W/'captured-chapters'/f'{i:02}-stage{i:02}.mp4';assert src.is_file();src.rename(h/src.name)
(W/'fin-scope-render-revision.json').write_text(json.dumps({'reason':'Four complete side assemblies are returned; chapter titles indicate focused features.','affected_chapters':['stage06','stage07','stage08','stage09'],'voice_text_changed':False,'source_geometry_changed':False,'archived_previous_captures':str(h)},ensure_ascii=False,indent=2)+'\n')
