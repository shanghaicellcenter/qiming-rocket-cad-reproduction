from pathlib import Path
import io, json, hashlib, shutil, subprocess
from pypdf import PdfReader, PdfWriter
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from PIL import Image, ImageChops, ImageDraw, ImageFont

root = Path('/Users/qianqiming/Documents/Codex/2026-10-19/new-chat')
out = root / 'outputs/mojave-machine/library/source-drawings'
work = root / 'work/source-drawings'
raw = work / 'unmodified-render'
raw.mkdir(exist_ok=True)
m = json.loads((out/'index.json').read_text())
source = Path(m['source_pdf'])
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(source) == m['source_pdf_sha256']
locations = json.loads((work/'title-name-locations.json').read_text())
assert len(locations) == 13 and all(len(r['matches']) == 2 for r in locations)
pdfmetrics.registerFont(TTFont('TitleHeiti', '/System/Library/Fonts/STHeiti Light.ttc', subfontIndex=0))
reader = PdfReader(source)
writer = PdfWriter()
patches = []
scale = 1600/842
for page, row in zip(reader.pages, locations):
    assert float(page.mediabox.width) == 842 and float(page.mediabox.height) == 595
    i = row['physical_pdf_page']
    src_png = out / f'page-{i:02d}.png'
    original = raw / src_png.name
    if not original.exists(): shutil.copy2(src_png, original)
    original_hash = sha(original)
    assert original_hash == m['rows'][i-1].get('original_unmodified_png_sha256', m['rows'][i-1]['image_sha256'])
    b = io.BytesIO(); c = canvas.Canvas(b, pagesize=(842,595))
    pixel_rects = []
    for match in row['matches']:
        x0,y0,x1,y1 = match['pixel_bbox']
        rect = [x0-2,y0-2,x1+2,y1+2]
        # A precise word-only overlay in the raster title region; no drawing
        # line, dimension, identifier or attribution is rewritten.
        x0,y0,x1,y1 = rect
        c.setFillColorRGB(1,1,1)
        c.rect(x0/scale,595-y1/scale,(x1-x0)/scale,(y1-y0)/scale,fill=1,stroke=0)
        # Two extra pixels account for raster antialiasing at PDF overlay edges.
        pixel_rects.append([x0-2,y0-2,x1+2,y1+2])
    name = next(r for r in row['matches'] if r['word'].lower().strip('.,') == 'mojave')
    x0,y0,x1,y1 = name['pixel_bbox']
    c.setFillColorRGB(0,0,0); c.setFont('TitleHeiti',8.7)
    c.drawString(x0/scale,595-(y1-2)/scale,'启明火箭')
    c.save(); b.seek(0)
    page.merge_page(PdfReader(b).pages[0]); writer.add_page(page)
    patches.append({'physical_pdf_page':i,'original_unmodified_png_sha256':original_hash,'source_name_pixel_bboxes':[r['pixel_bbox'] for r in row['matches']],'allowed_difference_pixel_rects':pixel_rects,'replacement_zh':'启明火箭','font':'embedded STHeiti Light, 8.7pt','operation':'precise title-name-only white overlay and Chinese display name on a derived PDF copy'})
writer.add_metadata({'/Title':'启明火箭 - 原图纸展示副本','/Author':'Half Cat Rocketry','/Subject':'仅替换展示名称；原PDF、几何、标注、尺寸与署名保持来源记录。'})
derived = out / '启明火箭-展示图纸.pdf'
with derived.open('wb') as f: writer.write(f)
assert len(PdfReader(derived).pages) == 13
subprocess.run(['/opt/homebrew/bin/pdftoppm','-png','-scale-to','1600',str(derived),str(work/'renamed-page')],check=True,capture_output=True)
for row, patch in zip(m['rows'], patches):
    i=row['physical_pdf_page']; old=Image.open(raw/f'page-{i:02d}.png').convert('RGB'); new=Image.open(work/f'renamed-page-{i:02d}.png').convert('RGB')
    assert old.size == new.size == (1600,1131)
    diff=ImageChops.difference(old,new); mask=Image.new('L',new.size,0); md=ImageDraw.Draw(mask)
    for rect in patch['allowed_difference_pixel_rects']: md.rectangle(rect,fill=255)
    outside=diff.copy(); outside.paste((0,0,0),(0,0),mask)
    patch['outside_title_rectangles_difference_bbox']=outside.getbbox()
    assert outside.getbbox() is None, (i,'Unexpected change outside source-name word boxes',outside.getbbox())
    patch['changed_pixel_bbox']=list(diff.getbbox())
    patch['outside_title_rectangles_pixels_identical']=True
    new.save(out/row['image'])
    row['original_unmodified_png_sha256']=patch['original_unmodified_png_sha256']
    row['image_sha256']=sha(out/row['image']); row['bytes']=(out/row['image']).stat().st_size
    row['display_title_replacement']=patch
    row['visual_review']='pending latest title-copy inspection'
m['image_bytes']=sum(r['bytes'] for r in m['rows'])
m['display_name_zh']='启明火箭'
m['derived_display_pdf']={'filename':derived.name,'sha256':sha(derived),'bytes':derived.stat().st_size,'physical_pages':13,'original_source_pdf_modified':False,'original_source_pdf_sha256':sha(source),'title_replacement_only':True,'original_author_attribution':'Half Cat Rocketry'}
m['render_policy']='Original whole MediaBox rendering plus precisely bounded display-name title overlay on a derived PDF copy; no geometry, dimensions, identifiers, attribution or other source pixels altered outside recorded source-name word rectangles'
m['visual_review']='pending latest title-copy inspection'
m['browser_check']='pending renamed display review'
(out/'index.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n')
audit={'source_pdf_sha256':sha(source),'original_source_unchanged':True,'derived_display_pdf':m['derived_display_pdf'],'page_count':13,'source_3d_counts_unchanged':{'source_records':170,'three_view_images':510},'all_pages_outside_title_name_rectangles_pixel_identical':True,'patches':patches,'visual_review':'pending'}
(out/'title-display-audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n')
# Fresh contact sheets are for checking all thirteen final display copies.
font=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',20)
sheets=[]
for group in range(4):
    subset=m['rows'][group*4:(group+1)*4]
    sheet=Image.new('RGB',(1280,58+490*((len(subset)+1)//2)),(233,237,241));d=ImageDraw.Draw(sheet)
    d.text((20,16),f'TITLE DISPLAY COPY REVIEW | {group*4+1:02d}-{group*4+len(subset):02d} / 13',font=font,fill=(35,49,64))
    for j,row in enumerate(subset):
        x=(j%2)*640;y=58+(j//2)*490;im=Image.open(out/row['image']).convert('RGB');im.thumbnail((612,440),Image.Resampling.LANCZOS)
        d.text((x+14,y+9),f'D{row["physical_pdf_page"]:02d} | PDF physical page {row["physical_pdf_page"]}',font=font,fill=(35,49,64));sheet.paste(im,(x+(640-im.width)//2,y+41))
    p=out/f'contactsheet-{group+1:02d}.png';sheet.save(p);sheets.append({'image':p.name,'sha256':sha(p),'physical_pages':[r['physical_pdf_page'] for r in subset]})
m['contact_sheets']=sheets
(out/'index.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'derived_pdf':str(derived),'source_unchanged':True,'all13_outside_title_pixel_identical':True,'png_bytes':m['image_bytes']},ensure_ascii=False))
