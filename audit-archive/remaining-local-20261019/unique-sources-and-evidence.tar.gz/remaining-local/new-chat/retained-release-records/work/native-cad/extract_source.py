import hashlib
import json
from pathlib import Path
import zipfile

root = Path.home() / "codex-mojave-cad-review-20261019"
source = root / "source.zip"
expected = "a7af67f407d2729f70154a7f5b98113c31b8249661527d6a9ed72e67e68b4dd5"
digest = hashlib.sha256(source.read_bytes()).hexdigest()
if digest != expected:
    raise SystemExit("source ZIP hash mismatch")
target = root / "source"
target.mkdir(exist_ok=True)
with zipfile.ZipFile(source) as archive:
    for item in archive.infolist():
        resolved = (target / item.filename).resolve()
        if not resolved.is_relative_to(target.resolve()):
            raise SystemExit("unsafe archive path")
        if (item.external_attr >> 16) & 0o170000 == 0o120000:
            raise SystemExit("archive symlink rejected")
    archive.extractall(target)
cad = target / "Mojave Sphinx CAD - R01"
fin = cad / "FIN-STD-250T-4X250C Fin, Standard, Mojave Sphinx.SLDPRT"
result = {
    "source_zip_sha256": digest,
    "fin": str(fin),
    "fin_sha256": hashlib.sha256(fin.read_bytes()).hexdigest(),
    "fin_bytes": fin.stat().st_size,
    "assembly_candidates": [str(p) for p in sorted(cad.glob("*.SLDASM"))],
}
(root / "source-manifest.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({k: v for k, v in result.items() if k != "assembly_candidates"}, indent=2))
