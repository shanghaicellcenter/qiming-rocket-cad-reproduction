"""Read-only checks after the parent confirms a real public release download.

Never downloads, extracts, restores, uploads, edits payloads or deletes files.
"""
from pathlib import Path,PurePosixPath
import argparse,json,hashlib,datetime,os,re,subprocess,stat

EXPECTED_MANIFEST='b5122c9f67b948f15e3f476e1bcd01f447593c46a6dff80292bd61994f314877'
EXPECTED_COMMIT='82c2a2a255b66556cead58ec3444f81f1757ae68'
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b)
 return h.hexdigest()
def load(p):return json.loads(p.read_text())
def inside(root,relative):
 rel=PurePosixPath(relative)
 if rel.is_absolute() or not rel.parts or '..' in rel.parts:raise ValueError('Unsafe relative path')
 p=root.joinpath(*rel.parts)
 if not p.resolve().is_relative_to(root):raise ValueError('Resolved path escapes root')
 return p
def main():
 a=argparse.ArgumentParser(description=__doc__)
 a.add_argument('--asset-dir',type=Path,required=True);a.add_argument('--expanded-root',type=Path,required=True);a.add_argument('--restored-root',type=Path,required=True);a.add_argument('--release-api-json',type=Path,required=True);a.add_argument('--tag-ref-api-json',type=Path,required=True);a.add_argument('--annotated-tag-api-json',type=Path);a.add_argument('--actual-download-provenance',type=Path,required=True);a.add_argument('--isolation-probe-json',type=Path,required=True);a.add_argument('--output',type=Path,required=True)
 opt=a.parse_args(); assets=opt.asset_dir.resolve(strict=True); root=opt.expanded_root.resolve(strict=True); api=load(opt.release_api_json);provenance=load(opt.actual_download_provenance)
 errors=[]; asset_rows=[]; file_rows=[]; symlink_rows=[];original_rows=[]
 tag=load(opt.tag_ref_api_json);tag_object=tag.get('object',{})
 if tag_object.get('type')=='tag' and opt.annotated_tag_api_json:tag_object=load(opt.annotated_tag_api_json).get('object',{})
 tag_commit_ok=tag.get('ref')=='refs/tags/v1.0.0' and tag_object.get('type')=='commit' and tag_object.get('sha')==EXPECTED_COMMIT
 if not tag_commit_ok:errors.append({'type':'Actual public tag commit does not equal accepted source commit'})
 if not all(provenance.get(k) is True for k in ['download_passed','verify_passed','restore_passed']):raise RuntimeError('Actual-download marker has not passed download/verify/restore')
 isolation=load(opt.isolation_probe_json)
 if not isolation.get('passed'):raise RuntimeError('Original-input denial probe not passed')
 runtime_denials=[]
 for denied in [Path('/Users/qianqiming/Documents/Codex/2026-10-19/new-chat/outputs/启明火箭/打开项目.html'),Path('/Users/qianqiming/Documents/Codex/2026-10-19/ni/work/rocket/parts.json'),Path('/Users/qianqiming/Desktop/火箭设计 中文版'),Path('/Users/qianqiming/Desktop/skill-repos/scenario-labs--blender-expert-skills/scenario-blender-animation/SKILL.md')]:
  try:
   if denied.suffix:
    with denied.open('rb') as f:f.read(1)
   else:list(denied.iterdir())
   denied_ok=False
  except PermissionError:denied_ok=True
  runtime_denials.append({'path':str(denied),'denied_with_PermissionError':denied_ok})
 if not all(x['denied_with_PermissionError'] for x in runtime_denials):raise RuntimeError('Current verification process lacks OS original-input denial')
 manifest_path=assets/'release-manifest.json';manifest=load(manifest_path)
 if digest(manifest_path)!=EXPECTED_MANIFEST:errors.append({'type':'Unexpected manifest SHA'})
 if manifest.get('status')!='final_frozen_local_snapshot':errors.append({'type':'Manifest is not final frozen'})
 expected_assets=load(assets/'assets.json')['assets'];sums={name:d for d,name in (line.split(None,1) for line in (assets/'SHA256SUMS').read_text().splitlines() if line.strip())};api_assets={x['name']:x for x in api['assets']}
 names={f'qiming-visual-{n:03d}-of-006.tar.gz' for n in range(1,7)}|{'qiming-audio-noncommercial-001-of-001.tar.gz','assets.json','release-manifest.json','SHA256SUMS'}
 if {r['name'] for r in expected_assets}!=names-{'assets.json','release-manifest.json','SHA256SUMS'}:errors.append({'type':'Unexpected seven-archive metadata name set'})
 if set(api_assets)!=names:errors.append({'type':'Public asset name set mismatch','missing':sorted(names-set(api_assets)),'unexpected':sorted(set(api_assets)-names)})
 if api.get('draft') or api.get('tag_name')!='v1.0.0':errors.append({'type':'Release not public final v1.0.0'})
 for name in sorted(names):
  p=inside(assets,name);r=api_assets.get(name,{})
  if not p.is_file() or p.is_symlink():errors.append({'type':'Asset missing or symlink','path':name});continue
  sha=digest(p); expected=sums.get(name); remote=r.get('digest');expected_meta=next((x for x in expected_assets if x['name']==name),None)
  ok=p.stat().st_size==r.get('size') and remote=='sha256:'+sha and (expected is None or expected==sha) and (expected_meta is None or (expected_meta['bytes']==p.stat().st_size and expected_meta['sha256']==sha))
  asset_rows.append({'name':name,'bytes':p.stat().st_size,'sha256':sha,'GitHub_API_digest':remote,'GitHub_API_download_url':r.get('browser_download_url'),'passed':ok})
  if not ok:errors.append({'type':'Actual asset SHA/size/API digest mismatch','path':name})
 for row in manifest['files']:
  try:
   p=inside(root,row['path']);ok=p.is_file() and not p.is_symlink() and p.stat().st_size==row['bytes'] and digest(p)==row['sha256']
  except (OSError,ValueError):ok=False
  file_rows.append({'path':row['path'],'layer':row['layer'],'passed':ok})
  if not ok:errors.append({'type':'Expanded actual file byte/SHA/boundary mismatch','path':row['path']})
 for row in manifest['symlinks']:
  try:
   p=inside(root,row['path']);ok=p.is_symlink() and os.readlink(p)==row['target'] and p.exists()
  except (OSError,ValueError):ok=False
  symlink_rows.append({'path':row['path'],'target':row['target'],'passed':ok})
  if not ok:errors.append({'type':'Declared internal alias mismatch','path':row['path']})
 base=root/'outputs/启明火箭/source/original-project'; original=load(base.parent/'original-project-manifest.json')
 for row in original['files']:
  try:
   p=inside(base.resolve(strict=True),row['relative_path']);ok=p.is_file() and not p.is_symlink() and p.stat().st_size==row['bytes'] and digest(p)==row['sha256']
  except (OSError,ValueError):ok=False
  original_rows.append({'relative_path':row['relative_path'],'passed':ok})
  if not ok:errors.append({'type':'Original source snapshot mismatch','path':row['relative_path']})
 if len(original_rows)!=392:errors.append({'type':'Original source count not392'})
 unsafe_links=[]
 for p in root.rglob('*'):
  if p.is_symlink() and (not p.resolve().is_relative_to(root) or not p.exists()):unsafe_links.append(p.relative_to(root).as_posix())
 if unsafe_links:errors.append({'type':'External/broken symlinks found','paths':unsafe_links})
 visual_audio=[];html=[];video=[]
 for row in manifest['files']:
  if row['layer']!='visual':continue
  p=inside(root,row['path'])
  if p.suffix.lower() in {'.wav','.mp3','.m4a','.aac','.flac','.ogg'} or '/source/audio/' in row['path']:visual_audio.append(row['path'])
  if p.suffix.lower()=='.html':
   found=False;tail=b''
   with p.open('rb') as f:
    for b in iter(lambda:f.read(1024*1024),b''):
     b=tail+b;found|=bool(re.search(rb'data:audio/',b,re.I));tail=b[-32:]
   html.append({'path':row['path'],'embedded_audio':found})
  if p.suffix.lower()=='.mp4':
   z=subprocess.run(['ffprobe','-v','error','-select_streams','a','-show_entries','stream=index','-of','json',str(p)],capture_output=True,text=True)
   video.append({'path':row['path'],'probe_exit':z.returncode,'audio_stream_count':len(json.loads(z.stdout).get('streams',[])) if z.returncode==0 else None})
 if visual_audio or any(x['embedded_audio'] for x in html) or any(x['probe_exit']!=0 or x['audio_stream_count']!=0 for x in video):errors.append({'type':'Visual/noncommercial layer leakage'})
 fontbase=root/'outputs/启明火箭/source/component-illustrations';font=load(fontbase/'font-safe-manifest.json');fresh=load(fontbase/'fresh-reopen-audit.json');freshrows={r['id']:r for r in fresh['items']};fonts=[]
 for row in font['items']:
  p=inside(root,row['release_path']);reopen=freshrows.get(row['id'],{});ok=digest(p)==row['published_sha256']==reopen.get('published_sha256') and reopen.get('font_object_count')==0 and reopen.get('restricted_packed_vfont_count')==0 and reopen.get('external_blend_library_count')==0
  fonts.append({'id':row['id'],'published_sha256':row['published_sha256'],'actual_downloaded_bytes_and_bound_reopen_audit_passed':ok})
 if len(fonts)!=62 or not all(x['actual_downloaded_bytes_and_bound_reopen_audit_passed'] for x in fonts):errors.append({'type':'62 font-safe actual bytes/reopen audit binding failed'})
 atlas=root/'outputs/启明火箭/library/部件说明图册/部件说明图册.html';atlas_ok=digest(atlas)=='f968452fd599c43f2edb7f2ead8c381f0c0b13a2e7f37521516a36f8b29e9ca9'
 if not atlas_ok:errors.append({'type':'Accepted current atlas hash mismatch'})
 restored=opt.restored_root.resolve(strict=True); ref=load(root/'release-metadata/restoration-reference.json');rh=restored/'逐步虚拟归位.html';rm=restored/'media/逐步虚拟归位讲解.mp4'
 def run(args):
  z=subprocess.run(args,capture_output=True,text=True)
  if z.returncode:raise RuntimeError('Read-only media check failed: '+args[0])
  return z.stdout
 html_exact=digest(rh)==ref['original_combined_html_sha256']=='42df32ff769517f160a4d1fa9333bf20d6195c2873a6cf7117985fe9a4dc1ff3'
 packet={k:run(['ffmpeg','-nostdin','-v','error','-i',str(rm),'-map',f'0:{k}:0','-c','copy','-f','hash','-hash','sha256','-']).strip().split('=')[-1] for k in ['v','a']}
 pr=json.loads(run(['ffprobe','-v','error','-count_frames','-show_entries','stream=codec_type,nb_read_frames,width,height,duration,sample_rate,channels','-of','json',str(rm)]));vs=next(x for x in pr['streams'] if x['codec_type']=='video');aus=next(x for x in pr['streams'] if x['codec_type']=='audio');media_ok=html_exact and packet['v']==ref['original_video_packet_sha256'] and packet['a']==ref['original_audio_packet_sha256'] and int(vs['nb_read_frames'])==6051 and (vs['width'],vs['height'])==(1280,720) and abs(float(vs['duration'])-201.7)<.04 and int(aus['sample_rate'])==24000 and int(aus['channels'])==1 and abs(float(aus['duration'])-201.7)<.05
 if not media_ok:errors.append({'type':'Restored HTML/AV identity/frames mismatch'})
 report={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Independent checks on parent-confirmed actual newly downloaded public release and actual expanded filesystem, executed with OS original-input denial; no source workspace fallback, extraction, mutation, new restoration or cleanup.','repository_commit_expected':EXPECTED_COMMIT,'actual_public_tag_resolved_commit':tag_object.get('sha'),'public_tag_commit_passed':tag_commit_ok,'public_release_url':api.get('html_url'),'public_release_id':api.get('id'),'actual_download_provenance':provenance,'original_input_denial_used':True,'actual_isolation_probe':isolation,'assets_directory':str(assets),'expanded_root':str(root),'manifest_sha256':digest(manifest_path),'file_count':len(file_rows),'file_sha_errors':sum(not x['passed'] for x in file_rows),'logical_bytes':sum(x['bytes'] for x in manifest['files']),'assets_checked':asset_rows,'declared_symlinks_checked':symlink_rows,'unsafe_actual_symlinks':unsafe_links,'original_392_file_checks':original_rows,'original_392_all_passed':len(original_rows)==392 and all(x['passed'] for x in original_rows),'source_Desktop_directory_not_read_or_modified_during_this_sandboxed_QA':True,'visual_forbidden_audio_paths':visual_audio,'visual_HTML':html,'visual_MP4':video,'font_safe_62_actual_byte_and_bound_audit_checks':fonts,'accepted_atlas_current_f968_hash_passed':atlas_ok,'restored_HTML_exact42df':html_exact,'restored_AV_packet_sha256':packet,'restored_AV_packet_SHA_frame_resolution_rate_contract_passed':media_ok,'restored_probe':pr,'movie_container_byte_identity_claimed':False,'all_passed':not errors and len(file_rows)==3829 and len(asset_rows)==10,'errors':errors,'files':file_rows,'no_new_Blender_render_browser_or_restore_executed':True}
 report['current_same_process_original_input_denials']=runtime_denials
 report['actual_executed_helper_sha256']=digest(Path(__file__))
 report['original_source_ZIP_container_count']=sum(x['relative_path'].lower().endswith('.zip') for x in original_rows)
 opt.output.parent.mkdir(parents=True,exist_ok=True);opt.output.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'all_passed':report['all_passed'],'files':len(file_rows),'assets':len(asset_rows),'originals':len(original_rows),'errors':errors},ensure_ascii=False))
 if not report['all_passed']:raise SystemExit(1)
if __name__=='__main__':main()
