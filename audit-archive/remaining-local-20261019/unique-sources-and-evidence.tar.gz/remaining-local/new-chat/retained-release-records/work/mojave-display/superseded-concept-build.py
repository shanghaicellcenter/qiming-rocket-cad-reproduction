"""Mojave Sphinx exterior study: NON-FUNCTIONAL CONCEPT DISPLAY ONLY.

This file creates a new scene from primitives. It never reads CAD, drawings,
engineering measurements, simulation, or original project geometry. The sole
visual reference is p001_i5.jpeg. Coordinates are arbitrary normalized display
units. No manufacturing or propulsion geometry is represented.

Run with a factory background Blender session, for example:
Blender --background --factory-startup --python-exit-code 1 --python build_display.py
Optional: -- --stage blockout. Re-running replaces only this display's outputs.
"""
import bpy
import bmesh
import json
import math
import os
import sys
from pathlib import Path
from mathutils import Vector, Matrix

BASE = Path(__file__).resolve().parent.parent
MODEL_DIR = BASE / "model"
RENDER_DIR = BASE / "renders"
WORK_DIR = BASE.parent.parent / "work" / "mojave-display"
for d in (MODEL_DIR, RENDER_DIR, WORK_DIR):
    d.mkdir(parents=True, exist_ok=True)
FULL = "blockout" not in sys.argv
REFERENCE = "/Users/qianqiming/Desktop/火箭设计 中文版/中文文档/images/p001_i5.jpeg"
SAFETY = "Conceptual non-functional exterior display; arbitrary units; no manufacturing or flight use."

# A factory session is required by the accompanying workflow. This scene was
# created here; no object belonging to an existing user scene is touched.
for ob in list(bpy.data.objects):
    bpy.data.objects.remove(ob, do_unlink=True)
scene = bpy.context.scene
scene.name = "01_Assembly_Concept_Display"
scene.unit_settings.system = "NONE"
scene["display_only"] = True
scene["units"] = "arbitrary normalized display units; not real-world measurements"
scene["reference"] = REFERENCE
scene["status"] = SAFETY

model_col = bpy.data.collections.new("MOJAVE_Concept_Exterior")
scene.collection.children.link(model_col)
studio_col = bpy.data.collections.new("Studio_Presentation_Only")
scene.collection.children.link(studio_col)
groups = {}
GROUP_LABELS = {
    "01": "Nose silhouette / illustrative exterior",
    "02": "White upper shell / illustrative exterior",
    "03": "Red visual separation band / decorative seam",
    "04": "Silver main shell / solid closed display body",
    "05": "Open rear frame / exterior-only approximation",
    "06": "Swept red fins / hidden-side count inferred",
    "07": "Visible surface details / decorative guide lines",
    "08": "Inert solid placeholders / unspecified interiors",
}
for gid, label in GROUP_LABELS.items():
    e = bpy.data.objects.new(f"Group_{gid}_{label.split(' / ')[0]}", None)
    model_col.objects.link(e)
    e.empty_display_type = "PLAIN_AXES"
    e.empty_display_size = .12
    e["conceptual"] = True
    e["display_group"] = gid
    e["description"] = label
    groups[gid] = e

all_meshes = []

def material(name, color, metallic=0, roughness=.35):
    m = bpy.data.materials.new(name)
    m.diffuse_color = (*color, 1)
    m.use_nodes = True
    bs = m.node_tree.nodes.get("Principled BSDF")
    bs.inputs["Base Color"].default_value = (*color, 1)
    bs.inputs["Metallic"].default_value = metallic
    bs.inputs["Roughness"].default_value = roughness
    return m

white = material("Concept_Pearl_White", (.78, .79, .77), .03, .28)
red = material("Concept_Oxblood_Red", (.235, .008, .016), .17, .25)
silver = material("Concept_Satin_Aluminium", (.47, .53, .58), .78, .30)
edge_metal = material("Concept_Bright_Edge_Aluminium", (.68, .73, .76), .8, .23)
dark = material("Concept_Graphite_Accent", (.035, .046, .055), .52, .32)
black = material("Concept_Decorative_Seam", (.026, .029, .031), .15, .45)
inert = material("Concept_Inert_Blank", (.14, .18, .19), .20, .48)
brass = material("Concept_Muted_Brass_Accent", (.40, .25, .065), .65, .33)
floor_mat = material("Studio_Warm_Grey", (.13, .16, .19), .05, .6)

# Very fine visual roughness only; this is not a manufacturing texture map.
nt = silver.node_tree
noise = nt.nodes.new("ShaderNodeTexNoise")
noise.name = "Subtle_Display_Finish"
noise.inputs["Scale"].default_value = 13
noise.inputs["Detail"].default_value = 2
noise.location = (-450, -180)
mapr = nt.nodes.new("ShaderNodeMapRange")
mapr.inputs["From Min"].default_value = 0
mapr.inputs["From Max"].default_value = 1
mapr.inputs["To Min"].default_value = .27
mapr.inputs["To Max"].default_value = .34
mapr.location = (-210, -170)
nt.links.new(noise.outputs["Fac"], mapr.inputs["Value"])
nt.links.new(mapr.outputs["Result"], nt.nodes.get("Principled BSDF").inputs["Roughness"])

def relink(ob, col):
    for c in list(ob.users_collection):
        c.objects.unlink(ob)
    col.objects.link(ob)

def register(ob, name, mat, gid, note="Exterior form inferred from one image."):
    ob.name = name
    relink(ob, model_col)
    ob.parent = groups[gid]
    ob["conceptual"] = True
    ob["display_group"] = gid
    ob["source_type"] = "visual-reference approximation"
    ob["detail_status"] = note
    ob["not_for_manufacture"] = True
    if mat:
        ob.data.materials.append(mat)
    all_meshes.append(ob)
    return ob

def bevel(ob, width=.008, segments=3, weighted=True):
    be = ob.modifiers.new("Display_Edge_Soften", "BEVEL")
    be.width = width
    be.segments = segments
    be.limit_method = "ANGLE"
    be.angle_limit = math.radians(30)
    be.harden_normals = True
    if weighted:
        wn = ob.modifiers.new("Display_Weighted_Normals", "WEIGHTED_NORMAL")
        wn.keep_sharp = True
    return ob

def mesh_obj(name, verts, faces, mat, gid, note, smooth=False):
    me = bpy.data.meshes.new(name + "_Mesh")
    me.from_pydata(verts, [], faces)
    me.update()
    ob = bpy.data.objects.new(name, me)
    model_col.objects.link(ob)
    for p in me.polygons:
        p.use_smooth = smooth
    return register(ob, name, mat, gid, note)

def lathe(name, profile, mat, gid, cap=True, closed_profile=False, segments=96, note="Solid exterior display shape; no specified interior."):
    verts = [(x, r*math.cos(2*math.pi*j/segments), r*math.sin(2*math.pi*j/segments))
             for x, r in profile for j in range(segments)]
    faces = []
    cnt = len(profile) if closed_profile else len(profile)-1
    for k in range(cnt):
        kn = (k+1) % len(profile)
        for j in range(segments):
            q = (j+1) % segments
            faces.append((k*segments+j, k*segments+q, kn*segments+q, kn*segments+j))
    side_count = len(faces)
    if cap and not closed_profile:
        faces.append(tuple(reversed(range(segments))))
        faces.append(tuple((len(profile)-1)*segments+j for j in range(segments)))
    ob = mesh_obj(name, verts, faces, mat, gid, note, True)
    for p in list(ob.data.polygons)[side_count:]:
        p.use_smooth = False
    return ob

def cyl_x(name, x0, x1, radius, mat, gid, width=.006, segments=96, note="Solid closed display cylinder; no pressure vessel or internal dimensions."):
    ob = lathe(name, [(x0, radius), (x1, radius)], mat, gid, segments=segments, note=note)
    if width:
        bevel(ob, width)
    return ob

def collar(name, x, width, radius, thickness, mat, gid, note="Exterior decorative collar; dimensions arbitrary."):
    return bevel(lathe(name, [(x-width/2, radius), (x+width/2, radius),
                    (x+width/2, radius-thickness), (x-width/2, radius-thickness)],
                    mat, gid, cap=False, closed_profile=True, note=note), min(width/6, .006))

def cube(name, size, loc, mat, gid, rounding=.008, rotation=(0,0,0), note="Decorative exterior block; not an engineering part."):
    bpy.ops.mesh.primitive_cube_add(size=1, location=loc, rotation=rotation)
    ob = bpy.context.object
    ob.scale = size
    ob.data.transform(Matrix.Diagonal((*ob.scale, 1)))
    ob.scale = (1,1,1)
    for p in ob.data.polygons:
        p.use_smooth = True
    register(ob, name, mat, gid, note)
    if rounding:
        bevel(ob, rounding)
    return ob

def rod_between(name, p0, p1, radius, mat, gid, note="Decorative line; no service routing or connection specification.", vertices=20):
    p0, p1 = Vector(p0), Vector(p1)
    d = p1-p0
    bpy.ops.mesh.primitive_cylinder_add(vertices=vertices, radius=radius, depth=d.length, end_fill_type="NGON", location=(p0+p1)*.5)
    ob = bpy.context.object
    ob.rotation_euler = d.to_track_quat("Z", "Y").to_euler()
    for p in ob.data.polygons:
        p.use_smooth = len(p.vertices) == 4
    return register(ob, name, mat, gid, note)

def radial_disc(name, x, theta, r, disc_r, depth, mat, gid):
    n = Vector((0, math.cos(theta), math.sin(theta)))
    center = Vector((x, 0, 0)) + n*r
    ob = rod_between(name, center-n*depth/2, center+n*depth/2, disc_r, mat, gid,
        note="Unthreaded solid decorative fastener-head marker; placement and count illustrative.", vertices=24)
    bevel(ob, .0025, 2)
    return ob

def fin(name, theta):
    # A closed, solid visual plate; no aerodynamic profile or attachment design.
    profile = [(-7.55,.47), (-7.72,1.48), (-6.97,1.66), (-5.18,.48)]
    thick = .050
    radial = Vector((0, math.cos(theta), math.sin(theta)))
    tangent = Vector((0, -math.sin(theta), math.cos(theta)))
    verts = []
    for side in (-1,1):
        for x, r in profile:
            verts.append(tuple(Vector((x,0,0))+radial*r+tangent*(side*thick/2)))
    n = len(profile)
    faces = [tuple(reversed(range(n))), tuple(range(n,2*n))]
    faces += [(i, (i+1)%n, (i+1)%n+n, i+n) for i in range(n)]
    ob = mesh_obj(name, verts, faces, red, "06",
        "Visible red swept silhouette; hidden-side fin count and exact outline not resolved by single reference.")
    return bevel(ob, .012, 3)

# -------- Stage 1: silhouette and largest material areas. --------
# These proportions are a visual interpretation, not project measurements.
cyl_x("C04_Silver_Closed_Exterior", -4.45, 2.16, .435, silver, "04")
cyl_x("C02_White_Lower_Exterior", 2.16, 4.34, .450, white, "02")
cyl_x("C02_White_Upper_Exterior", 4.40, 6.76, .450, white, "02")
cyl_x("C03_Red_Decorative_Separation", 4.34, 4.40, .452, red, "03", width=.003)
white_profile = []
for i in range(29):
    t = i/28
    white_profile.append((6.76+1.22*t, .45*(1-t)**.63))
white_profile[-1] = (7.98,.105)
# Use an explicit smooth decreasing profile to keep the white/red junction clean.
white_profile = [(6.76,.450),(6.88,.444),(7.00,.429),(7.12,.406),(7.24,.375),
                 (7.36,.338),(7.48,.293),(7.60,.244),(7.72,.192),(7.84,.143),(7.98,.090)]
lathe("C01_White_Nose_Exterior", white_profile, white, "01", segments=128)
lathe("C01_Red_Tip_Exterior", [(7.979,.090),(8.05,.062),(8.12,.035),(8.19,.012),(8.21,.004)], red, "01", segments=96)

for i, theta in enumerate((math.radians(30), math.radians(150), math.radians(270))):
    fin(f"C06_Illustrative_Swept_Fin_{i+1:02d}", theta)
for i, theta in enumerate((0,math.pi/2,math.pi,3*math.pi/2)):
    cube(f"C05_Exterior_Frame_Rail_{i+1:02d}", (3.28,.090,.075),
         (-6.05,.475*math.cos(theta),.475*math.sin(theta)), edge_metal, "05", .012,
         rotation=(theta,0,0), note="Open exterior frame outline inferred visually; cross-section arbitrary.")

# Closed tail display disc intentionally prevents any implied nozzle or flow path.
cyl_x("C08_Solid_Blank_Tail_Face", -7.73,-7.66,.355,inert,"08",width=.006,
      note="Fully solid inert display disc. No nozzle, bore, chamber, or functional interior.")
collar("C05_Rear_Visual_Rim",-7.70,.09,.455,.070,silver,"05")
collar("C05_Front_Visual_Rim",-4.45,.17,.465,.045,silver,"05")

if FULL:
    # -------- Stage 2: exterior collars and visible panel rhythm. --------
    for name,x,w,r,mat,gid in [
        ("C04_Front_Shell_Trim",2.155,.080,.448,edge_metal,"04"),
        ("C04_Rear_Shell_Trim",-4.40,.115,.449,edge_metal,"04"),
        ("C02_Upper_Panel_Line",6.76,.019,.453,silver,"02"),
        ("C01_Nose_Panel_Line",7.25,.015,.373,silver,"01"),
        ("C02_White_Base_Trim",2.255,.032,.454,edge_metal,"02"),
        ("C03_Lower_Seam_Shadow",4.326,.010,.452,black,"03"),
        ("C03_Upper_Seam_Shadow",4.414,.010,.452,black,"03")]:
        collar(name,x,w,r,.020,mat,gid)
    # Only exterior ribs; the open bay has no pressure or propulsion mechanism.
    for i,x in enumerate((-7.18,-5.77,-4.72)):
        collar(f"C05_Exterior_Cage_Hoop_{i+1:02d}",x,.065,.468,.047,silver,"05")
    for i,theta in enumerate((0,math.pi/2,math.pi,3*math.pi/2)):
        for j,x in enumerate((-7.43,-6.82,-5.62,-4.74)):
            cube(f"C05_Visible_Rail_Tab_{i+1:02d}_{j+1:02d}",(.17,.11,.055),
                 (x,.510*math.cos(theta),.510*math.sin(theta)),silver,"05",.008,
                 rotation=(theta,0,0),note="Solid exterior visual tab; spacing and attachments illustrative.")
            radial_disc(f"C07_Rail_Head_{i+1:02d}_{j+1:02d}",x,theta,.547,.036,.025,dark,"07")
            radial_disc(f"C07_Rail_Head_Center_{i+1:02d}_{j+1:02d}",x,theta,.562,.014,.006,edge_metal,"07")
    # Unspecified inner volumes are deliberately reduced to disconnected solid
    # blanks, with no seals, valves, fluid path, injector, wiring or interfaces.
    cube("C08_Inert_Blank_A",(.87,.28,.23),(-6.57,0,-.01),inert,"08",.055,
         note="Abstract solid placeholder, disconnected; no system or service geometry represented.")
    cube("C08_Inert_Blank_B",(.60,.25,.20),(-5.29,0,.01),inert,"08",.045,
         note="Abstract solid placeholder, disconnected; no mechanism represented.")
    # Simple blank accents keep the material hierarchy of the reference.
    cube("C08_Inert_Red_Surface_Accent",(.80,.035,.10),(-6.60,-.162,-.025),red,"08",.012,
         note="Purely visual red surface accent on a solid placeholder.")
    # Surface-guide lines are external graphic accents; not functional routing.
    for k,theta in enumerate((math.radians(225),math.radians(315))):
        n = Vector((0,math.cos(theta),math.sin(theta)))
        p0=Vector((-4.33,0,0))+n*.458
        p1=Vector((2.02,0,0))+n*.458
        rod_between(f"C07_External_Decorative_Line_{k+1:02d}",p0,p1,.011,dark,"07")
        for j,x in enumerate((-3.9,-2.3,-.7,.9,1.9)):
            radial_disc(f"C07_Guide_Line_Blank_Marker_{k+1:02d}_{j+1:02d}",x,theta,.464,.022,.023,edge_metal,"07")
        for j,x in enumerate((-4.12,1.87)):
            radial_disc(f"C07_Muted_Accent_{k+1:02d}_{j+1:02d}",x,theta,.474,.037,.04,brass,"07")
    # Head markers have no threads, screw drive, hole or build specification.
    for row,x in enumerate((2.28,6.56)):
        for j in range(8):
            theta=2*math.pi*j/8+math.pi/8
            radial_disc(f"C07_White_Surface_Head_{row+1:02d}_{j+1:02d}",x,theta,.453,.024,.012,dark,"07")
    for row,x in enumerate((-7.70,-4.43)):
        for j in range(12):
            theta=2*math.pi*j/12
            radial_disc(f"C07_Frame_Rim_Head_{row+1:02d}_{j+1:02d}",x,theta,.469,.022,.020,edge_metal,"07")
    for fi,theta in enumerate((math.radians(30),math.radians(150),math.radians(270))):
        for j,x in enumerate((-7.30,-6.85,-6.40,-5.95,-5.50)):
            n=Vector((0,math.cos(theta),math.sin(theta)))
            tangent=Vector((0,-math.sin(theta),math.cos(theta)))
            center=Vector((x,0,0))+n*.52+tangent*.043
            ob=rod_between(f"C07_Fin_Visual_Head_{fi+1:02d}_{j+1:02d}",
                           center-tangent*.009,center+tangent*.009,.029,edge_metal,"07",
                           note="Unthreaded decorative exterior head marker; no attachment instructions.",vertices=24)
            bevel(ob,.002,2)

# -------- Presentation studio. --------
world=bpy.data.worlds.new("Neutral_Studio_World")
world.use_nodes=True
world.node_tree.nodes["Background"].inputs["Color"].default_value=(.10,.13,.17,1)
world.node_tree.nodes["Background"].inputs["Strength"].default_value=.32
scene.world=world
bpy.ops.mesh.primitive_plane_add(size=200,location=(0,0,-1.85))
floor=bpy.context.object
floor.name="Studio_Ground_Not_Part_Of_Model"
relink(floor,studio_col)
floor.data.materials.append(floor_mat)
floor["presentation_only"]=True

def area(name,loc,energy,size,color,target=(0,0,0),shape="DISK",size_y=None):
    data=bpy.data.lights.new(name,"AREA")
    data.energy=energy
    data.shape=shape
    data.size=size
    if shape=="RECTANGLE": data.size_y=size_y or size
    data.color=color
    ob=bpy.data.objects.new(name,data)
    studio_col.objects.link(ob)
    ob.location=loc
    ob.rotation_euler=(Vector(target)-ob.location).to_track_quat("-Z","Y").to_euler()
    ob["presentation_only"]=True
    return ob

area("Studio_Key_Softbox",(0,-6,9),2600,9,(1,.91,.80),shape="RECTANGLE",size_y=4)
area("Studio_Upper_Strip",(0,4,7),3200,12,(.80,.89,1),shape="RECTANGLE",size_y=2)
area("Studio_Rear_Rim",(-9,1.5,3.5),1000,5,(.85,.91,1),target=(-6,0,0))
area("Studio_Front_Fill",(7,-4,2.5),350,4,(1,.97,.91),target=(5,0,0))

def setup_scene(sc):
    sc.unit_settings.system="NONE"
    sc.render.engine="CYCLES"
    sc.cycles.samples=64 if FULL else 24
    sc.cycles.use_denoising=True
    sc.cycles.max_bounces=4
    sc.cycles.diffuse_bounces=2
    sc.cycles.glossy_bounces=3
    sc.cycles.transmission_bounces=0
    sc.cycles.use_light_tree=True
    sc.render.resolution_x=1600 if FULL else 1000
    sc.render.resolution_y=900 if FULL else 563
    sc.render.resolution_percentage=100
    sc.render.image_settings.file_format="PNG"
    sc.render.image_settings.color_mode="RGBA"
    sc.render.image_settings.color_depth="8"
    sc.render.film_transparent=False
    sc.view_settings.view_transform="AgX"
    if "AgX - Medium High Contrast" in [i.identifier for i in sc.view_settings.bl_rna.properties["look"].enum_items]:
        sc.view_settings.look="AgX - Medium High Contrast"
    else:
        try: sc.view_settings.look="AgX - Medium High Contrast"
        except TypeError: pass
    sc.view_settings.exposure=.35

def camera(sc,name,loc,target,ortho):
    data=bpy.data.cameras.new(name)
    ob=bpy.data.objects.new(name,data)
    sc.collection.objects.link(ob)
    ob.location=loc
    ob.rotation_euler=(Vector(target)-ob.location).to_track_quat("-Z","Y").to_euler()
    data.type="ORTHO"
    data.ortho_scale=ortho
    data.lens=85
    data.clip_end=500
    ob["presentation_only"]=True
    sc.camera=ob
    return ob

setup_scene(scene)
hero_cam=camera(scene,"Camera_Assembly",(-5,-24,14),(.15,0,0),18.3)

def render(sc,path,cam=None):
    if cam: sc.camera=cam
    sc.render.filepath=str(path)
    bpy.ops.render.render(write_still=True,scene=sc.name)

if not FULL:
    render(scene,WORK_DIR/"blockout_assembly.png")
    bpy.ops.wm.save_as_mainfile(filepath=str(WORK_DIR/"blockout.blend"))
    print("DISPLAY_RESULT="+json.dumps({"stage":"blockout","objects":len(all_meshes),"render":str(WORK_DIR/"blockout_assembly.png")},ensure_ascii=False))
    sys.exit(0)

# Read-only multi-angle review. The bundled review helper targets 5.2 and uses
# media_type, unavailable on this installed 4.4; this equivalent local review
# creates a disposable Workbench scene and leaves the delivered scene untouched.
def review_sheet(objs):
    import numpy as np
    sc=bpy.data.scenes.new("Temporary_Display_Review")
    for ob in objs: sc.collection.objects.link(ob)
    sc.render.engine="BLENDER_WORKBENCH"
    sc.render.resolution_x=640
    sc.render.resolution_y=360
    sc.render.resolution_percentage=100
    sc.render.image_settings.file_format="PNG"
    sc.display.shading.light="STUDIO"
    sc.display.shading.show_shadows=True
    sc.display.shading.show_cavity=True
    sc.view_settings.view_transform="Standard"
    sc.world=bpy.data.worlds.new("Temporary_Review_World")
    sc.world.color=(.72,.72,.72)
    ca=camera(sc,"Temporary_Review_Camera",(0,-26,0),(0,0,0),18.5)
    positions=[((0,-26,0),"side"),((0,0,26),"top"),((-8,-22,12),"threequarter"),((-8,-22,-8),"low")]
    panels=[]
    for mode in ("silhouette","matcap"):
        sh=sc.display.shading
        if mode=="silhouette":
            sh.light="FLAT";sh.color_type="SINGLE";sh.single_color=(0,0,0)
            sh.background_type="WORLD";sc.world.color=(1,1,1)
            sh.show_shadows=False;sh.show_cavity=False
        else:
            sh.light="MATCAP";sh.color_type="SINGLE";sh.studio_light="basic.sl"
            sh.background_type="WORLD";sc.world.color=(.14,.14,.14)
            sh.show_cavity=True
            # Blender ships several matcaps; choose one actually installed.
            mats=[x.name for x in bpy.context.preferences.studio_lights if x.type=="MATCAP"]
            if mats: sh.studio_light=next((x for x in mats if "studio" in x),mats[0])
        row=[]
        for pos,label in positions:
            ca.location=pos
            ca.rotation_euler=(Vector((0,0,0))-ca.location).to_track_quat("-Z","Y").to_euler()
            path=WORK_DIR/f"review_{mode}_{label}.png"
            render(sc,path)
            im=bpy.data.images.load(str(path),check_existing=False)
            ar=np.array(im.pixels[:],dtype=np.float32).reshape(360,640,4)
            row.append(ar)
            bpy.data.images.remove(im)
        panels.append(np.concatenate(row,axis=1))
    # Blender pixel buffers start at the lower left: matcap below silhouette.
    arr=np.concatenate(list(reversed(panels)),axis=0)
    out=bpy.data.images.new("Display_Review_Sheet",width=2560,height=720,alpha=True)
    out.pixels.foreach_set(arr.ravel())
    out.filepath_raw=str(RENDER_DIR/"05_review_sheet.png")
    out.file_format="PNG"
    out.save()
    bpy.data.images.remove(out)
    ca_data=ca.data
    bpy.data.objects.remove(ca,do_unlink=True)
    wo=sc.world
    bpy.data.scenes.remove(sc)
    bpy.data.cameras.remove(ca_data)
    bpy.data.worlds.remove(wo)

# Assembly, with editable groups retained.
render(scene,RENDER_DIR/"01_assembly.png")
tail_cam=camera(scene,"Camera_Rear_Exterior",(-9.5,-7.5,4.8),(-6.0,0,-.03),5.4)
render(scene,RENDER_DIR/"03_rear_exterior_closeup.png",tail_cam)
seam_cam=camera(scene,"Camera_Shell_Seams",(3.2,-9,4.5),(3.65,0,0),5.2)
render(scene,RENDER_DIR/"04_shell_seam_closeup.png",seam_cam)
scene.camera=hero_cam

# Exploded is an arbitrary display arrangement; no actual assembly sequence.
exploded=bpy.data.scenes.new("02_Exploded_Concept_Display")
exploded.world=world
exploded["display_only"]=True
exploded["status"]="Arbitrary visual group separation, not a physical disassembly or assembly procedure."
exploded["units"]="arbitrary display units"
excol=bpy.data.collections.new("MOJAVE_Exploded_Exterior_Concept")
exploded.collection.children.link(excol)
exploded.collection.children.link(studio_col)
offsets={"01":Vector((1.35,0,1.05)),"02":Vector((.55,0,.35)),
         "03":Vector((.25,0,1.35)),"04":Vector((0,0,0)),
         "05":Vector((-.55,0,-.05)),"06":Vector((-.55,0,-.05)),
         "07":Vector((0,-.75,.18)),"08":Vector((-.55,.25,1.55))}
for ob in all_meshes:
    cp=ob.copy()
    cp.name="EX_"+ob.name
    cp.parent=None
    cp.matrix_world=ob.matrix_world.copy()
    cp.location+=offsets[ob["display_group"]]
    if ob["display_group"]=="06":
        # Radial spread is for reading the red plates only.
        center=sum((cp.matrix_world@Vector(v) for v in cp.bound_box),Vector())/8
        radial=Vector((0,center.y,center.z+.05))
        if radial.length: cp.location+=radial.normalized()*.38
    cp["conceptual"]=True
    cp["exploded_status"]="Presentation offset only; no mechanical relation implied."
    excol.objects.link(cp)
setup_scene(exploded)
camera(exploded,"Camera_Exploded",(-5,-25,16),(.30,0,.45),21.8)
render(exploded,RENDER_DIR/"02_exploded.png")
review_sheet(all_meshes)

# Audit actual data and evaluated geometry without deriving engineering facts.
bpy.context.window.scene=scene
bpy.context.view_layer.update()
dg=bpy.context.evaluated_depsgraph_get()
object_audits=[]
totals={"mesh_objects":len(all_meshes),"base_vertices":0,"base_faces":0,"base_triangles":0,"evaluated_triangles":0,
        "boundary_edges":0,"non_manifold_edges":0,"loose_vertices":0,"loose_edges":0,"zero_area_faces":0,
        "unapplied_scale_objects":0,"all_meshes_conceptual":True}
for ob in all_meshes:
    bm=bmesh.new();bm.from_mesh(ob.data)
    me=ob.evaluated_get(dg).to_mesh()
    me.calc_loop_triangles()
    rep={"name":ob.name,"display_group":ob["display_group"],"conceptual":bool(ob.get("conceptual")),
         "vertices":len(ob.data.vertices),"faces":len(ob.data.polygons),
         "base_triangles":sum(len(p.vertices)-2 for p in ob.data.polygons),"evaluated_triangles":len(me.loop_triangles),
         "boundary_edges":sum(e.is_boundary for e in bm.edges),
         "non_manifold_edges":sum(not e.is_manifold for e in bm.edges),
         "loose_vertices":sum(not v.link_edges for v in bm.verts),
         "loose_edges":sum(not e.link_faces for e in bm.edges),
         "zero_area_faces":sum(f.calc_area()<1e-12 for f in bm.faces),
         "scale_applied":all(abs(s-1)<1e-6 for s in ob.scale),
         "detail_status":ob["detail_status"]}
    object_audits.append(rep)
    totals["base_vertices"]+=rep["vertices"]
    totals["base_faces"]+=rep["faces"]
    for key in ("base_triangles","evaluated_triangles","boundary_edges","non_manifold_edges","loose_vertices","loose_edges","zero_area_faces"):
        totals[key]+=rep[key]
    totals["unapplied_scale_objects"]+=not rep["scale_applied"]
    totals["all_meshes_conceptual"] &= rep["conceptual"]
    bm.free();ob.evaluated_get(dg).to_mesh_clear()

skill_samples=[]
try:
    sys.path.append("/Users/qianqiming/.codex/skills/scenario-blender-expert/scripts")
    import bx_audit
    for ob in [all_meshes[0],bpy.data.objects["C01_White_Nose_Exterior"],bpy.data.objects["C06_Illustrative_Swept_Fin_01"],bpy.data.objects["C05_Exterior_Frame_Rail_01"]]:
        ar=bx_audit.audit(ob,evaluated=True)
        skill_samples.append({"report":ar,"verdict_non_deforming":bx_audit.verdict(ar,deforming=False)})
except Exception as exc:
    skill_samples.append({"error":str(exc),"fallback":"All meshes checked with local bmesh audit above."})

notes="""MOJAVE SPHINX — NON-FUNCTIONAL EXTERIOR DISPLAY

This scene is an original visual interpretation of one overview image. It is
not an exact CAD reproduction. All units, proportions, seam widths, fastener
positions and details are illustrative. Mesh object counts are presentation
objects, not the original bill of materials.

No original CAD, drawings, dimensions, engineering archive, simulations or
manufacturing details have been read or imported by this build. The closed
body and tail blanks have no specified interior. Open-bay blocks are solid,
disconnected placeholders with no propulsion, pressure, fluid, ignition or
service function. The tail face is closed and solid. Decorative surface lines
do not represent functional connections. No printable STL is provided.

The hidden side, fin count, exact rear-frame construction and detailed surface
features cannot be confirmed from the sole image. Three fins are an explicitly
inferred display choice. No functional accuracy, flight worthiness, physical
disassembly sequence, loads, tolerances or manufacturability is claimed.

Scenes: 01_Assembly_Concept_Display and 02_Exploded_Concept_Display.
The exploded scene uses arbitrary offsets for readability only.
Eight named groups remain editable. Every model mesh has conceptual=True.

Built locally with factory Blender; no cloud generation or network use.
"""
text=bpy.data.texts.new("README_Concept_Display_Only")
text.write(notes)
if "build_display.py" not in bpy.data.texts:
    text_source=bpy.data.texts.new("build_display.py")
    text_source.write(Path(__file__).read_text())

audit={"project":"Mojave Sphinx — conceptual exterior display",
       "status":"NON-FUNCTIONAL VISUAL INTERPRETATION; NOT COMPLETE PROJECT REPRODUCTION",
       "blender_version":bpy.app.version_string,"blender_version_tuple":list(bpy.app.version),
       "render_engine":"Cycles CPU","samples":64,"resolution":[1600,900],
       "color_management":{"view_transform":scene.view_settings.view_transform,"look":scene.view_settings.look,"exposure":scene.view_settings.exposure},
       "source_reference":REFERENCE,"cad_imported":False,"network_used":False,
       "units":"arbitrary normalized display units; not physical measurements",
       "groups":GROUP_LABELS,"totals":totals,"objects":object_audits,"skill_audit_samples":skill_samples,
       "checks":{"all_meshes_closed_and_manifold":totals["non_manifold_edges"]==0,
                 "no_loose_geometry":totals["loose_vertices"]==0 and totals["loose_edges"]==0,
                 "no_degenerate_faces":totals["zero_area_faces"]==0,
                 "all_scale_applied":totals["unapplied_scale_objects"]==0,
                 "all_meshes_conceptual":totals["all_meshes_conceptual"]},
       "known_limitations":["Single image exterior interpretation only; not exact CAD.",
          "Hidden surfaces and fin count unresolved; three fins are illustrative.",
          "Seam, surface-head counts and rear details are illustrative.",
          "No functional propulsion, pressure, ignition, fluid or service geometry.",
          "Inert disconnected solids substitute unspecified inner volumes.",
          "Exploded offsets are presentation only, not a real assembly procedure.",
          "No validation against original CAD, dimensions, loads, simulations or manufacturing.",
          "No animation or physical behavior validation."]}

# Only the assembly's conceptual model objects are exported. Studio and cameras
# are absent from GLB. Mesh data remain editable in the native .blend.
bpy.ops.object.select_all(action="DESELECT")
for ob in all_meshes: ob.select_set(True)
for ob in groups.values(): ob.select_set(True)
bpy.context.view_layer.objects.active=all_meshes[0]
glb_path=MODEL_DIR/"mojave-sphinx-concept-display.glb"
try:
    bpy.ops.export_scene.gltf(filepath=str(glb_path),export_format="GLB",use_selection=True,
        export_apply=True,export_extras=True,export_yup=True,export_animations=False)
    audit["glb_export"]={"success":True,"path":str(glb_path),"bytes":glb_path.stat().st_size}
except Exception as exc:
    audit["glb_export"]={"success":False,"error":str(exc)}

bpy.ops.object.select_all(action="DESELECT")
groups["04"].select_set(True)
bpy.context.view_layer.objects.active=groups["04"]
scene.camera=hero_cam
for screen in bpy.data.screens:
    for area_ui in screen.areas:
        if area_ui.type=="VIEW_3D":
            area_ui.spaces.active.region_3d.view_distance=18
            area_ui.spaces.active.region_3d.view_location=Vector((0,0,0))
            area_ui.spaces.active.shading.type="MATERIAL"
blend_path=MODEL_DIR/"mojave-sphinx-concept-display.blend"
bpy.ops.wm.save_as_mainfile(filepath=str(blend_path))
audit["blend"]={"path":str(blend_path),"bytes":blend_path.stat().st_size}
(MODEL_DIR/"blender-audit.json").write_text(json.dumps(audit,ensure_ascii=False,indent=2))
(MODEL_DIR/"README.txt").write_text(notes)
print("DISPLAY_RESULT="+json.dumps({"stage":"final","blend":str(blend_path),"glb":audit["glb_export"],"totals":totals,"checks":audit["checks"]},ensure_ascii=False))
