"""Read-only checks and full-frame contact sheets for all source HD previews."""
from pathlib import Path
from collections import Counter
from PIL import Image,ImageDraw,ImageFont
import numpy as np,json,hashlib,math
ROOT=Path(__file__).resolve().parent
OUT=ROOT.parent.parent/'outputs/mojave-machine/library/part-previews'
REVIEW=OUT/'review';REVIEW.mkdir(exist_ok=True)
source=json.loads((ROOT/'original-part-library/original-part-library.audit.json').read_text())
audit=json.loads((OUT/'part-previews.audit.json').read_text())
assert audit['image_count']==465 and audit['source_record_count']==155
byid={x['source']['id']:x for x in source['items']}
views=('front','side','oblique');viewlabels={'front':'FRONT / tilted','side':'SIDE / tilted','oblique':'OBLIQUE / overview'}
rows=audit['rows'];mapping={};checks=[]
font=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',13)
small=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',12)
for row in rows:
 key=(row['source_id'],row['view']);assert key not in mapping;mapping[key]=row
 original=byid[row['source_id']];s=original['source'];path=OUT/(row['source_id']+'-'+row['view']+'.png')
 identity=(row['source_filename']==s['source_filename'] and row['format']==s['format'] and row['revision_group']==s['revision_group'] and row['source_triangles']==original['triangle_count'] and Path(row['image']).name==path.name)
 assert path.exists() and identity
 rawhash=hashlib.sha256(path.read_bytes()).hexdigest()
 with Image.open(path) as im:
  im.verify()
 with Image.open(path) as im:
  im=im.convert('RGBA');a=np.asarray(im.getchannel('A'));mask=a>127;y,x=np.nonzero(mask)
  assert im.size==(768,768) and len(x)>0 and rawhash==row['image_sha256']
  border=int(mask[:2].sum()+mask[-2:].sum()+mask[:,:2].sum()+mask[:,-2:].sum())
  check={'source_id':row['source_id'],'view':row['view'],'file':path.name,'source_filename':s['source_filename'],'source_identity_matches_original_library':identity,'png_sha256_matches_render_audit':rawhash==row['image_sha256'],'width':768,'height':768,'independent_nonempty_alpha_pixels':len(x),'independent_pixels_at_2px_border':border,'independent_bbox_pixels':[int(x.min()),int(y.min()),int(x.max()),int(y.max())],'clear_frame':border==0,'original_image_unchanged':True}
  checks.append(check)
assert len(mapping)==465 and set(mapping)=={(i,v) for i in byid for v in views}
CELL=224;RH=270;ids=[x['source']['id'] for x in source['items']];sheets=[]
for page in range(math.ceil(len(ids)/6)):
 group=ids[page*6:(page+1)*6];image=Image.new('RGB',(CELL*3,RH*6),(234,237,241));d=ImageDraw.Draw(image)
 for rr,identity in enumerate(group):
  orig=byid[identity]['source'];mass='Mass Volume'in orig['source_filename'];name=Path(orig['source_filename']).stem
  title=identity+' | '+name
  while font.getlength(title)>CELL*3-16:title=title[:-2]+'…'
  d.rectangle((0,rr*RH,CELL*3-1,rr*RH+23),fill=(221,227,235) if orig['format']=='USD_FROM_NATIVE' else (215,233,245))
  d.text((7,rr*RH+4),title,font=font,fill=(22,30,40))
  for cc,view in enumerate(views):
   row=mapping[(identity,view)];path=OUT/(identity+'-'+view+'.png')
   with Image.open(path) as src:
    thumb=src.convert('RGBA').resize((CELL,CELL),Image.Resampling.LANCZOS)
    bg=Image.new('RGBA',thumb.size,(246,247,249,255));bg.alpha_composite(thumb);image.paste(bg.convert('RGB'),(cc*CELL,rr*RH+46))
   label=(view.upper()+' | MASS VOLUME SOURCE') if mass else viewlabels[view]
   d.text((cc*CELL+6,rr*RH+27),label,font=small,fill=(122,63,15) if mass else (58,68,81))
 path=REVIEW/f'contactsheet-{page+1:02d}.png';image.save(path,optimize=True)
 sheets.append({'page':page+1,'file':path.name,'source_ids':group,'view_order':list(views),'image_count':len(group)*3,'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
assert sum(s['image_count'] for s in sheets)==465
index={'source_records':155,'hd_images':465,'views_per_source':3,'contactsheet_count':len(sheets),'all_source_ids_once_per_view':True,'qa_sheets_bytes':sum(s['bytes']for s in sheets),'sheet_geometry':'6 source rows x 3 complete image frames; each 768px original fitted to224px without crop','original_pngs_modified_or_moved':False,'image_checks':checks,'sheets':sheets,'source_mass_volume_ids':[i for i in ids if 'Mass Volume'in byid[i]['source']['source_filename']]}
assert index['qa_sheets_bytes']<25_000_000
(REVIEW/'contactsheet-index.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in index.items() if k not in ['image_checks','sheets']},indent=2))
