/* Mojave Sphinx: original-component inspection, built with Airsup Machine Skill.
 * Evidence: research/coverage.json; original STL bytes are embedded in data.js.
 * No geometry substitution, remeshing, mesh repair, performance solver or firing sequence.
 * Coordinates are translated and uniformly scaled for display. STL units are undeclared.
 * This is a component atlas, not an authoritative assembled rocket or engineering simulation.
 */
import { THREE, Lab, MAT, GEO } from './vendor/machine/kit/lab-kit.js';
import { STLLoader } from 'three/addons/loaders/STLLoader.js';
import { toCreasedNormals } from 'three/addons/utils/BufferGeometryUtils.js';
import { PARTS, COVERAGE, SUMMARY, REFERENCE } from './data.js';

const q=new URLSearchParams(location.search), reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
const lab=new Lab({prompt:'Mojave Sphinx · 从原始工程文件逐件检视',no:1,title:'Mojave Sphinx',sub:'原件 · 三维检视',size:.8,
 view:{az:12,el:46,dist:1.9,target:[0,.035,0],frameX:-.11,fov:32},autoOrbit:false,
 cut:{a:[0,0,1],b:[0,0,1],center:[0,.055,0],reach:.55},pills:['原始几何','逐文件核对','制作中']});
document.documentElement.lang='zh-CN';
document.title='Mojave Sphinx · 原件三维检视';
lab.renderer.setPixelRatio(lab.filmMode?Number(q.get('ss')||1):Math.min(devicePixelRatio,1.5));
lab._resize();
const applyView=lab._applyView.bind(lab);
lab._applyView=v=>{applyView(v);if(innerWidth<760){lab.camera.setViewOffset(innerWidth,innerHeight,0,innerHeight*.16,innerWidth,innerHeight);lab.camera.updateProjectionMatrix()}};
lab.grade.uniforms.uGrain.value=.004;
lab.key.shadow.mapSize.set(1024,1024);lab.key.shadow.blurSamples=8;
lab.ao.updateGtaoMaterial({samples:8});
// The contact-shadow map depends on the model, not an idle camera. Reuse it while stationary.
const updateContact=lab._contact.update.bind(lab._contact);let shadowSignature='';
lab._contact.update=()=>{const signature=[lab.currentPart,lab._assembly,lab.state.explode,lab.state.cut].map(v=>typeof v==='number'?v.toFixed(3):String(v)).join(':');if(signature!==shadowSignature){shadowSignature=signature;updateContact()}};
lab.hero({label:'当前显示的原始构件',unit:'件',max:PARTS.length});
const spread=lab.slider({id:'spread',label:'图谱展开',min:0,max:100,value:0,unit:'%',ends:['原件图谱','分开展示'],onInput:v=>{lab.target.explode=v/100}});
spread.el.setAttribute('aria-label','图谱展开程度');
lab.how('页面直接读取原包中的三角网格。每件保留原始三角面；居中、统一缩放及排布用于检视，不代表原装配配合。材质是展示赋色。STL 未声明单位，因此这里不显示制造尺寸。<br><br>目录中的 221 条是 CAD 文件记录，包含不同格式和装配文件，不能当作零件实例数。整箭装配尚未解析，本页不代表完整复现。',[
 '已读取几何数 = 成功解析且通过数量核对的原始 STL 数',
 '网格三角面 = Σ 原始 STL 中的面数',
 '展示排布 ≠ 原始装配变换；几何完整性 ≠ 工程适用性'
]);
lab.$('.lab-how summary').textContent='来源、范围与未完成项';
lab.$('.lab-scale').style.display='none';

const style=document.createElement('style');style.textContent=`
:root{--serif:Georgia,'Songti SC','STSong',serif;--sans:Inter,-apple-system,BlinkMacSystemFont,'PingFang SC','Microsoft YaHei',sans-serif;--mono:ui-monospace,Menlo,monospace}
.lab-prompt{max-width:65vw;font-size:12px;top:25px;left:30px}.lab-prompt b{font-size:11px;letter-spacing:.08em}.lab-pills{top:35px;right:30px;font-size:11px;gap:15px}
.lab-side{right:30px;width:270px;top:42%}.lab-title{font-size:40px}.lab-title i{font-family:var(--sans);font-size:15px;font-style:normal;letter-spacing:.12em;margin-top:15px}.lab-no{font-size:10px;letter-spacing:.14em}
.lab-big{font-size:88px}.lab-big i{font-family:var(--sans);font-size:14px;margin-left:12px}.lab-metric{margin-top:25px}.lab-sub{font-size:12px;line-height:1.8}.lab-ctl{margin-top:24px}.lab-ctl .row{font-size:12px}.lab-ctl input[type=range]{height:20px}.lab-ctl .ends{font-size:10px}.lab-ctl input[type=range]::-webkit-slider-thumb{width:20px;height:20px;margin-top:-7px}
.lab-how{right:30px;bottom:30px;width:270px;font-size:11px;max-height:38vh;overflow:auto;background:var(--paper)}.lab-how .eq{font-size:10px}
.lab-modes{left:30px;bottom:28px;font-size:11px;max-width:calc(100vw - 350px)}.lab-modes button{padding:9px 13px}.lab-lab{font-size:11px}
.inspect-toolbar{position:fixed;left:30px;top:85px;display:flex;gap:7px;z-index:5;flex-wrap:wrap;max-width:68vw}
.inspect-toolbar button,.inspect-toolbar select{font:12px var(--sans);border:1px solid #d6d4cc;border-radius:4px;padding:9px 11px;background:#f8f7f2;color:#242421;cursor:pointer}.inspect-toolbar button:hover{background:white}.inspect-toolbar button[aria-pressed=true]{background:#252623;color:#fff;border-color:#252623}
.inspect-toolbar select{max-width:210px}.inspect-help{position:fixed;left:30px;top:132px;font-size:10px;letter-spacing:.03em;color:#77776e;z-index:3}.part-detail{margin-top:18px;padding-top:15px;border-top:1px solid var(--line);font:11px/1.7 var(--sans);color:#6b6a64}.part-detail strong{font-weight:500;color:#242521;font-size:13px}.part-detail code{display:block;font:9px/1.5 var(--mono);overflow-wrap:anywhere;margin-top:5px;color:#89877e}.part-detail .flag{display:inline-block;background:#ebe8df;color:#6b6557;font-size:9px;letter-spacing:.08em;padding:2px 6px;margin:7px 0 3px}
.scope-note{position:fixed;left:30px;bottom:78px;z-index:3;font-size:10px;color:#8b8577;line-height:1.6;max-width:65vw}.scope-note b{font-weight:500;color:#74684b}
.inventory-button{margin-top:12px;padding:8px 12px;border:1px solid #d8d4c9;border-radius:3px;background:transparent;font:11px var(--sans);cursor:pointer;color:#4d4c45}
dialog{background:#f6f5ef;color:#252623;border:1px solid #d3d0c6;border-radius:8px;padding:24px;width:min(1020px,calc(100vw - 40px));max-height:83vh;box-sizing:border-box}dialog::backdrop{background:rgba(27,28,25,.36);backdrop-filter:blur(6px)}dialog h2{font:26px var(--serif);margin:0 0 8px}.dialog-head{display:flex;justify-content:space-between;gap:20px}.dialog-head button{border:0;background:none;font-size:22px;cursor:pointer}.dialog-note{font-size:12px;line-height:1.7;color:#777366;margin:8px 0 15px}.filters{display:flex;gap:10px;margin:14px 0}.filters input,.filters select{background:#fff;border:1px solid #ddd8cb;padding:10px;font:12px var(--sans);border-radius:3px}.filters input{flex:1;min-width:0}.table-wrap{overflow:auto;max-height:54vh}table{border-collapse:collapse;width:100%;font-size:11px;text-align:left}th{position:sticky;top:0;background:#eae8de;font-weight:500}th,td{padding:10px 12px;border-bottom:1px solid #e1ddd2}td.name{font:10px/1.5 var(--mono);overflow-wrap:anywhere;max-width:440px}td span.done{color:#276947}td span.pending{color:#8a7560}.record-count{font-size:11px;color:#807a69}.dialog-links{display:flex;gap:20px;margin-top:16px;font-size:11px}.dialog-links a{color:#5b6451}
.load-state{position:fixed;inset:0;z-index:99;background:#f3f2ee;display:grid;place-items:center;font:14px var(--sans)}.load-state small{display:block;color:#8c8b87;margin-top:12px;font-size:11px}
.lab-film .inspect-toolbar,.lab-film .inspect-help,.lab-film .scope-note,.lab-film .inventory-button{display:none}.lab-film .lab-beat{font-size:22px;bottom:36px;max-width:70vw}.lab-film .lab-beat>div>span{display:block;font-size:13px;margin-top:7px}.lab-film .lab-side{top:39%}.lab-film .part-detail{display:none}.lab-film .lab-no{display:none}
button:focus-visible,select:focus-visible,input:focus-visible,summary:focus-visible{outline:2px solid #a9633a;outline-offset:3px}
@media(max-width:760px){.lab-prompt{left:16px;right:16px;max-width:none;top:16px;font-size:10px}.inspect-toolbar{left:16px;right:16px;top:64px;max-width:none;gap:5px}.inspect-toolbar button,.inspect-toolbar select{font-size:10px;padding:8px}.inspect-toolbar select{max-width:154px}.inspect-help{left:16px;top:145px;font-size:9px}.lab-side{top:auto;bottom:100px;left:16px;right:16px;width:auto;display:grid;grid-template-columns:1fr 1fr;gap:0 20px;transform:none}.lab-title{font-size:26px}.lab-title i{font-size:11px;margin-top:7px}.lab-no{grid-column:1/-1;margin-bottom:9px}.lab-metric{margin-top:0;grid-row:2/4;grid-column:2}.lab-metric .lbl{font-size:10px}.lab-big{font-size:55px}.lab-sub{font-size:9px;line-height:1.6}.lab-ctls{grid-column:1/-1}.lab-ctl{margin-top:10px}.lab-ctl .ends{display:none}.part-detail{display:none}.scope-note{left:16px;right:16px;max-width:none;bottom:65px;font-size:9px}.lab-modes{left:16px;right:16px;bottom:15px;max-width:none;gap:4px}.lab-modes button{padding:8px 10px;font-size:10px}.lab-modes kbd{display:none}.inventory-button{font-size:10px;padding:6px 9px;margin-top:8px}.filters{flex-wrap:wrap}.filters select{width:110px}.dialog-links{flex-wrap:wrap;gap:10px}dialog{padding:17px}.lab-film .lab-side{display:none}.lab-film .lab-beat{font-size:16px;max-width:90vw;left:16px;bottom:25px}.lab-film .lab-beat>div>span{font-size:11px}}
@media(prefers-reduced-motion:reduce){*{scroll-behavior:auto!important}.lab-prompt .caret{animation:none!important}}
`;document.head.append(style);

const loader=new STLLoader(), items=[], raycaster=new THREE.Raycaster(), pointer=new THREE.Vector2();
const palettes={white:MAT.paint({color:[.78,.79,.76],roughness:.37,clearcoat:.22,finish:'cast'}),red:MAT.paint({color:[.28,.018,.025],roughness:.34,finish:'cast'}),polymer:MAT.plastic({color:[.16,.20,.20],roughness:.48}),metal:MAT.plastic({color:[.33,.37,.36],roughness:.43})};
const toBytes=s=>Uint8Array.from(atob(s),c=>c.charCodeAt(0)).buffer;
PARTS.forEach((p,i)=>{
 let geometry=loader.parse(toBytes(p.data));
 if(geometry.attributes.position.count/3!==p.triangles)throw new Error('原始面数不一致：'+p.id);
 const rawNormals=geometry.attributes.normal.array.slice();
 const rawPositions=geometry.attributes.position.array.slice();
 geometry=toCreasedNormals(geometry,Math.PI/5);
 if(!geometry.attributes.position.array.every((v,j)=>v===rawPositions[j]))throw new Error('法线处理改变了源顶点：'+p.id);
 geometry.userData.sourceNormals=rawNormals;
 geometry.computeBoundingBox();const box=geometry.boundingBox.clone(),center=box.getCenter(new THREE.Vector3());
 geometry.translate(-center.x,-box.min.y,-center.z);geometry.scale(.001,.001,.001);
 // 0.001 is a presentation factor only; source STL carries no unit declaration.
 const wrap=new THREE.Group();lab.machine.add(wrap);
 const mesh=new THREE.Mesh(geometry,palettes[p.display_material].clone());mesh.name=p.id;
 const col=i%5,row=Math.floor(i/5), pos=[(col-2)*.157,.016,(row-.5)*.22];
 mesh.position.set(...pos);mesh.userData.sourceId=p.id;
 lab.add(mesh,{name:p.label_zh,parent:wrap,count:1,explode:[(col-2)*.033,.025+((i%3)*.014),(row-.5)*.07],delay:i*.025,xray:p.id.includes('section')||p.id.includes('coupler')?'shell':undefined});
 const entry={...p,mesh,wrap,base:pos,sourceBox:box,material:mesh.material};items.push(entry);
 const pedestal=new THREE.Mesh(GEO.rbox(.135,.008,.135,.004),MAT.satin({color:[.61,.61,.57],roughness:.74}));
 pedestal.position.set(pos[0],.004,pos[2]);pedestal.receiveShadow=true;pedestal.castShadow=true;pedestal.userData.presentationOnly=true;lab.machine.add(pedestal);entry.pedestal=pedestal;
});
lab.trisSource=PARTS.reduce((n,p)=>n+p.triangles,0);
lab.$('.lab-no').textContent='HALF CAT ROCKETRY / R01 · 原件检视';
const detail=document.createElement('div');detail.className='part-detail on';detail.innerHTML='<strong>原件图谱</strong><div class="desc">十件原始外观及被动电子舱构件。点击模型或选择名称，逐件放大检查。</div><span class="flag">展示排布 · 装配变换未解析</span><code>原始 STL · 无几何简化<br>展示材质 · 不代表原件材质认证</code>';lab.$('.lab-side').append(detail);
const invButton=document.createElement('button');invButton.className='inventory-button on';invButton.textContent='查看全部 221 条 CAD 记录';lab.$('.lab-side').append(invButton);
const toolbar=document.createElement('nav');toolbar.className='inspect-toolbar';toolbar.setAttribute('aria-label','三维检视');toolbar.innerHTML='<button id="atlas" aria-pressed="true">本页 10 件</button><select id="part-select" aria-label="选择原始部件"><option value="">逐件查看…</option>'+items.map(x=>`<option value="${x.id}">${x.label_zh}</option>`).join('')+'</select><button id="wire" aria-pressed="false">网格</button><button id="fit">复位视角</button>';document.body.append(toolbar);
const help=document.createElement('div');help.className='inspect-help';help.textContent='拖动旋转 · 滚轮缩放 · 点击原件选中 · Esc 返回图谱';document.body.append(help);
const note=document.createElement('div');note.className='scope-note';note.innerHTML='<b>制作中：整箭装配尚未解析。</b> 当前为 10 件原始几何的检视图谱，未进入模型的文件均列在目录。';document.body.append(note);
const refButton=document.createElement('button');refButton.textContent='整箭来源图';toolbar.append(refButton);
const referenceDialog=document.createElement('dialog');referenceDialog.setAttribute('aria-label','整箭来源图');referenceDialog.innerHTML='<div class="dialog-head"><h2>原作整箭 · 来源对照</h2><button aria-label="关闭来源图">×</button></div><img alt="Half Cat Rocketry 提供的 Mojave Sphinx 整箭外观插图" style="display:block;width:100%;max-height:65vh;object-fit:contain;background:white" src="'+REFERENCE+'"><p class="dialog-note">来源：Half Cat Rocketry，HCR-5100 原书整箭插图（本地提取图 p001_i5.jpeg）。这张来源图用于核对整箭外观；当前三维图谱仅含已读取的十件原始构件。原作品许可见随附 LICENSE-Half-Cat.txt。</p>';document.body.append(referenceDialog);
refButton.onclick=()=>referenceDialog.showModal();referenceDialog.querySelector('button').onclick=()=>referenceDialog.close();
let selected=null, wire=false;
const defaultView={az:12,el:46,dist:1.9,target:[0,.035,0],frameX:-.11,fov:32};
function fit(){const phone=innerWidth<760;if(!selected){lab.setView(phone?{...defaultView,dist:2.7,fov:52,frameX:0}:defaultView);return}const x=selected;const max=Math.max(...x.native_bbox_size)*.001;lab.setView({az:32,el:25,dist:Math.max(.16,max*(phone?5.5:4.3)),target:[0,x.native_bbox_size[1]*.0005+.005,0],frameX:phone?0:-.14,fov:phone?52:32})}
function select(id,{camera=true}={}){
 selected=items.find(x=>x.id===id)||null;
 for(const x of items){x.wrap.visible=!selected||x===selected;x.pedestal.visible=!selected;if(selected){lab.place(x.mesh,0,.005,0)}else{lab.place(x.mesh,...x.base)}}
 document.getElementById('part-select').value=selected?.id||'';document.getElementById('atlas').setAttribute('aria-pressed',String(!selected));
 if(selected){detail.innerHTML='<strong>'+selected.label_zh+'</strong><div class="desc">'+selected.triangles.toLocaleString()+' 个原始三角面；保留源几何。孔位、曲面与凹槽来自原件网格。</div><span class="flag">原始文件直接读取 · 展示赋色</span><code>'+selected.source_name+'<br>SHA256 '+selected.sha256.slice(0,18)+'…</code>'}else{detail.innerHTML='<strong>原件图谱</strong><div class="desc">十件原始外观及被动电子舱构件。点击模型或选择名称，逐件放大检查。</div><span class="flag">展示排布 · 装配变换未解析</span><code>原始 STL · 无几何简化<br>展示材质 · 不代表原件材质认证</code>'}
 if(camera)fit();lab.currentPart=selected?.id||'atlas';document.body.dataset.selection=lab.currentPart;
}
const originalToggle=lab.toggle.bind(lab);
lab.toggle=(key,on)=>{if(key==='cut'&&!selected)select('nose-shoulder');if(key==='xray'&&(!selected||!['nose-section-1','nose-section-2','avbay-coupler-half'].includes(selected.id)))select('nose-section-1');if(key==='explode'&&selected)select(null);originalToggle(key,on)};
window.selectComponent=select;
document.getElementById('atlas').onclick=()=>select(null);
document.getElementById('part-select').onchange=e=>select(e.target.value);
document.getElementById('fit').onclick=fit;
document.getElementById('wire').onclick=()=>{wire=!wire;for(const x of items)x.mesh.material.wireframe=wire;document.getElementById('wire').setAttribute('aria-pressed',String(wire))};
let down;
lab.renderer.domElement.addEventListener('pointerdown',e=>{down=[e.clientX,e.clientY]});
lab.renderer.domElement.addEventListener('pointerup',e=>{if(!down||Math.hypot(e.clientX-down[0],e.clientY-down[1])>5)return;pointer.set(e.clientX/innerWidth*2-1,-e.clientY/innerHeight*2+1);raycaster.setFromCamera(pointer,lab.camera);const hit=raycaster.intersectObjects(items.filter(x=>x.wrap.visible).map(x=>x.mesh));if(hit[0])select(hit[0].object.userData.sourceId)});
addEventListener('keydown',e=>{if(e.target.matches('input,select,textarea'))return;if(e.key==='Escape'){select(null);return}if(e.key==='ArrowRight'||e.key==='ArrowLeft'){const idx=selected?items.indexOf(selected):-1;select(items[(idx+(e.key==='ArrowRight'?1:items.length-1)+items.length)%items.length].id);e.preventDefault()}});

const esc=s=>String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('"','&quot;');
const dialog=document.createElement('dialog');dialog.id='inventory';dialog.setAttribute('aria-label','CAD 来源与覆盖目录');dialog.innerHTML=`<div class="dialog-head"><div><h2>每一条源记录，都留有位置</h2><div class="dialog-note">${COVERAGE.length} 条 CAD 文件记录 · 含多种格式与装配文件，非零件实例数。<br>10 个 STL 已进入当前检视；其余逐项保留状态。没有把文件数当成完整复现率。</div></div><button id="close-inventory" aria-label="关闭目录">×</button></div><div class="filters"><input id="search" type="search" placeholder="搜索原文件名或格式" aria-label="搜索CAD记录"><select id="format" aria-label="筛选格式"><option value="">全部格式</option>${['SLDPRT','SLDASM','SLDDRW','STEP','STL','DXF'].map(v=>`<option>${v}</option>`).join('')}</select><select id="coverage" aria-label="筛选覆盖状态"><option value="">全部状态</option><option value="done">当前已读取</option><option value="pending">未进入模型</option></select></div><div class="record-count" aria-live="polite"></div><div class="table-wrap"><table><thead><tr><th>原始文件</th><th>格式</th><th>来源归档</th><th>当前状态</th></tr></thead><tbody></tbody></table></div><div class="dialog-links"><a href="research/coverage.csv" download>下载完整目录 CSV</a><a href="research/资料审计.md">查看资料审计</a><a href="research/覆盖与缺口.md">查看覆盖与缺口</a></div>`;document.body.append(dialog);
const known=new Set(PARTS.map(p=>p.zip_member));
function rows(){const term=dialog.querySelector('#search').value.toLowerCase(),format=dialog.querySelector('#format').value,filter=dialog.querySelector('#coverage').value;const records=COVERAGE.filter(r=>{const done=known.has(r.relative_path);return(!term||(r.relative_path+' '+r.archive).toLowerCase().includes(term))&&(!format||r.format===format)&&(!filter||(filter==='done')===done)});dialog.querySelector('tbody').innerHTML=records.map(r=>`<tr><td class="name">${esc(r.relative_path.split('/').pop())}</td><td>${esc(r.format)}</td><td>${esc(r.archive.replace('英文原件/',''))}</td><td><span class="${known.has(r.relative_path)?'done':'pending'}">${known.has(r.relative_path)?'原件已读取':'目录已登记 · 未进入模型'}</span></td></tr>`).join('');dialog.querySelector('.record-count').textContent='当前显示 '+records.length+' / '+COVERAGE.length+' 条记录'}
for(const input of dialog.querySelectorAll('input,select'))input.addEventListener('input',rows);
invButton.onclick=()=>{rows();dialog.showModal()};dialog.querySelector('#close-inventory').onclick=()=>dialog.close();
const names={run:'暂停动态',explode:'分开展示',cut:'展示剖切',xray:'外壳透视',slow:'慢动作',labels:'名称'};
lab._syncButtons=function(){for(const b of this.ui.querySelectorAll('.lab-modes button')){const k=b.dataset.k;b.classList.toggle('act',k==='run'?!!this.paused:this.target[k]>.5);b.setAttribute('aria-pressed',String(k==='run'?!!this.paused:this.target[k]>.5));b.firstChild.textContent=k==='run'?(this.paused?'恢复动态':'暂停动态'):(names[k]||k)}};
const oldModes=lab._modes.bind(lab);lab._modes=function(){oldModes();for(const k of ['slow','labels'])this.ui.querySelector(`[data-k="${k}"]`)?.remove();this._syncButtons()};
// Reuse the kit's section/camera/film machinery; no operational rocket solver is added.
lab.onTick(()=>{if(reduced&&!lab.filmMode){for(const k of ['explode','cut','xray','labels'])lab.state[k]=lab.target[k]}const n=selected?1:items.length;lab.setHero(n,{state:selected?'单件检视':'原件图谱',sub:(selected?selected.triangles:lab.trisSource).toLocaleString()+' 原始三角面<br>'+COVERAGE.length+' 条源记录 · 装配配合未解析'});{const actual=lab.target.explode*100;if(Math.abs(spread.value-actual)>1)spread.set(actual)}});
lab.film('main',{len:24,shots:[
 {t:0,...defaultView},{t:5,...defaultView,az:18,el:42,dist:1.8},{t:9,az:38,el:28,dist:.39,target:[0,.04,0],frameX:-.15},
 {t:13,az:62,el:20,dist:.39,target:[0,.04,0],frameX:-.15},{t:17,az:18,el:36,dist:.34,target:[0,.03,0],frameX:-.15},{t:19,...defaultView},{t:21,...defaultView,az:18,dist:2.1},{t:24,...defaultView}],events:[
 {t:0,beat:['01','先看原件。','十件原始 STL，保留全部源三角面。'],do:()=>select(null,{camera:false})},
 {t:5.4,beat:['02','曲面与孔位，来自源文件。','鼻锥连接肩 · 原始几何近看。'],do:()=>select('nose-shoulder',{camera:false})},
 {t:10.2,beat:['03','剖面必须有源几何依据。','剖切用于观察源网格的内部表面。'],set:{cut:1}},
 {t:14,beat:['04','再看电子舱构件。','电池托架 · 显示原件细节。'],set:{cut:0},do:()=>select('avbay-battery-holder',{camera:false})},
 {t:19,beat:['05','每一条记录，都能追溯。','221 条 CAD 记录已登记，完整装配仍待解析。'],do:()=>select(null,{camera:false}),set:{explode:1}},
 {t:22,set:{explode:0}}
]});
lab.start();select(null,{camera:!lab.filmMode});
addEventListener('resize',()=>{if(!lab.filmMode)fit()});
if(reduced&&!lab.filmMode)lab._assembly=0;
window.machineEvidence={nativeGeometryCount:items.length,nativeTriangles:lab.trisSource,cadRecords:COVERAGE.length,originalAssemblyParsed:false,allPartsReplicated:false,sourceHashes:PARTS.map(p=>({id:p.id,sha256:p.sha256,triangles:p.triangles}))};
document.body.dataset.ready='true';
document.getElementById('loading')?.remove();
