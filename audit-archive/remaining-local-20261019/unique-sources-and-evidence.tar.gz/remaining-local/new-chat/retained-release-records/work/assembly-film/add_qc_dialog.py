from pathlib import Path
f=Path('work/assembly-film/source/film.js');s=f.read_text()
s=s.replace('import {PLAN,NARRATION,TIMELINE,FILES}', 'import {PLAN,NARRATION,TIMELINE,FILES,QC}',1)
s=s.replace('<button id="play">播放</button>', '<button id="play">播放</button><button id="qc-open" disabled>本环节核对</button>',1)
a="const publicName=s=>"
b="const qcStyle=document.createElement('style');qcStyle.textContent='.qc-dialog{width:min(640px,calc(100vw - 48px));max-height:78vh;overflow:auto;border:1px solid #aab49d;border-radius:8px;padding:25px;color:#343d2f;background:#f3f2ee;font-size:15px;line-height:1.8}.qc-dialog::backdrop{background:#26331f66}.qc-dialog h2{font-size:23px;font-weight:500}.qc-dialog strong{font-weight:600}.qc-dialog button{font:inherit;border:1px solid #aab49d;border-radius:4px;padding:5px 16px;background:#fafbf7;color:#425937}';document.head.append(qcStyle);\n"+a
assert a in s;s=s.replace(a,b,1)
a="setCaps('metal');"
b="document.body.insertAdjacentHTML('beforeend','<dialog class=\"qc-dialog\" aria-label=\"本环节质量核对\"><h2></h2><div></div><form method=\"dialog\"><button>关闭，返回观察</button></form></dialog>');\n"+a
assert a in s;s=s.replace(a,b,1)
a="$('#stage').value=String(ci);}"
b="$('#stage').value=String(ci);$('#qc-open').disabled=!isStage;}"
assert a in s;s=s.replace(a,b,1)
a="$('#play').onclick=async()=>"
b="$('#qc-open').onclick=()=>{const r=QC.stages[lastChapter-1];if(!r)return;pause();const d=$('.qc-dialog'),v=r.verified_digital_qc;d.querySelector('h2').textContent=r.stage_id+' · '+r.title_zh;d.querySelector('div').innerHTML=`<p><strong>看哪里</strong><br>${esc(r.look_at_zh)}</p><p><strong>为什么要看</strong><br>${esc(r.why_quality_matters_zh)}</p><p><strong>已通过的数字核对</strong><br>${v.source_mesh_occurrences}个源网格实例，${v.source_hidden_mesh_occurrences}个源默认隐藏。该组归位时逐项比较${v.source_objects_compared_at_return}个源对象，局部和世界矩阵最大数值差均为0。这个0表示数字位置与源模型一致。</p><p><strong>判断实体质量仍需哪些证据</strong><br>${esc(r.independent_physical_evidence_needed_zh)}</p><p><strong>对应来源</strong><br>原作指南 ${r.source_sections.map(esc).join('；')}；alignment-qc.json 第${r.stage_id}组。</p>`;d.showModal();};\n"+a
assert a in s;s=s.replace(a,b,1);f.write_text(s)
