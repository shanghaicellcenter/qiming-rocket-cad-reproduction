"""Read-only conversion of every supplied R01 CAD file into a passive USD library."""
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import threading
import time

ROOT = Path.home() / "codex-mojave-cad-review-20261019"
CAD = ROOT / "source/Mojave Sphinx CAD - R01"
LIBRARY = ROOT / "library"
LIBRARY.mkdir(exist_ok=True)
WORKERS = 3
STOP = threading.Event()
LOCK = threading.Lock()
ACTIVE = {}
STARTED = time.monotonic()
PYTHON = ROOT / "venv/bin/python"
CLI = ROOT / "venv/bin/usd-convert-cad"
PROGRESS = LIBRARY / "progress.jsonl"
LICENSE = re.compile(r"(?:license|licensing|entitlement).{0,80}(?:error|fail|denied|invalid|missing|expired)|A3D_LICENSE", re.I)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def launch(cmd, stdout, stderr):
    with stdout.open("w") as out, stderr.open("w") as err:
        with LOCK:
            if STOP.is_set():
                return None
            p = subprocess.Popen(cmd, cwd=CAD, stdout=out, stderr=err)
            ACTIVE[p.pid] = p
        rc = p.wait()
        with LOCK:
            ACTIVE.pop(p.pid, None)
        return rc

def record(result):
    with LOCK:
        with PROGRESS.open("a") as f:
            f.write(json.dumps(result) + "\n")
            f.flush()
        print(json.dumps({k: result.get(k) for k in (
            "source_basename", "status", "wall_seconds", "mesh_count", "component_kind_node_count", "face_count"
        )}), flush=True)

def convert(source):
    category = "parts" if source.suffix.upper() == ".SLDPRT" else "assemblies"
    dest = LIBRARY / category
    dest.mkdir(exist_ok=True)
    output = dest / (source.stem + ".usdc")
    manifest = output.with_suffix(".conversion.json")
    if manifest.exists():
        old = json.loads(manifest.read_text())
        if old.get("status") == "passed" and output.exists() and old.get("input_sha256_after") == sha(source) and old.get("output_sha256") == sha(output):
            record({**old, "status": "reused_verified"})
            return old
    if STOP.is_set():
        return {"source_basename": source.name, "status": "not_started_after_license_error"}
    t0 = time.monotonic()
    source_hash = sha(source)
    cmd = [str(CLI), "-i", str(source), "-o", str(output), "--tess-lod", "3",
           "--instancing-style", "reference", "--composition-style", "none",
           "--filter-style", "hide", "--load-hidden"]
    stdout = output.with_suffix(".stdout.log")
    stderr = output.with_suffix(".stderr.log")
    rc = launch(cmd, stdout, stderr)
    logs = stdout.read_text(errors="replace") + "\n" + stderr.read_text(errors="replace")
    license_error = bool(LICENSE.search(logs))
    if license_error:
        STOP.set()
        with LOCK:
            for p in list(ACTIVE.values()):
                p.terminate()
    result = {
        "revision_group": "main-R01", "source": str(source), "source_basename": source.name,
        "input_sha256_before": source_hash, "input_sha256_after": sha(source),
        "command": cmd, "tessellation_lod": 3,
        "output": str(output), "conversion_exit_code": rc,
        "licensing_error_detected": license_error,
        "missing_reference_lines": [line for line in logs.splitlines() if re.search(r"missing|not.found|unresolved|reference.*fail|cannot.*(?:open|load)|could not.*(?:open|load)", line, re.I)],
        "scope": "passive source geometry conversion only; no constraints, physics data, solver, or invented geometry",
    }
    if rc == 0 and output.exists() and not license_error:
        result["output_sha256"] = sha(output)
        result["output_bytes"] = output.stat().st_size
        audit_out = output.with_suffix(".audit.stdout.log")
        audit_err = output.with_suffix(".audit.stderr.log")
        audit_rc = launch([str(PYTHON), str(ROOT / "validate_usd.py"), str(output)], audit_out, audit_err)
        result["audit_exit_code"] = audit_rc
        audit_file = output.with_suffix(".validation.json")
        if audit_file.exists():
            audit = json.loads(audit_file.read_text())
            for key in ("mesh_count", "nonempty_mesh_count", "point_count", "face_count",
                        "component_kind_node_count", "prim_count_with_instance_proxies", "native_instance_count",
                        "instance_proxy_prim_count", "unique_point_attribute_provider_count", "meters_per_unit", "up_axis"):
                result[key] = audit.get(key)
        result["status"] = "passed" if audit_rc == 0 else "converted_needs_audit_review"
    else:
        result["status"] = "license_error" if license_error else "conversion_failed_or_cancelled"
    result["input_unchanged"] = result["input_sha256_before"] == result["input_sha256_after"]
    if not result["input_unchanged"]:
        result["status"] = "source_changed_error"
        STOP.set()
    result["wall_seconds"] = round(time.monotonic() - t0, 3)
    manifest.write_text(json.dumps(result, indent=2) + "\n")
    record(result)
    return result

sources = sorted(CAD.glob("*.SLDPRT")) + [p for p in sorted(CAD.glob("*.SLDASM")) if p.name != "Mojave Sphinx Vehicle Assembly.SLDASM"]
if len(sources) != 132:
    raise SystemExit(f"Unexpected batch source count {len(sources)}, expected 119 parts + 13 assemblies")
with concurrent.futures.ThreadPoolExecutor(max_workers=WORKERS) as pool:
    futures = [pool.submit(convert, source) for source in sources]
    results = [f.result() for f in concurrent.futures.as_completed(futures)]
summary = {
    "revision_group": "main-R01", "workers": WORKERS, "source_count": len(sources),
    "part_count": sum(p.suffix.upper() == ".SLDPRT" for p in sources),
    "assembly_count": sum(p.suffix.upper() == ".SLDASM" for p in sources),
    "wall_seconds": round(time.monotonic() - STARTED, 3),
    "license_stop": STOP.is_set(),
    "status_counts": {s: sum(r.get("status") == s for r in results) for s in sorted({r.get("status") for r in results})},
    "results": sorted(results, key=lambda r: r["source_basename"]),
    "geometry_count_is_not_part_count": True,
}
(LIBRARY / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps({k: v for k, v in summary.items() if k != "results"}, indent=2), flush=True)
if STOP.is_set():
    raise SystemExit(2)
