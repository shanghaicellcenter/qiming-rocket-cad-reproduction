from pathlib import Path
import subprocess,sys,json,time
folder=Path(__file__).resolve().parent;start=time.monotonic();last=None
while time.monotonic()-start<2700:
    r=subprocess.run([sys.executable,str(folder/'collect-firered-voice.py')],text=True,capture_output=True)
    if r.returncode:print(r.stderr,flush=True);raise SystemExit(r.returncode)
    j=json.loads((folder/'narration-audio-manifest.json').read_text());state=(j['generated_track_count'],j['asr_checked_track_count'],str(j['remote_batch_status']))
    if state!=last:print(r.stdout.strip(),flush=True);last=state
    status=j.get('remote_batch_status') or {}
    if status.get('state')=='failed':raise RuntimeError('Own FireRed client failed: '+status.get('error','unknown'))
    if j['generated_track_count']==17 and status.get('state')=='generation_finished_pending_asr_and_listening':
        if j['asr_checked_track_count']<17:
            print('17 FireRed tracks collected. Starting independent per-sentence acoustic ASR, no character averaging.',flush=True)
            with (folder/'firered-asr-launch.log').open('w') as log:
                r=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=8','spark','/home/qianqiming/work/drama-3/.venv/bin/python /home/qianqiming/codex-mojave-assembly-voice-20261019/firered-offline-asr.py'],stdout=log,stderr=subprocess.STDOUT)
            if r.returncode:raise RuntimeError('Independent ASR failed; inspect firered-asr-launch.log')
            subprocess.run([sys.executable,str(folder/'collect-firered-voice.py')],check=True)
        print('All17 waveform + acoustic evidence ready for difference review; subjective listening remains pending.',flush=True);break
    time.sleep(30)
else:raise RuntimeError('Own FireRed monitor reached45-minute bound')
