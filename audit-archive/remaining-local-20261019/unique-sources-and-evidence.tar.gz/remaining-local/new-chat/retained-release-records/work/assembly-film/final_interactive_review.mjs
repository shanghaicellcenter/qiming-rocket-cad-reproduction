import {launch} from '../../outputs/启明火箭/source/vendor/machine/scripts/lib/browser.mjs';
import {writeFile,mkdir} from 'node:fs/promises';
import {resolve} from 'node:path';import {pathToFileURL} from 'node:url';
const draft=process.argv.includes('--draft'),target=process.env.QIMING_REVIEW_HTML||'work/assembly-film/逐步虚拟归位.html',folder=resolve(draft?'work/assembly-film/audio-ui-draft-review':'work/assembly-film/audio-ui-final-review');await mkdir(folder,{recursive:true});
const {browser,page}=await launch({width:1440,height:960});const checks=[],errors=[],requests=[];page.on('pageerror',e=>errors.push(e.message));page.on('request',r=>{if(/^https?:/.test(r.url()))requests.push(r.url())});
const check=(name,pass,details)=>{checks.push({name,pass,details});if(!pass)throw new Error(name+': '+JSON.stringify(details));};
try{
 await page.goto(pathToFileURL(resolve(target)).href,{waitUntil:'load',timeout:60000});await page.waitForFunction(()=>document.body.dataset.ready==='true',{timeout:60000});
 check('intro quality button disabled',await page.locator('#qc-open').isDisabled());
 const timeline=await page.evaluate(()=>assemblyFilm.timeline);check('17 chapters',timeline.clips.length===17,timeline.clips.length);
 const captions=timeline.clips.flatMap(c=>c.captions||[]);if(!draft)check('actual acoustic captions for all17',timeline.clips.every(c=>c.captions?.length),captions.length);
 for(let i=1;i<=15;i++){
  await page.evaluate(i=>assemblyFilm.stage(i),i);await page.locator('#qc-open').click();
  await page.locator('.qc-dialog summary').click();const d=await page.locator('.qc-dialog').innerText();check('quality detail '+i,d.includes(String(i).padStart(2,'0')+' · ')&&d.includes('判断实体质量仍需哪些证据')&&d.includes('数字位置与源模型一致'));
  check('play pauses for quality '+i,await page.locator('#play').innerText()==='播放');
  if(i===3)await page.screenshot({path:folder+'/desktop-quality03.png'});
  await page.locator('.qc-dialog button').click();
 }
 await page.evaluate(()=>assemblyFilm.stage(3));await page.screenshot({path:folder+'/desktop-stage03.png'});
 check('new03 fixed valve body text',(await page.locator('.principle').innerText()).includes('阀体固定'));
 const visible=await page.evaluate(()=>document.body.innerText);check('public project names',!/mojave|sphinx|莫哈维斯芬/i.test(visible));
 if(!draft){
  await page.evaluate(()=>assemblyFilm.seek(0));await page.locator('#play').click();await page.waitForTimeout(1800);
  let state=await page.evaluate(()=>({a:assemblyFilm.audioState(),visual:assemblyFilmEvidence.currentTime}));check('real embedded audio playback',state.a&&!state.a.paused&&state.a.currentTime>1,state);check('audio master clock',Math.abs(state.a.currentTime-state.visual)<.15,state);
  await page.locator('#play').click();const held=await page.evaluate(()=>assemblyFilm.audioState().currentTime);await page.waitForTimeout(300);check('pause stops real audio',Math.abs(await page.evaluate(()=>assemblyFilm.audioState().currentTime)-held)<.02);
  for(const clip of timeline.clips){await page.evaluate(t=>assemblyFilm.seek(t),clip.start+.01);const at=await page.evaluate(()=>({a:assemblyFilm.audioState(),v:assemblyFilmEvidence.currentTime}));check('seek audio and geometry '+clip.id,Math.abs(at.a.currentTime-at.v)<.03,at);}
  for(const clip of timeline.clips.filter(c=>(c.visual_mapping?.length||0)>2)){for(const point of clip.visual_mapping.slice(1,-1)){await page.evaluate(t=>assemblyFilm.seek(t),clip.start+point.frame/timeline.fps);const shown=await page.evaluate(()=>assemblyFilmEvidence.visualSourceFraction);check('speech anchored close-up '+clip.id+' '+point.source_fraction,Math.abs(shown-point.source_fraction)<1e-6,shown);}}
  await page.locator('#sound').click();check('mute toggle on',await page.evaluate(()=>assemblyFilm.audioState().muted));await page.locator('#sound').click();check('mute toggle off',!await page.evaluate(()=>assemblyFilm.audioState().muted));
  const row=captions.find(x=>x.text.length>30)||captions[0];await page.evaluate(t=>assemblyFilm.seek(t),(row.start+row.end)/2);check('caption uses actual acoustic span',(await page.locator('.caption').innerText())===row.text);await page.screenshot({path:folder+'/desktop-long-caption.png'});
 }
 await page.evaluate(()=>assemblyFilm.seek(assemblyFilm.timeline.duration));const audit=await page.evaluate(()=>assemblyFilm.audit());check('source unchanged and complete',audit.sourceIdentityNodes===1980&&audit.sourceMeshIdentities===688&&audit.renderMeshes===706&&audit.sourceHidden===3&&audit.sourceLocalMatricesUnchanged&&audit.sourceGeometryShared&&audit.finalDisplayMatrixError===0,audit);
 await page.setViewportSize({width:390,height:844});await page.evaluate(()=>assemblyFilm.stage(8));await page.locator('#qc-open').click();await page.screenshot({path:folder+'/mobile-quality08.png'});const overflow=await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth);check('mobile no horizontal overflow',!overflow);await page.locator('.qc-dialog button').click();await page.screenshot({path:folder+'/mobile-stage08.png'});
 check('offline no network',requests.length===0,requests);check('no script errors',errors.length===0,errors);
 await writeFile(folder+'/checks.json',JSON.stringify({target:resolve(target),draft,checks,errors,requests},null,2));console.log(JSON.stringify({draft,checks:checks.length,allPassed:checks.every(c=>c.pass),folder}));
}finally{await writeFile(folder+'/checks.partial.json',JSON.stringify({checks,errors,requests},null,2));await browser.close()}
