# GitHub 下载后 Blender 重建准备检查

当前状态：仅完成源脚本与依赖检查，还没有收到真实 GitHub 下载目录，也没有执行下载后重建、复开或渲染验证。

已按用户要求读取 Blender expert、animation、lighting-rendering 及 bpy reliability 工作流。将使用 `/Applications/Blender 5.2.app/Contents/MacOS/Blender`，要求实际版本 5.2.2 LTS 或兼容更新版。

## 路径与依赖结论

`prepare_blender_rebuild.py` 会在下载根下生成 `rebuild/virtual-assembly/`，保留原交付脚本。生成脚本中的 `Path(__file__).resolve().parents[2]` 正确返回下载根。原来源 Blend、USD、审计和源名映射均改为包内路径；Scenario helper 只从包内 `rebuild/vendor/scenario/` 导入。该 helper 自身只依赖 Blender API 与标准库，没有额外本机目录导入。

新建结果写入 `rebuilt/virtual-assembly/`；工作计划、坐标报告、阶段图和复开图写入 `rebuild/virtual-assembly/`。原 `outputs/` 原件只读。原脚本在当前发布 staging 中与本地最终交付逐字节一致。13 个必需输入的完整路径、体积和 SHA 见 `preparation-review.json`。

正常执行次序是：准备可移植脚本；重新运行 stage planner 读取包内源审计和映射生成15分组；运行 builder；用独立 Blender 进程运行原 verifier；再用第三个独立 Blender 进程运行补充源件对照。运行前后应另核对下载输入的 SHA 未变。

以下仅为命令模板，尚未执行；`NEW_ROOT` 必须指向实际下载并恢复完成的目录。

```sh
python3 "$NEW_ROOT/prepare_blender_rebuild.py" --root "$NEW_ROOT" --blender "/Applications/Blender 5.2.app/Contents/MacOS/Blender"
python3 "$NEW_ROOT/rebuild/virtual-assembly/plan_assembly_stages.py"
"/Applications/Blender 5.2.app/Contents/MacOS/Blender" --background --factory-startup --disable-autoexec --python-exit-code 1 --python "$NEW_ROOT/rebuild/virtual-assembly/build_virtual_assembly.py"
"/Applications/Blender 5.2.app/Contents/MacOS/Blender" --background --factory-startup --disable-autoexec --python-exit-code 1 --python "$NEW_ROOT/rebuild/virtual-assembly/verify_virtual_assembly.py"
"/Applications/Blender 5.2.app/Contents/MacOS/Blender" --background --factory-startup --disable-autoexec --python-exit-code 1 --python "$NEW_ROOT/qa/independent_source_compare.py" -- --root "$NEW_ROOT" --report "$NEW_ROOT/qa/independent-source-compare.json"
```

实际执行需逐个套入读隔离，并从新下载目录工作，不从旧项目目录启动。禁止读取旧 `new-chat`、`ni`、桌面原项目、用户技能路径及 Scenario 原仓库；网络也可禁用。原 `outputs/`、包内 vendor 和源名映射禁止写入。这里不提前宣称隔离已成功。

## 验收范围

原 verifier 会独立重开新产物，核对每场景1980源对象、688网格、2864600面、15分组、终态局部和世界矩阵差0、17个运动帧与3个原隐藏网格，并实际渲染7张新静帧。builder 另生成15张当前源组归位图。需实际打开这些新图检查形体、隔离与取景，不能用旧截图代替。

补充 `independent_source_compare.py` 不导入技能、不保存 Blend，不做影片/TTS。它先打开下载源 Blend，捕获每个源身份的原顶点坐标、拓扑索引、面材质索引/平滑标记、材质槽、UV及原层级/矩阵；再打开新产物，对照保存参考场景的这些值，并检查15组各自归位和最终1980对象的 local/world/basis/parent-inverse 全部逐项差0。该补充脚本目前只通过语法检查，需真实下载后执行才能称其通过。

这些测试是 CAD 表示与展示动画验证，不产生实物装配约束、碰撞可达性或工作过程求解结论。
