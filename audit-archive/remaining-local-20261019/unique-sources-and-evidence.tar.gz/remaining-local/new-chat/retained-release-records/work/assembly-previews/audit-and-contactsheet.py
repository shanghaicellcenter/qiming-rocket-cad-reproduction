from PIL import Image,ImageDraw,ImageFont
from pathlib import Path
import json,hashlib,math,collections,csv

root=Path('/Users/qianqiming/Documents/Codex/2026-10-19/new-chat');jobs=json.loads((root/'work/assembly-previews/jobs.json').read_text());out=Path(jobs['output_dir'])
rows=[];issues=[];hashes=collections.defaultdict(list)
for source in jobs['rows']:
    d=json.loads((out/(source['id']+'.audit.json')).read_text())
    d.update({k:source[k] for k in ['source_kind','revision_group']})
    assert d['source_geometry_transforms_unchanged']
    for r in d['renders']:
        p=out/r['image'];b=p.read_bytes();actual=hashlib.sha256(b).hexdigest();assert actual==r['image_sha256'];im=Image.open(p).convert('RGBA');alpha=im.getchannel('A');box=alpha.getbbox()
        n=sum(1 for v in alpha.getdata() if v>8);w,h=im.size
        border=sum(1 for v in list(alpha.crop((0,0,w,2)).getdata())+list(alpha.crop((0,h-2,w,h)).getdata())+list(alpha.crop((0,0,2,h)).getdata())+list(alpha.crop((w-2,0,w,h)).getdata()) if v>8)
        crop=not box or border>0 or min(box[0],box[1],w-box[2],h-box[3])<3
        r.update({'pixel_nonempty':bool(box and n>100),'foreground_alpha_pixels':n,'pixel_bbox':list(box) if box else None,'nontransparent_border_pixels':border,'pixel_crop_check':'passed' if not crop else 'failed','pixel_margin_min':min(box[0],box[1],w-box[2],h-box[3]) if box else None})
        if crop or not r['pixel_nonempty']:issues.append({'id':source['id'],'view':r['view'],'crop':crop,'pixels':n})
        hashes[actual].append({'id':source['id'],'view':r['view']})
    d['status']='rendered; numerical checks passed; visual review pending';d['visual_review']='pending actual contact-sheet review'
    (out/(source['id']+'.audit.json')).write_text(json.dumps(d,ensure_ascii=False,indent=2))
    rows.append(d)

try:font=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',16);small=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',13)
except Exception:font=ImageFont.load_default();small=font
sheets=[];cellw=420;cellh=315;titleh=56;rowh=350
for s in range(math.ceil(len(rows)/4)):
    group=rows[s*4:(s+1)*4];canvas=Image.new('RGB',(cellw*3,titleh+rowh*len(group)),(29,37,46));draw=ImageDraw.Draw(canvas)
    draw.text((18,12),f'ORIGINAL ASSEMBLIES + SEPARATE PATCH | {s*4+1:02d}-{s*4+len(group):02d} / {len(rows)}',font=font,fill=(230,235,240))
    draw.text((18,34),'FRONT  /  SIDE  /  OBLIQUE   |   Original USD geometry, independent camera fit',font=small,fill=(165,180,195))
    for ri,d in enumerate(group):
        y=titleh+ri*rowh;name=d['source_filename'];caption=d['id']+(' [HCR-5105, SEPARATE REVISION]' if d['revision_group']=='HCR-5105' else '')+' | '+name
        if len(caption)>112:caption=caption[:109]+'...'
        draw.text((14,y+8),caption,font=small,fill=(220,226,232))
        if d['source_mass_volume_placeholders']:draw.text((880,y+8),'SOURCE MASS/VOLUME MODELS',font=small,fill=(220,191,120))
        for ci,r in enumerate(d['renders']):
            im=Image.open(out/r['image']).convert('RGBA');im.thumbnail((cellw-12,cellh-12),Image.Resampling.LANCZOS);x=ci*cellw+(cellw-im.width)//2;yy=y+30+(cellh-im.height)//2;canvas.paste(im,(x,yy),im)
    path=out/f'contactsheet-{s+1:02d}.png';canvas.save(path);sheets.append(path.name)

duplicates=[v for v in hashes.values() if len(v)>1];cross_source=[v for v in duplicates if len(set(x['id'] for x in v))>1]
manifest={'schema_version':1,'kind':'14 original native SLDASM previews and 1 separately identified source patch','source_record_count':len(rows),'source_assembly_count':sum(d['source_kind']=='SLDASM' for d in rows),'independent_patch_count':sum(d['revision_group']=='HCR-5105' for d in rows),'image_count':sum(len(d['renders']) for d in rows),'resolution':[jobs['render_width'],jobs['render_height']],
 'numerical_checks':'passed' if not issues else 'failed','visual_review':'pending actual contact-sheet review','source_geometry_or_transforms_edited':False,'new_part_geometry_created':False,'blend_duplicates_saved':False,
 'source_visibility_respected':True,'camera_only_fit':True,'renders_are_not_crops_of_other_assemblies':True,'image_bytes':sum(r['bytes'] for d in rows for r in d['renders']),
 'source_archive':jobs['source_archive'],'source_archive_sha256':jobs['source_archive_sha256'],'source_archive_member_hashes_rechecked':True,
 'contact_sheets':sheets,'issues':issues,'identical_image_hash_groups':duplicates,'cross_source_identical_image_hashes':cross_source,
 'note':'Counts are source records and mesh occurrences, not unique physical parts. Orthographic views of symmetric source geometry can appear the same. Source CAD curves were tessellated upstream. Workbench shading is presentation only.',
 'rows':rows}
(out/'index.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
with (out/'index.csv').open('w',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=['id','label_zh','source_kind','revision_group','source_filename','source_archive','source_member','source_sha256','source_usd_sha256','view','image','image_sha256','width','height','pixel_nonempty','pixel_crop_check'])
    writer.writeheader()
    for d in rows:
        for r in d['renders']:
            writer.writerow({**{k:d[k] for k in ['id','label_zh','source_kind','revision_group','source_filename','source_archive','source_member','source_sha256','source_usd_sha256']},**{k:r[k] for k in ['view','image','image_sha256','pixel_nonempty','pixel_crop_check']},'width':r['resolution'][0],'height':r['resolution'][1]})
print(json.dumps({k:manifest[k] for k in ['source_record_count','source_assembly_count','independent_patch_count','image_count','numerical_checks','image_bytes','contact_sheets','issues','cross_source_identical_image_hashes']},ensure_ascii=False))
if issues:raise SystemExit(1)
