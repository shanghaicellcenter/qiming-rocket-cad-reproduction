import urllib.request, json, hashlib, pathlib, concurrent.futures, re, html
from urllib.parse import quote
base='https://api.github.com/repos/HalfCatRocketry/mojave-sphinx'
patch='HCR-5105 - Design Modification to Correct Recovery Anchor Fuel Leakage of Mojave Sphinx.zip'
targets={
 'repo':base,
 'branch':base+'/branches/main',
 'root_files':base+'/contents/',
 'simulation_files':base+'/contents/Simulation',
 'patch_commits':base+'/commits?path='+quote(patch)+'&per_page=10',
 'guide_commits':base+'/commits?path='+quote('HCR-5100 - Mojave Sphinx Build, Integration, and Launch Guidebook - R01.pdf')+'&per_page=10',
 'official_project':'https://www.halfcatrocketry.com/mojave-sphinx',
 'official_rockets':'https://www.halfcatrocketry.com/rockets',
}
def fetch(item):
 k,u=item
 try:
  data=urllib.request.urlopen(urllib.request.Request(u,headers={'User-Agent':'source-evidence-audit/1.0'}),timeout=30).read()
  if 'api.github.com' in u: val=json.loads(data)
  else:
   text=data.decode();vals=[]
   for m in re.finditer(r'(?:youtube|youtu\.be|vimeo|HCR-5105)',text,re.I):
    vals.append(html.unescape(text[max(0,m.start()-140):m.end()+300]))
   val={'html_sha256':hashlib.sha256(data).hexdigest(),'media_fragments':vals,'links':list(dict.fromkeys(html.unescape(x) for x in re.findall(r'href=[\"\']([^\"\']+)',text)))}
  return k,{'url':u,'sha256':hashlib.sha256(data).hexdigest(),'data':val}
 except Exception as e: return k,{'url':u,'error':str(e)}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex: results=dict(ex.map(fetch,targets.items()))
pathlib.Path('work/flight-evidence/web-source-metadata.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
for k,r in results.items():
 d=r.get('data')
 if k=='branch' and d: print(k,d['commit']['sha'], d['commit']['commit']['committer']['date'])
 elif k.endswith('_commits') and isinstance(d,list): print(k,[{'sha':c['sha'],'date':c['commit']['committer']['date'],'message':c['commit']['message']} for c in d])
 elif k.endswith('_files') and isinstance(d,list): print(k,[{'name':x['name'],'size':x['size'],'url':x['html_url']} for x in d])
 elif k.startswith('official') and d: print(k,{'media_fragments':d['media_fragments'],'social_links':[u for u in d['links'] if any(s in u for s in ['youtube','youtu.be','vimeo','github','drive.google','flickr'])]})
 elif r.get('error'): print(k,r['error'])
