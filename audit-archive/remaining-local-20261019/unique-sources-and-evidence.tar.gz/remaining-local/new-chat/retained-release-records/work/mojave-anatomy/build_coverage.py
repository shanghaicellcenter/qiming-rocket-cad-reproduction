from pathlib import Path
from collections import Counter
import csv,json,re

OUT=Path('/Users/qianqiming/Documents/Codex/2026-10-19/new-chat/outputs/mojave-anatomy/research')
manifest=json.loads((OUT/'source-manifest.json').read_text())
FORMATS={'.sldprt','.sldasm','.slddrw','.step','.stp','.stl','.dxf'}
ROLE_ORDER=['外观箭体','头锥','尾翼','电子舱展示','框架','其他','限制功能件']

def classify(name):
    b=Path(name).stem.casefold()
    # Filename-only labels; no engineering payload is opened or interpreted.
    if re.search(r'ignit|pyro|ejection|propul|propellant|tank|fuel|oxidiz|combustion|injector|nozzle|throat|valve|piston|quick.disconnect|\bnpt\b|servo|pressure|thrust.chamber|nut retaining ring|vehicle assembly',b):
        return '限制功能件'
    if re.search(r'^(tmplt|drljg|plg-drl)',b) or re.search(r'template|sacrificial|drilling',b):
        return '其他'
    if re.search(r'^nscn|nose cone',b): return '头锥'
    if re.search(r'^avby|avbay|avbavy|avionics bay',b): return '电子舱展示'
    if re.search(r'airframe tube|airframe assembly',b): return '外观箭体'
    if re.search(r'^fin-|^aero-|fin bracket assembly',b): return '尾翼'
    if re.search(r'bracket|frame',b): return '框架'
    return '其他'

rows=[]
for archive in manifest['files']:
    if 'zip' not in archive: continue
    for member in archive['zip']['members']:
        fmt=Path(member['name']).suffix.lower()
        if member['is_directory'] or fmt not in FORMATS: continue
        rows.append({'relative_path':member['name'],'format':fmt.removeprefix('.').upper(),'archive':archive['relative_path'],'role_category':classify(member['name']),'status':['源存在','未导入','待验证']})

summary={
 'cad_file_record_count':len(rows),
 'format_counts':dict(sorted(Counter(r['format'] for r in rows).items())),
 'role_category_counts':{k:sum(r['role_category']==k for r in rows) for k in ROLE_ORDER},
 'unique_full_filename_count_case_sensitive':len({Path(r['relative_path']).name for r in rows}),
 'unique_filename_stem_count_case_sensitive':len({Path(r['relative_path']).stem for r in rows}),
 'unique_filename_stem_count_case_insensitive':len({Path(r['relative_path']).stem.casefold() for r in rows}),
 'part_instance_count':None,
 'part_instance_count_status':'未知；未解析原生装配体，文件记录不能换算为装配实例。',
 'assembly_mates_status':'未知；未打开 SLDASM，也未解析配合、引用、配置或几何。',
 'naming_group_note':'去扩展名和大小写归并仅为文件名称统计，不代表独特工程零件数。',
}
coverage={'schema_version':1,'basis':'source-manifest.json ZIP central-directory metadata only','scope_note':'Filename-only coverage inventory. Role labels are provisional and do not establish engineering membership. Engineering payloads were not extracted.','field_definitions':{'relative_path':'Original member path inside archive; original names are provenance metadata only.','format':'Filename suffix only; actual import/parse support unverified.','archive':'Source ZIP relative to source root.','role_category':'Provisional high-level role inferred only from filename.','status':'All records are source-present, not-imported, pending verification.'},'summary':summary,'records':rows}
(OUT/'coverage.json').write_text(json.dumps(coverage,ensure_ascii=False,indent=2)+'\n')
with (OUT/'coverage.csv').open('w',newline='',encoding='utf-8-sig') as f:
    writer=csv.DictWriter(f,fieldnames=['relative_path','format','archive','role_category','status'])
    writer.writeheader()
    for row in rows: writer.writerow({**row,'status':' / '.join(row['status'])})

# Narrow allowlist: only exterior appearance and passive avionics display items.
# The source names stay exact in metadata. Human labels omit specification-like codes.
labels={
 'NSCN-SC1':'头锥第一段外形',
 'NSCN-SC2':'头锥第二段外形',
 'NSCN-SLDR':'头锥肩部外形',
 'NSCN-TIP':'头锥顶端外形',
 'AVBY-BH':'电子舱电池座展示件',
 'AVBY-CR':'电子舱定心环展示件',
 'AVBY-HF':'电子舱半联接外套展示件',
 'AVBY-MT':'电子托板安装件',
 'AVBY-SB':'电子舱开关带外形',
 'AERO-':'尾翼支架整流端件（不是尾翼本体）',
}
safe=[]
for row in rows:
    if row['format']!='STL':continue
    b=Path(row['relative_path']).name
    found=next((label for prefix,label in labels.items() if b.startswith(prefix)),None)
    if found:
        safe.append({**row,'display_name':found,'availability':'归档原有 STL 目录记录；未解压、未导入，拓扑与可显示性待验证。'})
(OUT/'safe-appearance-candidates.json').write_text(json.dumps({'scope':'仅非功能外观和被动电子舱展示候选；不含推进、高压、烟火或操作相关几何。','count':len(safe),'note':'STL 格式记录存在，不等于当前文件已通过渲染或几何验证；所有候选仍未导入。','candidates':safe},ensure_ascii=False,indent=2)+'\n')

scale={'scope':'仅整箭外形的名义展示比例，不能替代工程图或作为细分制造依据。','source_relative_path':'中文文档/01-HCR-5100 建造集成与发射指南-中文版.md','source_section':'2.1.1 关键规格','source_printed_page':35,'overall_length':{'source_value':96,'source_unit':'inch','display_value_m':2.4384,'source_line':1251},'nominal_diameter':{'source_value':4.0,'source_unit':'inch','display_value_m':0.1016,'source_line':1250},'limitations':'仅取全长与名义火箭直径；没有提取子部件尺寸、公差、材料、性能或操作参数。未与 CAD 实测外包围尺寸核对。'}
(OUT/'exterior-display-scale.json').write_text(json.dumps(scale,ensure_ascii=False,indent=2)+'\n')

role_rows='\n'.join(f'| {role} | {summary["role_category_counts"][role]} |' for role in ROLE_ORDER)
safe_rows='\n'.join(f'| {s["display_name"]} | {s["role_category"]} | 原包 STL 记录存在，未导入 |' for s in safe)
report=f'''# 可视化可用源与明确缺口

本次进一步检查的是原有归档目录，**没有解压工程文件，也没有导入或重建原生几何**。`coverage.csv` 与 `coverage.json` 为全部 CAD 源记录建立一行一文件的覆盖表；所有行状态均为“源存在 / 未导入 / 待验证”。角色类别只按文件名做暂定归类，不代表装配关系已确认。

## 数量必须分开理解

- **{len(rows)} 条 CAD 文件记录**：SLDPRT {summary['format_counts']['SLDPRT']}、SLDASM {summary['format_counts']['SLDASM']}、SLDDRW {summary['format_counts']['SLDDRW']}、STEP {summary['format_counts']['STEP']}、STL {summary['format_counts']['STL']}、DXF {summary['format_counts']['DXF']}。
- 含扩展名的独特文件名为 **{summary['unique_full_filename_count_case_sensitive']} 个**；不含扩展名、区分大小写的名称为 **{summary['unique_filename_stem_count_case_sensitive']} 个**，忽略大小写后为 **{summary['unique_filename_stem_count_case_insensitive']} 组**。跨格式归并只是名称统计，不能称为独特工程零件数。
- **装配实例数量未知**。同一个零件文件可以被多次引用；装配体、图纸、网格和交换文件也不能各算一个实体零件。
- **装配配合、引用、配置、几何与版本同步均未知**。目前没有模型逐件覆盖率，不能宣称原工程已完整复现。

| 暂定高层类别 | CAD 文件记录数 |
|---|---:|
{role_rows}

归档中的源文件名可能带有规格样式字符串；覆盖表仅保留原名做来源元数据，没有转写成尺寸、采购、制造或性能信息。

## 原包自带的非功能外观 STL 候选

原包目录已经包含 **36 个 STL 文件记录**。其中以下 **{len(safe)} 个**进入严格限定的非功能外观/被动电子舱展示候选列表。它们是原包已有记录，不是本次生成；名字与原归档路径可在 `safe-appearance-candidates.json` 追溯。仅确认 STL 格式和文件记录存在，尚未确认解码成功、网格完好或渲染效果。

| 外观候选 | 高层角色 | 当前状态 |
|---|---|---|
{safe_rows}

这些候选不会构成完整箭体：头锥分段不是整箭；尾翼支架整流端件不是尾翼本体；电子托板安装件也不是电子托板。

## 当前最明确的几何格式缺口

| 目标外观 | 找到的原始源记录 | 缺口 |
|---|---|---|
| 上、下箭体外壳 | 原生 SLDPRT；另有 Airframe Assembly 的 SLDASM 记录 | 没有同名原包 STL；未解析装配或转换外壳几何。钻孔模板、牺牲垫件不能当作外壳。 |
| 标准尾翼本体 | 原生 Fin, Standard 的 SLDPRT；另有 Fin Bracket Assembly 记录 | 没有同名原包 STL。尾翼整流端件不能替代尾翼本体。 |
| 电子舱托板本体 | 原生 Avbay Sled 的 SLDPRT；另有 Sled Assembly 记录 | 没有同名原包 STL；当前 STL 只有相关安装件等被动展示件。 |
| 完整整箭外观与装配层级 | Vehicle Assembly、Nose Cone Assembly、Airframe Assembly 等目录记录 | 未解析零件实例、配合、位置、朝向或配置；整箭装配包含超出本次范围的功能系统，不能直接整体导入。 |

R01 与独立修订包仍并存，没有验证修订是否合入主装配。覆盖表将它们视为各自的来源记录，不推断版本已同步。

## 整箭展示尺度

指南 **2.1.1，原书正文 p.35**给出全长 **96 英寸（2.4384 米）**、名义火箭直径 **4.0 英寸（0.1016 米）**。这两项仅用于整体外形的展示比例；尚未与 CAD 外包围尺寸核对，不能据此推断各部件的制造尺寸。来源行号和换算值见 `exterior-display-scale.json`。

## 数字展示边界

源工程参数不导入展示模型。除上述整箭名义外形比例外，不提炼或导入细分制造尺寸、公差、材料工艺、推进剂、压力、性能仿真或采购信息，也不包含烟火、推进、高压系统及装填、点火、发射等操作细节。与这些功能相关的记录仅作来源目录登记，不用于几何重建。

当前可核实的结论是“所有归档 CAD 文件记录已进入覆盖清单，并识别出有限的原始外观 STL 候选”；不是“所有零件原件已导入”，也不是“原工程完整复现”。
'''
(OUT/'可视化源与缺口.md').write_text(report)
print(json.dumps({'summary':summary,'safe_original_stl_candidates':len(safe),'outputs':['coverage.csv','coverage.json','safe-appearance-candidates.json','exterior-display-scale.json','可视化源与缺口.md']},ensure_ascii=False,indent=2))
