"""All-source isolated visual cards, from an audited .blend; never save source edits."""
import bpy,hashlib,json,math,sys,time
from pathlib import Path
import numpy as np
from mathutils import Vector,Matrix
ROOT=Path(__file__).resolve().parent
LIB=ROOT/'original-part-library'
OUT=LIB/'review-all';OUT.mkdir(exist_ok=True)
AUDIT=json.loads((LIB/'original-part-library.audit.json').read_text())
START=time.monotonic()
def ph(a):return hashlib.sha256(np.asarray(a).tobytes()).hexdigest()
def points(me):
 a=np.empty(len(me.vertices)*3,dtype=np.float32);me.vertices.foreach_get('co',a);return a.reshape(-1,3)
def verify_all():
 n=0;faces=0
 for item in AUDIT['items']:
  for rec in item['objects']:
   ob=bpy.data.objects.get(rec['object']);assert ob is not None
   if rec['type']!='MESH':continue
   p=points(ob.data);expected=rec.get('points_sha256') or item.get('raw_stl_vertex_sha256')
   assert ph(p)==expected,(ob.name,'points')
   assert len(ob.data.polygons)==rec['faces'],(ob.name,'faces')
   assert np.allclose(np.asarray(ob.matrix_world),np.asarray(rec['world_matrix_native']),atol=1e-8),(ob.name,'world matrix')
   n+=1;faces+=len(ob.data.polygons)
 return {'meshes_exact':n,'faces_exact':faces}

assert bpy.app.version[:2]>=(5,2)
before=verify_all()
sc=bpy.data.scenes.new('SOURCE_LIBRARY_VISUAL_REVIEW_TEMP')
sc.render.engine='BLENDER_WORKBENCH'
sc.render.resolution_x=sc.render.resolution_y=320;sc.render.resolution_percentage=100
sc.render.image_settings.media_type='IMAGE';sc.render.image_settings.file_format='PNG';sc.render.image_settings.color_mode='RGBA'
sc.render.film_transparent=True
sc.view_settings.view_transform='Standard'
sh=sc.display.shading;sh.light='MATCAP';sh.studio_light='clay_studio.exr';sh.color_type='SINGLE';sh.single_color=(.70,.74,.77)
sh.show_cavity=True;sh.cavity_type='BOTH';sh.curvature_ridge_factor=1.1;sh.curvature_valley_factor=1.1
sh.show_shadows=True;sh.show_specular_highlight=True
world=bpy.data.worlds.new('SOURCE_REVIEW_TEMP_WORLD');world.color=(.17,.17,.17);sc.world=world
cd=bpy.data.cameras.new('SOURCE_REVIEW_TEMP_CAMERA');cam=bpy.data.objects.new('SOURCE_REVIEW_TEMP_CAMERA',cd);sc.collection.objects.link(cam);sc.camera=cam;cd.type='ORTHO'
direction=Vector((-.7,-1,.5)).normalized();fwd=-direction
up=Vector((0,0,1));right=fwd.cross(up).normalized();up=right.cross(fwd).normalized()
cam.rotation_euler=Matrix((right,up,-fwd)).transposed().to_euler()
rows=[]
for item in AUDIT['items']:
 row=item['source'];objects=[bpy.data.objects[x['object']] for x in item['objects'] if x['type']=='MESH']
 copies=[];worldpoints=[]
 for ob in objects:
  copy=ob.copy();copy.data=ob.data;copy.parent=None;copy.matrix_world=ob.matrix_world.copy();copy.hide_viewport=False;copy.hide_render=False;copy.hide_set(False);sc.collection.objects.link(copy);copies.append(copy)
  p=points(ob.data).astype(np.float64);mw=np.asarray(ob.matrix_world,dtype=np.float64);worldpoints.append(p@mw[:3,:3].T+mw[:3,3])
 p=np.concatenate(worldpoints);assert len(p)>0
 lo=p.min(0);hi=p.max(0);center=(lo+hi)*.5;rel=p-center
 px=rel@np.array(right);py=rel@np.array(up);pz=rel@np.array(direction)
 half=max(float(np.abs(px).max()),float(np.abs(py).max()),1e-5)
 depth=max(float(np.abs(pz).max()),half*.1,1e-5)
 dist=depth*3+half*4
 cam.location=Vector(center.tolist())+direction*dist;cd.ortho_scale=half*2*1.16
 cd.clip_start=max(1e-7,dist*.001);cd.clip_end=max(dist*5,1.0)
 sc.render.filepath=str(OUT/(row['id']+'.png'))
 bpy.ops.render.render(write_still=True,scene=sc.name)
 image=bpy.data.images.load(sc.render.filepath,check_existing=False)
 a=np.empty(image.size[0]*image.size[1]*4,dtype=np.float32);image.pixels.foreach_get(a);a=a.reshape(image.size[1],image.size[0],4)
 mask=a[:,:,3]>.5;ys,xs=np.nonzero(mask)
 if not len(xs):raise RuntimeError('Empty source render: '+row['id'])
 border=int(mask[:2].sum()+mask[-2:].sum()+mask[:,:2].sum()+mask[:,-2:].sum())
 report={'source_id':row['id'],'source_filename':row['source_filename'],'format':row['format'],'revision_group':row['revision_group'],'image':sc.render.filepath,'image_sha256':hashlib.sha256(Path(sc.render.filepath).read_bytes()).hexdigest(),'image_bytes':Path(sc.render.filepath).stat().st_size,'image_width':int(image.size[0]),'image_height':int(image.size[1]),'source_mesh_count':len(objects),'source_triangles':item['triangle_count'],'source_mass_volume':'Mass Volume' in row['source_filename'],'nonempty_alpha_pixels':len(xs),'bbox_pixels':[int(xs.min()),int(ys.min()),int(xs.max()),int(ys.max())],'pixels_at_2px_border':border,'framing_has_clear_border':border==0,'review_only_show_hidden':True,'source_geometry_unchanged':True,'source_units':row['original_units']}
 rows.append(report);bpy.data.images.remove(image)
 for ob in copies:bpy.data.objects.remove(ob,do_unlink=True)
 print('ALL_SOURCE_REVIEW='+json.dumps({'completed':len(rows),'id':row['id'],'nonempty':len(xs),'border':border}),flush=True)
 (OUT/'checkpoint.json').write_text(json.dumps({'completed':len(rows),'expected':len(AUDIT['items']),'rows':rows},ensure_ascii=False,indent=2)+'\n')
after=verify_all();assert before==after
ids=[x['source_id'] for x in rows];assert len(ids)==155 and len(set(ids))==155
result={'blender_version':bpy.app.version_string,'saved_source_blend':bpy.data.filepath,'saved_source_blend_sha256':hashlib.sha256(Path(bpy.data.filepath).read_bytes()).hexdigest(),'source_record_count':155,'native_record_count':119,'raw_stl_record_count':36,'unique_source_id_count':len(set(ids)),'all_images_nonempty':all(r['nonempty_alpha_pixels']>0 for r in rows),'all_images_have_clear_border':all(r['framing_has_clear_border'] for r in rows),'original_geometry_precheck':before,'original_geometry_postcheck':after,'native_blend_not_resaved':True,'render_engine':'Workbench matcap + cavity; no source material edits','camera':'one cached orthographic three-quarter camera; each original world-space vertex set individually framed','source_geometry_repair_or_simplification':False,'total_png_bytes':sum(r['image_bytes'] for r in rows),'elapsed_seconds':time.monotonic()-START,'rows':rows}
(OUT/'review-all.audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print('ALL_SOURCE_COMPLETE='+json.dumps({k:v for k,v in result.items() if k!='rows'}),flush=True)
