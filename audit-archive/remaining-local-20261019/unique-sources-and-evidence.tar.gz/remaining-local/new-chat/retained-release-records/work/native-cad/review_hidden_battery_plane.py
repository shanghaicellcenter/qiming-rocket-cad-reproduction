"""Temporary, source-preserving review of the first hidden battery-holder mesh.
No thickness/repair and no saved source scene or GLB changes.
"""
import bpy,numpy as np,json
from pathlib import Path
from mathutils import Vector
BASE=Path('/Users/qianqiming/Documents/Codex/2026-10-19/new-chat/work/native-cad')
OUT=BASE/'hidden-battery-review';OUT.mkdir(parents=True,exist_ok=True)
bpy.ops.wm.open_mainfile(filepath=str(BASE/'vehicle-blender/vehicle-browse.blend'))
source=next(o for o in bpy.data.objects if o.type=='MESH' and o.get('source_hidden') and '7712K511_BatteryHolder1' in o.get('source_usd_path','') and o.get('source_usd_path','').endswith('/Mesh_1'))
bpy.context.view_layer.update()
points=np.array([tuple(v.co) for v in source.data.vertices],dtype=np.float64)
faces=np.array([tuple(f.vertices) for f in source.data.polygons],dtype=np.int64)
cross=np.cross(points[faces[:,1]]-points[faces[:,0]],points[faces[:,2]]-points[faces[:,0]])
areas=np.linalg.norm(cross,axis=1)*.5
normals=cross/np.maximum(np.linalg.norm(cross,axis=1)[:,None],1e-30)
wm=np.array(source.matrix_world,dtype=np.float64)
wp=points@wm[:3,:3].T+wm[:3,3]
worldcross=np.cross(wp[faces[:,1]]-wp[faces[:,0]],wp[faces[:,2]]-wp[faces[:,0]])
worldareas=np.linalg.norm(worldcross,axis=1)*.5
normal=Vector(normals[int(np.argmax(areas))].tolist())
world_normal=(source.matrix_world.to_3x3().inverted().transposed()@normal).normalized()
lo=wp.min(axis=0);hi=wp.max(axis=0);center=Vector(((lo+hi)*.5).tolist());size=float(max(hi-lo))
report={'source_object':source.name,'source_usd_path':source['source_usd_path'],
 'source_hidden':bool(source['source_hidden']),'vertices':len(points),'triangles':len(faces),
 'nonzero_area_triangles':int(np.sum(areas>1e-12)),'zero_area_triangles':int(np.sum(areas<=1e-12)),
 'local_area_sum':float(areas.sum()),'local_area_min':float(areas.min()),'local_area_max':float(areas.max()),
 'world_native_area_sum':float(worldareas.sum()),'normal_local_representative':list(normal),
 'normal_world_blender_z_up':list(world_normal),
 'normal_world_gltf_y_up':[world_normal.x,world_normal.z,-world_normal.y],
 'unique_local_normals_rounded':np.unique(np.round(normals,6),axis=0).tolist(),
 'local_bbox_min':points.min(axis=0).tolist(),'local_bbox_max':points.max(axis=0).tolist(),
 'world_bbox_native_min':lo.tolist(),'world_bbox_native_max':hi.tolist(),
 'source_geometry_changed':False,'source_blend_or_glb_changed':False}
sc=bpy.data.scenes.new('TEMP_HIDDEN_BATTERY_PLANE_REVIEW')
copy=source.copy();copy.parent=None;copy.matrix_world=source.matrix_world.copy()
copy.hide_render=False;copy.hide_viewport=False;sc.collection.objects.link(copy)
world=bpy.data.worlds.new('TEMP_REVIEW_WORLD');world.color=(.10,.10,.10);sc.world=world
camdata=bpy.data.cameras.new('TEMP_CAMERA');cam=bpy.data.objects.new('TEMP_CAMERA',camdata)
sc.collection.objects.link(cam);sc.camera=cam;camdata.type='ORTHO';camdata.ortho_scale=size*1.25;camdata.clip_end=1000
camdata.clip_start=max(size*.001,1e-6)
sc.render.engine='BLENDER_WORKBENCH';sc.render.resolution_x=1000;sc.render.resolution_y=800
sc.render.resolution_percentage=100;sc.render.image_settings.file_format='PNG';sc.render.film_transparent=False
sc.view_settings.view_transform='Standard'
sh=sc.display.shading;sh.light='STUDIO';sh.color_type='SINGLE';sh.single_color=(.62,.68,.74)
sh.show_shadows=False;sh.show_cavity=False;sh.show_backface_culling=False;sh.background_type='WORLD'
tangent=world_normal.cross(Vector((0,1,0)))
if tangent.length<1e-6:tangent=world_normal.cross(Vector((1,0,0)))
tangent.normalize()
for label,direction in [('front',world_normal),('oblique',(world_normal+Vector((.5,0,.4))).normalized()),('edge',tangent)]:
    cam.location=center+direction*size*3
    cam.rotation_euler=(center-cam.location).to_track_quat('-Z','Y').to_euler()
    sc.render.filepath=str(OUT/(label+'.png'));bpy.ops.render.render(write_still=True,scene=sc.name)
report['render_paths']=[str(OUT/(x+'.png')) for x in ('front','oblique','edge')]
(OUT/'audit.json').write_text(json.dumps(report,indent=2))
print('HIDDEN_BATTERY_REVIEW='+json.dumps(report),flush=True)
