"""Review existing local ASR JSON; never recognize or synthesize audio."""
import datetime
from collections import Counter
import difflib
import hashlib
import json
import math
from pathlib import Path
import wave

ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent
EXPECTED_NARRATION = '96c7b3e545973bd573445474d9bc1f380b778c6871609509e0bed5bb6693b7e7'
HOMOPHONES = {
    ('筒', '桶'): 'tǒng / tǒng', ('室', '式'): 'shì / shì',
    ('贮', '炷'): 'zhù / zhù', ('贮', '柱'): 'zhù / zhù', ('贮', '住'): 'zhù / zhù',
    ('只', '支'): 'zhī / zhī', ('件', '键'): 'jiàn / jiàn',
    ('芯', '心'): 'xīn / xīn', ('剂', '技'): 'jì / jì',
    ('箭', '舰'): 'jiàn / jiàn',
    ('翼', '意'): 'yì / yì', ('隔', '格'): 'gé / gé',
    ('源', '圆'): 'yuán / yuán', ('原', '圆'): 'yuán / yuán',
    ('源', '原'): 'yuán / yuán', ('舱', '仓'): 'cāng / cāng',
    ('锥', '椎'): 'zhuī / 椎可读zhuī', ('源', '元'): 'yuán / yuán', ('原', '元'): 'yuán / yuán',
    ('树', '术'): 'shù / shù', ('另', '令'): 'lìng / lìng', ('核', '和'): 'hé / hé',
    ('长', '场'): 'cháng / 场可读cháng（场院），也可读chǎng；仅凭识别字不能认定声调不同',
}
SPECIAL = {
    ('逐', '主'): ('tone_distinct_ASR_ambiguity', '逐 zhú / 主 zhǔ；声调不同，ASR不能证明TTS误读，需回听对应词块。'),
    ('筒', '通'): ('tone_distinct_ASR_ambiguity', '圆筒 tǒng / 通 tōng；声调不同，ASR不能证明TTS误读，需回听对应词块。'),
    ('组', '足'): ('tone_distinct_ASR_ambiguity', '四组 zǔ / 足 zú；声调不同，ASR不能证明TTS误读，需回听对应词块。'),
    ('段', '端'): ('tone_distinct_ASR_ambiguity', '段 duàn / 端 duān；声调不同，ASR不能证明TTS误读，需回听对应词块。'),
    ('置', '之'): ('tone_or_word_segmentation_ASR_ambiguity', '位置后 / 位之后：置 zhì / 之 zhī，存在声调与分词歧义，需回听，不自动视为同音或增漏词。'),
}


def read(path):
    return json.loads(path.read_text())


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda: f.read(1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()


def normalized(text):
    return ''.join(c.lower() for c in text if c.isalnum())


def numeric(value):
    return type(value) in (int, float) and math.isfinite(value)


def review_clip(target, status):
    cid = target['id']
    ap = ROOT / f'results/{cid}/{cid}.asr.json'
    sp = ROOT / f'results/{cid}/{cid}.sentence-alignment.json'
    result = {'id': cid, 'target_text': target['text'], 'target_text_sha256': target['text_sha256'],
              'review_status': 'pending_actual_ASR', 'full_text_reviewed': False,
              'human_content_passed': False, 'voice_naturalness_reviewed': False,
              'eligible_for_final_movie': False}
    if not ap.exists():
        return result
    asr = read(ap)
    integrity = []
    wav = BASE / 'collected' / status['wav_file']
    with wave.open(str(wav), 'rb') as f:
        duration = f.getnframes() / f.getframerate()
    actual_hash = sha(wav)
    if asr['input_wav_sha256'] != actual_hash or status['wav_sha256'] != actual_hash:
        integrity.append('ASR_input_WAV_hash_mismatch')
    if abs(asr['duration_seconds'] - duration) > 0.000001:
        integrity.append('ASR_duration_mismatch')
    if asr.get('target_text_supplied_to_asr') is not False:
        integrity.append('independent_ASR_not_demonstrated')
    if target['text_sha256'] != hashlib.sha256(target['text'].encode()).hexdigest():
        integrity.append('target_text_hash_mismatch')
    if status['text_sha256'] != target['text_sha256']:
        integrity.append('generated_text_version_mismatch')
    words = asr.get('words', [])
    word_issues = []
    for i, word in enumerate(words):
        start, end = word.get('start'), word.get('end')
        if not numeric(start) or not numeric(end):
            word_issues.append({'word_index': i, 'issue': 'None_or_nonfinite_timestamp'})
            continue
        if start < 0 or end > duration + 0.000001:
            word_issues.append({'word_index': i, 'issue': 'outside_audio_duration', 'start': start, 'end': end})
        if end <= start:
            word_issues.append({'word_index': i, 'issue': 'reversed_or_zero_duration'})
        if i and numeric(words[i - 1].get('end')) and start < words[i - 1]['end']:
            word_issues.append({'word_index': i, 'issue': 'word_overlap_or_reverse_order'})
    raw_join = ''.join(w['text'] for w in words)
    if normalized(raw_join) != normalized(asr['transcript']):
        integrity.append('transcript_differs_from_word_chunks')
    expected, actual = normalized(target['text']), normalized(asr['transcript'])
    diffs = []
    mapped_actual_parts = []
    opcodes = []
    for op, i, j, k, l in difflib.SequenceMatcher(a=expected, b=actual, autojunk=False).get_opcodes():
        if op == 'replace' and j - i == l - k:
            opcodes.extend((op, i + n, i + n + 1, k + n, k + n + 1) for n in range(j - i))
        else:
            opcodes.append((op, i, j, k, l))
    for op, i, j, k, l in opcodes:
        if op == 'equal':
            mapped_actual_parts.append(actual[k:l])
            continue
        a, b = expected[i:j], actual[k:l]
        category, explanation = 'unresolved_text_difference', '需回听；ASR文本差异不等于已证明的生成音频错误。'
        if (a, b) in HOMOPHONES:
            category, explanation = 'homophone_character_choice', HOMOPHONES[a, b] + '；同音选字，不据此判为漏读或误读。'
        elif (a, b) in SPECIAL:
            category, explanation = SPECIAL[a, b]
        elif not a:
            category, explanation = 'possible_extra_or_repeated_ASR_text', '识别多字，需回听区分生成重复与识别插入。'
        elif not b:
            category, explanation = 'possible_omitted_ASR_text', '识别缺字，需回听区分生成漏读与识别遗漏。'
        mapped_actual_parts.append(a if category == 'homophone_character_choice' else b)
        overlap = []
        cursor = 0
        for wi, word in enumerate(words):
            length = len(normalized(word['text']))
            if cursor < l and cursor + length > k:
                overlap.append(wi)
            cursor += length
        diffs.append({'operation': op, 'target_start_character': i, 'target_end_character': j,
                      'recognized_start_character': k, 'recognized_end_character': l,
                      'target': a, 'recognized': b, 'category': category, 'explanation': explanation,
                      'target_context': expected[max(0, i-6):min(len(expected), j+6)],
                      'recognized_context': actual[max(0, k-6):min(len(actual), l+6)],
                      'observed_word_indices': overlap,
                      'observed_word_spans': [words[n] for n in overlap]})
    sentence_issues, sentence_rows = [], []
    if sp.exists():
        alignment = read(sp)
        if alignment.get('input_wav_sha256') != actual_hash:
            integrity.append('sentence_alignment_WAV_hash_mismatch')
        if alignment.get('text_sha256') != target['text_sha256']:
            integrity.append('sentence_alignment_target_hash_mismatch')
        if len(alignment.get('sentences', [])) != len(target['sentences']):
            sentence_issues.append({'issue': 'sentence_count_mismatch'})
        previous_end = None
        previous_indices = set()
        used_word_indices = set()
        for index, row in enumerate(alignment.get('sentences', [])):
            issues = []
            start, end = row.get('start'), row.get('end')
            indices = row.get('whisper_word_indices', [])
            valid_indices = bool(indices) and all(type(n) is int and 0 <= n < len(words) for n in indices)
            if not valid_indices:
                issues.append('missing_or_invalid_Whisper_word_indices')
            elif indices != sorted(set(indices)):
                issues.append('word_indices_not_strictly_in_order')
            if index >= len(target['sentences']) or row.get('target_text') != target['sentences'][index]['text']:
                issues.append('sentence_target_text_mismatch')
            if index >= len(target['sentences']) or row.get('sentence_id') != target['sentences'][index]['id']:
                issues.append('sentence_target_id_mismatch')
            if not numeric(start) or not numeric(end):
                issues.append('None_or_nonfinite_sentence_boundary')
            else:
                if start < 0 or end > duration + 0.000001:
                    issues.append('sentence_boundary_outside_audio')
                if end <= start:
                    issues.append('sentence_boundary_reversed_or_zero_duration')
                if previous_end is not None and start < previous_end:
                    issues.append('sentence_overlap')
                previous_end = end
            if valid_indices:
                selected = [words[n] for n in indices]
                if all(numeric(w.get('start')) and numeric(w.get('end')) for w in selected):
                    if start != min(w['start'] for w in selected) or end != max(w['end'] for w in selected):
                        issues.append('boundary_not_equal_to_observed_word_span')
                if row.get('recognized_span') != ''.join(w['text'] for w in selected):
                    issues.append('recognized_span_differs_from_observed_words')
                if previous_indices.intersection(indices):
                    issues.append('word_chunk_shared_between_sentences')
                previous_indices = set(indices)
                used_word_indices.update(indices)
            sentence_rows.append({'sentence_id': row['sentence_id'], 'target_text': row['target_text'],
                                  'start': start, 'end': end, 'whisper_word_indices': indices,
                                  'recognized_span': row['recognized_span'],
                                  'exact_character_coverage': row['exact_character_coverage'], 'issues': issues})
            sentence_issues.extend({'sentence_id': row['sentence_id'], 'issue': issue} for issue in issues)
        if used_word_indices != set(range(len(words))):
            sentence_issues.append({'issue': 'ASR_word_chunks_not_all_accounted_for',
                                    'unaccounted_word_indices': sorted(set(range(len(words))) - used_word_indices)})
        alignment_hash = sha(sp)
    else:
        sentence_issues.append({'issue': 'pending_actual_sentence_alignment'})
        alignment_hash = None
    ambiguous = [d for d in diffs if d['category'] != 'homophone_character_choice']
    classification = 'exact_text_after_punctuation_and_case_normalization' if not diffs else 'homophone_character_choices_only'
    if ambiguous:
        classification = 'requires_targeted_audio_recheck_for_ASR_ambiguity'
    result.update({'review_status': 'reviewed_existing_actual_ASR', 'full_text_reviewed': True,
                   'asr_engine': asr.get('engine'), 'asr_device': asr.get('device'),
                   'asr_offline': asr.get('offline'), 'target_text_supplied_to_asr': asr.get('target_text_supplied_to_asr'),
                   'asr_file': str(ap.relative_to(ROOT)), 'asr_sha256': sha(ap),
                   'alignment_file': str(sp.relative_to(ROOT)) if sp.exists() else None,
                   'alignment_sha256': alignment_hash, 'wav_sha256': actual_hash,
                   'audio_duration_seconds': duration, 'recognized_text': asr['transcript'],
                   'text_classification': classification, 'normalized_character_differences': diffs,
                   'target_normalized_characters': len(expected), 'recognized_normalized_characters': len(actual),
                   'raw_text_exact_match': target['text'] == asr['transcript'],
                   'only_punctuation_or_case_differences': target['text'] != asr['transcript'] and expected == actual,
                   'integrity_issues': integrity, 'word_timestamp_issues': word_issues,
                   'sentence_boundary_issues': sentence_issues, 'sentences': sentence_rows,
                   'observed_word_chunk_count': len(words),
                   'tail_target_last8_literal_match': bool(expected) and actual.endswith(expected[-8:]),
                   'tail_target_last8_match_allowing_documented_homophones': bool(expected) and ''.join(mapped_actual_parts).endswith(expected[-8:]),
                   'last_observed_word': words[-1] if words else None,
                   'last_observed_word_end_to_file_end_seconds': duration - words[-1]['end'] if words and numeric(words[-1].get('end')) else None,
                   'timing_basis': 'Real Whisper decoder word chunks; sentence min/max of listed chunks; approximate, not per-character forced alignment',
                   'target_mapping_suggestions': [{'recognized': d['recognized'], 'target': d['target'],
                                                   'word_indices': d['observed_word_indices']}
                                                  for d in diffs if d['category'] == 'homophone_character_choice']})
    return result


def main():
    bundle = read(BASE / 'clips.json')
    assert bundle['source_narration_sha256'] == EXPECTED_NARRATION
    status = read(BASE / 'collected/results/status.json')
    assert status['engine'] == 'Breeze2' and status['source_narration_sha256'] == EXPECTED_NARRATION
    by_id = {r['id']: r for r in status['clips']}
    clips = [review_clip(t, by_id[t['id']]) for t in bundle['clips']]
    done = [c for c in clips if c['full_text_reviewed']]
    issues = [c['id'] for c in done if c['integrity_issues'] or c['word_timestamp_issues'] or c['sentence_boundary_issues']]
    unresolved = [c['id'] for c in done if c['text_classification'] == 'requires_targeted_audio_recheck_for_ASR_ambiguity']
    report = {'engine': 'Breeze2', 'review_updated_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'source_narration_sha256': EXPECTED_NARRATION, 'source_clips_file_sha256': sha(BASE / 'clips.json'),
              'review_scope': 'Existing independent Whisper transcript text and observed word/sentence bounds only',
              'expected_clip_count': 17, 'actual_ASR_reviewed_count': len(done),
              'actual_sentence_boundary_reviewed_count': sum(len(c.get('sentences', [])) for c in done),
              'pending_actual_ASR_ids': [c['id'] for c in clips if not c['full_text_reviewed']],
              'all17_actual_ASR_evidence_reviewed': len(done) == 17,
              'observed_Whisper_word_chunk_count': sum(c['observed_word_chunk_count'] for c in done),
              'text_classification_counts': dict(Counter(c['text_classification'] for c in done)),
              'character_difference_category_counts': dict(Counter(d['category'] for c in done for d in c['normalized_character_differences'])),
              'ASR_device_counts': dict(Counter(c['asr_device'] for c in done)),
              'inserted_or_deleted_ASR_text_spans': [{'id': c['id'], 'difference': d}
                  for c in done for d in c['normalized_character_differences'] if d['operation'] in ('insert', 'delete')],
              'clips_with_integrity_or_boundary_issues': issues, 'clips_with_unresolved_ASR_text_differences': unresolved,
              'human_content_passed': False, 'voice_naturalness_reviewed': False, 'eligible_for_final_movie': False,
              'clips': clips}
    path = ROOT / 'progress/text-review.json'
    path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    lines = ['# Breeze2 独立文本与边界复核', '',
             f"真实ASR已审查 {len(done)}/17 段，句边界 {report['actual_sentence_boundary_reviewed_count']} 条。",
             f"目标源SHA256：`{EXPECTED_NARRATION}`。", '',
             '仅比较原始独立Whisper全文、真实词块时间与目标；未运行模型、未发TTS、未改音频或原始ASR。',
             'Whisper词块有时覆盖整个分句，时间是近似声学解码边界；不冒称逐字强制对齐。',
             'ASR选字差异不能单独证明TTS读错；未进行人工声音自然度验收，成片资格始终为false。', '',
             f"去标点/大小写后逐字一致：{report['text_classification_counts'].get('exact_text_after_punctuation_and_case_normalization', 0)} 段；仅记录同音选字：{report['text_classification_counts'].get('homophone_character_choices_only', 0)} 段；保留回听疑点：{len(unresolved)} 段。",
             f"真实Whisper词块共 {report['observed_Whisper_word_chunk_count']} 个。未发现空时间、越音频时长、倒序、句间重叠或绑定哈希异常。" if not issues else '具体边界或完整性异常见下表。',
             '未见转写增字/删字、重复或尾词缺失；词块边界不能单独排除波形截断。' if not report['inserted_or_deleted_ASR_text_spans'] else '存在转写增删字疑点，见逐段详情。',
             '当前没有繁简转换或英文字母大小写差异；标点缺失、逗号/句号/分号转换作为解码排版差异单列。',
             'ASR设备来源：' + '，'.join(k + ' ' + str(v) + ' 段' for k, v in report['ASR_device_counts'].items()) + '。本审查未启动任何识别或生成进程。', '',
             '| 段落 | 文本差异 | 真实句界（秒） | 边界/完整性异常 |',
             '|---|---|---|---|']
    for c in clips:
        if not c['full_text_reviewed']:
            lines.append(f"| {c['id']} | 等待实际ASR | 待证据 | 待证据 |")
            continue
        d = '；'.join(x['target'] + '→' + x['recognized'] + ' [' + x['category'] + ']' for x in c['normalized_character_differences']) or '去标点/大小写后一致'
        boundaries = '；'.join(str(s['start']) + '–' + str(s['end']) for s in c['sentences'])
        errors = c['integrity_issues'] + c['word_timestamp_issues'] + c['sentence_boundary_issues']
        lines.append(f"| {c['id']} | {d} | {boundaries} | {str(errors) if errors else '未发现'} |")
    lines += ['', '## 定点回听疑点', '',
              '下列是转写的未决差异，不能直接称为TTS已误读。时间范围直接取真实词块，未细分成虚构的单字时间。', '',
              '| 段落 | 目标→识别 | 真实词块时间（秒） |', '|---|---|---|']
    for c in done:
        for d in c['normalized_character_differences']:
            if d['category'] == 'homophone_character_choice':
                continue
            spans = '；'.join(str(w['start']) + '–' + str(w['end']) for w in d['observed_word_spans'])
            lines.append(f"| {c['id']} | {d['target']}→{d['recognized']} | {spans} |")
    lines += ['', '分类更正：stage05“长→场”中的“场”可读cháng，也可读chǎng；仅凭识别选字不能认定声调不同，归入可由同音选字解释。']
    for c in done:
        lines += ['', '## ' + c['id'], '', '**目标**：' + c['target_text'], '', '**原始识别**：' + c['recognized_text'], '']
        for d in c['normalized_character_differences']:
            spans = '；'.join(str(w['start']) + '–' + str(w['end']) + ' 秒：' + w['text'] for w in d['observed_word_spans'])
            lines.append('- `' + d['target'] + '→' + d['recognized'] + '`：' + d['explanation'] + ' 真实词块 ' + spans)
        if not c['normalized_character_differences']:
            lines.append('- 去除标点并统一大小写后，识别全文逐字一致。')
        lines.append('- 尾部最后八字逐字一致：' + str(c['tail_target_last8_literal_match']) +
                     '；仅接受已记录同音选字后是否一致：' + str(c['tail_target_last8_match_allowing_documented_homophones']) +
                     '；最后词块结束距文件尾 ' + str(round(c['last_observed_word_end_to_file_end_seconds'], 4)) +
                     ' 秒。这仅为转写/时间证据，不能单独证明波形没有截断。')
    lines += ['', '## 仍需独立处理', '',
              '- 未产生真实ASR的段落始终记为待证据。',
              '- `tone_distinct_ASR_ambiguity`、漏词/多词或其他未分类差异需定点回听，不能靠替换目标字自动消除。',
              '- 同音字映射建议只在本报告中；未改canonical manifest、原始转写或边界。',
              '- 响度、主观音色/自然度与最终成片放行不在本报告验收范围。']
    (ROOT / 'text-review.md').write_text('\n'.join(lines) + '\n')
    print(json.dumps({k: report[k] for k in ('actual_ASR_reviewed_count', 'actual_sentence_boundary_reviewed_count',
          'pending_actual_ASR_ids', 'clips_with_integrity_or_boundary_issues', 'clips_with_unresolved_ASR_text_differences')}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
