import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import time

root = Path.home() / "codex-mojave-cad-review-20261019"
cad = root / "source/Mojave Sphinx CAD - R01"
mode = sys.argv[1]
names = {
    "fin": "FIN-STD-250T-4X250C Fin, Standard, Mojave Sphinx.SLDPRT",
    "vehicle": "Mojave Sphinx Vehicle Assembly.SLDASM",
    "vehicle-browse": "Mojave Sphinx Vehicle Assembly.SLDASM",
}
source = cad / names[mode]
output = root / f"{mode}.usdc"
before = hashlib.sha256(source.read_bytes()).hexdigest()
cmd = [str(root / "venv/bin/usd-convert-cad"), "-i", str(source), "-o", str(output),
       "--tess-lod", "1" if mode == "vehicle-browse" else "3", "--instancing-style", "reference", "--composition-style", "none",
       "--filter-style", "hide", "--load-hidden", "--progress"]
started = time.monotonic()
with (root / f"{mode}.stdout.log").open("w") as stdout, (root / f"{mode}.stderr.log").open("w") as stderr:
    result = subprocess.run(cmd, cwd=cad, stdout=stdout, stderr=stderr)
after = hashlib.sha256(source.read_bytes()).hexdigest()
logs = (root / f"{mode}.stdout.log").read_text(errors="replace") + "\n" + (root / f"{mode}.stderr.log").read_text(errors="replace")
licensing_error = bool(re.search(r"(?:license|licensing|entitlement).{0,80}(?:error|fail|denied|invalid|missing|expired)|A3D_LICENSE", logs, re.I))
summary = {
    "source": str(source), "input_sha256_before": before, "input_sha256_after": after,
    "input_unchanged": before == after, "command": cmd,
    "return_code": result.returncode, "wall_seconds": round(time.monotonic() - started, 3),
    "output": str(output), "output_exists": output.exists(),
    "output_bytes": output.stat().st_size if output.exists() else None,
    "output_sha256": hashlib.sha256(output.read_bytes()).hexdigest() if output.exists() else None,
    "licensing_error_detected": licensing_error,
    "missing_reference_lines": [line for line in logs.splitlines() if re.search(r"missing|not.found|unresolved|reference.*fail|cannot.*(?:open|load)|could not.*(?:open|load)", line, re.I)],
    "scope": "passive source geometry conversion; no constraints, physics data, solver, or new design",
}
(root / f"{mode}.conversion.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2))
if result.returncode or licensing_error or not output.exists():
    print(logs[-5000:])
    raise SystemExit(result.returncode or 1)
