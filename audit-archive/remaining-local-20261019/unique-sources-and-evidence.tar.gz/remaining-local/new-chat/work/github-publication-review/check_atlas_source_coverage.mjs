import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
import {launch} from '../../outputs/启明火箭/source/vendor/machine/scripts/lib/browser.mjs';
import {LIBRARY_ENTRIES,SOURCE_CATALOG} from '../../outputs/启明火箭/source/assembly-viewer/source/data.js';
const root=resolve('.');
const html=resolve('outputs/启明火箭/整箭原件检视.html');
const atlasPath=resolve('work/atlas-integration/staged/部件说明图册/图册数据.json');
const atlas=JSON.parse(readFileSync(atlasPath,'utf8'));
const references=new Map();
for(const record of atlas.records) for(const image of record.images??[]){
 const name=image.sourceBasename;
 if(name){ if(!references.has(name))references.set(name,[]); references.get(name).push({record_id:record.id,origin:image.origin,source_assembly_present:image.sourceAssemblyPresent}); }
}
const errors=[],external=[];
const {browser,page}=await launch({width:1280,height:720});
try{
 page.on('pageerror',e=>errors.push(e.message));
 page.on('request',req=>{if(/^https?:/.test(req.url()))external.push(req.url().split('?')[0]);});
 await page.goto(pathToFileURL(html).href,{waitUntil:'load',timeout:120000});
 await page.waitForFunction(()=>document.body.dataset.ready==='true'||document.body.dataset.ready==='error',null,{timeout:120000});
 const actual=await page.evaluate(()=>({entries:window.assemblyReview?.getEntries()??[],meshes:window.assemblyReview?.getMeshes()??[],title:document.title,ready:document.body.dataset.ready,error:window.assemblyError??null}));
 if(actual.error)throw new Error(actual.error);
 const checks=[...references].sort(([a],[b])=>a.localeCompare(b)).map(([name,refs])=>{
  const main=actual.entries.filter(e=>e.filename===name&&e.kind!=='mesh');
  const library=LIBRARY_ENTRIES.filter(e=>e.source_filename===name);
  const catalog=SOURCE_CATALOG.filter(e=>e.filename===name);
  return {source_basename:name,atlas_reference_count:refs.length,atlas_records:[...new Set(refs.map(r=>r.record_id))],extension:name.split('.').at(-1).toLowerCase(),main_component_nodes:main.length,main_paths:main.map(e=>e.path),main_source_mesh_count:main.reduce((s,e)=>s+e.meshCount,0),independent_library_entries:library.map(e=>({id:e.supplement_id??e.source_id,asset_id:e.asset_id,source_archive:e.source_archive,source_member:e.source_member})),catalog_entries:catalog.map(e=>({archive:e.archive,zip_member:e.zip_member})),status:main.length?(library.length?'main_and_independent_revision_or_variant':'main_assembly_exact_filename'):(library.length?'independent_library_exact_filename':'no_exact_filename_in_vehicle_or_supplements')};
 });
 const report={created_utc:new Date().toISOString(),scope:'One successfully completed isolated headless file load of current main viewer; prior attempt with an assumed internal 688 runtime array length timed out and closed, so no false success was recorded. Exact basename coverage only. Repeated main component nodes are instances, not conflicting source files. No 102 repeated page loads and no geometry edits.',atlas_data_sha256:createHash('sha256').update(readFileSync(atlasPath)).digest('hex'),viewer_html_sha256:createHash('sha256').update(readFileSync(html)).digest('hex'),atlas_record_count:atlas.records.length,distinct_source_basename_keys:references.size,actual_runtime_render_mesh_objects:actual.meshes.length,actual_unique_source_mesh_paths:new Set(actual.meshes.map(e=>e.path)).size,actual_source_hidden_runtime_objects:actual.meshes.filter(e=>e.sourceHidden).length,actual_main_entry_count:actual.entries.length,independent_library_entry_count:LIBRARY_ENTRIES.length,counts_by_status:Object.fromEntries([...new Set(checks.map(e=>e.status))].map(s=>[s,checks.filter(e=>e.status===s).length])),page_errors:errors,external_requests:external,checks};
 mkdirSync(resolve('work/github-publication-review'),{recursive:true});
 writeFileSync(resolve('work/github-publication-review/atlas-source-coverage.json'),JSON.stringify(report,null,2));
 console.log(JSON.stringify({distinct:references.size,counts:report.counts_by_status,errors,external:external.length,unmatched:checks.filter(e=>e.status==='no_exact_filename_in_vehicle_or_supplements').map(e=>e.source_basename),overlap:checks.filter(e=>e.status==='main_and_independent_revision_or_variant').map(e=>e.source_basename)}));
}finally{await browser.close();}
