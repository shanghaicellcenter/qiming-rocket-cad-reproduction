"""One independently guarded, offline Drama3 sample. Writes only this task's folder."""
import argparse,fcntl,hashlib,json,os,re,signal,subprocess,sys,time
from pathlib import Path

TASK=Path('/home/qianqiming/codex-mojave-assembly-voice-20261019')
RUNTIME=Path('/home/qianqiming/work/drama-3')
SOURCE=RUNTIME/'fish-speech'
CHECKPOINT=Path('/home/qianqiming/models/fishaudio/drama-3')
REFERENCE=RUNTIME/'test-output/codes_0.npy'
REFERENCE_TEXT='你好，欢迎收听中文语音测试。今天的天气很好，我们一起出去走走吧。'
GIB=1024**3
def save(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2))
def available():return int(dict(x.split(':',1) for x in Path('/proc/meminfo').read_text().splitlines())['MemAvailable'].split()[0])*1024
def setup():
    inc=RUNTIME/'.deps/python-dev/usr/include'
    os.environ['CPATH']=':'.join([str(inc/'python3.12'),str(inc),os.environ.get('CPATH','')]).rstrip(':')
    for k,v in {'FISH_DRAMA3_FP8_EXPERTS':'1','FISH_DRAMA3_CUDA_GRAPH':'0','TOKENIZERS_PARALLELISM':'false','PYTHONDONTWRITEBYTECODE':'1','HF_HUB_OFFLINE':'1','TRANSFORMERS_OFFLINE':'1','MPLCONFIGDIR':str(TASK/'cache/matplotlib'),'NUMBA_CACHE_DIR':str(TASK/'cache/numba'),'TRITON_CACHE_DIR':str(TASK/'cache/triton'),'TORCHINDUCTOR_CACHE_DIR':str(TASK/'cache/torchinductor')}.items():os.environ[k]=v
    sys.path.insert(0,str(SOURCE))
def worker():
    setup()
    import numpy as np,soundfile as sf,torch
    from loguru import logger
    from fish_speech.models.text2semantic.inference import init_model,load_codec_model,generate_long,decode_to_audio
    job=json.loads((TASK/'sample-request.json').read_text())
    reference=torch.from_numpy(np.load(REFERENCE));assert reference.ndim==2 and 0<reference.shape[1]<300
    model,decode=init_model(CHECKPOINT,'cuda:0',torch.bfloat16,compile=False)
    codec=load_codec_model(CHECKPOINT/'codec.pth',str(model.device),model.dtype)
    sink=logger.add(TASK/'generation.log',mode='w',format='{time} | {level} | {message}')
    started=time.monotonic();torch.manual_seed(42);torch.cuda.manual_seed_all(42);codes=[]
    try:
        for response in generate_long(model=model,device='cuda:0',decode_one_token=decode,text=job['text'],num_samples=1,max_new_tokens=768,top_p=.7,top_k=30,temperature=.7,compile=False,iterative_prompt=True,chunk_length=200,single_chunk=True,prompt_text=[REFERENCE_TEXT],prompt_tokens=[reference]):
            if response.action=='sample':codes.append(response.codes)
    finally:logger.remove(sink)
    assert codes,'No audio codes';merged=torch.cat(codes,dim=1);np.save(TASK/'sample-codes.npy',merged.cpu().numpy())
    audio=decode_to_audio(merged.to(model.device),codec).cpu().float().numpy();assert audio.size and np.isfinite(audio).all()
    target=TASK/'assembly-narration-sample.wav';sf.write(target,audio,codec.sample_rate,subtype='PCM_16')
    finish=re.findall(r'finish=([a-z_]+)',(TASK/'generation.log').read_text());eos=bool(finish) and all(x=='eos' for x in finish)
    result={'text':job['text'],'engine':'Fish Audio Drama3 existing local FP8 expert runtime','device':'NVIDIA GB10','sample_rate':codec.sample_rate,'duration_seconds':len(audio)/codec.sample_rate,'audio_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'reference_sha256':hashlib.sha256(REFERENCE.read_bytes()).hexdigest(),'reference_text':REFERENCE_TEXT,'reference_kind':'Existing model-generated generic Chinese test sample; no claim of a real speaker identity','finish_reasons':finish,'eos':eos,'finite':True,'peak':float(np.max(np.abs(audio))),'rms':float(np.sqrt(np.mean(audio**2))),'inference_seconds':time.monotonic()-started,'speed_or_pitch_modified':False,'offline':True,'formal_batch_started':False,'asr_content_check':'pending','actual_listening':'not performed by this agent'}
    save(TASK/'sample-result.json',result);print(json.dumps(result,ensure_ascii=False),flush=True)
    if not eos:raise RuntimeError('Non-EOS sample is not accepted')
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--worker',action='store_true');args=ap.parse_args()
    if args.worker:return worker()
    TASK.mkdir(exist_ok=True);lock=(TASK/'sample.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    active=[]
    for line in subprocess.run(['ps','-eo','pid,comm,args'],capture_output=True,text=True,check=True).stdout.splitlines():
        bits=line.split(None,2)
        if len(bits)==3 and bits[1].startswith('python') and any(s in bits[2] for s in ['resident_drama3_guarded.py','batch_drama3_guarded.py','text2semantic.inference']):active.append(int(bits[0]))
    if active:raise RuntimeError('Another Drama3 process is active; sample not started')
    before=available();assert before>=48.87562012672424*GIB,'Insufficient available memory for guarded load'
    setup();save(TASK/'preflight.json',{'available_GiB':before/GIB,'minimum_load_GiB':48.87562012672424,'other_drama3_process_ids':active,'reference_exists':REFERENCE.is_file(),'checkpoint_exists':(CHECKPOINT/'codec.pth').is_file(),'existing_services_changed':False,'other_project_files_changed':False})
    start=time.monotonic();minimum=before;reason=None
    with (TASK/'worker.log').open('w') as log:
        child=subprocess.Popen([sys.executable,str(Path(__file__).resolve()),'--worker'],cwd=TASK,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        while child.poll() is None:
            minimum=min(minimum,available())
            if minimum<8*GIB:reason='Available memory below 8 GiB'
            elif time.monotonic()-start>900:reason='Own sample reached 15 minute guard'
            if reason:
                os.killpg(child.pid,signal.SIGTERM)
                try:child.wait(timeout=15)
                except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL)
                break
            time.sleep(2)
        code=child.wait()
    save(TASK/'guard-result.json',{'exit_code':code,'reason':reason,'minimum_available_GiB':minimum/GIB,'elapsed_seconds':time.monotonic()-start,'single_model_load':True,'only_own_worker_stopped_on_guard':True})
    if code or reason:raise SystemExit(1)
if __name__=='__main__':main()
