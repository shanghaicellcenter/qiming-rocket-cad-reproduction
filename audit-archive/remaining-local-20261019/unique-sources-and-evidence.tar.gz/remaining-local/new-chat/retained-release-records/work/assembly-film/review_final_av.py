"""Independently decode final media and prepare documented visual sample sheets."""
from pathlib import Path
import datetime, hashlib, json, math, re, subprocess
from PIL import Image, ImageDraw, ImageFont

H = Path(__file__).resolve().parent
R = H.parents[1]
P = R/'outputs/启明火箭'
OUT = H/'movie-review-final'
FRAMES, SHEETS = OUT/'frames', OUT/'sheets'
FRAMES.mkdir(parents=True,exist_ok=True)
SHEETS.mkdir(exist_ok=True)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
movie = P/'media/逐步虚拟归位讲解.mp4'
timeline = json.loads((H/'final-timeline.json').read_text())
canonical = json.loads((R/'work/virtual-assembly/narration-audio-manifest.json').read_text())
assert canonical['eligible_for_final_movie'] and timeline['frames']==6051 and timeline['fps']==30
current_sha = sha(movie)
probe = subprocess.run(['/opt/homebrew/bin/ffprobe','-v','error','-count_frames','-show_streams','-show_format','-of','json',str(movie)],capture_output=True,text=True,check=True)
(OUT/'ffprobe.json').write_text(probe.stdout)
d = json.loads(probe.stdout)
video = next(s for s in d['streams'] if s['codec_type']=='video')
audio = [s for s in d['streams'] if s['codec_type']=='audio']
assert int(video['nb_read_frames'])==timeline['frames'] and video['width']==1280 and video['height']==720
assert video['r_frame_rate']=='30/1' and len(audio)==1 and audio[0]['codec_name']=='aac'
assert abs(float(d['format']['duration'])-timeline['duration'])<=1/30
decode_cmd = ['/opt/homebrew/bin/ffmpeg','-hide_banner','-v','warning','-xerror','-err_detect','explode','-i',str(movie),'-f','null','-']
decode = subprocess.run(decode_cmd,capture_output=True,text=True)
(OUT/'strict-decode.log').write_text(decode.stderr)
assert decode.returncode==0,decode.stderr

def srt_seconds(text):
    a,b,c,ms = map(int,re.split('[:,]',text))
    return a*3600+b*60+c+ms/1000
blocks = [b for b in (P/'media/逐步虚拟归位.srt').read_text().strip().split('\n\n') if b]
captions = [r for c in timeline['clips'] for r in c['captions']]
assert len(blocks)==len(captions)==41
for i,(block,caption) in enumerate(zip(blocks,captions)):
    lines = block.splitlines()
    a,b = lines[1].split(' --> ')
    assert int(lines[0])==i+1 and '\n'.join(lines[2:])==caption['text']
    assert abs(srt_seconds(a)-caption['start'])<=.000501 and abs(srt_seconds(b)-caption['end'])<=.000501
ass_rows = [line for line in (H/'captions.ass').read_text().splitlines() if line.startswith('Dialogue:')]
assert len(ass_rows)==41

selection=[]
def add(label,frame,kind,chapter,**extra):
    selection.append(dict(label=label,frame=int(frame),seconds=int(frame)/30,kind=kind,chapter=chapter,**extra))
for i,c in enumerate(timeline['clips']):
    first=round(c['start']*30)
    for label,offset in [('first',0),('middle',c['frames']//2),('returned',c['frames']-2)]:
        add(f'chapter-{i:02d}-{label}',first+offset,'chapter',i)
    if i:
        add(f'cut-{i:02d}-before',first-1,'boundary',i-1)
        add(f'cut-{i:02d}-after',first,'boundary',i)
    for j,cap in enumerate(c['captions']):
        add(f'caption-{i:02d}-{j+1:02d}',min(timeline['frames']-1,round((cap['start']+cap['end'])/2*30)),'caption',i,expected_caption=cap['text'])
    for j,anchor in enumerate(c['visual_mapping'][1:-1]):
        for delta in (-3,0,3):
            add(f'anchor-{i:02d}-{j+1:02d}-{delta+3:02d}',first+anchor['frame']+delta,'anchor',i,basis=anchor['basis'],anchor_global_seconds=c['start']+anchor['frame']/30)
add('last-frame',timeline['frames']-1,'endpoint',16)
unique=sorted({r['frame'] for r in selection})
vf='select='+'+'.join(f'eq(n\\,{n})' for n in unique)
extract = subprocess.run(['/opt/homebrew/bin/ffmpeg','-y','-hide_banner','-v','error','-i',str(movie),'-vf',vf,'-fps_mode','passthrough',str(FRAMES/'extract-%03d.png')],capture_output=True,text=True)
assert extract.returncode==0,extract.stderr
files=sorted(FRAMES.glob('extract-*.png'));assert len(files)==len(unique)
mapping=dict(zip(unique,files))
for row in selection:
    image = Image.open(mapping[row['frame']]).convert('RGB')
    path=FRAMES/(row['label']+'.png');image.save(path)
    row.update(image=str(path.relative_to(OUT)),sha256=sha(path))
for path in files:path.unlink()
font=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',18)
sheets=[]
for kind in ('chapter','boundary','caption','anchor','endpoint'):
    group=[r for r in selection if r['kind']==kind]
    for offset in range(0,len(group),8):
        rows=group[offset:offset+8]
        name=f'{kind}-{offset//8+1:02d}'
        canvas=Image.new('RGB',(1180,44+365*math.ceil(len(rows)/2)),'#e7edf3')
        draw=ImageDraw.Draw(canvas);draw.text((14,12),name+' | FINAL ACTUAL AUDIO + SUBTITLES',font=font,fill='#172533')
        for j,row in enumerate(rows):
            x,y=j%2*590,44+j//2*365
            image=Image.open(OUT/row['image']).convert('RGB');image.thumbnail((570,321))
            draw.text((x+10,y+6),f"{row['label']} | f{row['frame']} | {row['seconds']:.3f}s",font=font,fill='#172533')
            canvas.paste(image,(x+10,y+35))
        path=SHEETS/(name+'.png');canvas.save(path)
        sheets.append(dict(image=str(path.relative_to(OUT)),sha256=sha(path),frame_labels=[r['label'] for r in rows],actual_visual_review='pending'))
assert sha(movie)==current_sha
result=dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),movie=str(movie),movie_sha256=current_sha,movie_bytes=movie.stat().st_size,
    timeline_sha256=sha(H/'final-timeline.json'),canonical_manifest_sha256=sha(R/'work/virtual-assembly/narration-audio-manifest.json'),
    status='Whole-file A/V decode and 41 SRT rows passed; documented visual sample review pending',
    probe=dict(width=1280,height=720,fps='30/1',decoded_video_frames=6051,duration_seconds=float(d['format']['duration']),audio_codec=audio[0]['codec_name'],audio_channels=audio[0]['channels'],audio_sample_rate=audio[0]['sample_rate']),
    strict_decode=dict(exit_code=decode.returncode,stderr_bytes=len(decode.stderr.encode()),command=decode_cmd),
    subtitle_sidecar_rows=41,all_srt_texts_and_times_match_final_timeline=True,ass_dialogue_rows=41,
    selection_count=len(selection),unique_frames=len(unique),frames=selection,contact_sheets=sheets,
    visual_review='pending',human_listening_performed=False,source_movie_not_modified_by_review=True)
(OUT/'review.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(sha256=current_sha,actual_frames=6051,strict_av_decode_passed=True,srt_rows=41,sample_frames=len(unique),contact_sheets=len(sheets),visual_review='pending')))
