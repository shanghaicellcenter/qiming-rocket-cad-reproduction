from pathlib import Path
import json,wave,math,subprocess,csv,hashlib,re,sys
ROOT=Path('/Users/qianqiming/Documents/Codex/2026-10-19/new-chat');HERE=ROOT/'work/assembly-film';OUT=ROOT/'outputs/mojave-machine/media';VIRT=ROOT/'outputs/virtual-assembly'
FPS=30; OUT.mkdir(parents=True,exist_ok=True)
manifest=json.loads((ROOT/'work/virtual-assembly/narration-audio-manifest.json').read_text())
assert manifest.get('eligible_for_final_movie') is True, 'This voice is not eligible for final movie; human-rejected or pending voice must not be muxed.'
assert 'Breeze' in manifest['engine']
assert manifest['source_narration_sha256']==hashlib.sha256((ROOT/'work/virtual-assembly/narration-draft.json').read_bytes()).hexdigest()
assert manifest['reference_sha256']=='b877cfd2a4b951b77e07743a4e569ecca2f3a62e4d990b0b4f2baaaffcd0191f'
assert len(manifest['tracks'])==17
if any(not t.get('wav_path') for t in manifest['tracks']):raise SystemExit('17 actual audio tracks required; remaining tracks still pending')
# This immutable file describes the already captured silent master, before narration retiming.
source=json.loads((HERE/'silent-timeline.json').read_text());draft=json.loads((ROOT/'work/virtual-assembly/narration-draft.json').read_text());stages=json.loads((VIRT/'assembly-stages.json').read_text())
captured=json.loads((HERE/'capture-progress.json').read_text())
assert captured['status']=='complete' and captured['completed']==17
captured_by_id={c['id']:c for c in captured['entries']}
def acoustic_word_start(track,phrase,observed_homophones=()):
 words=track.get('asr_words') or []
 if not words and track.get('asr_json_path'):
  words=json.loads(Path(track['asr_json_path']).read_text()).get('words',[])
 chars='';word_for_char=[]
 for index,word in enumerate(words):
  clean=''.join(c for c in word['text'] if c.isalnum());chars+=clean;word_for_char.extend([index]*len(clean))
 # Preserve the independent transcript. Some Chinese homophones are spelled
 # differently by ASR; only explicitly reviewed alternatives may locate a span.
 matched=next((p for p in (phrase,*observed_homophones) if p in chars),None)
 assert matched is not None,('Actual acoustic word span required',track['id'],phrase,chars)
 at=chars.find(matched)
 word=words[word_for_char[at]];assert word['start'] is not None
 return float(word['start'])
clips=[];startframe=0;params=None;audio_chunks=[]
for i,(t,s) in enumerate(zip(manifest['tracks'],source['clips'])):
 assert t['id']==s['id'],('Audio/chapter order mismatch',t['id'],s['id'])
 p=Path(t['wav_path']);assert p.is_file()
 assert hashlib.file_digest(p.open('rb'),'sha256').hexdigest()==t['wav_sha256'],('Canonical audio SHA mismatch',t['id'])
 paragraph=([draft['intro'],*draft['stages'],draft['outro']][i])['narration_zh']
 assert t['text_sha256']==hashlib.sha256(paragraph.encode('utf-8')).hexdigest(),('Canonical text SHA mismatch',t['id'])
 normalize=lambda text:''.join(c for c in text if c.isalnum())
 assert normalize(''.join(row['target_text'] for row in t['subtitle_sentences']))==normalize(paragraph),('Caption/source paragraph mismatch',t['id'])
 with wave.open(str(p),'rb') as f:
  now=(f.getnchannels(),f.getsampwidth(),f.getframerate());samples=f.readframes(f.getnframes());duration=f.getnframes()/now[2]
 assert now==(1,2,24000),now
 if params is None:params=now
 assert now==params
 assert abs(duration-t['duration_seconds'])<1/now[2]
 frames=math.ceil((duration+1.2)*FPS)
 if i==15:frames=max(frames,18*FPS)
 leadframes=round(.35*now[2]);target_samples=round(frames/FPS*now[2]);src_samples=len(samples)//2;tail=target_samples-leadframes-src_samples;assert tail>=0
 audio_chunks.extend([b'\0'*(leadframes*2),samples,b'\0'*(tail*2)])
 clip={'id':t['id'],'index':i,'start':startframe/FPS,'end':(startframe+frames)/FPS,'frames':frames,'fps':FPS,'audio_start':startframe/FPS+leadframes/now[2],'audio_duration':duration,'lead_silence':leadframes/now[2],'tail_silence':tail/now[2],'source_start':s['start'],'source_end':s['end'],'title_zh':([draft['intro'],*draft['stages'],draft['outro']][i])['title_zh'],'wav_sha256':hashlib.file_digest(p.open('rb'),'sha256').hexdigest(),'captions':[]}
 if 1<=i<=15:clip.update(stage_id=stages['stages'][i-1]['id'],source_mesh_occurrences=stages['stages'][i-1]['source_mesh_count'] if 'source_mesh_count' in stages['stages'][i-1] else len(stages['stages'][i-1]['mesh_source_paths']),source_mesh_paths=stages['stages'][i-1]['mesh_source_paths'])
 last_caption_end=0.0
 for sub in t.get('subtitle_sentences') or []:
  a=sub.get('start',sub.get('start_seconds'));b=sub.get('end',sub.get('end_seconds'));text=sub.get('target_text',sub.get('text',sub.get('text_zh')))
  if a is not None and b is not None and text:
   assert 0<=float(a)<float(b)<=duration+.1,(t['id'],sub)
   assert float(a)>=last_caption_end-1e-6,('Overlapping acoustic captions',t['id'],sub)
   last_caption_end=float(b)
   clip['captions'].append({'start':clip['audio_start']+float(a),'end':min(clip['end'],clip['audio_start']+float(b)),'text':text,'timing_kind':'independent acoustic ASR + actual PCM offset'})
 # Important close-ups follow observed words/sentences. The recorded CAD
 # motions remain the source picture; only their screen-time spacing changes.
 anchors=[];lead=clip['lead_silence']
 if t['id']=='stage08':
  second=next(r for r in t['subtitle_sentences'] if r['target_text'].startswith('两者之间'))
  anchors=[(lead+float(second['start']),.615,'second sentence acoustic onset: spacer')]
 elif t['id']=='stage09':
  anchors=[(lead+acoustic_word_start(t,'一起看'),.615,'observed words 一起看: four side groups together')]
 elif t['id']=='stage15':
  last=next(r for r in t['subtitle_sentences'] if r['target_text'].startswith('辅助件是否'))
  anchors=[(max(1.5,lead+acoustic_word_start(t,'连接件',('连接键',))),.615,'observed connecting-link words (ASR 件/键 homophones), minimum1.5s return view'),(lead+float(last['start']),.815,'last sentence acoustic onset: source auxiliary plug')]
 mapping=[{'frame':0,'source_fraction':0.0,'basis':'chapter start'}]
 for when,fraction,basis in anchors:
  frame=round(when*FPS);assert mapping[-1]['frame']<frame<frames,(t['id'],frame,frames)
  mapping.append({'frame':frame,'source_fraction':fraction,'basis':basis})
 mapping.append({'frame':frames,'source_fraction':1.0,'basis':'chapter end and retained inspection pause'})
 clip['visual_mapping']=mapping
 clips.append(clip);startframe+=frames
final={'schema_version':1,'duration':startframe/FPS,'frames':startframe,'fps':FPS,'audio_engine':manifest['engine'],'audio_speed_modified':False,'video_timing':'Recorded CAD picture retimed to actual audio duration; stage08/09/15 close-ups anchored to independently observed speech spans. Audio PCM speed and sample count unchanged.','captions_status':'all actual acoustic subtitles present' if all(c['captions'] for c in clips) else 'pending acoustic subtitle rows','clips':clips}
(HERE/'final-timeline.json').write_text(json.dumps(final,ensure_ascii=False,indent=2)+'\n')
if '--plan-only' in sys.argv:print(json.dumps({'duration':final['duration'],'frames':final['frames'],'captions':final['captions_status']}));raise SystemExit()
assert all(c['captions'] for c in clips),'Wait for acoustic subtitles; do not approximate timing by character count.'
with wave.open(str(OUT/'逐步虚拟归位旁白.wav'),'wb') as f:f.setnchannels(params[0]);f.setsampwidth(params[1]);f.setframerate(params[2]);f.writeframes(b''.join(audio_chunks))
parts=HERE/'retimed';parts.mkdir(exist_ok=True);commands=[]
def run(args):
 r=subprocess.run(args,capture_output=True,text=True);commands.append({'command':args,'exit_code':r.returncode,'stderr_tail':r.stderr[-1500:]});(HERE/'mux-commands.json').write_text(json.dumps(commands,ensure_ascii=False,indent=2)+'\n');assert r.returncode==0,r.stderr[-2000:]
def check_video(path,frames,require_audio=False):
 probe=subprocess.run(['ffprobe','-v','error','-count_frames','-show_entries','stream=codec_type,nb_read_frames,width,height,duration,sample_rate,channels','-of','json',str(path)],capture_output=True,text=True,check=True)
 streams=json.loads(probe.stdout)['streams'];video=next(s for s in streams if s['codec_type']=='video')
 assert int(video['nb_read_frames'])==frames and video['width']==1280 and video['height']==720,('Video dimensions/frame mismatch',str(path),video,frames)
 assert abs(float(video['duration'])-frames/FPS)<.00001,('Video timestamp duration mismatch',str(path),video,frames/FPS)
 if require_audio:
  audio=next(s for s in streams if s['codec_type']=='audio')
  assert int(audio['sample_rate'])==24000 and audio['channels']==1,('Audio format mismatch',audio)
  assert abs(float(audio['duration'])-frames/FPS)<1024/24000+.01,('Audio duration mismatch',audio,frames/FPS)
 return streams
for c in clips:
 dest=parts/(c['id']+'.mp4');source_a=math.ceil(c['source_start']*FPS);source_b=math.ceil(c['source_end']*FPS);original=captured_by_id[c['id']];assert original['frames']==source_b-source_a;source_path=Path(original['path']);assert hashlib.file_digest(source_path.open('rb'),'sha256').hexdigest()==original['sha256'];srclen=original['frames']/FPS;ratio=(c['frames']/FPS)/srclen
 mapping=c['visual_mapping']
 if len(mapping)==2:
  filters=['-vf',f'setpts={ratio:.12f}*(PTS-STARTPTS),tpad=stop_mode=clone:stop_duration=0.2,fps=30']
 else:
  segments=len(mapping)-1;graph='[0:v]split='+str(segments)+''.join(f'[s{j}]' for j in range(segments))+';';labels=[]
  for j,(left,right) in enumerate(zip(mapping,mapping[1:])):
   first=round(left['source_fraction']*original['frames']);end=round(right['source_fraction']*original['frames']);count=right['frame']-left['frame'];assert end>first and count>0
   graph+=f'[s{j}]trim=start_frame={first}:end_frame={end},setpts={count/(end-first):.12f}*(PTS-STARTPTS),tpad=stop_mode=clone:stop_duration=0.2,fps=30,trim=end_frame={count},setpts=PTS-STARTPTS[p{j}];';labels.append(f'[p{j}]')
  graph+=''.join(labels)+f'concat=n={segments}:v=1:a=0[outv]';filters=['-filter_complex',graph,'-map','[outv]']
 run(['ffmpeg','-y','-v','error','-i',str(source_path),'-an',*filters,'-frames:v',str(c['frames']),'-r',str(FPS),'-fps_mode','cfr','-c:v','libx264','-preset','veryfast','-crf','16','-pix_fmt','yuv420p','-video_track_timescale','15360',str(dest)])
 check_video(dest,c['frames'])
 concat=''.join("file '"+str((parts/(c['id']+'.mp4')).resolve())+"'\n" for c in clips);(parts/'concat.txt').write_text(concat)
# Standalone subtitle files use acoustic timings, not text length.
def srtstamp(t):
 ms=round(t*1000);return f'{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02},{ms%1000:03}'
def assstamp(t):
 cs=round(t*100);return f'{cs//360000:01}:{cs//6000%60:02}:{cs//100%60:02}.{cs%100:02}'
subs=[r for c in clips for r in c['captions']];(OUT/'逐步虚拟归位.srt').write_text('\n\n'.join(f"{i+1}\n{srtstamp(r['start'])} --> {srtstamp(r['end'])}\n{r['text']}" for i,r in enumerate(subs))+'\n',encoding='utf-8')
ass='''[Script Info]\nScriptType: v4.00+\nPlayResX: 1280\nPlayResY: 720\nWrapStyle: 0\nScaledBorderAndShadow: yes\n[V4+ Styles]\nFormat: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding\nStyle: Default,PingFang SC,30,&H00343D2F,&H00343D2F,&H00F3F2EE,&H00F3F2EE,0,0,0,0,100,100,0,0,3,2,0,2,64,420,42,1\n[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n'''
for r in subs:ass+=f"Dialogue: 0,{assstamp(r['start'])},{assstamp(r['end'])},Default,,0,0,0,,{r['text'].replace(chr(10),r'\N')}\n"
(HERE/'captions.ass').write_text(ass,encoding='utf-8')
run(['ffmpeg','-y','-v','error','-f','concat','-safe','0','-i',str(parts/'concat.txt'),'-i',str(OUT/'逐步虚拟归位旁白.wav'),'-map','0:v','-map','1:a','-vf','ass='+str(HERE/'captions.ass'),'-r',str(FPS),'-fps_mode','cfr','-c:v','libx264','-preset','veryfast','-crf','16','-pix_fmt','yuv420p','-video_track_timescale','15360','-c:a','aac','-b:a','192k','-t',str(final['duration']),'-movflags','+faststart',str(OUT/'逐步虚拟归位讲解.mp4')])
actual_streams=check_video(OUT/'逐步虚拟归位讲解.mp4',final['frames'],require_audio=True)
run(['ffmpeg','-v','error','-xerror','-err_detect','explode','-i',str(OUT/'逐步虚拟归位讲解.mp4'),'-f','null','-'])
(HERE/'final-stream-check.json').write_text(json.dumps({'frames':final['frames'],'duration':final['duration'],'streams':actual_streams,'strict_decode_passed':True},ensure_ascii=False,indent=2)+'\n')
run(['ffmpeg','-y','-v','error','-i',str(OUT/'逐步虚拟归位旁白.wav'),'-c:a','libmp3lame','-b:a','160k',str(OUT/'逐步虚拟归位旁白.mp3')])
(VIRT/'逐段时间表.json').write_text(json.dumps(final,ensure_ascii=False,indent=2)+'\n')
with (VIRT/'逐段时间表.csv').open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.DictWriter(f,fieldnames=['id','title_zh','start','end','audio_start','audio_duration','source_mesh_occurrences'],extrasaction='ignore');w.writeheader();w.writerows(clips)
print(json.dumps({'movie':str(OUT/'逐步虚拟归位讲解.mp4'),'duration':final['duration'],'frames':final['frames'],'subtitles':len(subs)},ensure_ascii=False))
