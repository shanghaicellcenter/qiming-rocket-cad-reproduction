"""Independent read-only comparison of a downloaded CAD source and a rebuilt film.

Run in a fresh Blender process after the downloaded builder and verifier.
This audit does not save either .blend, render a movie, or import skill helpers.
"""
import argparse
import hashlib
import json
import sys
from pathlib import Path

import bpy
import numpy as np


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(8 * 1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def bulk_digest(collection, prop, width, dtype):
    values = np.empty(len(collection) * width, dtype=dtype)
    collection.foreach_get(prop, values)
    return hashlib.sha256(values.tobytes()).hexdigest()


def mesh_record(mesh):
    # Actual geometry and topology arrays, rather than a name/count-only test.
    result = {
        'vertices': len(mesh.vertices), 'edges': len(mesh.edges),
        'loops': len(mesh.loops), 'polygons': len(mesh.polygons),
        'vertex_coordinates_sha256': bulk_digest(mesh.vertices, 'co', 3, np.float32),
        'edge_vertex_indices_sha256': bulk_digest(mesh.edges, 'vertices', 2, np.int32),
        'loop_vertex_indices_sha256': bulk_digest(mesh.loops, 'vertex_index', 1, np.int32),
        'polygon_loop_start_sha256': bulk_digest(mesh.polygons, 'loop_start', 1, np.int32),
        'polygon_loop_total_sha256': bulk_digest(mesh.polygons, 'loop_total', 1, np.int32),
        'polygon_material_indices_sha256': bulk_digest(mesh.polygons, 'material_index', 1, np.int32),
        'polygon_smooth_flags_sha256': bulk_digest(mesh.polygons, 'use_smooth', 1, np.bool_),
        'material_slots': [m.name if m else None for m in mesh.materials],
        'uv_layers': [],
    }
    for layer in mesh.uv_layers:
        result['uv_layers'].append({
            'name': layer.name,
            'uv_sha256': bulk_digest(layer.data, 'uv', 2, np.float32),
        })
    return result


def source_objects(scene):
    rows = [o for o in scene.objects if o.get('source_usd_path')]
    result = {o['source_usd_path']: o for o in rows}
    assert len(rows) == len(result) == 1980
    assert sum(o.type == 'MESH' for o in rows) == 688
    assert sum(len(o.data.polygons) for o in rows if o.type == 'MESH') == 2864600
    return result


def activate(scene, frame, show_hidden=None):
    bpy.context.window.scene = scene
    if show_hidden is not None:
        scene['QC_SHOW_SOURCE_HIDDEN'] = show_hidden
        scene.update_tag()
    scene.frame_set(frame)
    bpy.context.view_layer.update()


def matrix(obj, name):
    return np.asarray(getattr(obj, name), dtype=np.float64).copy()


def scene_record(scene):
    objects = source_objects(scene)
    for obj in objects.values():
        obj.hide_viewport = False
    activate(scene, 1)
    result = {}
    for path, obj in objects.items():
        result[path] = {
            'type': obj.type,
            'parent_path': obj.parent.get('source_usd_path') if obj.parent else None,
            'source_hidden': bool(obj.get('source_hidden', False)),
            'matrices': {k: matrix(obj, k) for k in
                         ('matrix_local', 'matrix_world', 'matrix_basis', 'matrix_parent_inverse')},
            'mesh': mesh_record(obj.data) if obj.type == 'MESH' else None,
        }
    return result


def matrix_error(obj, expected, key):
    return float(np.abs(matrix(obj, key) - expected['matrices'][key]).max())


def external_resources():
    return {
        'libraries': [x.filepath for x in bpy.data.libraries],
        'unpacked_images': [x.filepath for x in bpy.data.images
                            if x.source == 'FILE' and not x.packed_file and x.filepath],
        'unpacked_external_fonts': [x.filepath for x in bpy.data.fonts
                                   if x.filepath not in ('', '<builtin>') and not x.packed_file],
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--report', type=Path, required=True)
    args = parser.parse_args(sys.argv[sys.argv.index('--') + 1:])
    root = args.root.resolve()
    assert bpy.app.version >= (5, 2, 2), bpy.app.version_string
    source = root / 'outputs/启明火箭/assembly/vehicle-browse.blend'
    rebuilt = root / 'rebuilt/virtual-assembly/virtual-assembly.blend'
    plan_path = root / 'rebuild/virtual-assembly/assembly-stages.json'
    plan = json.loads(plan_path.read_text())
    assert len(plan['stages']) == plan['stage_count'] == 15
    assert Path(plan['source_blend']).resolve() == source
    usd = root / 'outputs/启明火箭/native-cad/vehicle-browse.usdc'
    assert Path(plan['source_usd']).resolve() == usd
    assert digest(usd) == plan['source_usd_sha256']
    hashes_before = {str(p.relative_to(root)): digest(p) for p in (source, rebuilt, usd)}

    bpy.ops.wm.open_mainfile(filepath=str(source), load_ui=False, use_scripts=False)
    baseline = scene_record(bpy.context.scene)
    baseline_resources = external_resources()
    assert not any(baseline_resources.values()), baseline_resources

    # Discard all Blender references before opening another main file.
    bpy.ops.wm.open_mainfile(filepath=str(rebuilt), load_ui=False, use_scripts=False)
    reference = bpy.data.scenes[plan['source_reference_scene']]
    animation = bpy.data.scenes[plan['animation_scene']]
    actual_reference = scene_record(reference)
    assert set(actual_reference) == set(baseline)
    for path, expected in baseline.items():
        actual = actual_reference[path]
        for key in ('type', 'parent_path', 'source_hidden', 'mesh'):
            assert actual[key] == expected[key], (path, key)
        for key in expected['matrices']:
            assert np.array_equal(actual['matrices'][key], expected['matrices'][key]), (path, key)

    refs = source_objects(reference)
    copies = source_objects(animation)
    assert set(copies) == set(baseline)
    assert all(copies[p].data is refs[p].data for p in copies if copies[p].type == 'MESH')
    groups = [p for stage in plan['stages'] for p in stage['mesh_source_paths']]
    mesh_paths = {p for p, obj in copies.items() if obj.type == 'MESH'}
    assert len(groups) == len(set(groups)) == 688 and set(groups) == mesh_paths
    assert all(not (o.animation_data and o.animation_data.action) for o in copies.values())

    stage_results = []
    for stage in plan['stages']:
        roots = stage['maximal_pure_source_roots']
        checked = set()
        for path in baseline:
            if any(path == r or path.startswith(r + '/') for r in roots):
                checked.add(path)
        for path in roots:
            parent = baseline[path]['parent_path']
            while parent:
                checked.add(parent)
                parent = baseline[parent]['parent_path']
        assert set(stage['mesh_source_paths']).issubset(checked)
        activate(animation, stage['end_frame'], True)
        errors = {key: max(matrix_error(copies[p], baseline[p], key) for p in checked)
                  for key in ('matrix_local', 'matrix_world', 'matrix_basis', 'matrix_parent_inverse')}
        assert all(v == 0 for v in errors.values()), (stage['id'], errors)
        stage_results.append({'id': stage['id'], 'frame': stage['end_frame'],
                              'checked_source_objects': len(checked), 'max_abs_errors': errors})

    activate(animation, plan['frame_end'], True)
    final_errors = {key: max(matrix_error(copies[p], baseline[p], key) for p in baseline)
                    for key in ('matrix_local', 'matrix_world', 'matrix_basis', 'matrix_parent_inverse')}
    assert all(v == 0 for v in final_errors.values()), final_errors
    activate(animation, plan['frame_end'], False)
    assert all(bool(o.hide_render) == bool(o.get('source_hidden', False)) for o in copies.values())
    assert sum(o.type == 'MESH' and o.hide_render for o in copies.values()) == 3
    rebuilt_resources = external_resources()
    assert not any(rebuilt_resources.values()), rebuilt_resources
    hashes_after = {str(p.relative_to(root)): digest(p) for p in (source, rebuilt, usd)}
    assert hashes_before == hashes_after
    summary = {
        'status': 'passed', 'blender_version': bpy.app.version_string,
        'source_objects_per_scene': 1980, 'mesh_occurrences_per_scene': 688,
        'polygons_per_scene': 2864600, 'stage_count': 15,
        'read_only_reopen_no_save': True, 'source_and_rebuilt_file_sha_unchanged': True,
        'input_source_geometry_arrays_exact_in_saved_reference': True,
        'input_source_parent_paths_and_matrices_exact_in_saved_reference': True,
        'animated_mesh_datablocks_shared_with_reference': True,
        'original_three_hidden_meshes_preserved': True,
        'final_max_abs_errors': final_errors, 'stage_end_checks': stage_results,
        'source_external_resources': baseline_resources,
        'rebuilt_external_resources': rebuilt_resources,
        'files_sha256': hashes_after,
        'scope': 'CAD representation and presentation animation; no physical assembly or operational solver.',
    }
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
    print('INDEPENDENT_SOURCE_COMPARE=' + json.dumps(summary, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
