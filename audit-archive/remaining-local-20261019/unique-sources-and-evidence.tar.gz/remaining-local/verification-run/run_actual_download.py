from pathlib import Path
import subprocess,json,hashlib,datetime,os,time
root=Path(__file__).resolve().parent;project=root/"project";reports=root/"reports";assets=root/"assets"
repo="shanghaicellcenter/qiming-rocket-cad-reproduction"
env=os.environ.copy();env["GODEBUG"]="http2client=0"
def run(args,cwd=root,log=None):
 start=time.monotonic()
 if log:
  with (reports/log).open("w") as f:subprocess.run(args,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
 else:subprocess.run(args,cwd=cwd,env=env,check=True)
 return time.monotonic()-start
def sha(p):
 h=hashlib.sha256()
 with p.open("rb") as f:
  while b:=f.read(4194304):h.update(b)
 return h.hexdigest()
r=json.loads(subprocess.check_output(["/opt/homebrew/bin/gh","api",f"repos/{repo}/releases/tags/v1.0.0"],env=env))
assert not r["draft"] and len(r["assets"])==10
assert subprocess.check_output(["git","rev-parse","HEAD"],cwd=project,text=True).strip()=="82c2a2a255b66556cead58ec3444f81f1757ae68"
assert not list(assets.iterdir()),"Fresh download directory required, no copied upload files."
x={"started_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"repo":f"https://github.com/{repo}","release_url":r["html_url"],"release_id":r["id"],"tag":r["tag_name"],"public_published_release":True,"original_input_reads_os_denied_during_validation":True,"download_passed":False,"verify_passed":False,"restore_passed":False}
(reports/"public-release-api.json").write_text(json.dumps(r,ensure_ascii=False,indent=2)+"\n")
print("Actual published GitHub Release download starting",flush=True)
download_input=reports/"published-assets-aria2-input.txt"
lines=[]
for a in r["assets"]:
 assert a["digest"].startswith("sha256:") and a["browser_download_url"].startswith("https://github.com/"+repo+"/releases/download/v1.0.0/")
 lines += [a["browser_download_url"],"  out="+a["name"],"  checksum=sha-256="+a["digest"].split(":",1)[1]]
download_input.write_text("\n".join(lines)+"\n")
for upper,lower in [("HTTPS_PROXY","https_proxy"),("HTTP_PROXY","http_proxy"),("ALL_PROXY","all_proxy")]:
 if upper in env and lower not in env:env[lower]=env[upper]
x["download_method"]="Anonymous published browser_download_url with installed aria2 parallel byte ranges; GitHub API SHA256 for every asset. No upload staging copy."
x["download_seconds"]=run(["/opt/homebrew/bin/aria2c","--no-conf=true","--input-file="+str(download_input),"--dir="+str(assets),"--max-concurrent-downloads=4","--split=8","--max-connection-per-server=8","--min-split-size=8M","--file-allocation=none","--allow-overwrite=false","--auto-file-renaming=false","--check-integrity=true","--max-tries=5","--retry-wait=3","--connect-timeout=15","--timeout=60","--summary-interval=10","--show-console-readout=false","--console-log-level=warn"],log="actual-anonymous-range-download.log")
actual={p.name:p for p in assets.iterdir() if p.is_file()};assert set(actual)=={a["name"] for a in r["assets"]}
rows=[]
for a in r["assets"]:
 p=actual[a["name"]];h=sha(p);assert p.stat().st_size==a["size"] and "sha256:"+h==a["digest"],a["name"];rows.append({"name":a["name"],"bytes":p.stat().st_size,"sha256":h,"github_asset_id":a["id"],"passed":True})
x.update({"download_passed":True,"actual_network_release_download":True,"assets":rows,"all10_github_api_size_digest_passed":True});(reports/"actual-download-receipt.json").write_text(json.dumps(x,ensure_ascii=False,indent=2)+"\n");print("Actual10 downloaded asset hashes passed; extraction/verification starting",flush=True)
prefix=["/usr/bin/sandbox-exec","-f",str(root/"deny-original-inputs.sb"),"python3"]
x["verify_seconds"]=run(prefix+[str(project/"verify_release.py"),"--asset-dir",str(assets),"--root",str(project),"--extract"],cwd=project,log="downloaded-extract-verify.log")
v=json.loads((project/"download-integrity-check.json").read_text());assert v["passed"] and v["file_count"]==3829 and v["original_392_sha256_passed"];x["verify_passed"]=True;x["payload_verification"]=v
(reports/"actual-download-receipt.json").write_text(json.dumps(x,ensure_ascii=False,indent=2)+"\n");print("Actual3829 payload and392 source hashes passed; local full voice restoration starting",flush=True)
x["restore_seconds"]=run(prefix+[str(project/"restore_local.py"),"--root",str(project),"--destination",str(root/"restored-lecture"),"--noncommercial-research"],cwd=project,log="downloaded-restore.log")
x["restore_passed"]=True;x["finished_utc"]=datetime.datetime.now(datetime.timezone.utc).isoformat();(reports/"actual-download-receipt.json").write_text(json.dumps(x,ensure_ascii=False,indent=2)+"\n");print("Actual published download, payload identity, and full local voice restoration passed",flush=True)
