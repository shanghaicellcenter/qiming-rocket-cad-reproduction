"""Own serial client for the existing queued FireRed service. No server/model changes."""
from pathlib import Path
import os,sys,json,time,datetime,hashlib,wave,re,shutil,fcntl,urllib.request
sys.dont_write_bytecode=True
for key in ['HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','http_proxy','https_proxy','all_proxy']:os.environ.pop(key,None)
os.environ['NO_PROXY']='127.0.0.1,localhost'
from gradio_client import Client,handle_file
TASK=Path('/home/qianqiming/codex-mojave-assembly-voice-20261019');RUN=TASK/'firered'
CONFIG=json.loads((RUN/'config.json').read_text());jobs=json.loads((TASK/'formal-jobs.json').read_text())
OTHER=Path('/home/qianqiming/work/drama-3/rocket-v2-20261019-tts/firered-v2-954ac5917585-20261019T145826Z/status.json')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(p,d):
    p.parent.mkdir(parents=True,exist_ok=True);t=p.with_suffix(p.suffix+'.tmp');t.write_text(json.dumps(d,ensure_ascii=False,indent=2));t.replace(p)
def mem():return next(int(l.split()[1])/2**20 for l in Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:'))
def wait_turn():
    started=time.monotonic()
    while True:
        other=json.loads(OTHER.read_text()) if OTHER.exists() else {}
        q=json.load(urllib.request.urlopen('http://127.0.0.1:7860/gradio_api/queue/status',timeout=10))
        active=other.get('stage') in ['tts','waiting_for_available_memory']
        if not active and q.get('queue_size',0)==0 and mem()>8:return
        save(RUN/'status.json',{'state':'waiting_for_other_queue_or_memory','other_tts_stage':other.get('stage'),'queue_size':q.get('queue_size'),'available_GiB':mem(),'checked_at':now(),'only_own_client_waiting':True})
        if time.monotonic()-started>1800:raise RuntimeError('Own client waited over30 minutes; no service changed')
        time.sleep(10)
lock=(RUN/'writer.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
reference=Path(CONFIG['reference_audio']);assert sha(reference)==CONFIG['reference_sha256'];assert len(jobs)==17
client=Client('http://127.0.0.1:7860',verbose=False);results=[];began=time.monotonic()
try:
    for job in jobs:
        ident=job['id'];assert re.fullmatch(r'intro|outro|stage(?:0[1-9]|1[0-5])',ident);folder=RUN/'tracks'/ident;folder.mkdir(parents=True,exist_ok=True)
        units=[s.strip() for s in re.findall(r'[^。！？]+[。！？]?',job['text']) if s.strip()];assert ''.join(units)==job['text'].strip()
        records=[];frames=[];params0=None;cursor=0
        for index,text in enumerate(units,1):
            dest=folder/f'unit-{index:02d}.wav';meta=folder/f'unit-{index:02d}.json'
            if dest.exists() and meta.exists():
                record=json.loads(meta.read_text());assert record['text']==text and record['audio_sha256']==sha(dest)
            else:
                wait_turn();save(RUN/'status.json',{'state':'generating','id':ident,'unit':index,'units':len(units),'completed_tracks':len(results),'checked_at':now()});start=time.monotonic()
                generated=client.predict(language='Chinese',text=text,prompt_audio=handle_file(str(reference)),prompt_text=CONFIG['reference_text'],frontend='none',api_url='',api_key='',api_model='',seed=1234,cfg=2.0,api_name='/generate')
                assert isinstance(generated,str);assert not dest.exists();shutil.copy2(generated,dest)
                record={'index':index,'text':text,'audio_sha256':sha(dest),'generation_seconds':time.monotonic()-start,'engine':'FireRedTTS3 existing local queued service','frontend':'none','external_llm_used':False,'api_external_fields_empty':True,'reference_sha256':CONFIG['reference_sha256'],'seed':1234,'cfg':2.0,'scope':'API completion is not EOS, ASR, or perceptual acceptance'}
            with wave.open(str(dest)) as f:params=f.getparams();data=f.readframes(params.nframes)
            assert params.nchannels==1 and params.sampwidth==2
            if params0 is None:params0=params
            assert (params.nchannels,params.sampwidth,params.framerate)==(params0.nchannels,params0.sampwidth,params0.framerate)
            duration=params.nframes/params.framerate;record.update({'file':str(dest),'start_seconds':cursor/params.framerate,'end_seconds':(cursor+params.nframes)/params.framerate,'duration_seconds':duration,'timing_kind':'actual generated PCM boundary, independent acoustic ASR pending'});save(meta,record);records.append(record);frames.append(data);cursor+=params.nframes
            if index<len(units):cursor+=round(.18*params.framerate)
        target=folder/'voice.wav'
        if not target.exists():
            with wave.open(str(target),'wb') as f:
                f.setparams(params0);silence=b'\0'*round(.18*params0.framerate)*params0.nchannels*params0.sampwidth
                for i,data in enumerate(frames):
                    if i:f.writeframes(silence)
                    f.writeframes(data)
        with wave.open(str(target)) as f:duration=f.getnframes()/f.getframerate();sr=f.getframerate()
        result={'id':ident,'text':job['text'],'audio':str(target),'audio_sha256':sha(target),'duration_seconds':duration,'sample_rate':sr,'engine':'FireRedTTS3 existing local queued service','units':records,'inter_unit_pause_seconds':.18,'speed_or_pitch_modified':False,'reference_sha256':CONFIG['reference_sha256'],'status':'generated; independent ASR and actual listening pending','actual_listening':'pending parent perceptual review'}
        save(folder/'result.json',result);results.append(result);save(RUN/'results.json',results);print(json.dumps({'id':ident,'duration_seconds':duration,'completed_tracks':len(results)},ensure_ascii=False),flush=True)
    save(RUN/'status.json',{'state':'generation_finished_pending_asr_and_listening','tracks':17,'elapsed_seconds':time.monotonic()-began,'checked_at':now(),'no_service_or_other_project_changed':True})
except Exception as e:
    save(RUN/'status.json',{'state':'failed','error':str(e),'checked_at':now(),'no_service_or_other_project_changed':True});raise
