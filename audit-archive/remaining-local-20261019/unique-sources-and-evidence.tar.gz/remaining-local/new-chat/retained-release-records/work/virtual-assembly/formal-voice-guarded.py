"""One finite, guarded model load for 17 approved narrations and targeted retries.
No HTTP service; no writes to the other project's directory or queue.
"""
import argparse,fcntl,hashlib,json,os,re,signal,subprocess,sys,time
from pathlib import Path
TASK=Path('/home/qianqiming/codex-mojave-assembly-voice-20261019')
RUNTIME=Path('/home/qianqiming/work/drama-3');SOURCE=RUNTIME/'fish-speech'
CHECKPOINT=Path('/home/qianqiming/models/fishaudio/drama-3');REFERENCE=RUNTIME/'test-output/codes_0.npy'
REFERENCE_TEXT='你好，欢迎收听中文语音测试。今天的天气很好，我们一起出去走走吧。';GIB=1024**3
def save(p,d):
    p.parent.mkdir(parents=True,exist_ok=True);temp=p.with_suffix(p.suffix+'.tmp');temp.write_text(json.dumps(d,ensure_ascii=False,indent=2));temp.replace(p)
def available():return int(dict(x.split(':',1) for x in Path('/proc/meminfo').read_text().splitlines())['MemAvailable'].split()[0])*1024
def setup():
    inc=RUNTIME/'.deps/python-dev/usr/include';os.environ['CPATH']=':'.join([str(inc/'python3.12'),str(inc),os.environ.get('CPATH','')]).rstrip(':')
    for k,v in {'FISH_DRAMA3_FP8_EXPERTS':'1','FISH_DRAMA3_CUDA_GRAPH':'0','TOKENIZERS_PARALLELISM':'false','PYTHONDONTWRITEBYTECODE':'1','HF_HUB_OFFLINE':'1','TRANSFORMERS_OFFLINE':'1','MPLCONFIGDIR':str(TASK/'cache/matplotlib'),'NUMBA_CACHE_DIR':str(TASK/'cache/numba'),'TRITON_CACHE_DIR':str(TASK/'cache/triton'),'TORCHINDUCTOR_CACHE_DIR':str(TASK/'cache/torchinductor')}.items():os.environ[k]=v
    sys.path.insert(0,str(SOURCE))
def worker():
    setup()
    import numpy as np,soundfile as sf,torch
    from loguru import logger
    from fish_speech.models.text2semantic.inference import init_model,load_codec_model,generate_long,decode_to_audio
    jobs=json.loads((TASK/'formal-jobs.json').read_text());assert len(jobs)==17
    reference=torch.from_numpy(np.load(REFERENCE));model,decode=init_model(CHECKPOINT,'cuda:0',torch.bfloat16,compile=False);codec=load_codec_model(CHECKPOINT/'codec.pth',str(model.device),model.dtype)
    def run(job,attempt=1,seed=42):
        ident=job['id'];assert re.fullmatch(r'intro|outro|stage(?:0[1-9]|1[0-5])',ident)
        folder=TASK/'formal'/ident/f'attempt-{attempt:02d}';folder.mkdir(parents=True,exist_ok=True)
        save(TASK/'formal-status.json',{'state':'generating','id':ident,'attempt':attempt,'pid':os.getpid()})
        log=folder/'generation.log';sink=logger.add(log,mode='w',format='{time} | {level} | {message}');started=time.monotonic();codes=[]
        try:
            torch.manual_seed(seed);torch.cuda.manual_seed_all(seed)
            for response in generate_long(model=model,device='cuda:0',decode_one_token=decode,text=job['text'],num_samples=1,max_new_tokens=1024,top_p=.7,top_k=30,temperature=.7,compile=False,iterative_prompt=True,chunk_length=200,single_chunk=True,prompt_text=[REFERENCE_TEXT],prompt_tokens=[reference]):
                if response.action=='sample':codes.append(response.codes)
            assert codes,'No audio codes';merged=torch.cat(codes,dim=1);np.save(folder/'codes.npy',merged.cpu().numpy());audio=decode_to_audio(merged.to(model.device),codec).cpu().float().numpy();assert audio.size and np.isfinite(audio).all()
            target=folder/'voice.wav';sf.write(target,audio,codec.sample_rate,subtype='PCM_16');reasons=re.findall(r'finish=([a-z_]+)',log.read_text());eos=bool(reasons) and all(r=='eos' for r in reasons)
            result={'id':ident,'text':job['text'],'attempt':attempt,'seed':seed,'status':'generated_pending_asr_and_listening','audio':str(target),'audio_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'sample_rate':codec.sample_rate,'duration_seconds':len(audio)/codec.sample_rate,'finish_reasons':reasons,'eos':eos,'finite':True,'peak':float(np.max(np.abs(audio))),'rms':float(np.sqrt(np.mean(audio**2))),'inference_seconds':time.monotonic()-started,'speed_or_pitch_modified':False,'pause_policy':'model-generated natural pauses retained; no character-derived timing','reference_sha256':hashlib.sha256(REFERENCE.read_bytes()).hexdigest(),'actual_listening':'pending parent perceptual review'}
        except Exception as e:result={'id':ident,'text':job['text'],'attempt':attempt,'status':'failed','error':str(e)}
        finally:logger.remove(sink)
        save(folder/'result.json',result);print(json.dumps(result,ensure_ascii=False),flush=True)
    for job in jobs:run(job)
    save(TASK/'formal-status.json',{'state':'awaiting_independent_asr_or_targeted_retry','pid':os.getpid(),'initial_tracks':17});idle=time.monotonic()
    # A bounded retry window keeps the same model available, avoiding another model copy.
    requests=TASK/'retry-requests';requests.mkdir(exist_ok=True)
    while not (TASK/'FINISH_FORMAL').exists() and time.monotonic()-idle<1200:
        pending=sorted(p for p in requests.glob('*.json') if not p.with_suffix('.done').exists())
        for p in pending:
            r=json.loads(p.read_text());job=next(j for j in jobs if j['id']==r['id']);run(job,r['attempt'],r.get('seed',43));p.with_suffix('.done').write_text('done');idle=time.monotonic()
        time.sleep(1)
    save(TASK/'formal-status.json',{'state':'stopped','pid':os.getpid(),'reason':'checks complete' if (TASK/'FINISH_FORMAL').exists() else '20 minute retry window elapsed'})
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--worker',action='store_true');args=ap.parse_args()
    if args.worker:return worker()
    lock=(TASK/'formal.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);before=available();assert before>=48.87562012672424*GIB,'Insufficient memory for one guarded model load'
    active=[]
    for l in subprocess.run(['ps','-eo','pid,comm,args'],capture_output=True,text=True,check=True).stdout.splitlines():
        b=l.split(None,2)
        if len(b)==3 and b[1].startswith('python') and any(t in b[2] for t in ['resident_drama3_guarded.py','batch_drama3_guarded.py','voice-sample-guarded.py --worker','formal-voice-guarded.py --worker']):active.append(int(b[0]))
    assert not active,'Another Drama3 voice worker exists; no second model load'
    setup();minimum=before;start=time.monotonic();reason=None
    with (TASK/'formal-worker.log').open('w') as log:
        child=subprocess.Popen([sys.executable,str(Path(__file__).resolve()),'--worker'],cwd=TASK,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        while child.poll() is None:
            minimum=min(minimum,available())
            if minimum<8*GIB:reason='Available memory below 8 GiB'
            elif time.monotonic()-start>3600:reason='Own finite batch reached one-hour guard'
            if reason:
                os.killpg(child.pid,signal.SIGTERM)
                try:child.wait(timeout=15)
                except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL)
                break
            time.sleep(2)
        code=child.wait()
    save(TASK/'formal-guard-result.json',{'exit_code':code,'reason':reason,'minimum_available_GiB':minimum/GIB,'elapsed_seconds':time.monotonic()-start,'single_model_load':True,'other_services_or_projects_changed':False})
    if code or reason:raise SystemExit(1)
if __name__=='__main__':main()
