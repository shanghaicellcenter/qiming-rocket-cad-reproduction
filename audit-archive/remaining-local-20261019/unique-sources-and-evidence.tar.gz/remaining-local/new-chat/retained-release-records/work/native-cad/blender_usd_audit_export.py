"""Source-only USD -> native Blender + GLB visualization conversion.

No model parts, geometry repairs, simplification, inferred internals, physical
solver, or operational information are generated. USD hierarchy/mesh instances
remain intact. Render studio objects are outside the exported source geometry.
Run in a factory Blender 5.2 background session, passing one explicit USD.
"""
import argparse,hashlib,json,math,struct,sys,time
from pathlib import Path
import bpy,numpy as np
from mathutils import Matrix,Vector,Quaternion
from pxr import Usd,UsdGeom

argv=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else []
ap=argparse.ArgumentParser()
ap.add_argument('--usd',required=True)
ap.add_argument('--out-dir',required=True)
ap.add_argument('--name',required=True)
ap.add_argument('--name-map')
ap.add_argument('--source-cad-name')
ap.add_argument('--source-cad-sha256')
ap.add_argument('--render',action='store_true')
ap.add_argument('--samples',type=int,default=24)
args=ap.parse_args(argv)
USD=Path(args.usd).resolve();OUT=Path(args.out_dir).resolve();OUT.mkdir(parents=True,exist_ok=True)
NAME=args.name
started=time.time()
def log(phase,**kw):print('CAD_PROGRESS='+json.dumps({'phase':phase,**kw},ensure_ascii=False),flush=True)
def hfile(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
    return h.hexdigest()
def matrix(m):return [[float(v) for v in row] for row in m]
def extent(points):
    if not len(points):return None
    return {'min':points.min(axis=0).tolist(),'max':points.max(axis=0).tolist(),
            'size':(points.max(axis=0)-points.min(axis=0)).tolist()}
def bounds_merge(lo,hi,points):
    if len(points):lo[:]=np.minimum(lo,points.min(axis=0));hi[:]=np.maximum(hi,points.max(axis=0))
def bounds_dict(lo,hi):return {'min':lo.tolist(),'max':hi.tolist(),'size':(hi-lo).tolist()}
def get_blender_points(me):
    a=np.empty(len(me.vertices)*3,dtype=np.float32);me.vertices.foreach_get('co',a)
    return a.reshape(-1,3)
def harray(a):return hashlib.sha256(np.asarray(a).tobytes()).hexdigest()

stage=Usd.Stage.Open(str(USD))
if not stage:raise RuntimeError('USD stage could not be opened')
mpu=float(UsdGeom.GetStageMetersPerUnit(stage));up=str(UsdGeom.GetStageUpAxis(stage))
axis=np.eye(4,dtype=np.float64)
if up=='Y':axis=np.array([[1,0,0,0],[0,0,-1,0],[0,1,0,0],[0,0,0,1]],dtype=np.float64)
elif up!='Z':raise RuntimeError('Unsupported USD up axis; refusing guessed axis conversion: '+up)
cache=UsdGeom.XformCache(Usd.TimeCode.Default())
usdlo=np.full(3,np.inf);usdhi=np.full(3,-np.inf)
usd_records={};usd_meshes={};usd_geometry_cache={}
source_paths={}
if args.name_map:
    nm=json.loads(Path(args.name_map).read_text())
    for filename,paths in nm.get('file_to_prim_paths',{}).items():
        for path in paths:source_paths[path]=filename

# Traverse includes active invisible prims, while excluding inactive provider
# definitions that are not assembly occurrences. TraverseAll double-counts the
# converter's inactive geometry library and therefore is unsuitable for totals.
for prim in stage.Traverse():
    path=str(prim.GetPath())
    vis='inherited';authored_vis='inherited'
    if prim.IsA(UsdGeom.Imageable):
        img=UsdGeom.Imageable(prim)
        vis=str(img.ComputeVisibility())
        authored_vis=str(img.GetVisibilityAttr().Get() or 'inherited')
    rec={'path':path,'name':prim.GetName(),'display_name':prim.GetDisplayName(),
         'type':prim.GetTypeName(),'parent_path':str(prim.GetParent().GetPath()),
         'visibility':vis,'visibility_authored':authored_vis,
         'is_instance':prim.IsInstance(),'is_instanceable':prim.IsInstanceable(),
         'is_instance_proxy':prim.IsInstanceProxy(),
         'world_matrix_usd_row_vector':matrix(cache.GetLocalToWorldTransform(prim))}
    usd_records[path]=rec
    if not prim.IsA(UsdGeom.Mesh):continue
    mesh=UsdGeom.Mesh(prim)
    points=np.asarray(mesh.GetPointsAttr().Get(),dtype=np.float32).reshape(-1,3)
    counts=np.asarray(mesh.GetFaceVertexCountsAttr().Get(),dtype=np.int64)
    indices=np.asarray(mesh.GetFaceVertexIndicesAttr().Get(),dtype=np.int64)
    stack=mesh.GetPointsAttr().GetPropertyStack()
    provider=str(stack[0].path) if stack else path+'.points'
    rec.update({'points':len(points),'faces':len(counts),'triangles':int(np.maximum(counts-2,0).sum()),
      'face_vertices':len(indices),'point_attribute_provider_path':provider,
      'points_sha256':harray(points),'face_counts_sha256':harray(counts),
      'face_indices_sha256':harray(indices),'bbox_local_native':extent(points)})
    usd_meshes[path]=rec
    if provider not in usd_geometry_cache:
        usd_geometry_cache[provider]={'points':points,'counts':counts,'indices':indices}
    world=np.asarray(cache.GetLocalToWorldTransform(prim).GetTranspose(),dtype=np.float64)
    p=points@world[:3,:3].T+world[:3,3]
    p=p@axis[:3,:3].T
    bounds_merge(usdlo,usdhi,p)

if not usd_meshes:raise RuntimeError('USD has no mesh data; no export will be made')
usd_hash=hfile(USD)
audit={'source_usd':str(USD),'source_usd_sha256':usd_hash,'source_usd_bytes':USD.stat().st_size,
       'source_cad_name':args.source_cad_name,'source_cad_sha256':args.source_cad_sha256,
       'usd_meters_per_unit':mpu,'usd_unit_metadata_authored':stage.HasAuthoredMetadata('metersPerUnit'),
       'usd_up_axis':up,'usd_prim_count':len(usd_records),'usd_mesh_occurrences':len(usd_meshes),
       'usd_unique_point_providers':len(usd_geometry_cache),
       'usd_mesh_faces':sum(x['faces'] for x in usd_meshes.values()),
       'usd_mesh_triangles':sum(x['triangles'] for x in usd_meshes.values()),
       'usd_expected_blender_world_bbox_native':bounds_dict(usdlo,usdhi),
       'usd_meshes':list(usd_meshes.values()),'blender_version':bpy.app.version_string,
       'scope':'Source format conversion and visualization only; no geometry added, repaired, simplified or inferred.',
       'cad_fidelity_note':'CAD surface fidelity is limited by upstream tessellation. This audit checks USD mesh preservation, not analytic CAD equality.',
       'traversal_policy':'Active USD occurrences including invisible prims; inactive provider definitions are not counted again.'}
audit_path=OUT/(NAME+'.audit.json')
audit_path.write_text(json.dumps(audit,ensure_ascii=False,indent=2))
log('USD audited',meshes=len(usd_meshes),triangles=audit['usd_mesh_triangles'],units=mpu,up=up)

for o in list(bpy.data.objects):bpy.data.objects.remove(o,do_unlink=True)
hook_log={}
class SourceProvenanceUSDHook(bpy.types.USDHook):
    bl_idname='source_provenance_audit'
    bl_label='Original USD node provenance'
    @staticmethod
    def on_import(context):
        mapping=context.get_prim_map()
        hook_log['mapped_usd_paths']=len(mapping)
        for path,ids in mapping.items():
            for idblock in ids:
                try:idblock['source_usd_path']=str(path)
                except Exception:pass
        return True
bpy.utils.register_class(SourceProvenanceUSDHook)
before=set(bpy.data.objects)
settings={'filepath':str(USD),'scale':1.0,'set_frame_range':False,
 'import_cameras':False,'import_lights':False,'import_curves':True,'import_volumes':False,
 'import_shapes':True,'import_meshes':True,'import_skeletons':False,'import_blendshapes':False,
 'import_points':False,'import_materials':True,'import_subdivision':False,
 'support_scene_instancing':True,'import_visible_only':False,'create_collection':True,
 'read_mesh_uvs':True,'read_mesh_colors':True,'read_mesh_attributes':True,
 'import_guide':True,'import_proxy':True,'import_render':True,
 'import_usd_preview':True,'property_import_mode':'ALL','validate_meshes':False,
 'create_world_material':False,'import_defined_only':False,'merge_parent_xform':False,
 'apply_unit_conversion_scale':False}
result=bpy.ops.wm.usd_import(**settings)
if 'FINISHED' not in result:raise RuntimeError('Blender USD import did not finish')
source_objects=[o for o in bpy.data.objects if o not in before]
sc=bpy.context.scene;sc.name=NAME+'_Source_Original'
sc.unit_settings.system='METRIC';sc.unit_settings.scale_length=mpu
sc['source_usd_path']=str(USD);sc['source_usd_sha256']=usd_hash
sc['source_native_coordinates']=True;sc['source_metres_per_native_unit']=mpu
sc['no_geometry_repair_or_simplification']=True
sc['unit_note']='Mesh/local transforms retain USD-native units. UI scale uses declared USD metresPerUnit.'
audit['import_options']=settings;audit['hook']=hook_log
audit['blender_objects']=[]
verified_geometry=[]
for ob in source_objects:
    path=ob.get('source_usd_path')
    rec=usd_records.get(path,{})
    ob['source_import_name']=ob.name
    ob['source_identity_kind']='USD node; not automatically a physical part'
    ob['source_usd_name']=rec.get('name',ob.name)
    ob['source_usd_display_name']=rec.get('display_name','')
    ob['source_usd_visibility']=rec.get('visibility','unknown')
    ob['source_usd_visibility_authored']=rec.get('visibility_authored','unknown')
    ob['source_hidden']=rec.get('visibility')=='invisible'
    ob['source_usd_document_sha256']=usd_hash
    walk=path;sourcefile=None
    while walk and walk!='/':
        if walk in source_paths:sourcefile=source_paths[walk];break
        walk=walk.rsplit('/',1)[0]
    if not sourcefile and args.source_cad_name and not args.name_map:sourcefile=args.source_cad_name
    if sourcefile:
        ob['source_cad_filename']=sourcefile
        ob['source_cad_association']='Explicit single-document source' if not args.name_map else 'Supplied unique display-name to source-basename map; nearest ancestor'
    report={'name':ob.name,'type':ob.type,'source_usd_path':path,
      'source_usd_display_name':rec.get('display_name',''),
      'parent':ob.parent.name if ob.parent else None,
      'parent_source_usd_path':ob.parent.get('source_usd_path') if ob.parent else None,
      'matrix_local':matrix(ob.matrix_local),'matrix_world':matrix(ob.matrix_world),
      'source_usd_visibility':ob['source_usd_visibility'],'source_hidden':ob['source_hidden'],
      'blender_hide_render':ob.hide_render,'blender_hide_viewport':ob.hide_viewport,
      'blender_hide_set':ob.hide_get() if ob.name in bpy.context.view_layer.objects else None,
      'source_cad_filename':sourcefile,'instance_type':ob.instance_type,
      'instance_collection':ob.instance_collection.name if ob.instance_collection else None,
      'mesh_data':ob.data.name if ob.type=='MESH' else None}
    if ob.type=='MESH':
        me=ob.data;points=get_blender_points(me)
        me.calc_loop_triangles()
        report.update({'vertices':len(me.vertices),'faces':len(me.polygons),'triangles':len(me.loop_triangles),
                       'points_sha256':harray(points),'modifiers':[m.type for m in ob.modifiers]})
        ob['source_triangle_count']=len(me.loop_triangles)
        if path in usd_meshes:
            u=usd_meshes[path]
            report['usd_point_array_exact_match']=report['points_sha256']==u['points_sha256']
            report['usd_face_count_match']=len(me.polygons)==u['faces']
            report['usd_triangle_count_match']=len(me.loop_triangles)==u['triangles']
            ob['point_attribute_provider_path']=u['point_attribute_provider_path']
            ob['source_mesh_geometry_sha256']=report['points_sha256']
            verified_geometry.append(report['usd_point_array_exact_match'] and report['usd_face_count_match'] and report['usd_triangle_count_match'])
    audit['blender_objects'].append(report)

bpy.context.view_layer.update()
source_object_set=set(source_objects)
lo=np.full(3,np.inf);hi=np.full(3,-np.inf)
occurrence_count=0;occurrence_faces=0;occurrence_tris=0;instance_records=[]
dg=bpy.context.evaluated_depsgraph_get()
for inst in dg.object_instances:
    ob=inst.object.original
    if ob not in source_object_set or ob.type!='MESH':continue
    points=get_blender_points(ob.data).astype(np.float64)
    mw=np.asarray(inst.matrix_world,dtype=np.float64)
    bounds_merge(lo,hi,points@mw[:3,:3].T+mw[:3,3])
    occurrence_count+=1;occurrence_faces+=len(ob.data.polygons)
    ob.data.calc_loop_triangles();occurrence_tris+=len(ob.data.loop_triangles)
    instance_records.append({'object':ob.name,'source_usd_path':ob.get('source_usd_path'),
      'is_instance':inst.is_instance,'matrix_world':matrix(inst.matrix_world),
      'instance_parent':inst.parent.original.name if inst.parent else None})
if not occurrence_count:raise RuntimeError('Imported Blender scene has no mesh occurrences')
nativebbox=bounds_dict(lo,hi)
tolerance=max(1e-5,float(np.max(usdhi-usdlo))*1e-5)
bbox_error=float(max(np.abs(lo-usdlo).max(),np.abs(hi-usdhi).max()))
audit.update({'blender_source_object_count':len(source_objects),
  'blender_mesh_objects':sum(o.type=='MESH' for o in source_objects),
  'blender_unique_mesh_data':len(set(o.data for o in source_objects if o.type=='MESH')),
  'blender_mesh_occurrences_expanded':occurrence_count,'blender_occurrence_faces':occurrence_faces,
  'blender_occurrence_triangles':occurrence_tris,'blender_world_bbox_native':nativebbox,
  'blender_bbox_max_abs_error_native':bbox_error,'bbox_tolerance_native':tolerance,
  'all_mapped_geometry_point_arrays_exact_match':all(verified_geometry),
  'mapped_mesh_geometry_verified':len(verified_geometry),'source_instances':instance_records,
  'bbox_matches_usd':bbox_error<=tolerance,
  'mesh_occurrence_count_matches_usd':occurrence_count==len(usd_meshes),
  'source_face_count_matches_usd':occurrence_faces==audit['usd_mesh_faces'],
  'source_triangle_count_matches_usd':occurrence_tris==audit['usd_mesh_triangles']})
audit_path.write_text(json.dumps(audit,ensure_ascii=False,indent=2))
if bbox_error>tolerance:raise RuntimeError('USD/Blender world bounds differ; refusing unchecked export')
if not audit['source_triangle_count_matches_usd']:
    raise RuntimeError('USD/Blender triangle counts differ; refusing unchecked export')
log('Blender import audited',objects=len(source_objects),mesh_occurrences=occurrence_count,triangles=occurrence_tris,bbox_error=bbox_error)

audit_path.write_text(json.dumps(audit,ensure_ascii=False,indent=2))
native_blend=OUT/(NAME+'.blend')
notes=bpy.data.texts.new('README_SOURCE_ONLY_CONVERSION')
notes.write('Original converted USD hierarchy and mesh data. No inferred/reconstructed parts. Native USD units and transforms retained.\nGLB uses a separate documented unit-conversion parent; hidden source meshes remain accessible through visibility extras.\nCAD fidelity is limited by upstream tessellation. This file does not validate engineering, physical operation, constraints or manufacturing.\n')
bpy.context.preferences.filepaths.save_version=0
bpy.ops.wm.save_as_mainfile(filepath=str(native_blend),compress=True)

# Temporary GLB-only adaptor. Source local transforms/hierarchy are not baked.
# The native .blend above preserves source visibility and coordinates exactly.
roots=[o for o in source_objects if not o.parent and o.name in sc.objects]
states={o:(o.hide_viewport,o.hide_render,o.hide_get() if o.name in bpy.context.view_layer.objects else None) for o in source_objects}
colstates={c:(c.hide_viewport,c.hide_render) for c in bpy.data.collections}
root_states={o:(o.parent,o.matrix_basis.copy(),o.matrix_parent_inverse.copy()) for o in roots}
unitroot=bpy.data.objects.new('SOURCE_UNIT_TO_METRES_ADAPTOR',None);sc.collection.objects.link(unitroot)
unitroot.scale=(mpu,mpu,mpu)
unitroot['source_adaptor_only']=True
unitroot['native_units_to_metres']=mpu
unitroot['source_usd_document_sha256']=usd_hash
unitroot['source_note']='Only this parent converts units for glTF. Descendant source local transforms are preserved.'
gltf_options={'filepath':str(OUT/(NAME+'.glb')),'export_format':'GLB','use_selection':False,
 'use_visible':False,'use_renderable':False,'use_active_scene':True,
 'export_extras':True,'export_yup':True,'export_apply':False,'export_animations':False,
 'export_gpu_instances':False,'export_hierarchy_flatten_objs':False,
 'export_hierarchy_full_collections':False,
 'export_draco_mesh_compression_enable':False,'export_meshopt_compression_enable':False}
valid_props={p.identifier for p in bpy.ops.export_scene.gltf.get_rna_type().properties}
gltf_options={k:v for k,v in gltf_options.items() if k in valid_props}
try:
    for c in bpy.data.collections:c.hide_viewport=False;c.hide_render=False
    for o in source_objects:
        o.hide_viewport=False;o.hide_render=False
        if o.name in bpy.context.view_layer.objects:o.hide_set(False)
    for o in roots:o.parent=unitroot
    bpy.context.view_layer.update()
    bpy.ops.export_scene.gltf(**gltf_options)
finally:
    for o,(parent,basis,parent_inverse) in root_states.items():
        o.parent=parent;o.matrix_basis=basis;o.matrix_parent_inverse=parent_inverse
    bpy.data.objects.remove(unitroot,do_unlink=True)
    for c,(hv,hr) in colstates.items():c.hide_viewport=hv;c.hide_render=hr
    for o,(hv,hr,hs) in states.items():
        o.hide_viewport=hv;o.hide_render=hr
        if hs is not None and o.name in bpy.context.view_layer.objects:o.hide_set(hs)
    bpy.context.view_layer.update()
audit['gltf_export_options']=gltf_options
audit['glb_unit_policy']='glTF world coordinates in metres; one unit-conversion parent, source descendant local transforms unbaked; glTF Y-up'

# Validate GLB world bounds from actual POSITION buffers and full node transforms.
glbpath=OUT/(NAME+'.glb');blob=glbpath.read_bytes()
length,kind=struct.unpack_from('<I4s',blob,12);g=json.loads(blob[20:20+length])
bin_start=20+length+8
bindata=memoryview(blob)[bin_start:]
def positions(accessor_index):
    ac=g['accessors'][accessor_index];view=g['bufferViews'][ac['bufferView']]
    if ac['componentType']!=5126 or ac['type']!='VEC3':raise RuntimeError('Unexpected GLB position buffer format')
    offset=view.get('byteOffset',0)+ac.get('byteOffset',0)
    return np.ndarray((ac['count'],3),dtype='<f4',buffer=bindata,offset=offset,strides=(view.get('byteStride',12),4))
def node_matrix(node):
    if 'matrix' in node:return np.array(node['matrix'],dtype=np.float64).reshape(4,4).T
    q=node.get('rotation',[0,0,0,1]);s=node.get('scale',[1,1,1]);t=node.get('translation',[0,0,0])
    m=np.eye(4);m[:3,:3]=np.asarray(Quaternion((q[3],q[0],q[1],q[2])).to_matrix())@np.diag(s)
    m[:3,3]=t;return m
glo=np.full(3,np.inf);ghi=np.full(3,-np.inf);gnodes=[];gmesh_occ=0;gtris=0
def visit(i,parent):
    global gmesh_occ,gtris
    n=g['nodes'][i];mw=parent@node_matrix(n)
    extras=n.get('extras',{})
    gr={'index':i,'name':n.get('name'),'children':n.get('children',[]),
        'source_usd_path':extras.get('source_usd_path'),'source_usd_display_name':extras.get('source_usd_display_name'),
        'source_hidden':extras.get('source_hidden'),'source_usd_visibility':extras.get('source_usd_visibility'),
        'matrix_world_gltf_metres':mw.tolist()}
    if 'mesh' in n:
        gmesh_occ+=1;gr['mesh']=n['mesh'];gr['triangles']=0
        for prim in g['meshes'][n['mesh']]['primitives']:
            pts=positions(prim['attributes']['POSITION']).astype(np.float64)
            bounds_merge(glo,ghi,pts@mw[:3,:3].T+mw[:3,3])
            nt=g['accessors'][prim['indices']]['count']//3 if 'indices' in prim else len(pts)//3
            gtris+=nt;gr['triangles']+=nt
    gnodes.append(gr)
    for child in n.get('children',[]):visit(child,mw)
for r in g['scenes'][g.get('scene',0)].get('nodes',[]):visit(r,np.eye(4))
# Blender Z-up -> glTF Y-up is x,y,z -> x,z,-y.
expectedlo=np.array([lo[0],lo[2],-hi[1]])*mpu
expectedhi=np.array([hi[0],hi[2],-lo[1]])*mpu
gerror=float(max(np.abs(glo-expectedlo).max(),np.abs(ghi-expectedhi).max()))
audit['glb']={'path':str(glbpath),'bytes':glbpath.stat().st_size,'sha256':hfile(glbpath),
 'unique_mesh_definitions':len(g.get('meshes',[])),'mesh_occurrences':gmesh_occ,
 'triangle_occurrences':gtris,'nodes':gnodes,'node_count':len(gnodes),
 'world_bbox_metres_y_up':bounds_dict(glo,ghi),'expected_bbox_metres_y_up':bounds_dict(expectedlo,expectedhi),
 'bbox_max_abs_error_metres':gerror,'bbox_match':gerror<=tolerance*mpu,
 'triangle_count_match':gtris==occurrence_tris,'mesh_occurrence_match':gmesh_occ==occurrence_count,
 'nodes_with_usd_path':sum(bool(x['source_usd_path']) for x in gnodes),
 'hidden_mesh_nodes_retained':sum(bool(x['source_hidden']) and 'mesh' in x for x in gnodes)}
audit['source_usd_hash_unchanged']=hfile(USD)==usd_hash
audit['elapsed_seconds_before_render']=time.time()-started
audit_path.write_text(json.dumps(audit,ensure_ascii=False,indent=2))
if not audit['glb']['bbox_match'] or not audit['glb']['triangle_count_match']:
    raise RuntimeError('GLB geometry or bounds differ; audit written for investigation')
log('GLB verified',path=str(glbpath),bytes=glbpath.stat().st_size,triangles=gtris,bbox_error_metres=gerror)

if args.render:
    # Review lights and ground are presentation objects, outside source export.
    center=Vector(((lo+hi)*.5).tolist());size=float(max(hi-lo))
    world=bpy.data.worlds.new('REVIEW_STUDIO_WORLD');world.use_nodes=True
    world.node_tree.nodes['Background'].inputs['Color'].default_value=(.10,.13,.17,1)
    world.node_tree.nodes['Background'].inputs['Strength'].default_value=.35;sc.world=world
    studio=bpy.data.collections.new('REVIEW_STUDIO_NOT_SOURCE');sc.collection.children.link(studio)
    def area(name,offset,power,ss):
        d=bpy.data.lights.new(name,'AREA');d.energy=power*size*size;d.shape='DISK';d.size=ss*size
        o=bpy.data.objects.new(name,d);studio.objects.link(o);o.location=center+Vector(offset)*size
        o.rotation_euler=(center-o.location).to_track_quat('-Z','Y').to_euler()
        o['presentation_only']=True
    area('REVIEW_KEY',(-.5,-1.5,2.5),90,2.5)
    area('REVIEW_RIM',(1.2,1.5,2),110,2)
    area('REVIEW_FILL',(-1,-1,.3),20,2)
    cd=bpy.data.cameras.new('REVIEW_CAMERA');cam=bpy.data.objects.new('REVIEW_CAMERA',cd);studio.objects.link(cam)
    direction=Vector((1.4,-2.5,1.5)).normalized();cam.location=center+direction*size*3
    quat=(center-cam.location).to_track_quat('-Z','Y');cam.rotation_euler=quat.to_euler()
    cd.type='ORTHO';cd.ortho_scale=size*1.5;cd.clip_end=max(1000,size*30);sc.camera=cam
    sc.render.engine='CYCLES';sc.cycles.samples=args.samples;sc.cycles.use_denoising=True;sc.cycles.max_bounces=4
    sc.render.resolution_x=1400;sc.render.resolution_y=1100;sc.render.resolution_percentage=100
    sc.render.image_settings.file_format='PNG';sc.render.film_transparent=True
    sc.view_settings.view_transform='AgX';sc.view_settings.exposure=-.4
    sc.render.filepath=str(OUT/(NAME+'.png'))
    bpy.ops.render.render(write_still=True)
    audit['review_render']={'path':sc.render.filepath,'source_visible_state_respected':True,
      'presentation_geometry_added_to_export':False,'engine':'Cycles','samples':args.samples}
    # Save a separate review scene; original native .blend remains untouched.
    bpy.ops.wm.save_as_mainfile(filepath=str(OUT/(NAME+'.review.blend')),compress=True)
audit['elapsed_seconds_total']=time.time()-started
audit_path.write_text(json.dumps(audit,ensure_ascii=False,indent=2))
log('Complete',audit=str(audit_path),blend=str(native_blend),glb=str(glbpath),render=args.render)
