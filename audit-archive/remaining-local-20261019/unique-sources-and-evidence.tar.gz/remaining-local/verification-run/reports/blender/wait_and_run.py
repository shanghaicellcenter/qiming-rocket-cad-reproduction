"""Wait in 45-second intervals for the actual public-download acceptance gate."""
from pathlib import Path
import json
import subprocess
import sys
import time

here=Path(__file__).resolve().parent
receipt=here.parent/'actual-download-receipt.json'
print('Waiting for actual GitHub download, verify and restore gate; no rebuild started.',flush=True)
while True:
    try:
        data=json.loads(receipt.read_text())
    except (FileNotFoundError,json.JSONDecodeError):
        data={}
    if all(data.get(k) is True for k in ('download_passed','verify_passed','restore_passed')):
        break
    time.sleep(45)
print('Actual download receipt all3 true; starting isolated downloaded-source Blender acceptance.',flush=True)
subprocess.run([sys.executable,str(here/'run_acceptance.py')],check=True)
