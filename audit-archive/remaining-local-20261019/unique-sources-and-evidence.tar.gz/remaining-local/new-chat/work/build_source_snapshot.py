from pathlib import Path
import json,hashlib,subprocess,datetime,os
R=Path('/Users/qianqiming/Documents/Codex/2026-10-19/new-chat/outputs/启明火箭')
m=json.loads((R/'research/source-manifest.json').read_text());src=Path(m['source_root']);rows=[r for r in m['files'] if Path(r['relative_path']).name!='.DS_Store'];dest=R/'source/original-project';stage=dest.with_name(dest.name+'.incomplete');target=dest if dest.exists() else stage;target.mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
result=[]
for row in rows:
 rel=row['relative_path'];a=src/rel;b=target/rel;assert a.is_file() and a.stat().st_size==row['bytes'] and sha(a)==row['sha256'],('Source changed',rel)
 if not b.exists():
  b.parent.mkdir(parents=True,exist_ok=True);subprocess.run(['cp','-c',str(a),str(b)],check=True,capture_output=True)
 assert b.is_file() and b.stat().st_size==row['bytes'] and sha(b)==row['sha256'],('Snapshot mismatch',rel)
 result.append({'relative_path':rel,'bytes':b.stat().st_size,'sha256':row['sha256'],'allocated_bytes':b.stat().st_blocks*512})
actual={str(p.relative_to(target)) for p in target.rglob('*') if p.is_file()};assert actual=={r['relative_path'] for r in rows}
if target==stage:stage.rename(dest)
report={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_root':str(src),'snapshot_root_relative':'source/original-project','copy_method':'macOS cp -c copy-on-write clone; logically independent paths, exact bytes verified','original_content_files':len(result),'metadata_excluded':len(m['files'])-len(result),'total_logical_bytes':sum(x['bytes'] for x in result),'all_original_content_sha256_match':True,'files':result}
(R/'source/original-project-manifest.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
(R/'source/原始工程快照说明.md').write_text('# 原始工程快照\n\noriginal-project/ 保存桌面源项目全部392个内容文件，文件名与字节保持原样，包括6个ZIP、原CAD包、原文手册、中文版资料和仿真文件；仅省略2个Finder元数据文件。每个文件已与初始source-manifest逐项核对字节数及SHA256。\n\n此快照采用同盘写时复制创建，之后编辑其中一份不会改变另一份。请通过原工具或副本编辑；这里保留原设计身份，与启明火箭展示名称分开。完整校验表在 original-project-manifest.json。派生几何、图册、讲解与实际读取失败记录在项目其他目录。\n\n原设计归属Half Cat Rocketry，原文件内许可与根目录LICENSE-Half-Cat.txt一并保留。\n')
print(json.dumps({k:v for k,v in report.items() if k!='files'},ensure_ascii=False))
