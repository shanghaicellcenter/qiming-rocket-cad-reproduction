from pathlib import Path
import json, hashlib, re, datetime
root=Path('/Users/qianqiming/Documents/Codex/2026-10-19/new-chat');out=root/'outputs/mojave-machine';paper=out/'library/source-drawings'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
p=paper/'index.json';m=json.loads(p.read_text());m['title_zh']='启明火箭 · 原图纸十三页'
assert sha(Path(m['source_pdf']))==m['source_pdf_sha256']
for row in m['rows']:
    assert sha(paper/row['image'])==row['image_sha256']
    assert row['display_title_replacement']['outside_title_rectangles_pixels_identical']
    row['visual_review']='passed actual latest full-page contact-sheet and all thirteen title-region visual inspection; source frame retained, Chinese display name legible, no other pixels changed outside recorded name rectangles'
review={'reviewed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Latest Chinese-name display copies, replacing earlier direct-render review','whole_page_visual_coverage':list(range(1,14)),'contact_sheets_actually_viewed':m['contact_sheets'],'all_thirteen_title_regions_actually_viewed':True,'blank_pages_found':0,'clipped_source_page_frames_found':0,'unintended_pixel_changes_outside_recorded_name_rectangles':0,'original_pdf_unchanged':True,'source_pdf_sha256':m['source_pdf_sha256'],'title_display_audit':'title-display-audit.json','result':'passed'}
m['visual_review']=review
(paper/'visual-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n')
audit=json.loads((paper/'title-display-audit.json').read_text());audit['visual_review']=review;(paper/'title-display-audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n')
p.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n')
(paper/'说明.md').write_text('''# 启明火箭 · 原图纸展示副本

**原PDF未改；本图仅替换项目显示名。** 原设计归属 Half Cat Rocketry。原始文件身份、SHA256与物理页序保留在来源清单中，不将本地展示名称解释为原创设计。

13页按原PDF全页框渲染，每页1600×1131像素。旧项目名称在右下题签中的26个独立词框内覆盖，并在相同文字位置写入“启明火箭”；未调整几何线、标注、尺寸、文件编号、许可或作者署名。每一页均与未经更名的直接渲染图作像素对照，所有名称框之外的像素完全一致。图纸内容未重画或提炼成参数表。

新版13页完整页框总览与13个题签已全部实际查看，未发现空白、页框裁切或中文缺字。对应PNG的新SHA256、原始PNG的SHA256、题签区域和派生PDF的SHA256均在核对记录中单列。

本项属于原PDF的展示副本，未解析SLDDRW原生图纸。13页单独计数，三维源件170条记录、510张三视图保持不变。

[打开图纸浏览](原图纸浏览.html) · [下载展示PDF](启明火箭-展示图纸.pdf) · [逐页来源与哈希](index.json) · [标题替换像素审计](title-display-audit.json) · [视觉核对](visual-review.json) · [浏览器实测](browser-check.json)
''')

# Rebuild UI independently of raw source names. Geometry images and provenance
# are inputs; this generator cannot silently re-render the old titles.
template=(paper/'原图纸浏览.html').read_text()
template=template.replace('来源与核对记录</a></header>','来源与核对记录</a> · <a href="启明火箭-展示图纸.pdf" target="_blank" rel="noopener">展示PDF</a></header>')
template=re.sub(r'const rows=.*?, dialog=document.querySelector', 'const rows=__ROWS__, dialog=document.querySelector',template,count=1,flags=re.S)
assert '__ROWS__' in template
(out/'source/drawing-gallery-template.html').write_text(template)
generator='''from pathlib import Path
import json
root=Path(__file__).resolve().parent.parent
out=root/'library/source-drawings'
m=json.loads((out/'index.json').read_text())
assert len(m['rows'])==13
for r in m['rows']:assert (out/r['image']).is_file()
rows=[{'physical_pdf_page':r['physical_pdf_page'],'image':r['image']} for r in m['rows']]
template=(root/'source/drawing-gallery-template.html').read_text()
(out/'原图纸浏览.html').write_text(template.replace('__ROWS__',json.dumps(rows,ensure_ascii=False)))
print('Rebuilt Chinese display-name drawing gallery; 13 existing source display images unchanged.')
'''
(out/'source/build-drawing-gallery.py').write_text(generator)
old=root/'work/source-drawings/build.py';s=old.read_text()
guard="if (out/'title-display-audit.json').exists():\n    raise SystemExit('Historical pre-title-copy builder disabled; use outputs project source/build-drawing-gallery.py for the reviewed display copies')\n"
if guard not in s:s=s.replace("source=Path(",guard+"source=Path(",1)
old.write_text(s)
print(json.dumps({'all13_visual_reviewed':True,'source_pdf_sha256_unchanged':m['source_pdf_sha256'],'png_bytes':m['image_bytes'],'source_3d_records':170,'source_3d_views':510},ensure_ascii=False))
