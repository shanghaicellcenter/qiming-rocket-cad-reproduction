# 真实 GitHub 下载后 Blender 重建验收

已通过。生产脚本与CAD输入来自公开仓库实际克隆及 Release 下载恢复；旧 new-chat、ni、桌面原项目及原 Scenario 仓库在全部生产阶段由系统沙箱拒绝读取，4条拒读探针均真实返回 Operation not permitted。

- Commit：`82c2a2a255b66556cead58ec3444f81f1757ae68`；实际 Blender 5.2.2 LTS。
- 包内 prepare → 15组计划 → 完整重建 → 独立进程复开 → 第三进程对照原源Blend，全部成功。
- 每场景1980源对象、688网格、2864600面；源顶点坐标、拓扑索引、材质槽/面索引/平滑标记与UV保留。15组各自归位及最终全部源对象 local/world/basis/parent-inverse 差0。
- 199个Git/运行输入文件前后SHA一致；原下载Blend、USD、脚本和映射保持不变。来源与重建场景均无外部library、未打包图片或外部字体依赖。
- 实际生成15张归位诊断图及7张复开图，22张全部解码；7张复开原尺寸逐张打开，15组contact实际目视，根也查看两张新contact。最终整箭轮廓完整。

运动诊断图按当前组取景，其他分散部件可能经过画面边缘；stage15是原分散辅助节点的诊断分组。这里没有宣称每张图中每个对象均不裁切，也没有重录最终讲解影片或TTS。此验收证明CAD表示与展示归位坐标保留，不产生实物配合、碰撞可达性或工作过程求解结论。

新场景：`project/rebuilt/virtual-assembly/virtual-assembly.blend`，97,264,269字节，SHA256 `b1483e6c3dd62bfdaa3888c8b30fdee77f5e6b20b9f5dd68d41a725da96e8ca5`。

主要证据：`blender-acceptance.json`、`independent-source-compare.json`、`actual-visual-review.json`、`final-evidence-manifest.json`；截图：`newly-reopened-motion-7.png`、`newly-built-source-groups-15.png`。全部在本独立验证目录的reports/blender下，证据清单记录完整路径与SHA。独立QA harness属于本地验收辅助，未冒称其为GitHub下载的生产来源。
