import { launch } from '../../outputs/mojave-machine/source/vendor/machine/scripts/lib/browser.mjs';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { mkdirSync, writeFileSync, readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
const folder = resolve('work/assembly-film/review/interactive-review');
mkdirSync(folder, { recursive: true });
const { browser, page } = await launch({ width: 1600, height: 1000 });
const errors = [], external = [], consoleErrors = [];
page.on('pageerror', e => errors.push(e.message));
page.on('console', e => { if (e.type() === 'error') consoleErrors.push(e.text()); });
await page.route(/^https?:/, route => { external.push(route.request().url()); return route.abort(); });
const file = resolve('work/assembly-film/逐步虚拟归位.html');
const url = pathToFileURL(file).href;
const report = { checked_at_utc: new Date().toISOString(), file_sha256: createHash('sha256').update(readFileSync(file)).digest('hex'), url, errors, external, consoleErrors, interactions: [], frames: [], full_movie_recording_started: false };
async function ready() {
  await page.waitForFunction(() => ['true', 'error'].includes(document.body.dataset.ready), { timeout: 120000 });
  if (await page.evaluate(() => document.body.dataset.ready) !== 'true') throw new Error('Model load failed');
}
async function sample(stage, local, name, mode) {
  const t = await page.evaluate(({ stage, local }) => { const c = window.assemblyFilm.timeline.clips[stage]; return c.start + (c.end - c.start) * local; }, { stage, local });
  await page.evaluate(({ t, mode }) => { if (mode === 'film') window.__film.seek(t); else window.assemblyFilm.seek(t); }, { t, mode });
  await page.waitForTimeout(150);
  const row = await page.evaluate(() => {
    const rect = selector => { const e = document.querySelector(selector), r = e.getBoundingClientRect(), s = getComputedStyle(e); return { x:r.x,y:r.y,width:r.width,height:r.height,display:s.display,visible:s.display !== 'none' && s.visibility !== 'hidden' }; };
    return { time:window.assemblyFilmEvidence.currentTime,stage:window.assemblyFilmEvidence.stage,body_class:document.body.className,viewport:[innerWidth,innerHeight],title:document.querySelector('.chapter h1').textContent,principle:document.querySelector('.principle').textContent,caption:document.querySelector('.caption').textContent,rectangles:{ chapter:rect('.chapter'),caption:rect('.caption'),control:rect('.control'),overview:rect('.overview') }, audit:window.assemblyFilm.audit() };
  });
  await page.screenshot({ path: `${folder}/${name}.png` });
  report.frames.push({ stage, local, mode, file:`interactive-review/${name}.png`, ...row });
}
try {
  await page.goto(url, { waitUntil:'load',timeout:120000 }); await ready();
  report.loaded_evidence = await page.evaluate(() => window.assemblyFilmEvidence);
  await page.locator('#stage').selectOption('10');
  let value = await page.evaluate(() => ({ stage:window.assemblyFilmEvidence.stage,time:window.assemblyFilmEvidence.currentTime }));
  if (value.stage !== 10) throw new Error('Chapter selector failed');
  report.interactions.push({ operation:'chapter selector to 10',...value,passed:true });
  const before = value.time; await page.locator('#play').click(); await page.waitForTimeout(500); await page.locator('#play').click();
  value = await page.evaluate(() => ({ time:window.assemblyFilmEvidence.currentTime,label:document.querySelector('#play').textContent }));
  if (!(value.time > before) || value.label !== '播放') throw new Error('Play / pause failed');
  report.interactions.push({ operation:'play / pause',before,...value,passed:true });
  await page.locator('#seek').focus(); await page.keyboard.press('End');
  value = await page.evaluate(() => ({ time:window.assemblyFilmEvidence.currentTime,duration:window.assemblyFilm.timeline.duration,stage:window.assemblyFilmEvidence.stage }));
  if (Math.abs(value.time-value.duration) > .02 || value.stage !== 'outro') throw new Error('Seek End failed');
  report.interactions.push({ operation:'seek End',...value,passed:true });
  await page.keyboard.press('Home');
  value = await page.evaluate(() => ({ time:window.assemblyFilmEvidence.currentTime,stage:window.assemblyFilmEvidence.stage }));
  if (value.time !== 0 || value.stage !== 'intro') throw new Error('Seek Home failed');
  report.interactions.push({ operation:'seek Home',...value,passed:true });
  await sample(10,.78,'desktop-10-inside','interactive');
  await sample(15,.70,'desktop-15-link','interactive');
  await sample(15,.90,'desktop-15-plug','interactive');
  await page.setViewportSize({ width:390,height:844 });
  for (const [stage,local,name] of [[3,.83,'mobile-03-returned'],[10,.78,'mobile-10-inside'],[15,.70,'mobile-15-link'],[15,.90,'mobile-15-plug']]) await sample(stage,local,name,'interactive');
  await page.setViewportSize({ width:1280,height:720 });
  await page.goto(url+'?film=1&shot=main&ss=1', {waitUntil:'load',timeout:120000}); await ready();
  await page.waitForFunction(() => window.__film?.ready && window.__film.loaded());
  report.film_loaded_evidence = await page.evaluate(() => ({filmMode:window.lab.filmMode,apiReady:window.__film.ready,loaded:window.__film.loaded(),duration:window.__film.len}));
  for (let stage=0;stage<17;stage++) await sample(stage,.83,`film720-${String(stage).padStart(2,'0')}-returned`,'film');
  await sample(10,.78,'film720-10-inside','film');
  await sample(15,.70,'film720-15-link','film');
  await sample(15,.90,'film720-15-plug','film');
  report.numerical_checks_passed = errors.length === 0 && external.length === 0 && consoleErrors.length === 0 && report.frames.every(x => x.audit.sourceLocalMatricesUnchanged && x.audit.sourceMeshIdentities === 688 && x.audit.partitionCovered);
  report.requires_actual_visual_examination = true;
  writeFileSync(resolve('work/assembly-film/review/interaction-checks.json'),JSON.stringify(report,null,2)+'\n');
  console.log(JSON.stringify({ frames:report.frames.length,interactions:report.interactions.length,numerical:report.numerical_checks_passed,errors,external,consoleErrors }));
} finally { await browser.close(); }
