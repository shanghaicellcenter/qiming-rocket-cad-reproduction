from pathlib import Path
import os,json,subprocess,math,time,datetime,hashlib,signal
R=Path('/Users/qianqiming/Documents/Codex/2026-10-19/new-chat');H=R/'work/assembly-film';C=H/'captured-chapters';C.mkdir(exist_ok=True);NODE='/Users/qianqiming/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node'
timeline=json.loads((H/'silent-timeline.json').read_text());entries=[];began=time.monotonic()
def inspect(p):
 if not p.is_file():return None
 r=subprocess.run(['ffprobe','-v','error','-count_frames','-show_entries','stream=nb_read_frames,width,height,r_frame_rate','-of','json',str(p)],capture_output=True,text=True)
 if r.returncode:return None
 try:return json.loads(r.stdout)['streams'][0]
 except:return None
def checkpoint(status):
 (H/'capture-progress.json').write_text(json.dumps({'status':status,'pid':os.getpid(),'updated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'completed':len(entries),'expected':17,'entries':entries},ensure_ascii=False,indent=2)+'\n')
for i,c in enumerate(timeline['clips']):
 a=math.ceil(c['start']*30-1e-7);b=math.ceil(c['end']*30-1e-7);frames=b-a;dest=C/(str(i).zfill(2)+'-'+c['id']+'.mp4');audit=inspect(dest)
 if not audit or int(audit['nb_read_frames'])!=frames:
  args=[NODE,str(H/'record-resumable.mjs'),str(H/'逐步虚拟归位.html')+'',str(dest),'--w','1280','--h','720','--ss','1','--fps','30','--from',str(a/30),'--to',str(b/30)]
  # Movie page is built without burned captions; acoustic subtitles are added after final narration.
  log=(C/(c['id']+'.log')).open('wb');p=subprocess.Popen(args,stdout=log,stderr=subprocess.STDOUT,cwd=R,start_new_session=True)
  checkpoint('recording '+c['id'])
  try:code=p.wait(timeout=240)
  except subprocess.TimeoutExpired:
   os.killpg(p.pid,signal.SIGTERM);p.wait(timeout=10);raise RuntimeError('Own chapter capture timed out: '+c['id'])
  if code:raise RuntimeError('Chapter capture failed '+c['id']+' exit '+str(code))
  audit=inspect(dest)
 assert audit and int(audit['nb_read_frames'])==frames and audit['width']==1280 and audit['height']==720,(c,audit)
 entries.append({'id':c['id'],'index':i,'source_first_frame':a,'source_end_frame_exclusive':b,'frames':frames,'path':str(dest),'sha256':hashlib.sha256(dest.read_bytes()).hexdigest()});checkpoint('completed '+c['id']);print(c['id'],'verified',frames,'frames',flush=True)
 assert time.monotonic()-began<2700
lst=C/'concat.txt';lst.write_text(''.join("file '"+e['path']+"'\n" for e in entries));out=H/'silent-master-启明火箭.mp4'
r=subprocess.run(['ffmpeg','-y','-v','error','-f','concat','-safe','0','-i',str(lst),'-map','0:v','-c','copy','-movflags','+faststart',str(out)],capture_output=True,text=True);assert r.returncode==0,r.stderr
final=inspect(out);assert int(final['nb_read_frames'])==6596,final
checkpoint('complete');print('COMPLETE',out,flush=True)
