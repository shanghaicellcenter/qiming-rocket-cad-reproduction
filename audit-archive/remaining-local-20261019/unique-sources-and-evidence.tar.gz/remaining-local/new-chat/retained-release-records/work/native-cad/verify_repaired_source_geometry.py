"""Read-only USD-to-repaired-Blend geometry and evaluated matrix comparison."""
import bpy,json,numpy as np
from pathlib import Path
from pxr import Usd,UsdGeom
ROOT=Path('/Users/qianqiming/Documents/Codex/2026-10-19/new-chat')
DIR=ROOT/'work/native-cad/vehicle-blender';results=[]
for name in ('vehicle-original','vehicle-browse'):
    auditpath=DIR/(name+'.audit.json');audit=json.loads(auditpath.read_text())
    bpy.ops.wm.open_mainfile(filepath=str(DIR/(name+'.blend')))
    objs={o['source_usd_path']:o for o in bpy.context.scene.objects if o.get('source_usd_path')}
    assert len(objs)==1980
    saved={o:o.hide_viewport for o in objs.values()}
    for o in saved:o.hide_viewport=False
    bpy.context.view_layer.update()
    matrix_errors=[]
    for row in audit['blender_objects']:
        o=objs[row['source_usd_path']]
        matrix_errors.append(float(max(np.abs(np.asarray(o.matrix_local)-np.asarray(row['matrix_local'])).max(),
            np.abs(np.asarray(o.matrix_world)-np.asarray(row['matrix_world'])).max())))
    assert max(matrix_errors)==0
    stage=Usd.Stage.Open(audit['source_usd']);rows=[]
    for path,o in objs.items():
        if o.type!='MESH':continue
        source=UsdGeom.Mesh(stage.GetPrimAtPath(path))
        points=np.empty(len(o.data.vertices)*3,dtype=np.float32);o.data.vertices.foreach_get('co',points)
        indices=np.empty(len(o.data.loops),dtype=np.int32);o.data.loops.foreach_get('vertex_index',indices)
        counts=np.empty(len(o.data.polygons),dtype=np.int32);o.data.polygons.foreach_get('loop_total',counts)
        exact_points=bool(np.array_equal(points.reshape(-1,3),np.asarray(source.GetPointsAttr().Get(),dtype=np.float32)))
        exact_indices=bool(np.array_equal(indices,np.asarray(source.GetFaceVertexIndicesAttr().Get(),dtype=np.int32)))
        exact_counts=bool(np.array_equal(counts,np.asarray(source.GetFaceVertexCountsAttr().Get(),dtype=np.int32)))
        assert exact_points and exact_indices and exact_counts,path
        rows.append({'source_usd_path':path,'points_exact':exact_points,'face_indices_exact':exact_indices,'face_counts_exact':exact_counts})
    assert len(rows)==688
    for o,v in saved.items():o.hide_viewport=v
    bpy.context.view_layer.update()
    assert sum(o.type=='MESH' and o.hide_render and o.hide_viewport for o in objs.values())==3
    result={'source_mesh_occurrences_checked':688,'source_objects_matrix_checked':1980,
        'all_native_usd_points_face_counts_and_indices_exact':True,
        'all_evaluated_local_world_matrices_exact_to_original_audit':True,
        'max_local_world_matrix_abs_error':0.,'source_default_hidden_meshes':3,
        'temporary_evaluation_visibility_restored':True,'blend_file_not_saved':True,'meshes':rows}
    audit['source_visibility_restoration']['post_repair_direct_usd_geometry_check']={k:v for k,v in result.items() if k!='meshes'}
    auditpath.write_text(json.dumps(audit,ensure_ascii=False,indent=2))
    results.append({'blend':name,**result})
    print('POST_VISIBILITY_USD_QC='+json.dumps({'blend':name,**{k:v for k,v in result.items() if k!='meshes'}}),flush=True)
(DIR/'post-visibility-source-geometry-qc.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
