"""Lossless GLB storage packing: share identical bytes/accessors, keep all nodes/meshes.

This does not tessellate, decimate, weld, move, recolor or remove source geometry.
All authored scene nodes, mesh definitions, materials and extras remain present.
"""
from pathlib import Path
from copy import deepcopy
import hashlib, json, struct, sys

def digest(value):
    return hashlib.sha256(value).hexdigest()

def canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()

def read(path):
    data=path.read_bytes()
    magic,version,total=struct.unpack_from('<4sII',data)
    assert magic==b'glTF' and version==2 and total==len(data)
    chunks=[];at=12
    while at<total:
        size,kind=struct.unpack_from('<I4s',data,at);at+=8
        chunks.append((kind,data[at:at+size]));at+=size
    assert chunks[0][0]==b'JSON' and len(chunks)==2 and chunks[1][0]==b'BIN\0'
    return data,json.loads(chunks[0][1]),chunks[1][1]

def pack(source,target):
    original,g,blob=read(source)
    assert len(g['buffers'])==1 and 'uri' not in g['buffers'][0]
    assert not any('sparse' in a for a in g.get('accessors',[])), 'Sparse accessors require explicit handling'
    assert not any('extensions' in m.get('primitives',[{}])[0] for m in g.get('meshes',[])), 'Mesh extension requires explicit handling'
    out=deepcopy(g)
    viewmap={};views=[];seen={};binary=bytearray()
    for i,v in enumerate(g.get('bufferViews',[])):
        assert v.get('buffer',0)==0
        b=blob[v.get('byteOffset',0):v.get('byteOffset',0)+v['byteLength']]
        assert len(b)==v['byteLength']
        meta={k:value for k,value in v.items() if k not in ('buffer','byteOffset','byteLength')}
        key=digest(canonical(meta)+b'\0'+b)
        if key not in seen:
            while len(binary)%4:binary.append(0)
            seen[key]=len(views)
            views.append({**v,'buffer':0,'byteOffset':len(binary)})
            binary.extend(b)
        viewmap[i]=seen[key]
    out['bufferViews']=views
    accessors=[];accmap={};aseen={}
    for i,a in enumerate(g.get('accessors',[])):
        a=deepcopy(a)
        if 'bufferView' in a:a['bufferView']=viewmap[a['bufferView']]
        key=digest(canonical(a))
        if key not in aseen:
            aseen[key]=len(accessors);accessors.append(a)
        accmap[i]=aseen[key]
    out['accessors']=accessors
    for m in out.get('meshes',[]):
        for p in m['primitives']:
            p['attributes']={k:accmap[v] for k,v in p['attributes'].items()}
            if 'indices' in p:p['indices']=accmap[p['indices']]
            for morph in p.get('targets',[]):
                for k in list(morph):morph[k]=accmap[morph[k]]
    for image in out.get('images',[]):
        if 'bufferView' in image:image['bufferView']=viewmap[image['bufferView']]
    for skin in out.get('skins',[]):
        if 'inverseBindMatrices' in skin:skin['inverseBindMatrices']=accmap[skin['inverseBindMatrices']]
    for animation in out.get('animations',[]):
        for sampler in animation['samplers']:
            sampler['input']=accmap[sampler['input']];sampler['output']=accmap[sampler['output']]
    assert out.get('nodes')==g.get('nodes') and out.get('materials')==g.get('materials')
    assert out.get('scenes')==g.get('scenes')
    # Every accessor resolves to exactly the same bytes and interpretation.
    for old,new in accmap.items():
        a=deepcopy(g['accessors'][old]);b=deepcopy(out['accessors'][new])
        av=g['bufferViews'][a.pop('bufferView')];bv=out['bufferViews'][b.pop('bufferView')]
        assert a==b
        oldbytes=blob[av.get('byteOffset',0):av.get('byteOffset',0)+av['byteLength']]
        newbytes=binary[bv.get('byteOffset',0):bv.get('byteOffset',0)+bv['byteLength']]
        assert oldbytes==newbytes
    # All mesh definitions remain in original order, with only accessor IDs remapped.
    for old,new in zip(g['meshes'],out['meshes']):
        restored=deepcopy(new)
        for a,b in zip(old['primitives'],restored['primitives']):
            b['attributes']=deepcopy(a['attributes'])
            if 'indices' in a:b['indices']=a['indices']
            if 'targets' in a:b['targets']=deepcopy(a['targets'])
        assert restored==old
    out['buffers'][0]['byteLength']=len(binary)
    while len(binary)%4:binary.append(0)
    jb=canonical(out)
    while len(jb)%4:jb+=b' '
    total=12+8+len(jb)+8+len(binary)
    target.parent.mkdir(parents=True,exist_ok=True)
    with target.open('wb') as f:
        f.write(struct.pack('<4sII',b'glTF',2,total))
        f.write(struct.pack('<I4s',len(jb),b'JSON'));f.write(jb)
        f.write(struct.pack('<I4s',len(binary),b'BIN\0'));f.write(binary)
    report={
        'source':str(source),'target':str(target),
        'source_bytes':len(original),'target_bytes':total,
        'source_sha256':digest(original),'target_sha256':digest(target.read_bytes()),
        'buffer_views_before':len(g.get('bufferViews',[])),'buffer_views_after':len(views),
        'accessors_before':len(g.get('accessors',[])),'accessors_after':len(accessors),
        'nodes_preserved':len(g.get('nodes',[])),'mesh_definitions_preserved':len(g.get('meshes',[])),
        'materials_preserved':len(g.get('materials',[])),
        'all_accessor_bytes_and_interpretation_identical':True,
        'all_scene_node_hierarchies_transforms_extras_identical':True,
        'all_mesh_material_bindings_and_primitives_preserved':True,
        'scope':'Identical buffer storage/accessors shared only; no geometry or original node removed.'
    }
    target.with_suffix('.packing.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(report,ensure_ascii=False))

if __name__=='__main__':pack(Path(sys.argv[1]),Path(sys.argv[2]))
