import json, pathlib, re, datetime
from urllib.parse import quote

out=pathlib.Path(__file__).parent
observed='2026-10-19T14:25:06Z'
repo='https://github.com/HalfCatRocketry/mojave-sphinx'
commit='6e455cf94c840fbb4b18315aa462218cb665644a'
guide_name='HCR-5100 - Mojave Sphinx Build, Integration, and Launch Guidebook - R01.pdf'
patch_name='HCR-5105 - Design Modification to Correct Recovery Anchor Fuel Leakage of Mojave Sphinx.zip'
guide_url=repo+'/blob/'+commit+'/'+quote(guide_name)
patch_url=repo+'/blob/'+commit+'/'+quote(patch_name)
site='https://www.halfcatrocketry.com/mojave-sphinx'
local_root='/Users/qianqiming/Desktop/火箭设计 中文版'
guide_local=local_root+'/英文原件/'+guide_name
identities=json.loads((out/'local-official-identity.json').read_text())
event_index=json.loads((out/'guide-event-index.json').read_text())
register=[]

def add(id,claim,date,url,kind,revision,proves,not_proves,**extra):
    register.append(dict(id=id,claim=claim,evidence_date=date,sourceurl=url,
        original_data_vs_claim=kind,whichrevision=revision,whatitproves=proves,
        doesnotprove=not_proves,primary_source=True,independent_validation=False,
        observed_at_utc=observed,**extra))

add('ID-01','本地 R01 指南与当前官方仓库文件的 Git blob 身份相同。',
    {'guide_revision_date':'2024-08-17','current_file_commit_date':'2024-08-26'},guide_url,
    '本地字节的 SHA256 与 Git blob SHA1 实测；GitHub 官方 contents API blob SHA1 对照，不是试验数据。',
    'HCR-5100 R01；该文件的当前官方仓库身份。',
    '所读本地英文原指南确实对应官方仓库当前提供的同一字节内容。',
    '不证明书内每个测量值经过独立审核，也不证明当前虚拟模型或新实物可用。',local_file=guide_local,identity=identities[0])
add('ID-02','本地 HCR-5105 ZIP 与当前官方仓库文件的 Git blob 身份相同。',
    {'local_release_note_month':'2026-06','repository_first_visible_commit':'2026-09-24T02:13:31Z','bulletin_document_date':None},patch_url,
    '发布物身份核对；通告正文不是修订后验收试验数据。',
    'HCR-5105，明示适用 HCR-5100 R01 的相关组件；与主包分开。',
    '修订包是可核对的官方发布物，而非本次补造设计。',
    '不能把本地 README 的六月说明或 GitHub 九月入库日当作故障日期、改装日期或修订后试验通过日。',
    identity=identities[1],date_caveat='PDF标题页及适用段未标日期；本地英文README记载六月补充，当前仓库此路径最早可见提交为九月。')
add('VERSION-01','指南明确说明研制数据包含较早构型，不能全部套到最终基准。',
    {'publication_revision':'2024-08-17','event_range':['2023-07-15','2024-07-20']},guide_url+'#page=97',
    '原作者的版本历程叙述，非独立逐件配置审计。',
    'v1.0、v1.1、v1.2 及其试验变体；R01 是出版修订号，不是每次实物试验配置号。',
    '原项目经历了真实的版本演进，历史测试不属于单一冻结配置。',
    '不能由同名 CAD 或同一篇指南推出全部试验使用了当前归档逐件相同的配置。',
    local_reference={'printed_page':88,'physical_page':97,'section':'3.1'})
add('TESTS-01','R01 第3.2节逐项列有19次地面试车记录及出版图表。',
    {'first_event':'2023-11-04','last_event':'2024-05-04'},guide_url+'#page=99',
    '一手试验报告中的照片、处理后曲线与说明；未取得相应原始DAQ时间序列及校准记录。',
    'SN01研制阶段的变化构型；不能统称最终R01同配置19次通过。',
    '作者发布了可追溯到日期与页码的地面试验史，超出仅有仿真或CAD的证据。',
    '不构成19次完全相同构型的合格性试验或统计可靠性证明。',event_index_file='guide-event-index.json')
add('FLIGHTS-01','R01 第3.3节列18条发射标题，其中最后两条明确属于SN02。',
    {'first_event':'2023-07-15','last_event':'2024-07-20'},guide_url+'#page=110',
    '原作者飞行叙述、现场照片及部分处理后飞行记录，不是本轮独立飞行试验。',
    '前16条为原型历程；Launch17/18标明SN02 Half Cat Walking II。',
    '该设计家族确有被报告的实物飞行史，且原作者区分序列号。',
    '不是18次SN01成功飞行，也不是18次当前R01逐件冻结配置的验收。',
    editorial_caveat='原书把Launch17/18小节号重复写成3.3.15/3.3.16；本登记使用事件编号、日期和SN识别，未静默改写源文。')
add('SITE-01','官网定义 Mojave Sphinx 为设计家族，而非单一固定实物。',None,site,
    '当前官网的原作者定义与登记说明。','多个SN及改型。',
    '型号名相同不能代替序列号和配置的追溯。','不能跨SN汇总推出当前R01或本次模型的实物可靠性。')
add('SITE-02','官网记载SN01已退役，累计19次发射及20次地面试验。',None,site,
    '官网寿命累计自述，未附完整逐次原始测量日志。','SN01 Mojave Sphinx；跨研制阶段。',
    '作者报告的SN01使用历程比R01书中较早阶段更长。',
    '不能当作39次无故障、同构型或独立认证通过；网页无逐项结果分母。')
add('SITE-03','官网记录SN02第三次发射后撞击损毁。','2024-09-07',site,
    '原作者事后事件与原因归因；未取得独立事故调查或原始遥测。',
    'SN02 Half Cat Walking II，使用过SN01的旧箭体及回收系统。',
    '作者公开记录失败，而非全部飞行一律成功。',
    '不能独立确认全部失效因果，也不能据一例推出其他构型的失效率。')
add('SITE-04','官网列有SN04试验平台、SN12加长改型等其他实物。',None,site,
    '官网登记及简述；不是本次逐件配置审计。','SN04/SN12等；与SN01/R01不同。',
    '后续公开成果可能对应改型。','不能把改型成绩直接归到本次主R01源装配。')
add('SITE-05','官网项目列表显示26次发射、32次试验的累计数。',None,
    'https://www.halfcatrocketry.com/rockets','官网显示的统计自述，页面未提供逐条口径和配置分解。',
    '页面未明确全部统计的SN与修订分解。','可以登记作者当前页面的累计说法。',
    '不能作为当前R01连续成功次数、全部最新实物事件清单或可靠性置信度。')
add('TSB-01','HCR-5105 明示R01存在回收锚固接口燃料泄漏的已知条件。',
    {'document_date':None,'repository_first_visible_commit':'2026-09-24T02:13:31Z'},patch_url,
    '作者技术服务通告，属于缺陷/适用性通知；不是修订后重复验收数据。',
    '明确适用HCR-5100 R01的相关组件；本次补库保留独立版本。',
    'R01发布后存在需要单独追踪的已知修订，不能宣称R01所有细节无条件可靠。',
    '不能证明本地主装配已合入修订，也未找到公开可审计的修订后复验样本和结果。',
    local_reference={'zip_member_type':'PDF','physical_page':2},scope_note='本登记不复制修正方法、零件规格、工序或试验步骤。')
add('DATA-01','当前官方仓库Simulation目录仅列仿真表、示例曲线与OpenRocket模型。',
    {'repository_snapshot':commit},repo+'/tree/'+commit+'/Simulation',
    '软件/模型输入与经过处理的示例文件，不能自动归类为原始测量数据。',
    'HalfCatSim v1.3.8；示例ENG身份关联旧v1.1/HF10；ORK文件名为v1.2。',
    '存在可追踪的仿真与示例数据输入，且文件身份并非同一修订标记。',
    '不证明已获得所有地面/飞行事件的原始传感器日志、标定、误差和完整配置记录。',
    filename_metadata_only=True,eng_content_scope='只读源注释以识别来源，不提取曲线数值、性能或操作参数。')
add('DATA-02','本轮所查官方当前main树与本地发布包未找到独立原始DAQ/遥测数据集。',
    {'repository_snapshot':commit},repo+'/tree/'+commit,
    '限定范围的负面发现；官方仓库完整recursive tree为92项且truncated=false。',
    '当前main和用户本地发布包；未穷尽历史分支、未公开文件或所有Google Drive内容。',
    '当前交付不足以重新独立估计测量误差或统计可靠性。',
    '不能证明作者从未采集或从未在其他位置公开原始数据。',
    repository_tree_file='official-repository-tree.json',raw_data_missing_for_reanalysis=['逐通道原始时间序列','传感器标定及不确定度','与每次测试对应的完整实物配置','修订后可追溯验收记录'])
add('MEDIA-01','已实际查看本地原指南中的4张相关实物/现场照片。',
    {'photo_capture_dates':'未独立核验；日期只来自所在报告事件'},guide_url,
    '原作者出版物中的照片；不是连续原视频或测量原始数据。',
    '分别位于早期原型及SN02报告附近；不由图像外观单独推断逐件配置。',
    '可见真实现场硬件与飞行场景，而不是仅有本次生成的三维图。',
    '单张照片不能证明完整上升、回收成功、测量值或拍摄日期真实性。',
    local_images_viewed=['中文文档/images/p110_i2.jpeg','中文文档/images/p113_i3.jpeg','中文文档/images/p118_i2.jpeg','中文文档/images/p118_i4.jpeg'],original_pdf_physical_pages_rendered_and_viewed=[110,113,118])
add('MEDIA-02','本轮没有取得可逐时间对照SN/配置的Mojave原作者完整连续视频。',None,site,
    '检索与可访问性边界；不使用论坛/剪辑转述作为试验合格证据。','未锁定可审计的视频与配置绑定。',
    '没有把剪辑片或其他型号影片充作本次原装配的实物验证。',
    '不代表相关原视频不存在；本轮未进行完整视频播放审核。',
    access_limits=['Chrome CDP未连接，未要求用户登录或改设置，公开静态来源仍可核查。','官方Flickr页面经当前网页工具不可访问。','论坛视频线索遇403，未用其正文作结论证据。'])

add('EDITORIAL-01','首个地面试车的相对时序叙述与标题日期存在待核对点。',
    {'test1_header':'2023-11-04','launch3_header':'2023-11-18'},guide_url+'#page=99',
    '同一原指南的内部文字对照；不是额外试验数据。',
    'R01出版文本，未据此修正实物配置或事件日期。',
    'Test1正文称此前有三次发射，但其标题日期早于Launch3标题日期；本登记保留源日期并标为as-reported。',
    '不能据此确定哪个日期/措辞有误，也不证明试验没有发生。',
    related_sourceurl=guide_url+'#page=111')

flight_outcomes={
 1:('v1.0；作者称其唯一一次点火。','起飞后回收分离失败并损坏，不能记为完整成功。'),
 2:('v1.1箭体；不能等同最终R01逐件配置。','回收展开，但着陆损坏尾翼；部分阶段成功不等于无损验收。'),
 5:('研制中的变化构型，完整配置未逐件锁定。','出现飞行不稳定，随后回收；不记为全程标称。'),
 8:('SN01研制构型；完整版本未锁定。','主伞未成功展开，撞击造成损坏。'),
 9:('作者称首次飞行采用指南推荐基准方案；并非逐件冻结配置证明。','作者报告正常飞行与回收，仍非本轮独立实物验证。'),
 10:('作者明示基准方案的试验变体。','变体飞行记录不能全套为主R01配置。'),
 13:('SN01；含地面控制配置差异。','初始行为异常后起飞并回收；不记作无异常成功。'),
 14:('SN01；源文记有已受损箭体状态。','出现显著飞行不稳定，但随后回收。'),
 17:('SN02 Half Cat Walking II；不是原SN01。','SN02起飞但回收时序异常；同日SN01未点火。'),
 18:('SN02 Half Cat Walking II；不是原SN01。','发生回收结构分离及着地损伤；同日SN01再次未点火。')}

for row in event_index:
    m=re.search(r'(Test|Launch) (\d+)',row['heading']);kind,num=m.group(1),int(m.group(2))
    date_text=re.sub(r'\s*\[SN02\]','',row['date_label']).strip()
    date=datetime.datetime.strptime(date_text,'%d %b %Y').date().isoformat()
    if kind=='Test':
        revision='SN01研制阶段；本次不把变化构型逐项推定为最终R01。'
        if num==10:revision='作者将此项关联最终基准方案；文件级完全配置未锁定。'
        what='原作者在指定日期登记一次地面试车，附出版图表/叙述。'
        limits='出版后的处理曲线不是原始DAQ；本轮未重新计算性能、测量误差或合格判定。'
    else:
        revision,outcome=flight_outcomes.get(num,('SN01研制历程；本轮未逐件锁定实物配置。','有作者飞行条目；完整结果应按原报告，不根据标题推定成功。'))
        what=outcome
        limits='不是本次虚拟复现或新造实物的试验；不能把发射条目数当成功验收数。'
    add(f'{kind.upper()}-{num:02d}',f'原指南记录{kind} {num}。',date,
        guide_url+'#page='+str(row['physical_page']),
        '原作者出版报告；日期/页码从本地英文原PDF直接提取并与官方文件身份对照。',
        revision,what,limits,local_reference={'file':guide_local,'original_heading':row['heading'],
            'printed_page':row['printed_page'],'physical_page':row['physical_page']})

result={'schema_version':1,'observed_at_utc':observed,'purpose':'实物试验、飞行与修订的证据强度登记；不生成设计、工序、点火/加压/发射参数或性能优化。',
        'repository_commit':commit,'entries':register,
        'strongest_supported_conclusion':'有可核对到原作者发布物、日期、序列号与不同版本的地面试车和飞行史，足以支持该设计家族不是纯仿真或纯CAD概念；同时存在公开失败和已知修订。',
        'not_supported':'不能证明本次CAD虚拟复现或任一新造实物足够真实可用、达到特定可靠性、全部配置有效，或HCR5105修订已在主R01上完成复验。',
        'research_scope':'官方Half Cat官网/仓库、用户本地原英文指南与发布包；没有消息发送、注册、源文件上传或性能计算。'}
(out/'evidence-register.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'entries':len(register),'tests':19,'launches':18,'primary_sources_only':True}))
