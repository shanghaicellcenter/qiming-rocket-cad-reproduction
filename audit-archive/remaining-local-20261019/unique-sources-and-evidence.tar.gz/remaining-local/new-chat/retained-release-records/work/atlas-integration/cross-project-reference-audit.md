# 伙伴项目跨目录引用审计

本次只读检查 `/Users/qianqiming/Documents/Codex/2026-10-19/ni` 的 `outputs/rocket`、`outputs/rocket-v2`、`work/rocket-v2`，另读取正式课程构建器直接使用的 `work/rocket/parts.json`、`custom-parts.json`。未修改伙伴文件，未复制或删除源文件。

**当前仍有未来重建和两份可编辑图卡的真实依赖，清理依赖尚未解除。** 直接盘点得到 103 份源输入，共 **143,449,994 字节（约 136.8 MiB）**；其中 4 份证据输入已有伙伴独立副本，另外 99 份几何/元数据/原图需要先保存或迁移。逐文件 SHA256、实际存在性、解析后的目标及消费者均在同名 JSON 的 `preserveOrRelocateBeforeDeletingSource` 中。

## 必须先保存或迁移

| 输入 | 实际数量 / 字节 | 消费者与处理要求 |
| --- | ---: | --- |
| 本方 `work/native-cad/vehicle.usdc`、`vehicle.hierarchy.json`、`component-labels.json`、`vehicle.name-source-map.json` | 4 / 75,408,337 | `extract_native_subset.py`、`audit_part_identity.py`、`merge_visual_patch.py`仍硬编码本方路径。实际 work 路径可解析到最终输出中的文件；应在伙伴独立输入目录保存，再修改构建路径。 |
| `native-thumbnail-jobs.json`列出的单件 USD | 93 / 67,295,017 | 正式缩略图重渲脚本从每条 `usd` 绝对路径读取。93 份均实际存在、记录了 SHA。仅保留已渲 WebP 不能重新生成这些原 CAD 图片。 |
| `library/part-previews/P087-oblique.png`、`P072-oblique.png` | 2 / 665,666 | 既是 `source-details-evidence/render_source_details.py`的输入，又仍由两份保存的图卡 `.blend`直接引用，当前未打包。必须复制原字节后重连或打包私有图卡源。 |
| OpenRocket结果/复核报告、飞行证据登记/审查共4文件 | 4 / 80,974 | 伙伴 `work/rocket-v2/qa/external-evidence`已有逐字节一致的独立副本；但 `build_evidence_page.py`仍读取本方 `outputs/mojave-machine/research`。应改用已有独立副本并验证重建。 |

根目录或兼容别名不是可移植输入规范。不要只保留失效的旧路径字符串，也不要依赖清理后继续存在的 symlink。

## 实际打开 Blender 核查

已用 `/Applications/Blender 5.2.app/Contents/MacOS/Blender`（5.2.2 LTS，d13f752e3b9c）以 factory startup、禁自动执行、后台只读方式打开 5 份伙伴文件，**没有保存任何 `.blend`**：

- `work/rocket-v2/native-selected.blend`、`outputs/rocket/animation/causal-course.blend`、`causal-course-clarity.blend`：没有外链 Blender library、文件图片、声音、电影或缓存依赖。当前几何已存在于伙伴自己的保存文件中。
- `source-details-evidence/A7-01-source-card.blend`：实际场景材质节点引用未打包的本方 P087 PNG。
- `source-details-evidence/A7-16-source-card.blend`：实际场景材质节点引用未打包的本方 P072 PNG。另残留一个不被当前场景材质使用的 P087 图片数据块，也指向本方。

因此“复制 blend 即独立可编辑”的结论不适用于这两张图卡。两份图片确实被当前场景使用，不只是来源说明字段。详见 `partner-blend-dependency-read-audit.json`。普通 `/Applications/Blender.app`实测为 4.4.3，不能读取这些较新文件；失败尝试没有修改文件。

## 已核实的独立副本

- 伙伴 `outputs/rocket/native-assembly.html`是独立普通文件，229,835,587 字节，非 symlink。实际提取其内嵌的 browse、precision、supplements 三份模型，SHA256分别与本方当前三份 compact GLB 完全一致。HTML中没有本方 `new-chat`绝对路径或 `file://` URL；接入记录里的旧 source 路径属于历史来源。它不需要在运行时访问本方 GLB。
- 伙伴 `outputs/rocket-v2/assembly-review/原CAD逐组归位_无声核查母片.mp4`是独立普通文件，15,855,465 字节；实际 SHA匹配其记录的 `19f66326…b06ca`。这是未验收历史静音预览，不能作为最新正式讲解视频交付，但不依赖本方旧MP4继续存在。
- 伙伴自己的 `native-selected.blend`、两个 causal-course `.blend`及 `native-piston.glb`、`native-valve.glb`、`fuel-route.glb`均是实际普通文件，已记录自身 SHA；前三份还完成上述实际 Blender 依赖读取。
- 4份仿真/飞行证据本地副本均与本方原文件逐字节一致。

## 仅历史来源说明

`outputs/rocket/data.js`、`内容数据.json`、课程数据及便携图册候选manifest中的两张 P087/P072 `sourceEvidence.sourceImage`，以及 `native-selected.json`、`assembly-sequence.json`、接入记录、重建说明中的旧路径，主要是来源登记。读取了当前 `app.js`、`course.js`、便携图册脚本：图片显示使用独立 `visual.image`/`media.src`等相对资产路径，`sourceEvidence`用于解释来源与限界，没有把这个绝对原图字段作为图片URL加载。

这不代表所有课程最终素材已经验收或复制齐全；本审计仅区分这些跨目录引用是否构成访问本方文件的依赖。

旧候选检查脚本 `qa/unverified-visual-candidates/write_candidates.py`还读本方 `library/preview-index.json`。它属于最初45候选的诊断阶段，当前 parts 选择状态已改变，不能直接称正式重建步骤。若决定保留该旧工具，应同时保存索引并记录对应旧输入快照；无需因这段脚本复制全部615图像。

## symlink、工具与当前服务

- 353条 symlink 中，**0条指向本方 new-chat**。352条指向桌面中文原文档图片，1条为共享 Codex Node模块目录。三个受查根文件夹本身也不是symlink。
- `work/rocket-v2/node_modules`指向 `/Users/qianqiming/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules`。Machine构建器仍从桌面 `AirsupHQ--machine-skill/kit/lab-kit.js`和`template.html`读取。它们是共享工具，不能作为本项目残留删除。
- 进程/端口快照中没有伙伴8766/8765服务监听；本方58926预览服务实际使用本方最终输出目录。OpenDesign两进程未持有这两个项目的文件句柄。这里只报告查询时刻；文件句柄缺失不能排除浏览器内存缓存，也不替代重建验证。

## 清理前完成顺序

1. 由伙伴把99份必要几何/元数据/原图保存到自己的独立输入目录，逐文件核 SHA；4份证据可直接沿用已核实的本地副本。
2. 重连/打包两张图卡的实际图片输入；将构建脚本和93条USD任务改为可移植或伙伴目录中的路径。
3. 保留来源登记及原 SHA；将记录说明与真正的构建输入路径分开，不能用简单全局替换抹掉来源证据。
4. 在独立副本上实际重建所需图片/页面，确认不访问本方目录；无需改名、移走或删除正在使用的源文件来制造测试条件。
5. 完成用户要求的发布、下载和下载物验证后，主线程再按授权处理本方可清理内容。桌面原项目、伙伴项目、共享 Machine/Node/Blender 工具均不在本报告的删除范围。

本报告未执行以上迁移或清理，`cleanupDependencyReleaseComplete=false`。
