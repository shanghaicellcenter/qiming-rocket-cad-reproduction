import {existsSync,readFileSync,createReadStream,createWriteStream} from 'node:fs';
import {once} from 'node:events';
import {dirname,resolve} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {spawnSync} from 'node:child_process';

const here=dirname(fileURLToPath(import.meta.url));
const prep=spawnSync('python3',[resolve(here,'prepare_data.py')],{encoding:'utf8'});
if(prep.status!==0)throw new Error(prep.stderr||prep.stdout);
const config=JSON.parse(readFileSync(resolve(here,'assets.json'),'utf8'));
const assets=[...(config.models||[]),...(config.library||[])].filter(x=>existsSync(resolve(here,x.path)));
if(!assets.length)throw new Error('No real GLB input is present. No placeholder geometry is generated.');
const runtime=resolve(here,'../../machine-runtime/node_modules');
const esbuild=await import(pathToFileURL(resolve(runtime,'esbuild/lib/main.js')));
const three=resolve(runtime,'three');
const built=await esbuild.build({entryPoints:[resolve(here,'source/viewer.js')],bundle:true,write:false,format:'iife',target:'es2022',minify:true,alias:{'three/addons':resolve(three,'examples/jsm'),three:resolve(three,'build/three.module.js')},legalComments:'inline'});
const dev=process.argv.includes('--dev');
const output=resolve(here,dev?'viewer-dev.html':'mojave-source-assembly.html');
const stream=createWriteStream(output);
async function write(s){if(!stream.write(s))await once(stream,'drain');}
await write('<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><link rel="icon" href="data:,"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Mojave Sphinx · 源装配检视</title><meta name="description" content="原始CAD装配转换的中文检视页，包含源层级、实例身份和离线模型。"></head><body><div id="loading" role="status" aria-live="polite" style="position:fixed;inset:0;background:#f3f2ee;z-index:99;display:grid;place-items:center;font:14px system-ui"><div>正在读取源装配…<small id="loading-detail" style="display:block;margin-top:14px;color:#888">模型直接包含在此文件中</small></div></div>');
for(const asset of dev?[]:assets){
  await write(`<script id="model-${asset.id}" type="application/octet-stream">`);
  let carry=Buffer.alloc(0);
  for await(const chunk of createReadStream(resolve(here,asset.path),{highWaterMark:3*1024*1024})){
    const buf=carry.length?Buffer.concat([carry,chunk]):chunk;
    const end=buf.length-buf.length%3;
    await write(buf.subarray(0,end).toString('base64'));
    carry=buf.subarray(end);
  }
  if(carry.length)await write(carry.toString('base64'));
  await write('</script>');
}
await write('<script>'+built.outputFiles[0].text.replace(/<\/script/gi,'<\\/script')+'</script></body></html>');
stream.end();await once(stream,'finish');
console.log(JSON.stringify({html:output,asset_count:assets.length,offline:true}));
