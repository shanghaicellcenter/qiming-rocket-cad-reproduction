"""Prepare now, wait for actual download/verification/restoration marker, then test.
No old workspace payload, downloaded-file edits, network transfer, cleanup or kill.
"""
from pathlib import Path
import json,hashlib,datetime,subprocess,os,time,sys,plistlib,shutil
BASE=Path(__file__).resolve().parent.parent;REPORTS=BASE/'reports';PROJECT=BASE/'project';MARKER=REPORTS/'actual-download-receipt.json';BROWSER=REPORTS/'browser';MEDIA=REPORTS/'media';NODE=Path('/Users/qianqiming/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node');PW=NODE.parents[1]/'node_modules/playwright/index.mjs';CHROME=Path('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome');PROFILE=BASE/'deny-original-inputs.sb';MANIFEST='b5122c9f67b948f15e3f476e1bcd01f447593c46a6dff80292bd61994f314877';ATLAS='f968452fd599c43f2edb7f2ead8c381f0c0b13a2e7f37521516a36f8b29e9ca9'

def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  while b:=f.read(4*1024*1024):h.update(b)
 return h.hexdigest()
def save(p,v):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);q=p.with_suffix(p.suffix+'.tmp');q.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n');q.replace(p)
def event(state,**kw):
 r={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'state':state,**kw};save(REPORTS/'browser-media-driver-status.json',r);print(json.dumps(r,ensure_ascii=False),flush=True)
def run(label,command,env):
 event('running_'+label)
 with (REPORTS/(label+'.log')).open('w') as log:
  p=subprocess.run(['/usr/bin/sandbox-exec','-f',str(PROFILE),*map(str,command)],cwd=BASE,env=env,stdout=log,stderr=subprocess.STDOUT)
 if p.returncode:raise RuntimeError(label+' failed, exit='+str(p.returncode)+'; see '+str(REPORTS/(label+'.log')))

assert all(p.is_file() for p in [NODE,PW,CHROME,PROFILE,PROJECT/'review_downloaded.mjs',PROJECT/'browser_smoke.mjs'])
env=dict(os.environ,MACHINE_NODE=str(NODE),MACHINE_PLAYWRIGHT_MODULE=PW.as_uri(),MACHINE_CHROMIUM_EXECUTABLE=str(CHROME))
runtime={'node':str(NODE),'node_version':subprocess.check_output([str(NODE),'--version'],text=True).strip(),'playwright_module':PW.as_uri(),'playwright_version':json.loads((PW.parent/'package.json').read_text())['version'],'chromium_executable':str(CHROME),'chrome_version':plistlib.loads(Path('/Applications/Google Chrome.app/Contents/Info.plist').read_bytes())['CFBundleShortVersionString'],'actual_os_deny_profile':str(PROFILE),'os_deny_profile_sha256':sha(PROFILE),'original_payload_read_before_marker':False}
save(REPORTS/'browser-media-runtime-paths.json',runtime);event('waiting_for_actual_download_verify_restore_marker',payload_accessed=False)
while True:
 try:
  marker=json.loads(MARKER.read_text())
  if all(marker.get(k) is True for k in ['download_passed','verify_passed','restore_passed']):break
 except (FileNotFoundError,json.JSONDecodeError):pass
 time.sleep(10)
try:
 event('actual_marker_true_starting_fresh_acceptance',marker_sha256=sha(MARKER))
 assert sha(PROJECT/'release-manifest.json')==MANIFEST
 assert sha(PROJECT/'outputs/启明火箭/library/部件说明图册/部件说明图册.html')==ATLAS
 git=subprocess.check_output(['git','-C',str(PROJECT),'rev-parse','HEAD'],text=True).strip();assert git=='82c2a2a255b66556cead58ec3444f81f1757ae68'
 BROWSER.mkdir(exist_ok=True);MEDIA.mkdir(exist_ok=True)
 silent=PROJECT/'outputs/启明火箭/逐步虚拟归位.html';complete=BASE/'restored-lecture/逐步虚拟归位.html';movie=BASE/'restored-lecture/media/逐步虚拟归位讲解.mp4';timeline=PROJECT/'outputs/启明火箭/source/assembly-film/final-timeline.json'
 assert all(p.is_file() for p in [silent,complete,movie,timeline]), 'Missing actual output paths: '+str([str(p) for p in [silent,complete,movie,timeline] if not p.is_file()])
 before={str(p):sha(p) for p in [silent,complete,movie,PROJECT/'review_downloaded.mjs',PROJECT/'browser_smoke.mjs']}
 restoration=json.loads((BASE/'restored-lecture/local-restoration-check.json').read_text());assert restoration['complete_html_original_bytes_recovered'] is True and restoration['strict_full_decode_passed'] is True and restoration['video_and_audio_packet_sha256_match_prepublication_master'] is True and restoration['actual_frames']==6051
 run('downloaded_browser',[NODE,REPORTS/'review_downloaded_qa_adapted.mjs','--root',PROJECT,'--out',BROWSER],env)
 run('downloaded_silent_complete',[NODE,PROJECT/'browser_smoke.mjs','--silent',silent,'--complete',complete,'--out',MEDIA/'html'],env)
 ffprobe=shutil.which('ffprobe');assert ffprobe
 p=subprocess.run(['/usr/bin/sandbox-exec','-f',str(PROFILE),ffprobe,'-v','error','-show_entries','format=duration:stream=codec_type,codec_name,width,height,nb_frames,sample_rate,channels','-of','json',str(movie)],cwd=BASE,env=env,capture_output=True,text=True);assert p.returncode==0,p.stderr
 probe=json.loads(p.stdout);save(MEDIA/'actual-restored-ffprobe.json',probe)
 video=next(s for s in probe['streams'] if s['codec_type']=='video');audio=next(s for s in probe['streams'] if s['codec_type']=='audio');assert video['width']==1280 and video['height']==720 and int(video['nb_frames'])==6051 and audio['codec_name']=='aac' and audio['sample_rate']=='24000' and audio['channels']==1
 run('downloaded_movie',[NODE,REPORTS/'movie_browser_acceptance.mjs','--root',BASE,'--out',MEDIA/'movie','--movie',movie,'--timeline',timeline],env)
 browser=json.loads((BROWSER/'downloaded-browser-review.json').read_text());smoke=json.loads((MEDIA/'html/browser-smoke.json').read_text());mp4=json.loads((MEDIA/'movie/actual-movie-browser-review.json').read_text());atlas=next(r for r in browser['pages'] if '部件说明图册' in r['relative']);main=next(r for r in browser['pages'] if r['relative']=='整箭原件检视.html');assert browser['passed'] is True and len(browser['pages'])==6 and browser['total3DViewImagesDecoded']==615 and len(atlas['images'])==208 and main['initial']['sourceMeshIdentitiesLoaded']==688 and main['initial']['sourceHiddenMeshObjects']==3
 assert smoke['silent_and_complete_actual_play_seek_chapter_passed'] is True and smoke['downloaded_assets_test_claimed'] is False and len(smoke['rows'])==2
 for row in smoke['rows']:
  assert row['passed'] is True and row['playing']['evidence']['currentTime']>0 and row['chapter']['stage']==15
  if row['kind']=='complete':assert row['playing']['audio']['currentTime']>0 and row['playing']['audio']['paused'] is False and row['playing']['audio']['muted'] is False
  else:assert row['initial']['audio'] is None
 assert mp4['passed'] is True and len(mp4['keyframes'])==3
 for p,h in before.items():assert sha(Path(p))==h,'Payload changed during read-only acceptance: '+p
 result={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'programmatic_passed':True,'visual_review_pending':True,'passed':False,'scope':'Fresh actual public download acceptance; programmatic pass awaits actual screenshot visual inspection','repo':'https://github.com/shanghaicellcenter/qiming-rocket-cad-reproduction','commit':git,'manifest_sha256':MANIFEST,'actual_download_marker':{'path':str(MARKER),'sha256':sha(MARKER),'receipt':marker},'actual_os_original_input_deny_profile_used':True,'original_workspace_inputs_used':False,'runtime':runtime,'pages_passed':6,'source3D_views_decoded':615,'atlas_records':atlas['evidence']['recordCount'],'atlas_images_decoded':208,'source_mesh_identities':688,'source_hidden_meshes':3,'silent_and_complete_play_seek_chapter_passed':True,'complete_audio_clock_advanced_unmuted':True,'actual_restored_mp4_play_clock_unmuted_audio_video_decode_seek_passed':True,'actual_restored_mp4_frames':6051,'payload_scripts_and_media_bytes_unchanged':True,'payload_hashes':before,'downloaded_qa_script_adaptation':json.loads((REPORTS/'downloaded-review-script-adaptation.json').read_text()),'source_reports':{'browser':str(BROWSER/'downloaded-browser-review.json'),'html_playback':str(MEDIA/'html/browser-smoke.json'),'movie':str(MEDIA/'movie/actual-movie-browser-review.json'),'ffprobe':str(MEDIA/'actual-restored-ffprobe.json'),'restoration':str(BASE/'restored-lecture/local-restoration-check.json')},'screenshots':[str(p) for p in sorted(BROWSER.glob('*.png'))]+[str(p) for p in sorted((MEDIA/'html').glob('*.png'))]+[str(p) for p in sorted((MEDIA/'movie').glob('*.png'))],'limitations':['Chrome unmuted decoder/playback state is measured, not a claim of full human listening. Original browser_smoke downloaded_assets_test_claimed remains false; the actual network download receipt here supplies provenance.']}
 save(REPORTS/'runtime-review.json',result);event('programmatic_acceptance_passed_waiting_actual_visual_review',screenshots=len(result['screenshots']))
except Exception as exc:
 event('actual_acceptance_failed',error=type(exc).__name__+': '+str(exc));save(REPORTS/'runtime-review.json',{'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'passed':False,'error':str(exc),'actual_marker_received':True,'no_payload_changes_intended':True});raise
