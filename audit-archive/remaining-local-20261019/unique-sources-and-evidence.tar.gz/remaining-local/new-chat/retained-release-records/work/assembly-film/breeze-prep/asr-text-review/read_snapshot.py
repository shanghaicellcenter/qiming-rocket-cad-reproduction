"""Read existing JSON from this task's fixed Spark directory; no model calls."""
import base64
import datetime
import hashlib
import json
from pathlib import Path, PurePosixPath
import subprocess

ROOT = Path(__file__).resolve().parent
REMOTE_PROGRAM = r'''import pathlib,json,base64,hashlib
root=pathlib.Path('/home/qianqiming/codex-qiming-assembly-breeze-20261019')
ids=['intro']+[f'stage{i:02d}' for i in range(1,16)]+['outro']
files=[]
for clip_id in ids:
 for suffix in ['asr.json','sentence-alignment.json']:
  rel=f'results/{clip_id}/{clip_id}.{suffix}'
  p=root/rel
  if p.is_file() and p.resolve()==p:
   data=p.read_bytes()
   files.append({'relative_path':rel,'sha256':hashlib.sha256(data).hexdigest(),'base64':base64.b64encode(data).decode()})
p=root/'results/asr-process.json'
if p.is_file() and p.resolve()==p:
 data=p.read_bytes();files.append({'relative_path':'results/asr-process.json','sha256':hashlib.sha256(data).hexdigest(),'base64':base64.b64encode(data).decode()})
print(json.dumps({'files':files}))
'''


def main():
    command = ['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=10', 'spark',
               "python3 - <<'PY'\n" + REMOTE_PROGRAM + "\nPY"]
    result = subprocess.run(command, capture_output=True, text=True, timeout=30)
    result.check_returncode()
    payload = json.loads(result.stdout)
    files, new = [], []
    for item in payload['files']:
        relative = PurePosixPath(item['relative_path'])
        assert relative.parts[0] == 'results' and '..' not in relative.parts
        data = base64.b64decode(item['base64'])
        assert hashlib.sha256(data).hexdigest() == item['sha256']
        path = ROOT.joinpath(*relative.parts)
        path.parent.mkdir(parents=True, exist_ok=True)
        if path.exists() and relative.name != 'asr-process.json':
            assert path.read_bytes() == data, f'ASR evidence changed: {relative}'
        else:
            if not path.exists():
                new.append(str(relative))
            path.write_bytes(data)
        files.append({'relative_path': str(relative), 'sha256': item['sha256'], 'bytes': len(data)})
    record = {'read_only_ssh_snapshot_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'remote_root': '/home/qianqiming/codex-qiming-assembly-breeze-20261019', 'files': files}
    (ROOT / 'progress').mkdir(exist_ok=True)
    (ROOT / 'progress/snapshot-latest.json').write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'asr_count': sum(p['relative_path'].endswith('.asr.json') for p in files),
                      'new': new, 'timestamp': record['read_only_ssh_snapshot_utc']}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
