// Bundle only the unmodified Machine kit and pinned THREE dependencies.
// No project scene, no network requests, and no operational simulation is added.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import esbuild from './node_modules/esbuild/lib/main.js';

const here = path.dirname(fileURLToPath(import.meta.url));
const workspace = path.resolve(here, '../..');
const vendor = path.join(workspace, 'outputs/mojave-machine/source/vendor/machine');
const output = path.resolve(process.argv[2] || path.join(here, 'lab-kit.bundle.js'));
const result = await esbuild.build({
  entryPoints: [path.join(vendor, 'kit/lab-kit.js')],
  bundle: true, format: 'iife', platform: 'browser', target: ['chrome120'],
  minify: true, write: false, nodePaths: [path.join(here, 'node_modules')],
  legalComments: 'eof',
});
fs.mkdirSync(path.dirname(output), { recursive: true });
fs.writeFileSync(output, result.outputFiles[0].contents);
console.log(JSON.stringify({ output, bytes: result.outputFiles[0].contents.byteLength }));
