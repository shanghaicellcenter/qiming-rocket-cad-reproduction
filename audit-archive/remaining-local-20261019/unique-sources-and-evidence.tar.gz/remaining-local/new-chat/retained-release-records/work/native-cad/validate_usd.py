import hashlib
import json
import os
import sys
from collections import Counter
from pathlib import Path
import usd_convert_cad  # Official wheel bootstrap exposes its bundled pxr runtime.
# The Linux loader reads LD_LIBRARY_PATH at process startup. Re-exec once after
# the official package has added its bundled native library directory.
if sys.platform.startswith("linux") and os.environ.get("MOJAVE_USD_BOOTSTRAPPED") != "1":
    os.environ["MOJAVE_USD_BOOTSTRAPPED"] = "1"
    os.execv(sys.executable, [sys.executable, *sys.argv])
from pxr import Usd, UsdGeom

path = Path(sys.argv[1]).resolve()
stage = Usd.Stage.Open(str(path))
if not stage:
    raise SystemExit("USD stage could not be opened")
def serial(value):
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, dict):
        return {str(k): serial(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [serial(v) for v in value]
    return str(value)

prims = list(Usd.PrimRange(stage.GetPseudoRoot(), Usd.TraverseInstanceProxies()))
meshes = []
hierarchy = []
for prim in prims:
    if prim.IsPseudoRoot():
        continue
    xf = UsdGeom.Xformable(prim)
    matrix = xf.GetLocalTransformation() if xf else None
    refs = []
    for spec in prim.GetPrimStack():
        if spec.HasInfo("references"):
            refs.append({"layer": spec.layer.identifier, "spec_path": str(spec.path),
                         "references": str(spec.GetInfo("references"))})
    hierarchy.append({
        "path": str(prim.GetPath()), "parent": str(prim.GetParent().GetPath()),
        "name": prim.GetName(), "display_name": serial(prim.GetMetadata("displayName")),
        "type": prim.GetTypeName(), "kind": serial(prim.GetMetadata("kind")),
        "custom_data": serial(prim.GetCustomData()), "asset_info": serial(prim.GetAssetInfo()),
        "instance": prim.IsInstance(), "instance_proxy": prim.IsInstanceProxy(),
        "prototype": prim.IsPrototype(),
        "prototype_path": str(prim.GetPrototype().GetPath()) if prim.IsInstance() else None,
        "references_from_specs": refs,
        "local_transform": [[float(matrix[i][j]) for j in range(4)] for i in range(4)] if matrix is not None else None,
        "reset_xform_stack": xf.GetResetXformStack() if xf else None,
        "visible": str(UsdGeom.Imageable(prim).ComputeVisibility()) if prim.IsA(UsdGeom.Imageable) else None,
    })
    if prim.IsA(UsdGeom.Mesh):
        mesh = UsdGeom.Mesh(prim)
        points = mesh.GetPointsAttr().Get() or []
        counts = mesh.GetFaceVertexCountsAttr().Get() or []
        indices = mesh.GetFaceVertexIndicesAttr().Get() or []
        provider = [{"layer": s.layer.identifier, "property_path": str(s.path)}
                    for s in mesh.GetPointsAttr().GetPropertyStack()]
        meshes.append({"path": str(prim.GetPath()), "points": len(points),
                       "faces": len(counts), "indices": len(indices),
                       "visible": str(UsdGeom.Imageable(prim).ComputeVisibility()),
                       "instance_proxy": prim.IsInstanceProxy(),
                       "point_attribute_providers": provider})
unique_providers = {json.dumps(m["point_attribute_providers"], sort_keys=True) for m in meshes}
result = {
    "output": str(path), "bytes": path.stat().st_size,
    "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
    "mesh_count": len(meshes),
    "nonempty_mesh_count": sum(m["points"] > 0 and m["faces"] > 0 for m in meshes),
    "point_count": sum(m["points"] for m in meshes),
    "face_count": sum(m["faces"] for m in meshes),
    "prim_count_with_instance_proxies": len(hierarchy),
    "kind_counts": dict(Counter(row["kind"] or "unclassified" for row in hierarchy)),
    "component_kind_node_count": sum(row["kind"] == "component" for row in hierarchy),
    "default_traverse_prim_count": sum(1 for _ in stage.Traverse()),
    "native_instance_count": sum(p.IsInstance() for p in prims),
    "instance_proxy_prim_count": sum(p.IsInstanceProxy() for p in prims),
    "native_prototype_count": len(stage.GetPrototypes()),
    "unique_point_attribute_provider_count": len(unique_providers),
    "mesh_count_is_not_part_count": True,
    "meters_per_unit": UsdGeom.GetStageMetersPerUnit(stage),
    "up_axis": str(UsdGeom.GetStageUpAxis(stage)),
    "used_layers": [layer.identifier for layer in stage.GetUsedLayers()],
    "meshes": meshes,
}
report = path.with_suffix(".validation.json")
report.write_text(json.dumps(result, indent=2) + "\n")
path.with_suffix(".hierarchy.json").write_text(json.dumps({"source_usd": str(path), "prims": hierarchy}, indent=2) + "\n")
print(json.dumps({k: v for k, v in result.items() if k != "meshes"}, indent=2))
if not result["nonempty_mesh_count"]:
    raise SystemExit("converted USD has no nonempty mesh")
