from pathlib import Path
import hashlib, json
from datetime import datetime, timezone

root = Path('/Users/qianqiming/Documents/Codex/2026-10-19/new-chat')
out = root / 'outputs/mojave-machine/library/source-drawings'
p = out / 'index.json'
m = json.loads(p.read_text())
sha = lambda q: hashlib.sha256(q.read_bytes()).hexdigest()
assert sha(Path(m['source_pdf'])) == m['source_pdf_sha256']
for row in m['rows']:
    assert sha(out / row['image']) == row['image_sha256']
    row['visual_review'] = 'passed actual whole-page contact-sheet inspection; full source page frame visible, no blank page or clipped frame'

review = {
    'reviewed_at_utc': datetime.now(timezone.utc).isoformat(),
    'method': 'Actual image viewing of all four whole-page contact sheets, plus full-resolution images and a native Chrome file:// UI review; not source-code inspection alone',
    'whole_page_visual_coverage': list(range(1, 14)),
    'contact_sheets_actually_viewed': m['contact_sheets'],
    'full_resolution_spot_checks': [
        {'physical_pdf_page': i, 'image': f'page-{i:02d}.png', 'sha256': sha(out / f'page-{i:02d}.png'), 'result': 'full page frame and title area retained; source lettering visibly legible at supplied image resolution'}
        for i in (1, 7, 13)
    ],
    'blank_pages_found': 0,
    'clipped_source_page_frames_found': 0,
    'content_transcribed_or_reconstructed': False,
    'result': 'passed'
}
browser = {
    'reviewed_at_utc': review['reviewed_at_utc'],
    'browser': 'Google Chrome, native macOS UI via CUA',
    'url_scheme': 'file',
    'html': '原图纸浏览.html',
    'html_sha256': sha(out / '原图纸浏览.html'),
    'checks': [
        {'name': 'local HTML opens and lists thirteen physical-page cards', 'result': 'passed'},
        {'name': 'first-page card opens full-frame modal image', 'result': 'passed'},
        {'name': 'right-arrow navigation through pages 2 to 13, matching page label and image identity in accessibility state', 'result': 'passed', 'physical_pages': list(range(2, 14))},
        {'name': 'page 13 to 1 and page 1 to 13 wrap with arrow keys', 'result': 'passed'},
        {'name': 'native-resolution mode changes button to fit-window mode', 'result': 'passed'},
        {'name': 'open-PNG action from page 13 opens actual page-13.png (1600x1131) in a new tab', 'result': 'passed'},
        {'name': 'Escape closes modal and restores page-card list', 'result': 'passed'},
        {'name': 'seventh-page card opens the correct modal, close button returns to list', 'result': 'passed'},
        {'name': 'actual browser screenshots of modal pages 1 and 13 show full source page frame', 'result': 'passed'}
    ],
    'desktop_interaction_result': 'passed',
    'mobile_viewport_result': 'not tested; responsive CSS is present but is not counted as a runtime mobile test',
    'network_requests_instrumented': False,
    'javascript_errors_instrumented': False,
    'scope_note': 'All 13 PNG files were independently decoded and visually covered by contact sheets. Page identities were stepped through in the live browser. No claim of a browser console/network audit or native SLDDRW parsing.'
}
m['visual_review'] = review
m['browser_check'] = {'desktop_interaction_result': 'passed', 'detail_file': 'browser-check.json', 'mobile_viewport_result': 'not tested'}
m['source_pdf_hash_rechecked_after_render'] = True
p.write_text(json.dumps(m, ensure_ascii=False, indent=2) + '\n')
(out / 'visual-review.json').write_text(json.dumps(review, ensure_ascii=False, indent=2) + '\n')
(out / 'browser-check.json').write_text(json.dumps(browser, ensure_ascii=False, indent=2) + '\n')
(out / '说明.md').write_text('''# 原PDF图纸的直接可视化

这13张PNG来自独立图纸PDF，按物理第1至13页直接渲染，保留整页MediaBox与页框；每页1600×1131像素，图片合计3,110,555字节。原PDF未修改，渲染后再次核对SHA256与最初源资料清单一致。图纸内容未重画或提炼成参数表。

13页的完整页框总览已经全部实看，第1、7、13页另作原尺寸文字与页框抽查，未发现空白或页框裁切。桌面Chrome实际打开本地HTML，逐页翻阅并检查放大、首尾循环、原尺寸切换、PNG新页链接、Esc和关闭按钮。手机尺寸尚未实测，也没有把源码检查算作网络或控制台实测。

本项验证的是PDF页面覆盖，属于原PDF直接可视化；未解析SLDDRW原生图纸。13页单独计数，三维源件170记录、510张三视图的统计保持不变。

[打开图纸浏览](原图纸浏览.html) · [来源、哈希与逐页核对](index.json) · [视觉核对](visual-review.json) · [浏览器实测](browser-check.json)
''')
print(json.dumps({'pages': len(m['rows']), 'png_bytes': m['image_bytes'], 'all_directory_bytes': sum(q.stat().st_size for q in out.iterdir() if q.is_file()), 'source_sha256': m['source_pdf_sha256'], 'visual_review': 'passed', 'desktop_ui': 'passed', 'mobile': 'not tested'}, ensure_ascii=False))
