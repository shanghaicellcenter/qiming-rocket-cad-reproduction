# 原生装配来源对照准备（中间研究）

只读取源ZIP目录和资料的版本/文件名信息；没有打开原生整箭、没有提炼制造或操作参数。Spark转换结果仍在验证，本文件不写其最终状态。

主整箭文件候选为 **`Mojave Sphinx Vehicle Assembly.SLDASM`**，位于 `英文原件/Mojave Sphinx CAD - R01.zip` 的 `Mojave Sphinx CAD - R01/` 下。这个候选依据原文件名确定；指南全文没有明确的 `.SLDASM` 文件名或原件引用清单，不能由指南或ZIP目录证明它的子件引用已经完整解析。

## 可作为对照基准的已知事实

- 主CAD ZIP有 **149 个文件记录**：119个SLDPRT、14个SLDASM、13个SLDDRW、3个免责声明/许可TXT。原生几何与装配身份对照目录共 **133 条**，已逐条保存在JSON。
- 这些源文件位于同一个目录；这是一份平铺文件清单，不是装配树。
- README说明原生CAD由 **SolidWorks 2022学生版**创建；指南版本表为 **修订01，首次发布17 Aug 2024**。它们是资料声明，未从每个CAD二进制提取内部版本。
- README另说明截至 **June 2026**有BOM和HCR-5105追加资料。补丁包单独存在，含PDF、SLDPRT、STEP各一份；未验证其是否合入R01主装配。
- **原件引用覆盖、缺失引用数、实例数、配合、配置和抑制状态均未知。** 119个零件文件不等于119个装配实例，14个装配文件也不能直接展开为14个真实层级。

## 源装配候选名单

此表只登记文件身份，不推断父子关系。

| 原文件名 | 暂定目录角色 | 引用/配合状态 |
|---|---|---|
| AVBY-ASSM Avbay Assembly, Mojave Sphinx.SLDASM | 电子舱外观子装配候选 | 未解析 |
| Igniter Cartridge COTS NPT Fittings.SLDASM | 其他源装配目录记录 | 未解析 |
| Mojave Sphinx Airframe Assembly.SLDASM | 箭体外观子装配候选 | 未解析 |
| Mojave Sphinx Avbavy Sled Assembly.SLDASM | 电子舱托板子装配候选（保留原拼写 Avbavy） | 未解析 |
| Mojave Sphinx Fin Bracket Assembly.SLDASM | 尾翼支架子装配候选；不等于尾翼本体 | 未解析 |
| Mojave Sphinx Fuel Bulkhead Subassambly.SLDASM | 其他源装配目录记录 | 未解析 |
| Mojave Sphinx Nut Retaining Ring Subassembly.SLDASM | 其他源装配目录记录 | 未解析 |
| Mojave Sphinx Oxidizer Bulkhead Subassembly.SLDASM | 其他源装配目录记录 | 未解析 |
| Mojave Sphinx Propulsion Assembly.SLDASM | 其他源装配目录记录 | 未解析 |
| Mojave Sphinx Tank Assembly.SLDASM | 其他源装配目录记录 | 未解析 |
| Mojave Sphinx Thrust Chamber Assembly.SLDASM | 其他源装配目录记录 | 未解析 |
| Mojave Sphinx Vehicle Assembly.SLDASM | 主整箭文件候选 | 未解析 |
| NSCN-ASSM Nose Cone Assembly, Mojave Sphinx.SLDASM | 头锥外观子装配候选 | 未解析 |
| SABV-04FF Servo Actuated Ball Valve Assembly, Mojave Sphinx.SLDASM | 其他源装配目录记录 | 未解析 |

## 后续USD对照的边界

核对实际转换输入来源，再以USD保留的来源文件元数据匹配JSON原名。不得把USD网格对象数、prim数、原型数和实例数混为一个计数。缺失、被抑制、隐藏、配置未选中和转换失败应分别记录；没有证据时留未知。静态几何位置和层级读取不等于原生配合约束已求解。原名中的 `Avbavy`、`Subassambly` 等拼写原样保留，不自动创建更正后的新原件。

## 现有研究文档拟更新点

结构化 `coverage.json` 与 `safe-appearance-candidates.json` 当前已将十件标记为STL解析/显示验证，余下211条保持未进入页面；这两个JSON不再存在“十件仍全部未导入”的问题。以下旧正文仍需按阶段更新，但本任务不改最终状态：

- `research/覆盖与缺口.md`：第11行将所有交换文件统称未导入，第17行称每个原件均未对应模型，与第22行已显示十件的后续状态冲突。 更新时：保留最初目录审计为有日期的历史快照；现状分为已验证十件STL、其余目录记录、未解析原生装配三层。不得将211条未进入页面记录称作缺失零件数。
- `research/可视化源与缺口.md`：主体仍写所有行未导入、未确认解码及十件均未导入；末尾第67行和当前JSON已确认十件读取显示。 更新时：将主体表格和初始核查文字与当前已验证状态同步；保留原始格式缺口说明，但转换产生新网格后应标作原包无同名STL、新转换文件另列来源。
- `research/资料审计.md`：初始目录审计中的未解压/未做几何对照属于早期阶段，但末尾追加十件几何验证；无阶段标识时容易被读为同一时点。 更新时：明确分开源目录审计时间与后续允许清单STL读取/浏览器验收时间；源文件哈希与PDF页数无需因此改写。
- `research/native-cad-readiness.md`：结论是限定Mac环境核查；第15行“尚未执行任何原生CAD转换”容易被误读为包含正在验证的Spark。 更新时：改为此次Mac核查未执行原生CAD转换；Spark转换独立按实际版本、输入来源、退出状态、输出可读性、实例/来源核对结果另记。当前不提前改成已成功。
- `research/source-manifest.json`：该字段仍描述最初未解压阶段；来源哈希及ZIP目录清单本身仍有效。 更新时：注明这是源目录捕获阶段的范围，不把它当作当前全部处理历史。后续转换证据使用独立manifest，不覆盖源哈希。
- `research/geometry-index.json`：当前只索引十件STL，并非原生CAD的最终覆盖表。unsupported_sources描述当前缺少导入，不应在原生转换后继续作为永久不支持结论。 更新时：在Spark结果验证后补充独立native-CAD转换索引/实例对应，保留原十件STL来源与哈希。不要把网格数直接改写成零件实例数。

## 原包交换格式备选的完整目录清点

`source-exchange-map.json` 与 `.csv` 已按全部原始STEP/STL记录分组，不局限于此前十件。共 **71 条三维交换文件记录**（STEP 35、STL 36），按去后缀、忽略大小写的文件名称分成 **37 组**：34组同时有STEP和STL，1组仅有STEP，2组仅有STL。原始重复格式各保留ZIP/成员来源。另有 **3条DXF记录**，单列而不充作三维STEP/STL。

在全部120条原生SLDPRT源记录中，有 **35 个名称组**可与交换记录作名称匹配，**85 条SLDPRT**没有同名STEP/STL；另外 **2 个交换名称组**未找到同名SLDPRT。这些只是目录名称匹配，不是几何等价证明或实例覆盖率。原生读取若失败，已有交换格式仍不能据此称为涵盖全部部件或还原装配层级。

拟更新研究文档中的过宽措辞：用“哪些源文件实际已读取、转换、验证，哪些尚未完成”替代笼统“不能读取原CAD/不能整体导入”。忠实来源的格式转换与原生配合求解、制造验证、飞行验证分别记录，不把它们互相等同，也不新增或补造任何工程设计与操作流程。
