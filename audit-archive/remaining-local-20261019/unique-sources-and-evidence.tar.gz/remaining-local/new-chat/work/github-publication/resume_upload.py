import subprocess,json,os,hashlib,datetime
from pathlib import Path
p=Path(__file__).resolve().parent
r=json.loads(subprocess.check_output(["/opt/homebrew/bin/gh","api","repos/shanghaicellcenter/qiming-rocket-cad-reproduction/releases/417612933"]))
assert r["draft"]
remote={a["name"]:a for a in r["assets"]}
missing=[]
for f in sorted((p/"release-assets").iterdir()):
 if f.name in remote:
  a=remote[f.name];h=hashlib.sha256(f.read_bytes()).hexdigest()
  assert a["state"]=="uploaded" and a["size"]==f.stat().st_size and a["digest"]=="sha256:"+h,f.name
 else:missing.append(str(f))
print(json.dumps({"preserved_actual_completed":list(remote),"uploading_missing_count":len(missing),"http2_client_disabled_for_this_process_only":True}),flush=True)
env=os.environ.copy();env["GODEBUG"]="http2client=0"
subprocess.run(["/opt/homebrew/bin/gh","release","upload","v1.0.0","--repo","shanghaicellcenter/qiming-rocket-cad-reproduction",*missing],env=env,check=True)
