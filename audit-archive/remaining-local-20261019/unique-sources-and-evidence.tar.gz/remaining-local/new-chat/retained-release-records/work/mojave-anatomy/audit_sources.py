from pathlib import Path
from collections import Counter
from datetime import datetime, timezone
import hashlib, json, re, zipfile

SOURCE = Path('/Users/qianqiming/Desktop/火箭设计 中文版')
OUT = Path('/Users/qianqiming/Documents/Codex/2026-10-19/new-chat/outputs/mojave-anatomy/research')
files = sorted((p for p in SOURCE.rglob('*') if p.is_file()), key=lambda p: p.relative_to(SOURCE).as_posix())
records = []
zip_member_extensions = Counter()
for p in files:
    digest = hashlib.sha256()
    with p.open('rb') as stream:
        for block in iter(lambda: stream.read(1024*1024), b''):
            digest.update(block)
    item = {'relative_path': p.relative_to(SOURCE).as_posix(), 'bytes': p.stat().st_size, 'sha256': digest.hexdigest()}
    if p.suffix.lower() == '.zip':
        with zipfile.ZipFile(p) as archive:
            members = []
            for z in archive.infolist():
                members.append({'name': z.filename, 'uncompressed_bytes': z.file_size, 'compressed_bytes': z.compress_size, 'crc32': f'{z.CRC:08x}', 'is_directory': z.is_dir()})
                if not z.is_dir():
                    zip_member_extensions[Path(z.filename).suffix.lower() or '<none>'] += 1
            item['zip'] = {'member_count': len(members), 'file_member_count': sum(not m['is_directory'] for m in members), 'uncompressed_bytes': sum(m['uncompressed_bytes'] for m in members), 'members': members, 'verification': 'Central-directory metadata read only; members not extracted; CRC values recorded, payload integrity not tested.'}
    records.append(item)

main = SOURCE / '中文文档/01-HCR-5100 建造集成与发射指南-中文版.md'
source_text = main.read_text(encoding='utf-8')
lines = source_text.splitlines()
page = None
markers = []
headings = []
for line_number, line in enumerate(lines, 1):
    mark = re.match(r'^`?〔原书 p\.(\d+)〕`?\s*$', line)
    if mark:
        page = int(mark.group(1))
        markers.append({'source_line': line_number, 'printed_page': page})
    heading = re.match(r'^(#{1,2})\s+(.+?)\s*$', line)
    if heading:
        headings.append({'level': len(heading.group(1)), 'title': heading.group(2), 'source_line': line_number, 'printed_page': page, 'page_basis': 'preceding standalone printed-page marker' if page is not None else 'unnumbered front matter; physical PDF page not verified'})
refs = re.findall(r'!\[[^\]]*\]\(([^)]+)\)', source_text)
image_files = sorted(p for p in (main.parent/'images').iterdir() if p.is_file())
missing = [r for r in refs if not (main.parent/r).is_file()]
marker_values = [m['printed_page'] for m in markers]
coverage = {'standalone_marker_count': len(markers), 'unique_printed_pages': len(set(marker_values)), 'first_printed_page': min(marker_values), 'last_printed_page': max(marker_values), 'missing_printed_pages_within_range': [n for n in range(min(marker_values), max(marker_values)+1) if n not in set(marker_values)], 'duplicate_printed_pages': [n for n,c in Counter(marker_values).items() if c>1], 'image_reference_count': len(refs), 'unique_image_reference_count': len(set(refs)), 'image_file_count': len(image_files), 'missing_referenced_image_count': len(missing), 'missing_referenced_image_paths': missing}

manifest = {'schema_version': 1, 'generated_utc': datetime.now(timezone.utc).isoformat(), 'source_root': str(SOURCE), 'audit_scope': 'Read-only file and archive metadata inventory. No engineering file extraction or model reconstruction.', 'file_count_including_metadata': len(records), 'file_count_excluding_ds_store': sum(p.name!='.DS_Store' for p in files), 'total_bytes': sum(r['bytes'] for r in records), 'loose_extension_counts': dict(sorted(Counter(p.suffix.lower() or '<none>' for p in files).items())), 'zip_file_member_extension_counts': dict(sorted(zip_member_extensions.items())), 'guide_markdown_coverage': coverage, 'pdf_physical_page_counts': {'status': 'not_verified', 'reason': 'No PDF parsing library was available in this audit; PDF contents were not parsed.'}, 'files': records}
(OUT/'source-manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
(OUT/'section-index.json').write_text(json.dumps({'schema_version':1, 'source_relative_path':main.relative_to(SOURCE).as_posix(), 'scope':'Only Markdown levels 1 and 2. No subordinate operations, dimensions, parameters, or procedure text included.', 'pagination_note':'printed_page is read from the preceding standalone source page marker; front matter is null. This is not a verified physical PDF page number.', 'guide_markdown_coverage':coverage, 'headings':headings}, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')

archive_records=[r for r in records if 'zip' in r]
rows='\n'.join(f"| {r['relative_path'].split('/')[-1]} | {r['zip']['member_count']} | {r['zip']['file_member_count']} |" for r in archive_records)
report=f'''# 本地资料完整性审计

对象：`{SOURCE}`。本次仅做只读文件清单、归档目录与指南高层结构核查；没有解压工程文件，没有打开装配模型，也没有复制原始图纸或制造指南到输出目录。

## 实测结果

- 共 **{len(records)} 个文件**，合计 **{sum(r['bytes'] for r in records):,} 字节**。其中系统元数据 `.DS_Store` 为 2 个，排除后为 **{sum(p.name!='.DS_Store' for p in files)} 个文件**。
- 松散文件包含 **6 个 ZIP、2 个 PDF、6 个 DOCX、2 个 XLSX、1 个 PPTX、8 个 Markdown、2 个 TXT**，另有 **365 个独立图片文件**。
- 指南 Markdown 中实测 **360 个独立页码标记**，编号为 **1–360**，区间内无缺号、无重复。该数字描述译本页码覆盖，不等同于原 PDF 的物理页数。
- 指南 Markdown 实测 **365 处图片引用**，引用路径各不相同；目录内实测 **365 张图片**，所引用图片均存在。这里只验证引用与文件存在，未逐张判断画面、图注与原 PDF 的对应关系。
- 指南 Markdown 的 **3 个一级标题、18 个二级标题**已列入 `section-index.json`；前言部分没有正文页码标记，记作 `null`。
- 六个 ZIP 共记录 **{sum(r['zip']['member_count'] for r in archive_records)} 个归档成员**，其中 **{sum(r['zip']['file_member_count'] for r in archive_records)} 个是文件成员**。成员名称、长度和中央目录 CRC 见清单；没有对成员内容做解压或 CRC 复算。

| 归档包 | 全部成员 | 文件成员 |
|---|---:|---:|
{rows}

## 原生模型与格式边界

归档目录确认存在 **{zip_member_extensions['.sldasm']} 个原生装配体文件名（SLDASM）**、**{zip_member_extensions['.sldprt']} 个原生零件文件名（SLDPRT）**和 **{zip_member_extensions['.slddrw']} 个原生图纸文件名（SLDDRW）**。这些是 ZIP 目录中的文件记录；不能据此确认引用关系完整、装配体可成功打开，或与其他修订版本一致。原生装配文件不以松散文件形式出现。

交换格式目录中有 STEP、STL、DXF 文件记录。尚未验证本机具体软件对原生文件或 STEP 的导入支持，也未验证不同格式之间的零件对应、拓扑、装配约束、外观及精度。STL 等网格文件的存在不能证明原生装配约束已被保存。仿真包仅登记文件名与格式，没有执行或读取仿真参数。

资料中存在独立修订包及其中文文档。这里只确认存在，不复述修订内容、实施方式或受影响参数。未验证修订包与主 CAD 包的同步状态。

## 页数与完整性的未验证项

指南译本开头自述原文共 369 页；**该数字不是本次 PDF 实测值**。本次环境未发现可用的 PDF 解析库，因此两个松散 PDF 及修订包内 PDF 的物理页数均记为未验证。360 个正文页码标记与自述物理页数的差异未据此认定为缺页，也未确认前置页与正文的对应关系。

DOCX 的分页、嵌入图片、公式和交叉引用，XLSX 的单元格内容与公式，以及 PPTX 的逐页内容与媒体均未审阅。各译本、原件和不同导出格式之间的语义一致性未验证。未打开原生 CAD、未进行装配求解或几何对照，因此这份审计不构成“项目已完整复现”的证明。

`source-manifest.json` 已为每个松散文件实测 SHA256 和字节数，可用于后续核对来源文件是否变化；ZIP 成员的 CRC 仅为归档目录中的声明值。本次无源文件修改操作。
'''
(OUT/'资料审计.md').write_text(report,encoding='utf-8')
print(json.dumps({'files':len(records),'bytes':sum(r['bytes'] for r in records),'zip_members':sum(r['zip']['member_count'] for r in archive_records),'zip_file_members':sum(r['zip']['file_member_count'] for r in archive_records),'native_assembly_count':zip_member_extensions['.sldasm'],'guide_coverage':coverage,'outputs':[str(OUT/n) for n in ['source-manifest.json','section-index.json','资料审计.md']]},ensure_ascii=False,indent=2))
