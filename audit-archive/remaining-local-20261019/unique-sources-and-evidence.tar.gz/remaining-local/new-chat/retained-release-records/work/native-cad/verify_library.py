"""Verify passive R01 conversion coverage against the unchanged source ZIP."""
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent
ZIP = Path('/Users/qianqiming/Desktop/火箭设计 中文版/英文原件/Mojave Sphinx CAD - R01.zip')
lib = ROOT / 'library'
summary = json.loads((lib / 'summary.json').read_text())
results = summary['results'] + [json.loads((ROOT / 'vehicle.conversion.json').read_text())]
by_source = {r['source_basename'] if 'source_basename' in r else Path(r['source']).name: r for r in results}
checks=[]
with zipfile.ZipFile(ZIP) as archive:
    expected=[i for i in archive.infolist() if Path(i.filename).suffix.upper() in ('.SLDPRT','.SLDASM') and not i.filename.startswith('__MACOSX/')]
    for info in expected:
        name=Path(info.filename).name
        row=by_source.get(name)
        source_sha=hashlib.sha256(archive.read(info)).hexdigest()
        if row:
            output = ROOT/'vehicle.usdc' if name=='Mojave Sphinx Vehicle Assembly.SLDASM' else lib/('parts' if name.endswith('.SLDPRT') else 'assemblies')/(Path(name).stem+'.usdc')
            manifest_sha = row.get('input_sha256_before') or row.get('input_sha256')
            manifest_after = row.get('input_sha256_after')
            output_sha=hashlib.sha256(output.read_bytes()).hexdigest() if output.exists() else None
            audit_file=output.with_suffix('.validation.json')
            audit=json.loads(audit_file.read_text()) if audit_file.exists() else {}
            checks.append({'source_basename':name,'source_zip_sha256':source_sha,'source_hash_matches_before': source_sha==manifest_sha,'source_hash_matches_after':source_sha==manifest_after,'output_local':str(output),'output_exists':output.exists(),'output_sha256':output_sha,'output_hash_matches_manifest':output_sha==row.get('output_sha256'),'nonempty_mesh_count':audit.get('nonempty_mesh_count'),'mesh_occurrence_count':audit.get('mesh_count'),'mesh_count_is_not_part_count':True,'status':row.get('status','converted' if row.get('return_code')==0 else 'unknown')})
        else:
            checks.append({'source_basename':name,'missing_conversion':True})
result={'revision_group':'main-R01','source_zip':str(ZIP),'source_cad_count':len(expected),'source_part_count':sum(Path(i.filename).suffix.upper()=='.SLDPRT' for i in expected),'source_assembly_count':sum(Path(i.filename).suffix.upper()=='.SLDASM' for i in expected),'converted_cad_count':len(by_source),'verified_output_count':sum(c.get('output_hash_matches_manifest',False) for c in checks),'source_hash_match_count':sum(c.get('source_hash_matches_before',False) and c.get('source_hash_matches_after',False) for c in checks),'nonempty_output_count':sum((c.get('nonempty_mesh_count') or 0)>0 for c in checks),'missing_cad_basenames':sorted(set(Path(i.filename).name for i in expected)-set(by_source)),'extra_cad_basenames':sorted(set(by_source)-set(Path(i.filename).name for i in expected)),'library_bytes':sum(p.stat().st_size for p in lib.rglob('*') if p.is_file()),'conversion_options':{'tess_lod':3,'instancing_style':'reference','composition_style':'none','filter_style':'hide','load_hidden':True,'read_constraints':False,'physics':False},'scope':'Faithful passive geometry format conversion. Nonempty mesh/hash checks do not alone constitute visual acceptance, design validation, or proof that a CAD source itself contains every intended project component.','checks':checks}
result['passed']=not result['missing_cad_basenames'] and not result['extra_cad_basenames'] and result['verified_output_count']==len(expected) and result['source_hash_match_count']==len(expected) and result['nonempty_output_count']==len(expected)
(ROOT/'library.coverage.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='checks'},indent=2))
if not result['passed']:raise SystemExit(1)
