# Machine runtime

Ready for the parent task to build. Existing complete packages are reused through local `node_modules` links:

- THREE **0.170.0**: `/Users/qianqiming/Desktop/skill-repos/cclank--cell-architecture-studio/node_modules/stats-gl/node_modules/three`
- esbuild **0.27.7**: `/Users/qianqiming/Desktop/skill-repos/cclank--cell-architecture-studio/node_modules/esbuild`
- Playwright **1.62.1**: `/Users/qianqiming/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs`
- Chromium-compatible executable: `/Applications/Google Chrome.app/Contents/MacOS/Google Chrome`

The initial isolated npm attempt used `--ignore-scripts --no-audit --no-fund`; its writer was terminated when the exact existing THREE version and complete esbuild were found. PID 78737 was confirmed absent with ESRCH. The partial download is retained only under this directory; no shared package is deleted. `package.json` records the reused versions, not a completed npm installation.

Actual checks: esbuild synchronous transform passed; the complete Machine kit bundled successfully into `lab-kit.bundle.js`; separate headless Chrome **155.0.8059.80** opened a fresh profile and rendered a generic WebGL2 clear frame using **ANGLE Metal / Apple M4**. `webgl-smoke.png` was opened and visually inspected. These tests do not validate the project's scene, material shaders, interactions or film.

Rebuild the kit bundle from the unmodified copied kit:

```sh
node work/machine-runtime/bundle-kit.mjs
```

`lab-kit.bundle.js` is an IIFE that already includes pinned THREE and the kit's addons, and sets `window.LabKit`. To make a truly offline HTML, embed it as an ordinary `<script>` before the scene script, remove the import map and external font links, use a local/system Chinese font, and inline the project scene/data. Escape closing script sequences when inserting JavaScript into HTML. Do not set the Lab `hdri` option or add remote assets. Check the browser's network requests to verify no external dependency remains.

The copied screenshot/record scripts are in `outputs/mojave-machine/source/vendor/machine/scripts`. Its `browser.mjs` adapts normal imports to bundled Playwright and uses existing Chrome if the expected Playwright Chromium revision is unavailable. Environment overrides are documented in the delivered `vendor/machine/PATCHES.md`. Use the copied scripts, not the original repository scripts, for this local runtime.

`runtime-status.json` records paths, tested versions, bundle size/hash and test boundaries. No main project page or film was rendered in this runtime preparation subtask.
