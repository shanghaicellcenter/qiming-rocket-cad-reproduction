from pathlib import Path
import json,re,hashlib
R=Path('/Users/qianqiming/Documents/Codex/2026-10-19/new-chat');O=R/'outputs/virtual-assembly'
N=json.loads((R/'work/virtual-assembly/narration-draft.json').read_text());A=json.loads((O/'alignment-qc.json').read_text());P=json.loads((O/'assembly-stages.json').read_text());Q={r['stage_id']:r for r in A['stage_alignment']}
notes=[
('筒体、上下封头、筒内隔离活塞和外侧管路的相对位置。','储存、分隔、传力是不同功能；看见封闭外形，只能说明模型表达了边界。','材料身份与状态、真实边界和接口检验记录、同一配置的密封与压力完整性证据。HCR-5105涉及的已知接口问题另列，不能因模型对齐就算修复验收。'),
('筒段、前后端结构及相邻连接件，不用外壳轮廓代替内部已有源件。','这一组把能量释放区域与外部结构连接起来；表面像金属不等于材料和热承载能力已经认证。','材料与构件可追溯记录、连接承载和热环境的独立验证，以及与其配置相符的原始试验记录。'),
('上端燃料阀、驱动部件、连接件、阀柄与固定阀体的支架。','驱动对象是阀柄和内部阀芯，阀体保持固定；静态模型可以讲连接关系，不能证明驱动功能。','对应实体驱动链、固定结构与阀门功能的检验记录；电气响应和密封状态需要独立证据。这里没有把阀体做旋转动画。'),
('下端氧化剂阀的独立位置和连接；与上端燃料阀区分。','相同外形的两只阀仍是两个空间实例、两条不同通路，不能以一个通过来代表另一个。','两只实体各自的来源与功能记录，以及它们与对应通路的实际一致性；不由同一CAD定义推导两个实体都合格。'),
('沿筒体外侧的长管、弯曲走向、接头和相邻部件。','管路表达连接关系；源走向被保留，不表示真实软管在受力、环境或装配状态下仍有同样形状。','实体连接身份、真实管路状态、接口完整性和环境适用的独立记录；没有进行弯曲、泄漏或流动验证。'),
('红色翼面、与长支架连接处，以及原件已经建模的孔位。','翼面受空气作用，连接结构传递作用力；看得见孔，不等于实体紧固和载荷都通过。','翼面材料与损伤状态、实体连接质量和相应载荷证据；本次只核对已有源几何与位置。'),
('直角截面的细长支架，以及翼面、贮箱和下方结构之间的关系。','角材的两条边把不同部件联系起来；结构连接与一个零件单独有多结实，是两个问题。','支架材料/构件身份、连接部位状态，以及整条传力关系的独立验证，不能只看渲染颜色或单件外形。'),
('位于圆筒弧面与平支架之间的原隔套；镜头给出该小件近景。','隔套回应两种接触面形状的差别。回到原坐标只能证明数字摆放一致，尚未计算接触或配合间隙。','实体接触与配合记录、连接状态和材料证据。没有求解接触压力或把零矩阵差解释为零间隙。'),
('四组翼面和支架围绕箭体的原始分布，随后一起显示。','飞行稳定与质量分布和空气作用有关，不能用“有四片翼”直接下结论。','与同一实体配置相符的质量/气动模型和实测证据。本任务另有原OpenRocket模型实跑，仍保留其警告，且没有验证每个CAD连接。'),
('电子模块、托板、连接支撑与外壳；临时透视仅帮助看见内部。','电子舱既容纳模块，也与上下结构相接。电路板的几何存在不等于电路、接线、供电与控制已经工作。','实体电气图与配置、模块/连接可追溯资料和独立功能证据；源未表达的布线没有凭想象补出。'),
('五种原作Mass Volume形体，共六个实例，以及它们所占的收纳空间。','这些是质量/体积与空间关系的简化表达，不能拿它们检查织物、绳结或展开动力学。','与实际回收配置一致的织物/绳索/连接资料及独立功能记录；本次未新建伞布细节，也未以占位模型判定回收可靠。'),
('下段原筒壁边界、上下接口与内部收纳空间的位置。','外壳归位让内外层次清楚，不能由此得出实体壁厚、接触或连接承载合格。','原件材料与尺寸检验、真实接口配合和连接证据；本次没有扩大筒壁或补造厚度来让画面更好看。'),
('上段筒壁与电子舱、鼻锥相邻的边界。','相邻件保持独立源身份，外形连续不等于已经证明实体连接或回收分离功能。','上段原件与接口的实际配置、材料/配合记录及独立功能证据；没有将相邻模型合成一个新外壳。'),
('分段鼻锥、连接肩以及源已有的内部杆件和连接结构。','光滑前端只是外形的一部分，源内件也应保留；外形相似不能替代气动、材料或连接承载验证。','同一构型的材料、层间/连接状态、气动与回收连接相关证据；本次只展示实际源件。'),
('连接环、紧固件、导向件，以及源树中命名为钻孔辅助塞的物件。','完整保留源树不等于断言其中每个对象都属于最终飞行配置；辅助件与飞行部件必须有配置依据。','实体完整配置及工具/辅助件的身份记录、连接质量证据。不能从一个辅助件在CAD里可见推定它应该随实物飞行。')]
rows=[];parts=['# 启明火箭：逐环节质量核对说明','这份说明解释每段应该看哪里、当前数字检查实际证明什么，以及实体质量还需要什么证据。它没有把视频归位顺序写成实物施工流程。','## 三种结果要分别理解','源身份与几何核对：对应源件是否真的被读出、是否漏件或替换。数字归位核对：展示对象是否回到原模型的位置。实体质量判断：需要实体材料、连接、功能与相同配置的独立证据；前两项不能替代第三项。']
for i,(s,obs) in enumerate(zip(N['stages'],notes)):
 q=Q[s['stage_id']];p=P['stages'][i];count=len(p['mesh_source_paths']);hidden=s['source_hidden_mesh_occurrences'];assert count==q['checked_source_mesh_objects']==s['source_mesh_occurrences'];assert q['max_local_matrix_abs_error']==q['max_world_matrix_abs_error_source_units']==0
 refs=[r.get('section') for r in s['source_references'] if r.get('section')]
 row={'stage_id':s['stage_id'],'title_zh':s['title_zh'],'role_zh':s['narration_zh'],'look_at_zh':obs[0],'why_quality_matters_zh':obs[1],'verified_digital_qc':{'source_mesh_occurrences':count,'source_hidden_mesh_occurrences':hidden,'source_objects_compared_at_return':q['checked_source_objects'],'reference_blender_frame':q['frame'],'source_mesh_data_preserved':True,'max_local_matrix_abs_error':0,'max_world_matrix_abs_error_source_coordinates':0,'evidence_file':'alignment-qc.json','evidence_stage_id':s['stage_id']},'independent_physical_evidence_needed_zh':obs[2],'physical_evidence_status':'not verified by this digital reproduction','source_sections':refs}

 if 5<=i<=8:
  row['group_scope_zh']=f'本段归位第{i-4}侧完整翼支架总成；标题分别指出翼面、长支架、隔套、四侧分布的观察重点。每侧均含35个源网格、110个源对象。'
  row['look_at_zh']=row['group_scope_zh']+' '+obs[0]
 rows.append(row);parts.extend([f"## {s['stage_id']} · {s['title_zh']}",f"**看哪里：** {row['look_at_zh']}",f"**为什么要看：** {obs[1]}",f"**已做的数字核对：** {count}个源网格实例；其中{hidden}个按源默认隐藏。该组归位时对比{q['checked_source_objects']}个源对象，局部和世界矩阵最大数值差均为0。源网格数据保留，未补造、加厚或简化。此0是数字坐标对照结果，不是实体公差。",f"**实体结论还缺什么证据：** {obs[2]}",f"**来源：** 原作指南 {'；'.join(refs)}；对齐数据 `alignment-qc.json` 的 stage_id={s['stage_id']}。"])
parts.extend(['## 已知修订与原仿真','原作HCR-5105通告记录了R01相关回收锚固接口的泄漏问题。该修订源件单列，未自动合入主R01；本次没有找到足以认证修订后固定配置的完整原始复验链。外形对齐不能消除一个已知实体接口问题。','官方OpenRocket24.12实际重算原作者既有ORK和精确匹配ENG一次，产生872点、无abort、保留一条高速回收事件警告。它是28参数节点的既有飞行模型，不是688源网格的接触、结构或动力系统求解。原输入与配置未改，也未用警告调参。详见[实际仿真报告](../启明火箭/research/simulation/simulation-review-report.md)。','作者官方发布物有真实地面试验、飞行和失败史，已按序列号、日期和构型登记；这些证据比只有CAD更强，但不能把不同构型累计次数当作本次模型或新造实体全部可靠。详见[证据审查](../启明火箭/research/flight-evidence/证据审查.md)。','原作设计归属Half Cat Rocketry；本项目采用“启明火箭”作为显示名称。'])
(O/'逐环节质量核对说明.md').write_text('\n\n'.join(parts)+'\n');(O/'逐环节质量核对说明.json').write_text(json.dumps({'schema_version':1,'project_display_name':'启明火箭','stage_count':15,'stage_mesh_occurrence_sum':sum(r['verified_digital_qc']['source_mesh_occurrences'] for r in rows),'stages':rows,'physical_quality_certified':False},ensure_ascii=False,indent=2)+'\n');print({'stages':len(rows),'source_mesh_occurrences':sum(r['verified_digital_qc']['source_mesh_occurrences'] for r in rows)})
