# 原仿真平台实测报告

**结论：已用官方 OpenRocket 24.12 在用户自有 Spark 无界面读取原 ORK，并实际执行其中原有的一条仿真一次。** 源 ENG 内容指纹与 ORK 原引用精确匹配，没有用其他发动机数据替代。软件产生1个分支、872个结果数据点，状态为 UPTODATE，软件错误标志为 false，模型到达 ground 事件，没有 abort 事件。计算调用约3.381秒。它仍返回1条恢复事件高速警告；这不是实箭、结构、高压或动力系统验证通过。

## 输入与原存档

输入来自用户原 `英文原件/Simulation - R01.zip`，仅提取原字节副本，没有修改原件：

| 文件 | 字节数 | SHA256 |
| --- | ---: | --- |
| Mojave Sphinx V1.2.ork | 3,820 | c2e4ab4e1a1f32e90110ec69d10b69b214ec764185a71f9d3dab260878b20a7c |
| HCR_L1018_MSV1.1.9-HF10 NoHWMass.eng | 8,215 | 55b97db7b8e07b2e83e97f2dfdcd49972dc6c74ea1e402b83b73d4c82f576d03 |

ORK 是包含 `rocket.ork` XML 的 ZIP 容器，原创建器为 OpenRocket23.09、格式1.9。它的参数化组件树有28个节点，含7个 masscomponent；只有1条已序列化仿真、1个 motor 引用，未包含自定义仿真扩展。

原 XML 把该仿真标成 `notsimulated`，同时保存10个高层摘要字段和一条警告，但没有逐点轨迹。官方读取器加载后报告 LOADED、存在摘要、没有完整轨迹。这些是旧存档证据，与本次真实执行分开记录。原配置中的 simulator 为 RK4Simulator、calculator 为 BarrowmanCalculator；保留其已序列化设置，没有新建配置。

## 实际运行而非安装状态

采用[官方24.12发行版](https://github.com/openrocket/openrocket/releases/tag/release-24.12)的完整 JAR，通过其中[官方 Core API](https://openrocket.readthedocs.io/en/latest/dev_guide/using_openrocket_core.html)初始化和读取文件；没有启动 GUI 或触碰用户现有浏览器/Blender 会话。

- Spark：Linux aarch64，便携 Temurin/OpenJDK17.0.20.1。系统原 Java8 未被替换；新运行时限定在独立目录。
- 官方 JAR 为83,149,098 bytes，SHA256 `4959b72f52f5f607941e9722abbb7b7f0c4a38ebbbf84204a329db9f31c4f897`，Mac流式传输校验与远端独立全文件校验均匹配官方 release asset digest。
- 官方 JDK archive 为191,962,709 bytes，SHA256 `457b57af8f9c93ec39080bb8c764f559dc8c89a6da1a39d718a400b7890d3e41`，与 Adoptium 官方 API 匹配。运行时没有要求账户、付费、试用或 API key。
- 本机仅有原输入、来源文档和小型结果/日志；大 JAR/JDK 保存在 Spark `~/codex-mojave-sim-review-20261019/`。所有 preferences 也限定在该目录的 isolated-profile。
- 原文件经官方 GeneralMotorLoader / GeneralRocketLoader 实际解析，原 ENG 注册后与原 ORK 的 digest 精确相符；不加载其他 motor 作为回退。
- 先完成独立 parse-only 核查，随后调用原 simulation 的 `simulate()` 一次。没有设置发动机、推进、加压、点火等新参数，没有优化、替代、扫描或新增设计。

| 检查 | 实测 |
| --- | --- |
| 官方模型载入 | 成功，载入警告0 |
| 原 ENG 引用 | 精确匹配，原数据1条 |
| 原 simulation 数 / 实际执行数 | 1 / 1 |
| 实际求解调用耗时 | 3,381.104 ms |
| 结果 | 1 branch / 872 points |
| 执行后状态 | UPTODATE |
| 软件错误 / abort | false / false |
| 模型 ground 事件 | true |
| 高层摘要有限值检查 | 7 / 7 |
| 警告 | 1条：恢复事件高速警告 |
| 运行前后原 options / configID | 均保持一致 |
| ORK / ENG 运行前后 SHA256 | 均保持一致 |

“UPTODATE”是软件对当前模型与配置的状态，不表示物理正确性或无风险。此次保存了软件状态、分支/数据点数、摘要有限性、警告与输入完整性证据；没有导出完整时间序列或性能曲线，不能把本报告当成飞行计划数据文件。

## 适用范围与不能推出的结论

OpenRocket 的计算对象是原作者提供的参数化飞行模型；它没有载入完整635个 CAD component occurrence 的装配网格。28个参数节点与 CAD 零件/网格数量不是同一种计数，不能由本次运行推导每个孔位、材料、接触面或高压连接已得到物理验证。[官方功能说明](https://openrocket.info/features.html)

原创建器23.09与运行24.12之间可能存在算法和缺省值差异；因此即使保持全部原已序列化设置，也不声称按位重现作者当年的历史计算。源仿真名称里的“Launch9 / StaticTest10”只是原文件命名，未由本任务证明其试验仪器、测量校准或实物对应。模型中的假设、环境与实物对应仍需独立证据。官方也明确说明其理想模型与现实会有差异。[官方准确性说明](https://openrocket.readthedocs.io/en/latest/user_guide/basic_flight_simulation.html#getting-a-good-simulation)

没有进行 CAD 接触求解、装配公差、结构强度、压力完整性、流动、燃烧、硬件在环或真实飞行核验。渲染、虚拟归位或这个飞行软件运行成功均不能替代这些证据。本任务没有依据该警告调参或提供硬件/操作修正流程。

## 可核查证据

- `source-preflight.json`、`source-model-structure.json`：原 ZIP/member 哈希、存档状态、简化模型结构。
- `source-settings-provenance.json`：原 simulator/calculator、已序列化设置字段与 XML 区块哈希，不输出设置数值。
- `official-runtime-verification.json`、`jdk-runtime.json`、`official-jar-transfer.json`：真实使用的官方发行物、字节数、校验。
- `execution-commands.json`：实际编译、parse-only、原仿真执行的完整命令与退出码，均为0。
- `compile.log`、`official-parse.log`、`official-existing-simulation.log`：实际运行日志。
- `official-parse-result.json`、`official-existing-simulation-result.json`、`simulation-readiness.json`：分别记录读取、执行、验证层级；不把安装混作求解。
- `SourceSimulationReview.java`、`run_official_review.py`：本次仅面向已有源模型的核查运行器。
- `official-sources.json` 与已保存官方源码/文档：API与平台范围来源。

传输记录：Spark直连公开资源曾遇TLS错误，单连接下载也很慢；最终使用官方 JAR 的 HTTP range 分块与单writer流式传到Spark，366.8秒后全文件哈希验证完成。曾尝试的 Maven 依赖通道未完成、没有用于实际计算；临时本地只读转发及未完成安装过程均已停止。实际计算所用的是上列已校验完整官方 JAR。独立 Spark 运行环境保留以便复核，没有继续后台仿真或新参数试验。
