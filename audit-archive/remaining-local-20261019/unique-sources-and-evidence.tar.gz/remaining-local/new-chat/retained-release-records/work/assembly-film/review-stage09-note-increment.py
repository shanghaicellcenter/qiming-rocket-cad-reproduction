from pathlib import Path
import datetime, hashlib, json, math, subprocess
from PIL import Image, ImageChops, ImageDraw, ImageFont

home = Path(__file__).resolve().parent
base = home / 'movie-review-qiming'
out = base / 'final-stage09-note'
frames = out / 'frames'
sheets = out / 'sheets'
frames.mkdir(parents=True, exist_ok=True)
sheets.mkdir(exist_ok=True)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_text())
movie = home / 'silent-master-启明火箭.mp4'
expected = 'e8115c65c40e66be5f5f6983aed238332208148524a4768b937cba89d145c2b4'
assert sha(movie) == expected
previous_path = base / 'final-fin-scope' / 'review.json'
if not previous_path.exists():
    previous_path.write_bytes((base / 'current-review.json').read_bytes())
    (previous_path.parent / 'review.md').write_bytes((base / 'current-review.md').read_bytes())
previous = read(previous_path)
assert previous['movie_sha256'] == '0157c12ec68187bc6e8ff6c3cfe06b32331f584f6f2910d3855da8f0bd28250d'
initial = read(base / 'review.json')
progress = read(home / 'capture-progress.json')
chapters = progress['entries']
assert progress['status'] == 'complete' and len(chapters) == 17
assert sum(c['frames'] for c in chapters) == 6596
for c in chapters:
    assert sha(Path(c['path'])) == c['sha256']
unchanged13 = [i for i in range(17) if i not in (6, 7, 8, 9)]
assert all(chapters[i]['sha256'] == initial['chapters'][i]['sha256'] for i in unchanged13)
old09 = home / 'history/pre-speech-anchor-note/09-stage09.mp4'
assert old09.is_file() and sha(old09) != chapters[9]['sha256']

probe_run = subprocess.run(['/opt/homebrew/bin/ffprobe', '-v', 'error', '-count_frames', '-show_streams', '-show_format', '-of', 'json', str(movie)], capture_output=True, text=True)
assert probe_run.returncode == 0
(out / 'ffprobe.json').write_text(probe_run.stdout)
probe = json.loads(probe_run.stdout)
video = next(s for s in probe['streams'] if s['codec_type'] == 'video')
assert int(video['nb_read_frames']) == 6596 and video['width'] == 1280 and video['height'] == 720 and video['r_frame_rate'] == '30/1'
assert not any(s['codec_type'] == 'audio' for s in probe['streams'])
decode_command = ['/opt/homebrew/bin/ffmpeg', '-hide_banner', '-v', 'warning', '-xerror', '-err_detect', 'explode', '-i', str(movie), '-map', '0:v:0', '-fps_mode', 'passthrough', '-f', 'null', '-']
decode = subprocess.run(decode_command, capture_output=True, text=True)
(out / 'strict-decode.log').write_text(decode.stderr)
assert decode.returncode == 0, decode.stderr

selection = []
def add(label, frame, kind, chapter, prior_image=None):
    selection.append(dict(label=label, frame=int(frame), seconds=int(frame)/30, kind=kind, chapter=chapter, prior_image=prior_image))
for phase in (.10, .25, .50, .75, .90, .98):
    c = chapters[9]
    add(f'chapter-09-phase-{round(phase*100):02d}', c['source_first_frame'] + min(c['frames']-1, round(c['frames']*phase)), 'changed-stage09', 9)
for i in (9, 10):
    n = chapters[i]['source_first_frame']
    add(f'cut-{i:02d}-before', n-1, 'stage09-boundary', i-1)
    add(f'cut-{i:02d}-after', n, 'stage09-boundary', i)
for r in previous['selected_increment_frames']:
    if r['kind'] == 'preserved-chapter-comparison' or (r['chapter'] in (6, 7, 8) and r['label'].endswith(('-50', '-90'))):
        add(r['label'], r['frame'], 'unchanged-16-chapter-sample', r['chapter'], r['image'])
assert len([r for r in selection if r['kind']=='unchanged-16-chapter-sample']) == 32
unique = sorted({r['frame'] for r in selection})
vf = 'select=' + '+'.join(f'eq(n\\,{n})' for n in unique)
run = subprocess.run(['/opt/homebrew/bin/ffmpeg', '-hide_banner', '-v', 'error', '-i', str(movie), '-vf', vf, '-fps_mode', 'passthrough', str(frames/'extract-%03d.png')], capture_output=True, text=True)
assert run.returncode == 0, run.stderr
extracted = sorted(frames.glob('extract-*.png'))
assert len(extracted) == len(unique)
mapping = dict(zip(unique, extracted))
comparisons = []
for r in selection:
    im = Image.open(mapping[r['frame']]).convert('RGB')
    p = frames/(r['label']+'.png')
    im.save(p)
    r['image'] = str(p.relative_to(base))
    r['sha256'] = sha(p)
    if r['prior_image']:
        old = Image.open(base/r['prior_image']).convert('RGB')
        same = ImageChops.difference(old, im).getbbox() is None
        assert same, r['label']
        comparisons.append(dict(chapter=r['chapter'], label=r['label'], decoded_pixels_identical=True))
for p in extracted:
    p.unlink()
font = ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf', 18)
sheet_index = []
for name, kind in [('stage09-phases', 'changed-stage09'), ('stage09-boundaries', 'stage09-boundary')]:
    rows = [r for r in selection if r['kind'] == kind]
    canvas = Image.new('RGB', (1180, 44+365*math.ceil(len(rows)/2)), '#e7edf3')
    d = ImageDraw.Draw(canvas)
    d.text((14, 12), name+' | ACTUAL NEW SILENT MASTER', font=font, fill='#172533')
    for j, r in enumerate(rows):
        x, y = j%2*590, 44+j//2*365
        im = Image.open(base/r['image']).convert('RGB')
        im.thumbnail((570,321))
        d.text((x+10,y+6), f"{r['label']} | f{r['frame']} | {r['seconds']:.3f}s", font=font, fill='#172533')
        canvas.paste(im, (x+10,y+35))
    p = sheets/(name+'.png')
    canvas.save(p)
    sheet_index.append(dict(image=str(p.relative_to(base)), sha256=sha(p), frame_labels=[r['label'] for r in rows], actual_visual_review='pending'))
assert sha(movie) == expected
audit = dict(created_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), movie=str(movie), movie_sha256=expected, movie_bytes=movie.stat().st_size,
    status='strict decode passed; stage09 note visual increment pending', is_current_silent_master=True, audio_and_subtitle_final_acceptance=False,
    strict_decode=dict(exit_code=decode.returncode, command=decode_command, stderr_bytes=len(decode.stderr.encode())),
    ffprobe=dict(width=1280,height=720,fps='30/1',decoded_frames=6596,duration_seconds=float(probe['format']['duration']),audio_stream_count=0),
    changed_source_chapters=[9], expected_display_note_change='后半段看四侧分布 → 随后看四侧分布',
    prior_visual_report='final-fin-scope/review.json', prior_movie_sha256=previous['movie_sha256'],
    chapters=chapters, actual_all_17_source_clip_hashes_checked=True,
    unchanged_13_non_fin_chapter_hashes_compared_to_initial=True,
    other_16_chapters_mid_and_return_decoded_pixels_identical=comparisons,
    previous_stage09_clip=dict(path=str(old09),sha256=sha(old09),bytes=old09.stat().st_size),
    selected_increment_frames=selection, increment_contact_sheets=sheet_index, visual_review='pending',
    prior_visual_review_reused=previous['visual_review'], source_master_not_modified_by_review=True)
(base/'current-review.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(sha256=expected,frames=6596,strict_decode_passed=True,unchanged_16_chapter_sample_comparisons=len(comparisons),new_contact_sheets=len(sheet_index),visual='pending')))
