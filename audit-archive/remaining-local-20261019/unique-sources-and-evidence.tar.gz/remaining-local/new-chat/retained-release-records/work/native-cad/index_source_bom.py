"""Index source document identities; do not generate CAD or infer assembly counts."""
from pathlib import Path
import hashlib, json, re

ROOT = Path('/Users/qianqiming/Documents/Codex/2026-10-19/new-chat')
SOURCE = Path('/Users/qianqiming/Desktop/火箭设计 中文版/中文文档/02-HCR-5101 物料清单-中英对照.md')
source_bytes = SOURCE.read_bytes()
labels = json.loads((ROOT/'work/native-cad/component-labels.json').read_text())
basenames = list(labels['by_basename'])
norm = lambda s: re.sub(r'[^a-z0-9]', '', s.lower())
group = None
rows = []
for line_no, line in enumerate(source_bytes.decode().splitlines(), 1):
    if line.startswith('## 附：'):
        group = None
    match = re.match(r'^### ([ABC]\d+) (.+)', line)
    if match:
        group = {'id': match[1], 'title': match[2], 'line': line_no}
    if not group or not re.match(r'^\|\s*\d+\s*\|', line):
        continue
    cells = [s.strip() for s in line.strip().strip('|').split('|')]
    if len(cells) != 10:
        raise ValueError(f'Unexpected source table layout at line {line_no}')
    number, source_name = cells[:2]
    candidate_code = norm(cells[6])
    # A3's PN/name columns are explicitly marked misaligned in the source.
    # Do not silently repair this or turn a PN match into an asserted identity.
    source_alignment_note = group['id'] == 'A3'
    candidates = [] if source_alignment_note or not candidate_code else [
        name for name in basenames
        if norm(name.rsplit('.', 1)[0].split(' ')[0].split('_')[0]) == candidate_code
    ]
    rows.append({
        'id': f'{group["id"]}-{int(number):02d}',
        'source_group': group,
        'source_row': int(number),
        'source_line': line_no,
        'source_item_name': source_name.replace('<br>', '\n'),
        'source_cad_filename_candidates': candidates,
        'candidate_basis': 'Exact normalized source PN to CAD filename prefix only; unverified identity.',
        'source_alignment_warning': source_alignment_note,
        'status': 'source_document_row_indexed; not an assembly instance count',
    })
result = {
    'source_document': str(SOURCE),
    'source_sha256': hashlib.sha256(source_bytes).hexdigest(),
    'source_table_row_count': len(rows),
    'source_groups': {r['source_group']['id']: r['source_group']['title'] for r in rows},
    'row_with_unverified_filename_candidate': sum(bool(r['source_cad_filename_candidates']) for r in rows),
    'known_alignment_warning_rows': sum(r['source_alignment_warning'] for r in rows),
    'interpretation': 'BOM rows include raw materials, packs, consumables and finished items. They cannot be equated to CAD files or physical assembly instances. Candidate name matches do not establish geometric coverage. No purchase quantities, manufacturing parameters or operations are derived.',
    'rows': rows,
}
out = ROOT/'work/native-cad/bom-source-index.json'
out.write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('rows','source_groups')}, ensure_ascii=False))
