from pathlib import Path
import json,shutil,subprocess,sys
R=Path(__file__).resolve().parents[2]; O=R/'outputs/启明火箭'; W=R/'work/assembly-film'; D=O/'source/assembly-film'; D.mkdir(parents=True,exist_ok=True);(D/'source').mkdir(exist_ok=True)
assert json.loads((W/'final-timeline.json').read_text())['captions_status']=='all actual acoustic subtitles present'
# Regenerate the exported data from the actual final timeline and current
# approved paragraphs before copying; a provisional page must never be packed.
subprocess.run([sys.executable,str(W/'build.py'),'--final'],cwd=R,check=True)
timeline_line=next(line for line in (W/'source/data.js').read_text().splitlines() if line.startswith('export const TIMELINE='))
assert json.loads(timeline_line.removeprefix('export const TIMELINE=').removesuffix(';'))==json.loads((W/'final-timeline.json').read_text())
for name in ['film.js','data.js']:
 text=(W/'source'/name).read_text()
 if name=='film.js':text=text.replace('../../native-cad/assembly-viewer/source/vendor/machine/kit/lab-kit.js','../../vendor/machine/kit/lab-kit.js')
 (D/'source'/name).write_text(text)
for name in ['silent-timeline.json','final-timeline.json','captions.ass']:
 shutil.copy2(W/name,D/name)
shutil.copy2(W/'render_movie_portable.py',D/'render_movie.py')
(D/'package.json').write_text(json.dumps({'name':'qiming-rocket-assembly-film','version':'1.0.0','private':True,'type':'module','engines':{'node':'>=18'},'scripts':{'build':'node build.mjs'},'dependencies':{'three':'0.170.0'},'devDependencies':{'esbuild':'0.27.7','playwright':'1.62.1'}},indent=2)+'\n')
(D/'build.mjs').write_text('''import {readFileSync,createReadStream,createWriteStream,existsSync} from 'node:fs';
import {once} from 'node:events';
import {dirname,resolve} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
const here=dirname(fileURLToPath(import.meta.url)),root=resolve(here,'../..');
const candidates=[process.env.MACHINE_NODE_MODULES,resolve(here,'node_modules'),resolve(here,'../node_modules')].filter(Boolean),runtime=candidates.find(p=>existsSync(resolve(p,'esbuild/lib/main.js'))&&existsSync(resolve(p,'three/build/three.module.js')));
if(!runtime)throw new Error('Install the pinned package dependencies here, or set MACHINE_NODE_MODULES.');
const esbuild=await import(pathToFileURL(resolve(runtime,'esbuild/lib/main.js'))),three=resolve(runtime,'three');
const built=await esbuild.build({entryPoints:[resolve(here,'source/film.js')],bundle:true,write:false,format:'iife',target:'es2022',minify:true,alias:{'three/addons':resolve(three,'examples/jsm'),three:resolve(three,'build/three.module.js')},legalComments:'inline'});
const out=resolve(root,'逐步虚拟归位.html'),s=createWriteStream(out+'.tmp');async function w(t){if(!s.write(t))await once(s,'drain');}
await w('<!doctype html><html lang="zh-CN"><meta charset="utf-8"><link rel="icon" href="data:,"><meta name="viewport" content="width=device-width,initial-scale=1"><title>启明火箭 · 十五组逐步虚拟归位</title><body>');
await w('<script id="narration-audio" type="application/octet-stream">data:audio/mpeg;base64,'+readFileSync(resolve(root,'media/逐步虚拟归位旁白.mp3')).toString('base64')+'</script>');
await w('<script id="overview-image" type="application/octet-stream">data:image/png;base64,'+readFileSync(resolve(root,'library/assembly-previews/A12-side.png')).toString('base64')+'</script><script id="model-browse" type="application/octet-stream">');
let carry=Buffer.alloc(0);for await(const chunk of createReadStream(resolve(root,'assembly/vehicle-browse.compact.glb'),{highWaterMark:3145728})){const b=carry.length?Buffer.concat([carry,chunk]):chunk,e=b.length-b.length%3;await w(b.subarray(0,e).toString('base64'));carry=b.subarray(e);}if(carry.length)await w(carry.toString('base64'));
await w('</script><script>'+built.outputFiles[0].text.replace(/<\\/script/gi,'<\\\\/script')+'</script></body></html>');s.end();await once(s,'finish');
const {renameSync}=await import('node:fs');renameSync(out+'.tmp',out);console.log(out);
''')
(D/'REBUILD.md').write_text('''# 启明火箭 · 逐步虚拟归位讲解源码

此页使用同一份真实源CAD浏览几何，不增加内部部件。展示副本共享几何；15组互斥覆盖688个源网格，原参考层级不参与展示动画。

`source/film.js` 是取景、显示与声音控制，`source/data.js` 保存逐段讲稿、来源、15组源路径、最终语音时码。`silent-timeline.json` 记录录制基础章节；`final-timeline.json` 记录按真实旁白时长调整后的时间。字幕时间来自实际语音识别和核对，不按字数推算。

重建离线交互页：在本目录安装 package.json 固定版本依赖，再执行 `node build.mjs`。也可以将 MACHINE_NODE_MODULES 指向已有对应依赖目录。输入为 ../../assembly/vehicle-browse.compact.glb、../../library/assembly-previews/A12-side.png、../../media/逐步虚拟归位旁白.mp3。输出为 ../../逐步虚拟归位.html，模型、图片、声音和代码全部内嵌，不依赖联网。

影片重渲：安装上述依赖、可用Chromium或Google Chrome及ffmpeg/ffprobe，再执行 `python3 render_movie.py`。脚本按真实最终时码逐章录制，可从已验证章节继续，默认写一个 rebuilt 副本，保留已验收原片。MACHINE_NODE、MACHINE_PLAYWRIGHT_MODULE、MACHINE_CHROMIUM_EXECUTABLE可指定已有运行时；不会调用TTS，也不会重新均衡或加速声音。重渲是重新取样与编码，不承诺MP4字节完全相同。

旁白使用用户确认方向的Spark本地合成声，每段一次生成；均衡音量保留采样数和实际时码。播放以真实音频时钟为准，拖动和章节选择同时定位音画。源WAV、字幕与核查记录另附，不代表合成模型运行环境已经打包。

影片通过相同展示代码录制各章，再按实际语音时长调整画面，隔套、四侧尾翼、连接环和辅助塞的近景按实测词句时间定位；声音不加速。MP4字幕烧录，另附SRT。Blender可编辑源与坐标检查放在 ../../../virtual-assembly/。

Machine Skill源代码许可与修改说明见 ../vendor/machine/。Three.js许可见 ../vendor/machine/THREE-LICENSE.txt。原工程及派生CAD归属Half Cat Rocketry。
''')
print(D)
