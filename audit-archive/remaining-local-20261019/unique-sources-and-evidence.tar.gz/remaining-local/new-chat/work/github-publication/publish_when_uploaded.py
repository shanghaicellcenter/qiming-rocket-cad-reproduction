from pathlib import Path
import subprocess,json,datetime,time,os,hashlib
p=Path(__file__).resolve().parent;repo="shanghaicellcenter/qiming-rocket-cad-reproduction"
expected={x.name for x in (p/"release-assets").iterdir() if x.is_file()}
assert len(expected)==10
assert hashlib.sha256((p/"release-assets/release-manifest.json").read_bytes()).hexdigest()=="b5122c9f67b948f15e3f476e1bcd01f447593c46a6dff80292bd61994f314877"
last=None
for i in range(100):
 r=json.loads(subprocess.check_output(["/opt/homebrew/bin/gh","api",f"repos/{repo}/releases/417612933"]))
 actual={a["name"] for a in r["assets"] if a["state"]=="uploaded"}
 if actual!=last:print(json.dumps({"utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"completed_asset_count":len(actual),"completed_assets":sorted(actual)}),flush=True);last=actual
 if actual==expected:break
 try:os.kill(54783,0)
 except ProcessLookupError:raise RuntimeError("Owned upload process stopped before all10 assets completed; inspect actual API, do not publish incomplete Release.")
 time.sleep(45)
else:raise RuntimeError("Upload wait limit reached; no automatic publication of incomplete Release.")
subprocess.run(["python3",str(p/"verify_remote_assets.py")],cwd=p.parent.parent,check=True)
ready=json.loads((p/"prepublication-readiness.json").read_text());assert ready["archive_stream_audit_passed"] and ready["final_manifest_file_count"]==3829 and ready["release_manifest_sha256"]=="b5122c9f67b948f15e3f476e1bcd01f447593c46a6dff80292bd61994f314877"
print("All10 actual GitHub upload digests verified; publishing approved Release",flush=True)
subprocess.run(["/opt/homebrew/bin/gh","release","edit","v1.0.0","--repo",repo,"--draft=false"],check=True)
r=json.loads(subprocess.check_output(["/opt/homebrew/bin/gh","api",f"repos/{repo}/releases/tags/v1.0.0"]))
ref=json.loads(subprocess.check_output(["/opt/homebrew/bin/gh","api",f"repos/{repo}/git/ref/tags/v1.0.0"]))
assert not r["draft"] and len(r["assets"])==10 and ref["object"]["sha"]=="82c2a2a255b66556cead58ec3444f81f1757ae68"
x={"published_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"repo":f"https://github.com/{repo}","release_url":r["html_url"],"tag":"v1.0.0","commit":ref["object"]["sha"],"all10_remote_upload_digest_checks_passed":True,"actual_fresh_download_not_yet_claimed":True,"cleanup_eligible":False}
(p/"actual-publication.json").write_text(json.dumps(x,ensure_ascii=False,indent=2)+"\n")
print("Release really published; starting actual fresh public Release download",flush=True)
v=Path("/Users/qianqiming/Documents/Codex/2026-10-19/qiming-github-verify-20261019")
subprocess.run(["python3",str(v/"run_actual_download.py")],cwd=v,check=True)
print("Public release download, extraction,392 source/3829 payload, and full local voice restoration complete; browser/rebuild acceptance remains",flush=True)
