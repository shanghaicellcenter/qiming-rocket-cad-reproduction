from pathlib import Path
import json,hashlib,re,datetime,subprocess,collections,sys
R=Path.cwd(); W=R/'work/github-publication'; O=R/'work/github-publication-review'
def load(p): return json.loads(Path(p).read_text())
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b)
 return h.hexdigest()
current=load(W/'inventory.private.json'); manifest=W/'release-manifest.json'
old_path=Path(sys.argv[1]) if len(sys.argv)>1 else next((W/'staging-history').rglob('release-manifest.json')); old={x['path']:x for x in load(old_path)['files']}
changed=[x for x in current['files'] if x['path'] not in old or x['sha256']!=old[x['path']]['sha256']]
added=[x for x in changed if x['path'] not in old]
modified=[x for x in changed if x['path'] in old]
deleted=sorted(set(old)-{x['path'] for x in current['files']})
stage=W/'repo-stage'; staged=sorted(p for p in stage.rglob('*') if p.is_file())
hash_errors=[]
for x in changed:
 p=Path(x['input_file'])
 if not p.is_file() or p.stat().st_size!=x['bytes'] or sha(p)!=x['sha256']: hash_errors.append(x['path'])
patterns={
 'private_key':re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH |DSA |ENCRYPTED )?PRIVATE KEY-----'),
 'github_token':re.compile(rb'(?<![A-Za-z0-9_])(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{60,})'),
 'openai_token':re.compile(rb'(?<![A-Za-z0-9_])sk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{32,}'),
 'aws_access_key':re.compile(rb'(?<![A-Z0-9])(?:AKIA|ASIA)[A-Z0-9]{16}(?![A-Z0-9])'),
 'slack_token':re.compile(rb'xox[baprs]-[0-9A-Za-z-]{20,}'),
 'google_api_key':re.compile(rb'AIza[0-9A-Za-z_-]{35}'),
}
text_suffix={'.md','.txt','.json','.py','.js','.mjs','.html','.css','.toml','.yaml','.yml','.csv','.xml','.svg','.sh','.srt','.ass','.map','.log'}
todo={str(p.resolve()):{'actual':p,'label':p.relative_to(R).as_posix()} for p in staged if p.suffix.lower() in text_suffix or p.name in ['LICENSE','NOTICE']}
for x in changed:
 p=Path(x['input_file'])
 if p.suffix.lower() in text_suffix or p.name in ['LICENSE','NOTICE']:todo[str(p.resolve())]={'actual':p,'label':x['path']}
secret=[]; structured=[]; scanned=0; total=0
for v in todo.values():
 p=v['actual']; scanned+=1;total+=p.stat().st_size
 # Stream all text including embedded GLB HTML without printing matching text.
 hits=set();tail=b''
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):
   b=tail+b
   hits.update(k for k,r in patterns.items() if r.search(b));tail=b[-512:]
 for hit in sorted(hits):secret.append({'path':v['label'],'type':hit})
 if p.suffix.lower()=='.json' and p.stat().st_size<5*1024*1024:
  try:d=load(p)
  except (ValueError,UnicodeDecodeError):continue
  def walk(node):
   if isinstance(node,dict):
    for k,value in node.items():
     if re.fullmatch(r'(?:api[_-]?key|access[_-]?token|refresh[_-]?token|client[_-]?secret|password|private[_-]?key|authorization)',str(k),re.I) and isinstance(value,str) and len(value)>16 and not re.search(r'placeholder|example|your[_ -]|env:|redact|none|not[_ -]?set|os\.environ|process\.env|bearer\s*$',value,re.I):
      structured.append({'path':v['label'],'type':'literal-sensitive-field:'+str(k)})
     walk(value)
   elif isinstance(node,list):
    for value in node:walk(value)
  walk(d)
all_inputs=[Path(x['input_file']) for x in current['files']]
credential_names=[];restricted=[]
for x,p in zip(current['files'],all_inputs):
 if p.name.lower() in {'.env','.npmrc','.pypirc','credentials','id_rsa','id_ed25519','authorized_keys'} or '.aws/credentials' in p.as_posix():credential_names.append(x['path'])
 if p.suffix.lower() in {'.safetensors','.ckpt','.pt','.pth','.onnx','.gguf','.ggml','.ttf','.otf','.ttc','.woff','.woff2','.dylib','.dll','.so','.exe'}:restricted.append({'path':x['path'],'type':'font/model/native-binary-extension'})
html_checks=[];video_checks=[]
for x in current['files']:
 if x['layer']!='visual':continue
 p=Path(x['input_file'])
 if p.suffix.lower()=='.html':
  found=False;tail=b''
  with p.open('rb') as f:
   for b in iter(lambda:f.read(1024*1024),b''):
    b=tail+b;found |= bool(re.search(rb'data:audio/',b,re.I));tail=b[-32:]
  html_checks.append({'path':x['path'],'contains_data_audio':found})
 if p.suffix.lower()=='.mp4':
  z=subprocess.run(['/opt/homebrew/bin/ffprobe','-v','error','-select_streams','a','-show_entries','stream=index','-of','json',str(p)],capture_output=True,text=True)
  video_checks.append({'path':x['path'],'exit_code':z.returncode,'audio_stream_count':len(json.loads(z.stdout).get('streams',[])) if z.returncode==0 else None})
transform=load(W/'publication-transformations.json'); fontp=W/'derived/public-tree/outputs/启明火箭/source/component-illustrations/font-safe-manifest.json';font=load(fontp); fresh=load(fontp.parent/'fresh-reopen-audit.json')
transform_map={x['path']:x for x in transform['files']}; fmismatches=[]; uv_variations=[];uvunbound=[]
frows={x['id']:x for x in fresh['items']}
for row in font['items']:
 t=transform_map.get(row['release_path'],{})
 if t.get('original_sha256')!=row['source_sha256'] or t.get('published_sha256')!=row['published_sha256']:fmismatches.append(row['release_path'])
 controls=row.get('ephemeral_modifier_uv_variations_after_reopen',[])+row.get('ephemeral_modifier_uv_variations_before_save',[])
 for uv in frows[row['id']].get('evaluated_uv_hash_variants',[]):
  hit=[c for c in controls if c.get('object')==uv.get('object') and uv.get('component')=='uv:'+c.get('uv_layer','')]
  if not hit:uvunbound.append({'id':row['id'],'object':uv.get('object'),'type':uv.get('component')})
  else:uv_variations.extend(c['maximum_abs_uv_difference'] for c in hit)
report={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':f'Read-only final-freeze incremental review against actual {len(old)}-file baseline; unchanged rows are not needlessly rescanned. No Git push, download, extraction, render or deletion performed.','manifest_sha256':sha(manifest),'manifest_status':current['status'],'final_file_count':len(current['files']),'final_logical_bytes':current['full_logical_bytes'],'final_layers':current['layers'],'baseline_manifest_sha256':sha(old_path),'added_paths':len(added),'modified_paths':len(modified),'removed_paths':deleted,'actual_added_modified_sha_errors':hash_errors,'final_stage_file_count':len(staged),'final_stage_bytes':sum(p.stat().st_size for p in staged),'actual_small_and_changed_text_files_scanned':scanned,'actual_text_bytes_scanned':total,'secret_pattern_candidates':secret,'literal_sensitive_field_candidates':structured,'credential_configuration_filename_candidates':credential_names,'font_model_or_native_binary_extension_candidates':restricted,'placeholder_token_words_are_not_secrets':True,'visual_html':html_checks,'visual_video':video_checks,'transformation_policy':transform['policy'],'all62_font_original_published_hashes_bound_to_transformations':not fmismatches,'font_transform_mismatches':fmismatches,'fresh_uv_variation_records':sum(len(x.get('evaluated_uv_hash_variants',[])) for x in fresh['items']),'uv_variants_missing_matching_per_object_control':uvunbound,'maximum_matched_evaluated_uv_difference':max(uv_variations,default=0),'no_whole_world_matrix_bitwise_identity_claim':True,'archive_stream_audit_is_peer_actual_local_not_GitHub_download':True,'remaining_required_acceptance':'Actual GitHub upload/download/extraction and downloaded-root browser acceptance, then authorized cleanup.'}
(O/(sys.argv[2] if len(sys.argv)>2 else 'final-incremental-scan.json')).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['manifest_status','final_file_count','added_paths','modified_paths','final_stage_file_count','secret_pattern_candidates','literal_sensitive_field_candidates','credential_configuration_filename_candidates','font_model_or_native_binary_extension_candidates','actual_added_modified_sha_errors','font_transform_mismatches','uv_variants_missing_matching_per_object_control','maximum_matched_evaluated_uv_difference']},ensure_ascii=False))
