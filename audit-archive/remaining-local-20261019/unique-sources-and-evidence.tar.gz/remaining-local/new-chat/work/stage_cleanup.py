"""Default DRY_RUN. With explicit final acceptance, stage owned roots only.
No deletion or process-termination function exists. Parent separately reviews
post-stage proof before any later removal of quarantined generated copies.
"""
from pathlib import Path
import argparse,datetime,hashlib,json,os,stat,subprocess,sys,uuid
ROOT=Path(__file__).resolve().parents[1]
VERIFY=ROOT.parent/'qiming-github-verify-20261019'
EXPECTED_REPO='https://github.com/shanghaicellcenter/qiming-rocket-cad-reproduction'
EXPECTED_COMMIT='82c2a2a255b66556cead58ec3444f81f1757ae68'
EXPECTED_MANIFEST='b5122c9f67b948f15e3f476e1bcd01f447593c46a6dff80292bd61994f314877'
REQUIRED_CHECKS={'public_release','download_integrity','restore','browser','frontend','blender'}
ALLOWED_RELATIVE={'outputs/启明火箭','outputs/virtual-assembly','outputs/mojave-machine','work/assembly-film','work/assembly-previews','work/atlas-integration','work/cad-research','work/final-entrance-review','work/flight-evidence','work/history','work/legacy-source-audit','work/machine-review-rounds','work/machine-runtime','work/mojave-anatomy','work/mojave-display','work/native-cad','work/portable-recorder-smoke','work/safe-stl','work/simulation-review','work/source-drawings','work/source-format-review','work/task-plan-history','work/virtual-assembly'}
ALLOWED_RELATIVE|={'work/github-publication/'+x for x in ['derived','portable-blender-smoke','release-assets','release-assets-history','restore-smoke-complete','restore-smoke-input','staging-history','nonrelease-backups','browser-review','preview-docs','__pycache__','repo-stage']}
PROTECTED=[Path('/Users/qianqiming/Desktop/火箭设计 中文版'),ROOT.parent/'ni',Path('/Users/qianqiming/Desktop/skill-repos'),Path('/Users/qianqiming/.codex'),Path('/Users/qianqiming/.agents'),Path('/Applications/Blender 5.2.app'),Path('/Applications/Blender.app'),VERIFY]

def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  while block:=f.read(4*1024*1024):h.update(block)
 return h.hexdigest()
def save(path,value):
 path=Path(path);path.parent.mkdir(parents=True,exist_ok=True);tmp=path.with_name(path.name+'.tmp');tmp.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n');tmp.replace(path)
def check(condition,message):
 if not condition:raise RuntimeError(message)
def pointer(data,path):
 check(path.startswith('/') and path!='/', 'Assertions require a nonempty RFC6901 JSON pointer')
 for part in path[1:].split('/'):
  part=part.replace('~1','/').replace('~0','~')
  data=data[int(part)] if isinstance(data,list) else data[part]
 return data
def plain_ancestors(path,include_leaf=False):
 p=path if include_leaf else path.parent
 while True:
  check(not p.is_symlink(),'Symlink ancestor forbidden: '+str(p))
  if p==p.parent:break
  p=p.parent

def validate_acceptance(path):
 check(path is not None,'Explicit --acceptance-receipt is required for APPLY')
 path=path.absolute();plain_ancestors(path,True);check(path.is_file(),'Final acceptance receipt does not exist')
 check(path.resolve().is_relative_to(VERIFY/'reports'),'Acceptance must be retained under actual verification reports, not upload workspace')
 a=json.loads(path.read_text());check(a.get('cleanup_eligible') is True and a.get('actual_download_performed') is True,'Final receipt must attest actual download and cleanup eligibility')
 for key,expected in [('repo',EXPECTED_REPO),('commit',EXPECTED_COMMIT),('tag','v1.0.0'),('manifest_sha256',EXPECTED_MANIFEST),('verification_root',str(VERIFY))]:check(a.get(key)==expected,'Acceptance scope mismatch: '+key)
 check(a.get('original_input_denial_used') is True,'Actual acceptance must use original-input denial, not upload inputs')
 checks=a.get('checks',{});check(REQUIRED_CHECKS.issubset(checks),'Missing public_release/download_integrity/restore/browser/frontend/blender proof')
 evidence=[]
 for name in sorted(REQUIRED_CHECKS):
  c=checks[name];check(c.get('passed') is True,'Acceptance check failed: '+name)
  p=Path(c['evidence_file']);p=p if p.is_absolute() else path.parent/p;plain_ancestors(p,True)
  check(p.is_file() and p.resolve().is_relative_to(VERIFY/'reports'),'Proof must be actual retained verification report: '+name)
  check(c.get('evidence_sha256')==sha(p),'Proof SHA changed: '+name)
  proof=json.loads(p.read_text());assertions=c.get('assertions');check(isinstance(assertions,dict) and assertions,'Each check needs actual JSON assertions: '+name)
  for k,v in assertions.items():
   actual=pointer(proof,k);check(type(actual) is type(v) and actual==v,'Actual proof field mismatch: '+name+' '+k)
  evidence.append({'check':name,'path':str(p),'sha256':sha(p),'assertions':assertions})
 clone=json.loads((VERIFY/'reports/actual-git-clone-receipt.json').read_text());check(clone.get('actual_network_git_clone') is True and clone.get('commit')==EXPECTED_COMMIT,'Actual independent network clone receipt failed')
 return {'path':str(path),'sha256':sha(path),'checks':evidence}

def clone_proof(plan):
 clone=Path(plan['retained_git_checkout']['root']);check(clone==VERIFY/'project','Retained clone path mismatch');plain_ancestors(clone,True)
 head=subprocess.check_output(['git','-C',str(clone),'rev-parse','HEAD'],text=True).strip();check(head==EXPECTED_COMMIT,'Retained clone HEAD differs')
 tracked=[x for x in subprocess.check_output(['git','-C',str(clone),'ls-files','-z']).decode().split('\0') if x];check(len(tracked)==194 and set(tracked)==set(plan['retained_git_checkout']['tracked_files']),'Retained194 tracked paths differ')
 status=subprocess.run(['git','-C',str(clone),'diff','--quiet','HEAD','--'],capture_output=True);check(status.returncode==0,'Retained clone tracked sources changed')
 check(sha(clone/'release-manifest.json')==EXPECTED_MANIFEST,'Retained fresh manifest differs')
 remote=subprocess.check_output(['git','-C',str(clone),'config','--get','remote.origin.url'],text=True).strip();check(remote.removesuffix('.git')==EXPECTED_REPO,'Retained clone remote differs')
 return {'root':str(clone),'head':head,'tracked_files':194,'tracked_worktree_clean':True,'manifest_sha256':EXPECTED_MANIFEST}

def check_103_and_desktop(plan):
 count=0
 for row in plan['process_and_reference_evidence']['independent_copy_checks']:
  p=Path(row['independent_local_path_to_keep']);check(p.is_file() and not p.is_symlink() and p.resolve().is_relative_to(ROOT.parent/'ni'),'Independent ni copy boundary changed')
  check(sha(p)==row['sha256'],'Independent ni copy SHA changed: '+str(p));count+=1
 check(count==103,'Expected exactly103 migration copies')
 d=json.loads(Path(plan['desktop392_protection_evidence']['path']).read_text());check(d['expected_files']==392,'Original protection manifest count differs');base=Path(d['protected_root']);check(base==PROTECTED[0],'Original desktop source root differs')
 for r in d['files']:
  p=base/r['relative_path'];check(p.is_file() and p.stat().st_size==r['bytes'] and sha(p)==r['sha256'],'Protected original392 changed: '+r['relative_path'])
 return {'independent_ni_copies_checked':103,'original_desktop_files_checked':392,'all_passed':True}

def outside_refs(plan):
 # Reuse the existing read-only inventory traversal. It writes only own report,
 # never candidate data, and ignores package/cache trees while scanning siblings.
 subprocess.run([sys.executable,str(ROOT/'work/prepare_cleanup_plan.py')],stdout=subprocess.DEVNULL,check=True,cwd=ROOT)
 e=json.loads((ROOT/'work/cleanup-inventory-evidence.json').read_text());check(not e['external_sibling_symlinks_targeting_our_root'],'New external symlink dependency found')
 approved={r['path']:r for r in plan['process_and_reference_evidence']['external_code_hits_classified']};current=e['external_sibling_program_reference_hits'];check({r['path'] for r in current}<=set(approved),'New outside source-code reference found')
 for r in current:check(sha(Path(r['path']))==approved[r['path']]['file_sha256_at_snapshot'],'Outside source reference file changed; review before staging: '+r['path'])
 return {'external_symlinks':0,'known_provenance_or_sandbox_code_files':len(current),'known_code_file_sha_unchanged':True}

def known_fingerprints(plan):
 p=Path(plan['known_path_fingerprints']['path']);check(sha(p)==plan['known_path_fingerprints']['sha256'],'Known path journal changed');return json.loads(p.read_text())['candidates']
def snapshot(base):
 rows={};stack=[base]
 while stack:
  p=stack.pop();s=p.lstat();kind='symlink' if stat.S_ISLNK(s.st_mode) else 'directory' if stat.S_ISDIR(s.st_mode) else 'file' if stat.S_ISREG(s.st_mode) else 'other';r={'relative_path':p.relative_to(base).as_posix(),'kind':kind,'device':s.st_dev,'inode':s.st_ino,'mtime_ns':s.st_mtime_ns,'bytes':s.st_size if kind=='file' else 0}
  if kind=='symlink':r['raw_target']=os.readlink(p)
  rows[r['relative_path']]=r
  if kind=='directory':stack.extend(p.iterdir())
 return rows
def match_fingerprints(group,base):
 old={r['relative_path']:r for r in group['items']};current=snapshot(base);check(set(old)==set(current),'New/missing candidate paths: '+str(base))
 for name,x in old.items():
  y=current[name]
  if x['kind']==y['kind']=='directory':x={k:v for k,v in x.items() if k!='mtime_ns'};y={k:v for k,v in y.items() if k!='mtime_ns'}
  check(x==y,'Candidate identity/size/mtime changed: '+str(base/name))
 return len(current)
def open_handles(prefixes):
 out=subprocess.run(['lsof','-nP','-Fpcfn'],capture_output=True,text=True);check(not out.stderr.strip(),'lsof could not provide complete protection evidence')
 r={'pid':None,'command':None,'fd':None};matches=[]
 for line in out.stdout.splitlines():
  if not line:continue
  k,v=line[0],line[1:]
  if k=='p':r={'pid':int(v),'command':None,'fd':None}
  elif k=='c':r['command']=v
  elif k=='f':r['fd']=v
  elif k=='n' and any(v==str(p) or v.startswith(str(p)+'/') for p in prefixes):matches.append({**r,'path':v})
 return matches

def validate_owned_roots(plan):
 sources=[Path(r['path']) for r in plan['candidate_roots_exact']];check(len(sources)==35 and len(set(sources))==35,'Expected exact35 owned candidate roots')
 for p in sources:
  check(p.is_absolute() and p.relative_to(ROOT).as_posix() in ALLOWED_RELATIVE,'Unowned candidate rejected: '+str(p));plain_ancestors(p)
  check(not any(p==x or p.is_relative_to(x) or x.is_relative_to(p) for x in PROTECTED),'Candidate overlaps protected original/shared/clone root: '+str(p))
  cwd=Path.cwd().resolve();check(cwd!=p and not cwd.is_relative_to(p),'Candidate contains current working directory: '+str(p))
  check(p.exists() or p.is_symlink(),'Candidate is absent; require new inventory: '+str(p))
  if p.is_symlink():
   expected=next(r for r in plan['candidate_roots_exact'] if r['path']==str(p))
   check(p==ROOT/'outputs/mojave-machine' and os.readlink(p)==expected['raw_link_target'] and p.resolve()==ROOT/'outputs/启明火箭','Only the exact known internal top-level alias may itself be staged as a symlink')
 for p in sources:check(not any(p!=q and p.is_relative_to(q) for q in sources),'Nested candidates would double-stage')
 return sources

def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--plan',type=Path,default=ROOT/'work/cleanup-plan-current.json');parser.add_argument('--acceptance-receipt',type=Path);parser.add_argument('--apply',action='store_true',help='Stage only after exact final acceptance. Never deletes.');a=parser.parse_args();plan=json.loads(a.plan.read_text());report={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'mode':'APPLY_STAGE_ONLY' if a.apply else 'DRY_RUN','deletions_performed':0,'processes_killed':0,'moves':[],'ready':False};journal=ROOT/'work/cleanup-stage-current.json'
 try:
  check(plan['commit']==EXPECTED_COMMIT and plan['release_manifest_sha256']==EXPECTED_MANIFEST,'Plan release identity differs');sources=validate_owned_roots(plan);groups=known_fingerprints(plan)
  report['candidate_paths_checked']=sum(match_fingerprints(g,Path(g['root'])) for g in groups);report['retained_clone']=clone_proof(plan);report['protected_inputs']=check_103_and_desktop(plan);report['outside_references']=outside_refs(plan)
  handles=open_handles(sources);report['open_candidate_handles']=handles;check(not handles,'Active candidate handles still open')
  owner=json.loads((ROOT/'work/output-preview-server.json').read_text());listen=subprocess.run(['lsof','-nP','-a','-p',str(owner['pid']),'-iTCP:'+str(owner['port']),'-sTCP:LISTEN','-Fpnc'],capture_output=True,text=True);check(not listen.stdout.strip(),'Known task preview server still listening; owner must close it, helper never kills')
  report['acceptance']=validate_acceptance(a.acceptance_receipt);report['ready']=True
  if not a.apply:report['result']='DRY_RUN passes; nothing moved';save(journal,report);return
  # Preserve small evidence before moving any generated path.
  subprocess.run([sys.executable,str(ROOT/'work/cleanup_preflight.py'),'--plan',str(a.plan),'--acceptance-report',str(a.acceptance_receipt),'--copy-receipts'],check=True,cwd=ROOT,stdout=subprocess.DEVNULL)
  preserved=Path(plan['retained_receipts_plan']['destination']);pm=json.loads((preserved/'preserved-receipts-manifest.json').read_text());success={r['source']:r for r in pm['files'] if 'target' in r}
  for r in plan['retained_receipts_plan']['files']:
   if r['mandatory']:check(r['source'] in success and sha(Path(success[r['source']]['target']))==success[r['source']]['sha256'],'Mandatory receipt not preserved: '+r['source'])
  # Also preserve actual final downloaded acceptance proofs, which did not exist
  # when the preparation receipt list was made.
  target=preserved/'final-verification-receipts';target.mkdir(parents=True,exist_ok=True)
  import shutil
  for name,p in [('final-acceptance.json',Path(report['acceptance']['path']))]+[(r['check']+'.json',Path(r['path'])) for r in report['acceptance']['checks']]:
   shutil.copy2(p,target/name);check(sha(p)==sha(target/name),'Final proof copy SHA differs')
  parent=ROOT/'.cleanup-quarantine';plain_ancestors(parent,True)
  if parent.exists():
   ownership=parent/'owner.json';check(ownership.is_file() and not ownership.is_symlink() and json.loads(ownership.read_text()).get('project_root')==str(ROOT),'Unknown existing quarantine directory')
  else:parent.mkdir();save(parent/'owner.json',{'project_root':str(ROOT),'purpose':'Task-owned reversible staging only; no deletion authorized by this file'})
  quarantine=parent/(datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'-'+uuid.uuid4().hex[:8]);quarantine.mkdir();report['quarantine']=str(quarantine);save(journal,report)
  check(not open_handles(sources),'A candidate was reopened during preflight')
  for group in groups:
   source=Path(group['root']);match_fingerprints(group,source);dest=quarantine/source.relative_to(ROOT);dest.parent.mkdir(parents=True,exist_ok=True);check(not dest.exists() and not dest.is_symlink(),'Quarantine target already exists');os.rename(source,dest);report['moves'].append({'source':str(source),'destination':str(dest),'known_entries':len(group['items'])});save(journal,report)
  report['post_stage_known_entries_checked']=sum(match_fingerprints(g,quarantine/Path(g['root']).relative_to(ROOT)) for g in groups)
  report['post_stage_open_handles']=open_handles([quarantine]);report['post_stage_outside_references']=outside_refs(plan);report['post_stage_protected_inputs']=check_103_and_desktop(plan);report['post_stage_retained_clone']=clone_proof(plan)
  for r in report['acceptance']['checks']:check(sha(Path(r['path']))==r['sha256'],'Actual acceptance proof changed while staging')
  check(not report['post_stage_open_handles'],'Staged files have active handles; preserve quarantine and review, never delete')
  report['post_stage_passed']=True;report['result']='35 owned roots staged reversibly; no deletion performed. Parent must independently review this post-stage proof before later removal.'
 except Exception as exc:
  report['error']=str(exc);report['result']='BLOCKED; nothing deleted. If moves are recorded, retain quarantine and review exact journal; this helper never overwrites an original path or deletes.';report['ready']=False
 finally:
  save(journal,report)
  if a.apply:
   receipt_root=Path(plan['retained_receipts_plan']['destination'])
   if receipt_root.exists():
    import shutil
    q=receipt_root/'cleanup-plan/post-stage-current.json';q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(journal,q)
  print(json.dumps({k:v for k,v in report.items() if k not in {'acceptance','moves'}},ensure_ascii=False,indent=2))
 if a.apply and not report.get('post_stage_passed'):raise SystemExit(1)

if __name__=='__main__':main()
