from pathlib import Path
import subprocess,json,hashlib,datetime
p=Path(__file__).resolve().parent
remote=json.loads(subprocess.check_output(["/opt/homebrew/bin/gh","api","repos/shanghaicellcenter/qiming-rocket-cad-reproduction/releases/417612933"]))
local={x.name:x for x in (p/"release-assets").iterdir() if x.is_file()}
assets={x["name"]:x for x in remote["assets"]}
assert set(local)==set(assets),(sorted(set(local)-set(assets)),sorted(set(assets)-set(local)))
rows=[]
for name,src in sorted(local.items()):
 h=hashlib.sha256()
 with src.open("rb") as f:
  while b:=f.read(4*1024*1024):h.update(b)
 digest=h.hexdigest();r=assets[name]
 assert r["size"]==src.stat().st_size and r["state"]=="uploaded" and r["digest"]=="sha256:"+digest,name
 rows.append({"name":name,"bytes":r["size"],"sha256":digest,"github_asset_id":r["id"],"github_digest":r["digest"],"passed":True})
x={"created_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"release_id":remote["id"],"tag":remote["tag_name"],"draft_at_check":remote["draft"],"all10_local_files_match_github_api_digest_and_size":True,"assets":rows,"actual_fresh_download_claimed":False}
(p/"remote-assets-upload-check.json").write_text(json.dumps(x,ensure_ascii=False,indent=2)+"\n")
print(json.dumps({"passed":True,"files":len(rows),"bytes":sum(r["bytes"] for r in rows),"draft":remote["draft"]}))
