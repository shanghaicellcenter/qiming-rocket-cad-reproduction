from pathlib import Path
import json,base64,sys
ROOT=Path('/Users/qianqiming/Documents/Codex/2026-10-19/new-chat')
HERE=ROOT/'work/assembly-film'; SRC=HERE/'source'
p=json.loads((ROOT/'work/virtual-assembly/assembly-stages.json').read_text());n=json.loads((ROOT/'work/virtual-assembly/narration-draft.json').read_text())
clips=[];t=0
for i,r in enumerate([n['intro'],*n['stages'],n['outro']]):
 d=max(8,len(r['narration_zh'])*.23+1.0);clips.append({'id':'intro' if i==0 else 'outro' if i==16 else 'stage'+str(i).zfill(2),'start':round(t,3),'end':round(t+d,3)});t+=d
# Preserve captured master chapter boundaries while changing explanatory wording.
fixed=HERE/'silent-timeline.json'
if fixed.exists():
 fixed_timeline=json.loads(fixed.read_text());clips=fixed_timeline['clips'];t=fixed_timeline['duration']
# Only an explicit final build may replace the captured silent master timing.
timeline={'duration':round(t,3),'clips':clips,'timing':'provisional until audio QA'}
if '--final' in sys.argv:
 timeline=json.loads((HERE/'final-timeline.json').read_text())
 assert timeline['captions_status']=='all actual acoustic subtitles present'
 assert len(timeline['clips'])==17 and all(c['captions'] for c in timeline['clips'])
 assert (ROOT/'outputs/启明火箭/media/逐步虚拟归位旁白.mp3').is_file()
plan={k:v for k,v in p.items() if k not in ['source_blend','source_usd']}
(SRC/'data.js').write_text('export const PLAN='+json.dumps(plan,ensure_ascii=False)+';\nexport const NARRATION='+json.dumps(n,ensure_ascii=False)+';\nexport const TIMELINE='+json.dumps(timeline,ensure_ascii=False)+';\n')

name_map=json.loads((ROOT/"work/native-cad/vehicle.name-source-map.json").read_text())
lookup={x["prim_path"]:x["source_filename_candidates"][0] for x in name_map["nodes"] if len(x.get("source_filename_candidates",[]))==1}
with (SRC/"data.js").open("a") as f:f.write("export const FILES="+json.dumps(lookup,ensure_ascii=False)+";\n")
qc=json.loads((ROOT/'outputs/virtual-assembly/逐环节质量核对说明.json').read_text())
assert qc['stage_count']==15 and qc['stage_mesh_occurrence_sum']==688
with (SRC/'data.js').open('a') as f:f.write('export const QC='+json.dumps(qc,ensure_ascii=False)+';\n')
