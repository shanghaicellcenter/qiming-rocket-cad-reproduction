"""One independent offline CPU Whisper content check, own task paths only."""
from pathlib import Path
import os,json,time,subprocess,re,hashlib
TASK=Path('/home/qianqiming/codex-mojave-assembly-voice-20261019')
MODEL=Path('/home/qianqiming/.cache/huggingface/hub/models--openai--whisper-large-v3-turbo/snapshots/41f01f3fe87f28c78e2fbf8b568835947dd65ed9')
for k,v in {'HF_HUB_OFFLINE':'1','TRANSFORMERS_OFFLINE':'1','CUDA_VISIBLE_DEVICES':'','OMP_NUM_THREADS':'6','MKL_NUM_THREADS':'6','TOKENIZERS_PARALLELISM':'false','PYTHONDONTWRITEBYTECODE':'1'}.items():os.environ[k]=v
import numpy as np,torch
from transformers import WhisperForConditionalGeneration,WhisperProcessor,pipeline
torch.set_num_threads(6);torch.set_num_interop_threads(1)
start=time.monotonic();processor=WhisperProcessor.from_pretrained(str(MODEL),local_files_only=True)
model=WhisperForConditionalGeneration.from_pretrained(str(MODEL),local_files_only=True,dtype=torch.float32,attn_implementation='eager').to('cpu').eval()
asr=pipeline('automatic-speech-recognition',model=model,tokenizer=processor.tokenizer,feature_extractor=processor.feature_extractor,device='cpu')
src=TASK/'assembly-narration-sample.wav'
raw=subprocess.run(['/usr/bin/ffmpeg','-nostdin','-v','error','-i',str(src),'-f','f32le','-ac','1','-ar','16000','pipe:1'],capture_output=True,check=True).stdout
audio=np.frombuffer(raw,dtype='<f4').copy();result=asr({'raw':audio,'sampling_rate':16000},return_timestamps='word',generate_kwargs={'language':'zh','task':'transcribe','max_new_tokens':192,'do_sample':False})
expected=json.loads((TASK/'sample-request.json').read_text())['text'];norm=lambda s:''.join(re.findall('[\u4e00-\u9fffA-Za-z0-9]',s)).lower()
reference_leak=any(t in result['text'] for t in ['欢迎收听','今天的天气','一起出去走走'])
record={'audio':str(src),'audio_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'engine':'Whisper large-v3-turbo','device':'cpu','offline':True,'expected':expected,'transcript':result['text'],'duration_seconds':len(audio)/16000,'words':[{'start':c['timestamp'][0],'end':c['timestamp'][1],'text':c['text']} for c in result.get('chunks',[])],'normalized_exact_match':norm(expected)==norm(result['text']),'reference_text_leak_detected':reference_leak,'elapsed_seconds':time.monotonic()-start,'timestamps':'Whisper decoder approximate acoustic alignment; not character averaging','actual_listening':'not performed by this agent; parent perceptual review pending','acceptance':'ASR result requires side-by-side review; naturalness not inferred from ASR'}
(TASK/'sample-asr.json').write_text(json.dumps(record,ensure_ascii=False,indent=2));print(json.dumps(record,ensure_ascii=False),flush=True)
