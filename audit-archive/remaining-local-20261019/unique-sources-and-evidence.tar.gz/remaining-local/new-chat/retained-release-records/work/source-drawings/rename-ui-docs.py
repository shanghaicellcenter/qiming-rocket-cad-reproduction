from pathlib import Path
import re, json, hashlib, shutil, subprocess
root=Path('/Users/qianqiming/Documents/Codex/2026-10-19/new-chat')
out=root/'outputs/mojave-machine'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pattern=re.compile(r'Mojave[\s_-]*Sphinx|MojaveSphinx|\bSphinx\b|莫哈韦(?:斯芬克斯)?|莫哈维(?:斯芬克斯)?|莫哈弗(?:斯芬克斯)?|斯芬克斯',re.I)
changed=[]
def save(p,text):
    before=p.read_text()
    if before!=text:
        oldsha=sha(p);p.write_text(text);changed.append({'path':str(p.relative_to(out)) if p.is_relative_to(out) else str(p.relative_to(root)),'before_sha256':oldsha,'after_sha256':sha(p)})
def display(s):return pattern.sub('启明火箭',s)

# Source identities and hashes remain in JSON. Markdown links retain their exact
# targets; visible file aliases are explicitly marked as display names.
for p in [*out.glob('*.md'),*out.glob('research/**/*.md'),*out.glob('library/**/*.md'),out/'native-cad/source-assembly-map.md',out/'source-components/阅读说明.md',out/'source/assembly-viewer/THIRD-PARTY-NOTICES.md']:
    if p.name=='OpenRocket-README-official.md':continue
    text=p.read_text(); protected={}
    def protect(m):
        key=f'@@PRESERVED_LINK_{len(protected)}@@';protected[key]=m.group(0);return key
    masked=re.sub(r'\]\([^)]*\)|https?://[^\s<>`]+',protect,text)
    updated=display(masked)
    for key,value in protected.items():updated=updated.replace(key,value)
    if updated!=text and ('| Mojave' in text or '`Mojave' in text or '.SLDASM' in text or 'HCR-5105 - Design' in text):
        note='显示名称说明：本文文件栏使用“启明火箭”展示别名；精确原文件身份与哈希以对应JSON来源记录为准，源文件没有重命名。\n\n'
        lines=updated.splitlines(keepends=True);updated=lines[0]+'\n'+note+''.join(lines[1:]).lstrip('\n')
    save(p,updated)

# Patch the actual gallery generator, then rebuild it. The DATA array and source
# JSON preserve exact identities; only strings sent to the DOM are filtered.
gp=root/'work/native-cad/build_preview_gallery.py';g=display(gp.read_text())
filter_js=r"const displayName=s=>String(s).replace(/Mojave[\s_-]*Sphinx|MojaveSphinx|\bSphinx\b|莫哈韦(?:斯芬克斯)?|莫哈维(?:斯芬克斯)?|莫哈弗(?:斯芬克斯)?|斯芬克斯/gi,'启明火箭');"
if 'const displayName=' not in g:g=g.replace('const buttons=',filter_js.replace('\\','\\\\')+'\nconst buttons=',1)
g=g.replace("(r.title+' '+r.name+' '+r.id)","(displayName(r.title)+' '+displayName(r.name)+' '+r.name+' '+r.id)")
g=g.replace('esc(r.title)','esc(displayName(r.title))').replace('esc(r.name)','esc(displayName(r.name))')
g=g.replace(".textContent=r.title;",".textContent=displayName(r.title);")
g=g.replace(".alt=r.title+' · '",".alt=displayName(r.title)+' · '")
g=g.replace("$('dialog code').textContent=r.name+","$('dialog code').textContent='展示文件名：'+displayName(r.name)+")
g=g.replace('搜索中文、原名或编号','搜索中文、显示文件名或编号')
g=g.replace('修订件未自动并入R01装配。</div>','修订件未自动并入R01装配。启明火箭为本地展示名；原设计归属Half Cat Rocketry，精确原文件身份保留在来源记录中。</div>')
save(gp,g)
portable=g.replace("ROOT=Path('/Users/qianqiming/Documents/Codex/2026-10-19/new-chat')\nout=ROOT/'outputs/mojave-machine/library'","ROOT=Path(__file__).resolve().parent.parent\nout=ROOT/'library'")
portable=portable.replace("ROOT/'work/native-cad/component-labels.json'","ROOT/'native-cad/component-labels.json'")
portable_path=out/'source/build-preview-gallery.py';portable_path.write_text(portable)
index_before=sha(out/'library/preview-index.json')
subprocess.run(['python3',str(portable_path)],check=True,capture_output=True)
assert sha(out/'library/preview-index.json')==index_before,'Gallery source identity index unexpectedly changed'

# Restore the real landing page from its existing source. Preserve the accidental
# JSON write as a work-only recovery copy rather than treating it as HTML.
landing=out/'打开项目.html'
if landing.read_text().lstrip().startswith('{'):shutil.copy2(landing,root/'work/source-drawings/landing-miswritten-json-recovery.json')
lp=out/'source/build-landing.py';s=lp.read_text()
s=s.replace('Mojave<br><em>Sphinx.</em>','启明<br><em>火箭</em>');s=display(s)
draw_link="    anchor('library/source-drawings/原图纸浏览.html','原图纸 · 13页','resource'),\n"
if draw_link not in s:s=s.replace("evidence_links=''.join([\n","evidence_links=''.join([\n"+draw_link)
save(lp,s);subprocess.run(['python3',str(lp)],check=True,capture_output=True)
assert landing.read_text().startswith('<!doctype html>')

dp=out/'library/source-drawings/原图纸浏览.html';s=display(dp.read_text())
s=s.replace('原图纸 · 十三页','启明火箭 · 原图纸十三页').replace('从原PDF逐页直接转换，保留完整页框。','原PDF未改；本图仅替换项目显示名，保留完整页框。')
s=s.replace('来源：启明火箭 Drawing Package - R01.pdf','来源：原作R01图纸PDF · 原设计 Half Cat Rocketry')
save(dp,s)

readme=out/'阅读我.md';s=readme.read_text()
note='“启明火箭”是本地展示名称，原设计归属 Half Cat Rocketry。源CAD/PDF、原始文件身份和哈希保持来源记录；图纸展示副本仅替换项目名称。\n\n'
if note not in s:s=s.replace('\n\n','\n\n'+note,1)
paper='\n[原图纸十三页](library/source-drawings/原图纸浏览.html)逐页保留全页框；原PDF未改，本图仅替换项目显示名。13页单独计数，不并入三维170条记录、510张三视图。\n'
if '原图纸十三页' not in s:s=s.replace('170不是物理零件总数。',paper+'\n170不是物理零件总数。')
save(readme,s)

audit={'display_name_zh':'启明火箭','original_design_author':'Half Cat Rocketry','source_metadata_modified':False,'source_geometry_modified':False,'gallery_source_index_sha256_unchanged':index_before,'source_record_count':170,'source_view_image_count':510,'drawing_pages_separate':13,'changed_text_files':changed,'portable_gallery_generator':'source/build-preview-gallery.py','landing_rebuilt_from_source':True,'latest_browser_check':'pending'}
(out/'research/display-name-audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'updated_docs':len(changed),'source_index_unchanged':True,'landing_html_bytes':landing.stat().st_size,'portable_generator':str(portable_path)},ensure_ascii=False))
