"""Restore retained USD visibility metadata in source .blend files in place.

No source CAD, USD, geometry, material, transform, hierarchy or GLB is edited.
The output is reopened to compare every source matrix and geometry digest.
"""
import bpy,json,hashlib
from pathlib import Path
import numpy as np

ROOT=Path('/Users/qianqiming/Documents/Codex/2026-10-19/new-chat')
DIRECTORY=ROOT/'work/native-cad/vehicle-blender'
def filehash(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        while True:
            b=f.read(1024*1024)
            if not b:break
            h.update(b)
    return h.hexdigest()
def geometry_digest(mesh):
    h=hashlib.sha256()
    for items,field,width,dtype in [(mesh.vertices,'co',3,np.float32),
        (mesh.loops,'vertex_index',1,np.int32),(mesh.polygons,'loop_total',1,np.int32),
        (mesh.polygons,'material_index',1,np.int32)]:
        a=np.empty(len(items)*width,dtype=dtype);items.foreach_get(field,a);h.update(a.tobytes())
    h.update(json.dumps([m.name if m else None for m in mesh.materials]).encode())
    return h.hexdigest()
def snapshot():
    # Blender deliberately leaves disabled viewport objects unevaluated on file
    # load, so their matrix_world can be the identity cache. Temporarily enable
    # evaluation for read-only matrix verification, then restore the flags.
    saved_visibility={o:o.hide_viewport for o in bpy.context.scene.objects if o.get('source_usd_path')}
    for o in saved_visibility:o.hide_viewport=False
    bpy.context.view_layer.update()
    result={}
    for o in bpy.context.scene.objects:
        if not o.get('source_usd_path'):continue
        result[o['source_usd_path']]={'name':o.name,'type':o.type,
            'parent_source_usd_path':o.parent.get('source_usd_path') if o.parent else None,
            'matrix_local':[list(r) for r in o.matrix_local],
            'matrix_world':[list(r) for r in o.matrix_world],
            'matrix_basis':[list(r) for r in o.matrix_basis],
            'matrix_parent_inverse':[list(r) for r in o.matrix_parent_inverse],
            'source_properties':{k:o[k] for k in o.keys() if k.startswith('source_')},
            'geometry_sha256':geometry_digest(o.data) if o.type=='MESH' else None}
    for o,v in saved_visibility.items():o.hide_viewport=v
    bpy.context.view_layer.update()
    return result

summary=[]
for stem in ('vehicle-original','vehicle-browse'):
    blend=DIRECTORY/(stem+'.blend');auditpath=DIRECTORY/(stem+'.audit.json')
    audit=json.loads(auditpath.read_text())
    source_usd=Path(audit['source_usd'])
    usd_hash=filehash(source_usd);assert usd_hash==audit['source_usd_sha256']
    before_file_hash=filehash(blend)
    bpy.ops.wm.open_mainfile(filepath=str(blend))
    before=snapshot();assert len(before)==1980
    originals=[o for o in bpy.context.scene.objects if o.get('source_usd_path')]
    changed=[]
    for o in originals:
        hidden=bool(o.get('source_hidden',False))
        if bool(o.hide_render)!=hidden or bool(o.hide_viewport)!=hidden:
            changed.append({'source_usd_path':o['source_usd_path'],
                'previous_hide_render':bool(o.hide_render),'previous_hide_viewport':bool(o.hide_viewport),
                'source_hidden':hidden})
        o.hide_render=hidden;o.hide_viewport=hidden
    assert len(changed) in (0,3)
    assert sum(o.type=='MESH' and o.hide_render for o in originals)==3
    assert before==snapshot()
    bpy.context.preferences.filepaths.save_version=0
    bpy.ops.wm.save_as_mainfile(filepath=str(blend),compress=True)
    # Drop RNA references before a true reopen; only plain arrays/hashes remain.
    del originals
    bpy.ops.wm.open_mainfile(filepath=str(blend))
    after=snapshot()
    assert before==after
    originals=[o for o in bpy.context.scene.objects if o.get('source_usd_path')]
    assert all(bool(o.hide_render)==bool(o.get('source_hidden',False)) and
        bool(o.hide_viewport)==bool(o.get('source_hidden',False)) for o in originals)
    assert sum(o.type=='MESH' and o.hide_render for o in originals)==3
    assert filehash(source_usd)==usd_hash
    current_file_hash=filehash(blend)
    by_path={o['source_usd_path']:o for o in originals}
    for row in audit['blender_objects']:
        o=by_path[row['source_usd_path']]
        row['blender_hide_render']=bool(o.hide_render)
        row['blender_hide_viewport']=bool(o.hide_viewport)
        row['blender_hide_set']=bool(o.hide_get())
    report={'blend_path':str(blend),'blend_sha256_before_visibility_restoration':before_file_hash,
        'blend_sha256':current_file_hash,'blend_bytes':blend.stat().st_size,
        'changed_visibility_objects':changed,'changed_visibility_object_count':len(changed),
        'default_source_hidden_mesh_count':3,
        'matrix_verification_temporarily_enabled_hidden_viewport_nodes':True,
        'matrix_verification_note':'Disabled viewport nodes are intentionally unevaluated by Blender after file load; the 3 hidden nodes were temporarily enabled only for matrix readback, then their saved visibility was restored without modifying transform channels.',
        'default_visibility_matches_source_usd_metadata':True,
        'hidden_meshes_retained_in_file':3,'source_objects_reopened_and_compared':1980,
        'source_meshes_reopened_and_compared':688,
        'all_source_geometry_and_material_assignment_digests_exact':True,
        'all_source_local_world_basis_parent_inverse_matrices_exact':True,
        'all_source_hierarchy_and_source_hash_properties_exact':True,
        'source_usd_file_sha256_unchanged':usd_hash,
        'blender_version':bpy.app.version_string,'geometry_or_glb_modified':False,
        'save_version':0,'compress':True,'true_reopen_verified':True}
    audit['source_visibility_restoration']=report
    audit['blend_artifact']={'path':str(blend),'bytes':blend.stat().st_size,'sha256':current_file_hash}
    auditpath.write_text(json.dumps(audit,ensure_ascii=False,indent=2))
    summary.append(report)
    print('SOURCE_VISIBILITY_REPAIRED='+json.dumps(report,ensure_ascii=False),flush=True)
(DIRECTORY/'source-visibility-repair.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
