from pathlib import Path
import json,subprocess,os,datetime,sys
R=Path('/Users/qianqiming/Documents/Codex/2026-10-19/new-chat');H=R/'work/assembly-film'
original=R/'outputs/mojave-machine/source/vendor/machine/scripts/record.mjs';s=original.read_text()
for name in ['serve.mjs','browser.mjs']:
 s=s.replace("'./lib/"+name+"'",repr(str(original.parent/'lib'/name)))
s=s.replace("'./pinkscan.mjs'",repr(str(original.parent/'pinkscan.mjs')))
s=s.replace("'-movflags', '+faststart', silent", "'-movflags', '+frag_keyframe+empty_moov+default_base_moof', silent")
(H/'record-resumable.mjs').write_text(s)
log=(H/'resumable-capture.log').open('ab',buffering=0)
p=subprocess.Popen([sys.executable,str(H/'capture_chapters.py')],cwd=R,start_new_session=True,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT)
(H/'capture-process.json').write_text(json.dumps({'pid':p.pid,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'script':str(H/'capture_chapters.py')},indent=2)+'\n')
print(json.dumps({'pid':p.pid,'log':str(H/'resumable-capture.log')}))
