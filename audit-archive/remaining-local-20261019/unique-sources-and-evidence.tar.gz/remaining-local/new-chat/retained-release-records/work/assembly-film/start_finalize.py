from pathlib import Path
import subprocess,sys,json,datetime,os
H=Path(__file__).resolve().parent;R=H.parents[1];record=H/'finalize-process.json'
if record.exists():
 d=json.loads(record.read_text());r=subprocess.run(['ps','-p',str(d['pid']),'-o','stat=,command='],capture_output=True,text=True)
 if r.returncode==0 and 'finalize_film.py' in r.stdout and not r.stdout.lstrip().startswith('Z'):raise SystemExit('Already running actual finalization PID '+str(d['pid']))
m=json.loads((R/'work/virtual-assembly/narration-audio-manifest.json').read_text());assert m.get('eligible_for_final_movie') is True
plan=subprocess.run([sys.executable,str(H/'finalize_film.py'),'--plan-only'],capture_output=True,text=True,cwd=R);assert plan.returncode==0,plan.stderr;print(plan.stdout.strip())
log=(H/'finalize.log').open('wb');p=subprocess.Popen([sys.executable,'-u',str(H/'finalize_film.py')],cwd=R,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);d={'pid':p.pid,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'script':str(H/'finalize_film.py'),'log':str(H/'finalize.log')};record.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');print(json.dumps(d,ensure_ascii=False))
