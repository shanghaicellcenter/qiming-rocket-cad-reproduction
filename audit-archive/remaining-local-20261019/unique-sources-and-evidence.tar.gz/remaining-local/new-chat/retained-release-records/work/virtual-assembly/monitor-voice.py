"""Collect new own-track outputs; run ASR once after serial TTS is idle."""
from pathlib import Path
import subprocess,sys,json,time
folder=Path(__file__).resolve().parent;start=time.monotonic();last=None
while time.monotonic()-start<2700:
    r=subprocess.run([sys.executable,str(folder/'collect-formal-voice.py')],text=True,capture_output=True)
    if r.returncode:print(r.stderr,flush=True);raise SystemExit(r.returncode)
    j=json.loads((folder/'narration-audio-manifest.json').read_text());state=(j['generated_track_count'],j['asr_checked_track_count'],str(j['remote_batch_status']))
    if state!=last:print(r.stdout.strip(),flush=True);last=state
    if j.get('guard_result',{}):
        guard=j['guard_result']
        if guard.get('exit_code') or guard.get('reason'):print('Own batch guard failed',guard,flush=True);raise SystemExit(1)
    if j['generated_track_count']==17:
        if j['asr_checked_track_count']<17:
            print('All 17 original-speed waveforms collected. Starting independent ASR while TTS waits idle.',flush=True)
            with (folder/'formal-asr-launch.log').open('w') as log:
                r=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=8','spark','/home/qianqiming/work/drama-3/.venv/bin/python /home/qianqiming/codex-mojave-assembly-voice-20261019/formal-offline-asr.py'],stdout=log,stderr=subprocess.STDOUT)
            if r.returncode:print('ASR failed; inspect formal-asr-launch.log. TTS retry worker is still bounded.',flush=True);raise SystemExit(r.returncode)
            subprocess.run([sys.executable,str(folder/'collect-formal-voice.py')],check=True)
        print('All initial audio and ASR evidence ready for side-by-side review. No automatic content acceptance.',flush=True);break
    if j.get('remote_batch_status',{}):
        if j['remote_batch_status'].get('state')=='stopped':print('Worker stopped before 17 waveforms; inspect evidence',flush=True);raise SystemExit(1)
    time.sleep(30)
else:raise RuntimeError('Own monitor reached 45 minute bound')
