from pathlib import Path
import hashlib,json
r=Path(__file__).resolve().parent
coverage=json.loads((r.parent/'legacy-source-audit/research/coverage.json').read_text())
main=json.loads((r/'library.index.json').read_text())
main_by_name={x['source_basename']:x for x in main['files']}
patchdir=r/'patches/HCR-5105'
patch_source=json.loads((patchdir/'source-manifest.json').read_text())
patch_verify=json.loads((patchdir/'independent-verification.json').read_text())
patch_output=next(patchdir.glob('*.usdc'))
rows=[]
for rec in coverage['records']:
    if rec['format'] not in ('SLDPRT','SLDASM'):continue
    base=Path(rec['relative_path']).name
    if rec['archive'].endswith('Mojave Sphinx CAD - R01.zip'):
        data=main_by_name[base]
        revision='main-R01'
        rel=data['usd_relative']
        source_hash=data['source_sha256']
        output_hash=data['usd_sha256']
        archive_hash=main['source_zip_sha256']
    elif rec['archive']==patch_verify['source_archive_relative'] and base==patch_source['source_basename']:
        revision='HCR-5105'
        rel=str(patch_output.relative_to(r))
        source_hash=patch_source['source_sha256']
        output_hash=patch_verify['output_sha256']
        archive_hash=patch_source['source_archive_sha256']
    else:raise RuntimeError(f'Unmapped native source identity: {rec["archive"]} / {rec["relative_path"]}')
    output=r/rel
    if not output.exists() or hashlib.sha256(output.read_bytes()).hexdigest()!=output_hash:raise RuntimeError('Output missing/hash mismatch')
    rows.append({'archive':rec['archive'],'relative_path':rec['relative_path'],'format':rec['format'],'revision_group':revision,'source_archive_sha256':archive_hash,'source_sha256':source_hash,'usd_relative':rel,'usd_sha256':output_hash,'native_conversion':'passed_nonempty','tess_lod':3,'source_simplification':'Source filename declares Mass Volume; preserved supplied geometry' if 'Mass Volume' in base else None,'visual_acceptance':'separate review required'})
assert len(rows)==134
assert len({(x['archive'],x['relative_path']) for x in rows})==134
result={'source_cad_file_record_count':coverage['summary']['cad_file_record_count'],'native_cad_record_count':len(rows),'native_part_record_count':sum(x['format']=='SLDPRT' for x in rows),'native_assembly_record_count':sum(x['format']=='SLDASM' for x in rows),'main_R01_native_count':sum(x['revision_group']=='main-R01' for x in rows),'patch_native_count':sum(x['revision_group']=='HCR-5105' for x in rows),'other_format_record_count':coverage['summary']['cad_file_record_count']-len(rows),'identity_basis':'archive + relative_path; source records are not geometric part counts','all_native_identity_records_mapped':True,'records':rows}
(r/'native-source-readiness.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='records'},indent=2))
