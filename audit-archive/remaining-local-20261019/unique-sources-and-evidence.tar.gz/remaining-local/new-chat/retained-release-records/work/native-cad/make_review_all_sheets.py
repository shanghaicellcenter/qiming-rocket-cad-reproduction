from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import json,textwrap,hashlib
r=Path(__file__).resolve().parent/'original-part-library/review-all'
a=json.loads((r/'review-all.audit.json').read_text());rows=a['rows'];font=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',15);small=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',13)
sheets=[]
for page in range((len(rows)+15)//16):
 subset=rows[page*16:(page+1)*16];sheet=Image.new('RGB',(1280,1504),(237,239,242));d=ImageDraw.Draw(sheet)
 for n,row in enumerate(subset):
  x=(n%4)*320;y=(n//4)*376
  im=Image.open(row['image']).convert('RGBA');background=Image.new('RGBA',im.size,(244,245,247,255));background.alpha_composite(im);sheet.paste(background.convert('RGB'),(x,y+56))
  name=Path(row['source_filename']).stem
  short=name
  while font.getlength(row['source_id']+' | '+short)>302:
   short=short[:-2]+'…' if not short.endswith('…') else short[:-2]+'…'
  d.rectangle((x,y,x+319,y+55),fill=(227,237,244) if row['format']=='BINARY_STL' else (221,225,231))
  d.text((x+8,y+5),row['source_id']+' | '+short,font=font,fill=(24,30,38))
  status='Original STL; unit undeclared' if row['format']=='BINARY_STL' else 'Native CAD / source geometry'
  if row['source_mass_volume']:status='SOURCE MASS VOLUME (simplified source)'
  d.text((x+8,y+29),status,font=small,fill=(113,57,15) if row['source_mass_volume'] else (65,75,88))
 path=r/f'contactsheet-{page+1:02d}.png';sheet.save(path,optimize=True)
 sheets.append({'page':page+1,'path':str(path),'source_ids':[x['source_id'] for x in subset],'source_count':len(subset),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'bytes':path.stat().st_size})
result={'source_records':len(rows),'sheet_count':len(sheets),'source_ids_in_sheets':len({i for s in sheets for i in s['source_ids']}),'all_155_included_once':len([i for s in sheets for i in s['source_ids']])==155 and len({i for s in sheets for i in s['source_ids']})==155,'sheets_bytes':sum(x['bytes'] for x in sheets),'individual_card_bytes':a['total_png_bytes'],'total_image_bytes':sum(x['bytes'] for x in sheets)+a['total_png_bytes'],'source_mass_volume_ids':[x['source_id'] for x in rows if x['source_mass_volume']],'sheets':sheets}
assert result['all_155_included_once'] and result['total_image_bytes']<50_000_000
(r/'contactsheet-index.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='sheets'},indent=2))
