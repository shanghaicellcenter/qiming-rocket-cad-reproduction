from pathlib import Path
import json,hashlib,subprocess,concurrent.futures,math,time
from PIL import Image,ImageDraw,ImageFont,ImageStat
root=Path('/Users/qianqiming/Documents/Codex/2026-10-19/new-chat')
home=root/'work/assembly-film';movie=home/'silent-master-启明火箭.mp4';out=home/'movie-review-qiming'
frames=out/'frames';sheets=out/'sheets';frames.mkdir(parents=True,exist_ok=True);sheets.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source_hash=sha(movie);progress=json.loads((home/'capture-progress.json').read_text());chapters=progress['entries']
assert progress['status']=='complete' and len(chapters)==17
assert all(c['index']==i and c['frames']==c['source_end_frame_exclusive']-c['source_first_frame'] for i,c in enumerate(chapters))
assert chapters[0]['source_first_frame']==0 and chapters[-1]['source_end_frame_exclusive']==6596
assert all(a['source_end_frame_exclusive']==b['source_first_frame'] for a,b in zip(chapters,chapters[1:]))
commands={
 'ffprobe':['/opt/homebrew/bin/ffprobe','-v','error','-count_frames','-show_streams','-show_format','-of','json',str(movie)],
 'decode':['/opt/homebrew/bin/ffmpeg','-hide_banner','-v','warning','-xerror','-err_detect','explode','-i',str(movie),'-map','0:v:0','-vsync','0','-f','null','-']}
def run(name):
 t=time.monotonic();r=subprocess.run(commands[name],capture_output=True,text=True)
 (out/(name+'.stderr.log')).write_text(r.stderr)
 if name=='ffprobe':(out/'ffprobe.json').write_text(r.stdout)
 return {'command':commands[name],'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-t,'stderr_bytes':len(r.stderr.encode())}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool: decode=dict(zip(commands,pool.map(run,commands)))
assert all(v['exit_code']==0 for v in decode.values()),decode
probe=json.loads((out/'ffprobe.json').read_text());v=[s for s in probe['streams'] if s['codec_type']=='video'];a=[s for s in probe['streams'] if s['codec_type']=='audio']
assert len(v)==1 and v[0]['width']==1280 and v[0]['height']==720 and v[0]['r_frame_rate']=='30/1' and int(v[0]['nb_read_frames'])==6596
assert not a,'Expected silent master; unexpected audio track'
selection=[]
def add(label,n,chapter,kind):selection.append({'label':label,'frame':int(n),'seconds':int(n)/30,'chapter':chapter,'kind':kind})
for c in chapters:
 i=c['index'];start=c['source_first_frame'];count=c['frames']
 add(f'chapter-{i:02d}-middle',start+count//2,i,'chapter-middle')
 add(f'chapter-{i:02d}-returned',start+min(count-1,round(count*.9)),i,'chapter-returned')
 if i in (3,8,9,10,14,15):
  for phase in (.10,.25,.75,.98):add(f'chapter-{i:02d}-phase-{round(phase*100):02d}',start+min(count-1,round(count*phase)),i,'key-phase')
for i,c in enumerate(chapters[1:],1):
 add(f'cut-{i:02d}-before',c['source_first_frame']-1,i-1,'boundary-before')
 add(f'cut-{i:02d}-after',c['source_first_frame'],i,'boundary-after')
add('first-frame',0,0,'endpoint');add('last-frame',6595,16,'endpoint')
unique=sorted(set(r['frame'] for r in selection));vf='select='+ '+'.join(f'eq(n\\,{n})' for n in unique)
(out/'frame-selection.json').write_text(json.dumps(selection,indent=2)+'\n');(out/'select-filter.txt').write_text(vf)
cmd=['/opt/homebrew/bin/ffmpeg','-hide_banner','-v','error','-i',str(movie),'-vf',vf,'-vsync','0',str(frames/'extract-%03d.png')]
r=subprocess.run(cmd,capture_output=True,text=True);(out/'frame-extraction.stderr.log').write_text(r.stderr);assert r.returncode==0,r.stderr
got=sorted(frames.glob('extract-*.png'));assert len(got)==len(unique),(len(got),len(unique))
mapping=dict(zip(unique,got))
for row in selection:
 image=Image.open(mapping[row['frame']]).convert('RGB');p=frames/(row['label']+'.png');image.save(p)
 row['image']=str(p.relative_to(out));row['sha256']=sha(p);row['pixel_size']=list(image.size);row['rgb_standard_deviation']=ImageStat.Stat(image).stddev
 assert image.size==(1280,720) and max(row['rgb_standard_deviation'])>5
for p in got:p.unlink()
font=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',18)
by={r['label']:r for r in selection};sheet_index=[]
def make_sheet(name,rows,columns=2):
 w,h=590,365;canvas=Image.new('RGB',(columns*w,44+math.ceil(len(rows)/columns)*h),'#e7edf3');d=ImageDraw.Draw(canvas);d.text((14,12),name+' | NEW QIMING SILENT MASTER',font=font,fill='#172533')
 for i,row in enumerate(rows):
  x=(i%columns)*w;y=44+(i//columns)*h;im=Image.open(out/row['image']).convert('RGB');im.thumbnail((570,321));d.text((x+10,y+6),f"{row['label']} | f{row['frame']} | {row['seconds']:.3f}s",font=font,fill='#172533');canvas.paste(im,(x+10,y+35))
 p=sheets/(name+'.png');canvas.save(p);sheet_index.append({'image':str(p.relative_to(out)),'sha256':sha(p),'frame_labels':[r['label'] for r in rows],'actual_visual_review':'pending'})
for start in range(0,17,4):make_sheet(f'chapters-{start//4+1:02d}',[by[f'chapter-{i:02d}-{kind}'] for i in range(start,min(17,start+4)) for kind in ('middle','returned')])
for start in range(1,17,4):make_sheet(f'boundaries-{(start-1)//4+1:02d}',[by[f'cut-{i:02d}-{kind}'] for i in range(start,min(17,start+4)) for kind in ('before','after')])
keys=[r for r in selection if r['kind']=='key-phase']
for start in range(0,len(keys),8):make_sheet(f'key-phases-{start//8+1:02d}',keys[start:start+8])
make_sheet('endpoints',[by['first-frame'],by['last-frame']])
assert sha(movie)==source_hash
audit={'movie':str(movie),'movie_sha256':source_hash,'movie_bytes':movie.stat().st_size,'not_the_old_master':True,'source_unchanged':True,'ffprobe':{'width':1280,'height':720,'fps':'30/1','decoded_video_frames':6596,'duration_seconds':float(probe['format']['duration']),'audio_stream_count':len(a),'subtitle_stream_count':sum(s['codec_type']=='subtitle' for s in probe['streams'])},'complete_strict_decode':decode,'chapters':chapters,'selected_frame_count':len(selection),'selected_unique_frame_count':len(unique),'frames':selection,'contact_sheets':sheet_index,'visual_review':'pending actual inspection','narration_or_subtitle_acceptance':False,'state':'silent picture master only; later audio/subtitle mux needs its own final acceptance'}
(out/'review.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'source_sha256':source_hash,'strict_decode_passed':True,'video_frames':6596,'duration':audit['ffprobe']['duration_seconds'],'audio_streams':len(a),'selected_frames':len(selection),'unique_frames':len(unique),'sheets':len(sheet_index),'visual':'pending'},ensure_ascii=False))
