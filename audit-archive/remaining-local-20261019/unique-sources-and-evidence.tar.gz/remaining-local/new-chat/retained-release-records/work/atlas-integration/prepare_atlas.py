#!/usr/bin/env python3
"""Read partner data, audit real images, and stage a portable atlas only after approval.

This script never writes into the partner project. It does not merge worker patches.
The partner must first finish its own merge and acknowledge its frozen snapshot.
"""
from __future__ import annotations

import argparse
import collections
import copy
import datetime as dt
import hashlib
import html
import json
from pathlib import Path
import re
import shutil
import urllib.parse

from PIL import Image

HERE = Path(__file__).resolve().parent
DEFAULT_PARTNER = Path('/Users/qianqiming/Documents/Codex/2026-10-19/ni')
KIND_LABELS = {
    'native_geometry_preview': '原 CAD 外形',
    'original_stl_preview': '原 STL 外形',
    'source_component_set_preview': '原 CAD 多件分示',
    'source_context': '原手册 CAD 局部',
    'source_photo_context': '原手册实照局部',
    'source_photo': '原手册实照局部',
    'source_labelled_context': '原手册标注局部',
    'source_material_context': '原手册材料局部',
    'same_material_reference': '同类材料参照',
    'teaching_schematic': '功能示意',
    'raw_stock_illustration': '原料形态示意',
    'stock_illustration': '原料形态示意',
    'raw_stock': '原料形态示意',
}


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path: Path):
    return json.loads(path.read_text())


def save(path: Path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def display(text):
    # Original filenames remain untouched in provenance and link parameters.
    return re.sub(r'mojave\s+sphinx', '启明火箭', str(text or ''), flags=re.I)


def within(path: Path, root: Path) -> bool:
    return path.resolve().is_relative_to(root.resolve())


def asset_path(partner: Path, rel: str) -> Path | None:
    if not isinstance(rel, str) or not rel or Path(rel).is_absolute():
        return None
    for base in (partner/'outputs/rocket', partner/'outputs/rocket-v2'):
        p = base/rel
        if within(p, base) and p.is_file():
            return p
    return None


def candidates(row):
    v = row.get('visual', {})
    images = []
    if v.get('image'):
        images.append({'image': v['image'], 'caption': v.get('caption', ''),
                       'sourceBasename': v.get('sourceBasename'), 'sourceAssemblyPresent':v.get('sourceAssemblyPresent')})
    for image in v.get('images', []):
        if image.get('image') and image['image'] not in [x['image'] for x in images]:
            images.append(image)
    if not v and row.get('thumbnail'):
        images.append({'image': row['thumbnail'], 'caption': row.get('thumbnailSource', '')})
    return images


def evidence(row):
    v = row.get('visual', {})
    kind = v.get('status') or ('original_stl_preview' if row.get('thumbnail') else 'missing')
    return {
        'kind': kind,
        'label': KIND_LABELS.get(kind, '图片类别待核对'),
        'caption': v.get('caption') or ('原 STL 外形预览；源文件身份与外观图来源分别保留。' if row.get('thumbnail') else ''),
        'sourceEvidence': v.get('sourceEvidence', {}),
        'identityCorrection': v.get('identityCorrection'),
        'sourcePartNumberOriginal': v.get('sourcePartNumberOriginal'),
    }


def inspect_image(path: Path):
    with Image.open(path) as im:
        im.load()
        size, mode = list(im.size), im.mode
    return {'bytes': path.stat().st_size, 'sha256': sha(path), 'size': size, 'mode': mode}


def bind_exchange_sources(rows, project_root):
    """Bind exact STEP filenames to the actual exchange reader index, never native fallbacks."""
    index = project_root/'library/exchange-source/step-library.audit.json'
    items = load(index)['items']
    byname = collections.defaultdict(list)
    for entry in items:
        byname[entry['source']['filename']].append(entry)
    bindings = []
    for row in rows:
        for image in row['images']:
            name = image.get('sourceBasename')
            if not name or not name.lower().endswith(('.step', '.stp')):
                continue
            matches = byname[name]
            assert len(matches) == 1, ('STEP source is missing or ambiguous', name, len(matches))
            entry = matches[0]; source = entry['source']; rid = entry['id']
            relative = source['source_extracted_relative']
            original = project_root/'native-cad/exchange-source'/relative
            assert original.is_file() and sha(original) == source['source_sha256']
            image['sourceLink'] = {
                'format': 'STEP', 'indexId': rid, 'basename': name,
                'href': '../exchange-source/交换格式来源图册.html#'+rid,
                'originalSourceHref': '../../native-cad/exchange-source/'+urllib.parse.quote(relative, safe='/'),
                'originalSourceSha256': source['source_sha256'],
            }
            bindings.append({'recordId': row['id'], **image['sourceLink']})
    return {'indexPathRelativeToProject': 'library/exchange-source/step-library.audit.json',
            'indexSha256': sha(index), 'indexCount': len(items),
            'exactFilenameBindings': bindings,
            'nativeFormatSubstitutionPerformed': False}


def audit_partner(partner: Path, stock_patch: Path | None = None):
    files = {'parts': partner/'work/rocket/parts.json',
             'custom': partner/'work/rocket/custom-parts.json'}
    source_hashes = {k: sha(v) for k, v in files.items()}
    rows = load(files['parts'])
    custom = load(files['custom'])
    base_rows = copy.deepcopy(rows)
    patch_info = None
    if stock_patch:
        patch_before_sha = sha(stock_patch)
        patch = load(stock_patch)
        assert len(patch['items']) == len({x['id']for x in patch['items']}) == 17
        byid = {x['id']: x for x in rows}
        applied, already_present = [], []
        for entry in patch['items']:
            row = byid[entry['id']]
            assert row['category'] == '原料'
            image = Path(entry['path'])
            assert sha(image) == entry['sha256'], 'Stock image bytes differ from independently reviewed patch'
            if candidates(row):
                assert row['visual']['image'] == entry['image']
                already_present.append(row['id'])
                continue
            v = row.setdefault('visual', {})
            v.update({key:copy.deepcopy(entry[key])for key in ['status','image','caption','sourceEvidence',
                       'editableSource','editableSourcePath','editableSourceSha256']if key in entry})
            # Worker review flags are provenance. This root integration uses separate independent QA.
            v['workerParentIndependentReviewPendingAtSnapshot'] = entry.get('parentIndependentReviewPending')
            row.setdefault('beginner', {}).update(copy.deepcopy(entry.get('beginner', {})))
            applied.append(row['id'])
        patch_info={'path':str(stock_patch),'sha256':patch_before_sha,'appliedInOwnMemoryOnly':applied,
                    'alreadyPresentNotAppliedTwice':already_present,'partnerFileModified':False}
    assert len(rows) == 172 and len(custom) == 34, 'Unexpected source row count'
    assert len({x['id'] for x in rows + custom}) == 206, 'Duplicate source identity'
    assets, out, errors = {}, [], []
    ids = {x['id'] for x in rows + custom}
    for row in rows + custom:
        is_custom = row in custom
        item = {
            'id': row['id'], 'name': row['name'],
            'recordType': 'custom' if is_custom else 'bom',
            'group': row['group'], 'groupName': row.get('groupName', row['group']),
            'role': row.get('role', ''), 'location': row.get('location', ''),
            'why': row.get('why', ''), 'interfaces': row.get('interfaces', []),
            'principle': row.get('principle', ''), 'misconception': row.get('misconception', ''),
            'beginner': row.get('beginner', {}),
            'sourceRef': row.get('sourceRef', {}),
            'sourceFile': row.get('sourceFile'), 'package': row.get('package'),
            'relatedIds': list(dict.fromkeys(row.get('relatedIds', []) + row.get('customPartIds', []))),
            'visual': evidence(row), 'images': [], 'sourceRecord':copy.deepcopy(row),
        }
        if row.get('sourceRef', {}).get('bomFile'):
            source = row['sourceRef']; bom_path = Path(source['bomFile'])
            original_line = bom_path.read_text().splitlines()[source['bomLine']-1]
            cells = [x.strip()for x in original_line.strip().strip('|').split('|')]
            item['procurementAsWritten'] = {'originalBOMRow':original_line,'allCells':cells,
                'sourceBOMFile':str(bom_path),'sourceBOMFileSha256':sha(bom_path),
                'rowNumber':source['bomLine'],'name':cells[1],'unitPrice':cells[2],
                'quantity':cells[3],'totalPrice':cells[4],'purpose':cells[5],'partNumber':cells[6]}
        for ref in candidates(row):
            path = asset_path(partner, ref['image'])
            if path is None:
                errors.append({'id': row['id'], 'error': 'image_path_missing', 'image': ref['image']})
                continue
            key = str(path.relative_to(partner))
            try:
                if key not in assets:
                    assets[key] = {'origin': key, **inspect_image(path)}
                meta = assets[key]
                item['images'].append({
                    'origin': key, 'image': ref['image'],
                    'caption': ref.get('caption', ''), 'sha256': meta['sha256'],
                    'size': meta['size'], 'sourceBasename': ref.get('sourceBasename'),
                    'sourceAssemblyPresent':ref.get('sourceAssemblyPresent'),
                })
            except Exception as exc:
                errors.append({'id': row['id'], 'error': 'image_decode_failed', 'detail': str(exc)})
        for rid in item['relatedIds']:
            if rid not in ids:
                errors.append({'id': row['id'], 'error': 'unknown_related_id', 'related': rid})
        out.append(item)
    for key, path in files.items():
        assert sha(path) == source_hashes[key], 'Partner JSON changed during audit; rerun'
    missing = [x['id'] for x in out if not x['images']]
    multi = [x['id'] for x in out if len(x['images']) > 1]
    pending = []
    pending_specs = [
        ('manual_cards', partner/'work/rocket-v2/manual-details-evidence/parts-visual-patch-all22.json'),
        ('functional_cards', partner/'work/rocket-v2/functional-visual-evidence/functional-visual-patch.json'),
    ]
    for category, path in pending_specs:
        if not path.exists():
            continue
        patch = load(path)
        records = []
        for p in patch.get('items', []):
            v = p.get('mergeVisual', p)
            image = asset_path(partner, v.get('image', ''))
            records.append({'id': p['id'], 'imageExists': image is not None,
                            'currentlyMissing': p['id'] in missing,
                            'parentIndependentReviewPending': v.get('visualReview', {}).get('parentIndependentReviewPending'),
                            'acceptedWorkerView': v.get('visualReview', {}).get('reviewed', v.get('visualReview', {}).get('actualViewed'))})
        pending.append({'category': category, 'patch': str(path.relative_to(partner)),
                        'patchSha256': sha(path), 'count': len(records), 'records': records})
    stock_pngs = sorted((partner/'work/rocket-v2/stock-visual-evidence').glob('*.png'))
    pending.append({'category': 'raw_stock_cards', 'count': len(stock_pngs),
                    'records': [{'id': x.stem, 'renderedPngExists': True, 'currentlyMissing': x.stem in missing,
                                 **inspect_image(x)} for x in stock_pngs]})
    report = {
        'checkedAtUTC': dt.datetime.now(dt.timezone.utc).isoformat(),
        'partnerRoot': str(partner),
        'partsSha256': source_hashes['parts'], 'customPartsSha256': source_hashes['custom'],
        'counts': {'bom': len(rows), 'custom': len(custom), 'records': len(out),
                   'withRealDecodedImages': len(out)-len(missing), 'withoutImages': len(missing),
                   'multiImageRecords': len(multi), 'imageReferences': sum(len(x['images']) for x in out),
                   'uniqueDecodedAssets': len(assets)},
        'missingIds': missing, 'multiImageIds': multi,
        'visualKinds': dict(collections.Counter(x['visual']['kind'] for x in out)),
        'errors': errors, 'assets': list(assets.values()), 'pendingWorkerDeliveries': pending,
        'partnerReadyAcknowledgementReceivedByThisScript': False,
        'independentStockPatch':patch_info,
        'baseParts':base_rows,'effectiveParts':rows,'completeCustomParts':custom,
        'acceptance': 'Current-state read-only audit. Worker output existence is not partner final acceptance.',
    }
    if stock_patch:
        assert sha(stock_patch) == patch_info['sha256'], 'Stock patch changed during audit'
    return report, out


HTML = r'''<!doctype html><html lang="zh-CN"><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>启明火箭 · 零件说明图册</title>
<style>
:root{font-family:-apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif;color:#182a31;background:#f4f3ee;line-height:1.65}*{box-sizing:border-box}body{margin:0}header,main,footer{max-width:1360px;margin:auto;padding:26px 28px}header{padding-top:38px}h1{font-size:34px;margin:8px 0}h2{font-size:20px;margin:5px 0}p{margin:8px 0}a{color:#006e78}button,input,select{font:inherit}button{cursor:pointer}.intro{max-width:920px}.counts{font-size:14px;color:#4a5d64}.tools{display:flex;gap:10px;flex-wrap:wrap;position:sticky;top:0;background:#f4f3eef5;z-index:5;padding:16px 0}.tools input{flex:1;min-width:200px}input,select{padding:10px 12px;border:1px solid #a8babd;border-radius:8px;background:white}.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:18px}.card{background:#fff;border:1px solid #d3dedc;border-radius:12px;overflow:hidden}.card:target{outline:3px solid #008795}.pictures{display:flex;background:#edf1ef}.pictures figure{flex:1;min-width:0;margin:0}.pictures img{display:block;object-fit:contain;width:100%;height:240px;cursor:zoom-in}.pictures figcaption{font-size:12px;padding:4px 12px}.body{padding:16px}.meta{color:#42636c;font-size:12px}.badge{display:inline-block;background:#e3efed;border:1px solid #bbd4d0;border-radius:20px;padding:2px 9px;margin:0 0 5px;font-size:12px}.caption{font-size:13px;color:#52666b}.field{margin:11px 0;overflow-wrap:anywhere}.field strong{display:block;color:#2c5e65;font-size:13px}.more{border-top:1px solid #e0e7e5;margin-top:12px;padding-top:10px}summary{cursor:pointer;color:#006b74}.links{display:flex;gap:9px;flex-wrap:wrap;font-size:13px;margin-top:12px}.empty{padding:24px}dialog{border:1px solid #adbfbc;border-radius:12px;padding:15px;max-width:min(1100px,95vw);max-height:95vh}dialog::backdrop{background:#172327bb}dialog img{max-width:100%;max-height:80vh;display:block;object-fit:contain}dialog button{float:right;border:1px solid #96aaa7;background:#fff;padding:5px 13px;border-radius:6px}footer{font-size:12px;color:#49636a}#status{margin-bottom:14px}@media(max-width:600px){header,main,footer{padding:18px}.pictures img{height:220px}h1{font-size:28px}.tools{position:static}.grid{grid-template-columns:1fr}}
</style>
<header><a href="../../打开项目.html">← 返回启明火箭项目</a><h1>零件说明图册</h1>
<p class="intro">把物料清单与定制件逐条看清楚。先看图片上的形体，再看它在哪里、与谁相连、为什么需要它。图片上方的标签说明图像来自原 CAD、原 STL、原手册局部，还是补绘的原料与功能示意。</p>
<p class="counts">172 条物料记录 + 34 条定制件记录。相同零件在采购材料、成品和不同位置中可能再次出现，206 条说明不代表 206 个独立装机零件。原 CAD 中的占位体不代表完整伞衣、软织物或电路。</p></header>
<main><div class="tools"><input id="query" type="search" placeholder="搜索名称、编号或用途" aria-label="搜索零件"><select id="group" aria-label="筛选系统"><option value="">所有系统</option></select><select id="kind" aria-label="筛选图片来源"><option value="">所有图片来源</option></select><select id="type" aria-label="筛选记录类型"><option value="">物料与定制件</option><option value="bom">物料清单</option><option value="custom">定制件</option></select></div><div id="status" aria-live="polite"></div><div class="grid" id="grid"></div></main>
<footer>开放项目来源：Half Cat Rocketry。原始文件身份保留在随附数据与来源记录中。单件外形、位置演示及功能示意各有说明；这些图像不构成加工、承压、密封或实物装配验收。相同源件可以服务于不同物料条目；功能图不会替代对应原件模型。</footer>
<dialog id="lightbox"><button id="close">关闭</button><p id="lightbox-title"></p><img id="large" alt=""></dialog>
<script id="atlas-data" type="application/json">__DATA__</script>
<script>
const DATA=JSON.parse(document.getElementById('atlas-data').textContent),rows=DATA.records;
const $=id=>document.getElementById(id),esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const display=x=>String(x??'').replace(/mojave\s+sphinx/ig,'启明火箭');
for(const [id,key,label]of[['group','group','groupName'],['kind','visual.kind','visual.label']]){let seen=new Map();for(const r of rows){const val=key.includes('.')?r.visual.kind:r[key],txt=label.includes('.')?r.visual.label:r[label];if(!seen.has(val))seen.set(val,txt)}for(const [v,t]of seen){const opt=document.createElement('option');opt.value=v;opt.textContent=display(t);$(id).append(opt)}}
const byid=new Map(rows.map(r=>[r.id,r]));
function field(label,text){return text?`<div class="field"><strong>${label}</strong>${esc(display(Array.isArray(text)?text.join(' · '):text))}</div>`:''}
function card(r){const b=r.beginner??{},pic=r.images.map((im,i)=>`<figure><img loading="lazy" src="${esc(im.localPath)}" alt="${esc(display(r.name))}：${esc(display(im.caption||r.visual.label))}" data-zoom="${esc(r.id)}" data-image="${i}" width="${im.size[0]}" height="${im.size[1]}">${r.images.length>1?`<figcaption>${esc(display(im.caption))}</figcaption>`:''}</figure>`).join('');const sources=[...new Set(r.images.filter(x=>x.sourceAssemblyPresent!==false).map(x=>x.sourceBasename).filter(x=>x&&/\.(sldprt|sldasm)$/i.test(x)))];
let refs=(r.relatedIds||[]).map(id=>byid.has(id)?`<a href="#${esc(id)}" data-jump="${esc(id)}">${esc(display(byid.get(id).name))}</a>`:'').join('');
let native=sources.map((n,i)=>`<a href="../../整箭原件检视.html?part=${encodeURIComponent(n)}" target="_blank" rel="noopener">检视${sources.length>1?'第'+(i+1)+'个':''}同源原件</a>`).join('');
const exchange=[...new Map(r.images.filter(im=>im.sourceLink?.format==='STEP').map(im=>[im.sourceLink.href,im.sourceLink])).values()];native+=exchange.map(s=>`<a href="${esc(s.href)}" data-source-format="STEP" data-source-id="${esc(s.indexId)}" target="_blank" rel="noopener">查看对应 STEP 来源</a>`).join('');
const s=r.sourceRef??{},provenance=[s.bomLine?'中文物料清单第 '+s.bomLine+' 行':'',s.manualSection||''].filter(Boolean).join('；');
return `<article class="card" id="${esc(r.id)}"><div class="pictures">${pic}</div><div class="body"><div class="meta">${esc(r.id)} · ${r.recordType==='bom'?'物料清单':'定制件'}</div><h2>${esc(display(r.name))}</h2><div class="badge">${esc(display(r.visual.label))}</div><p>${esc(display(b.summary||r.role))}</p>${field('先看哪里',b.look)}${field('与谁相连',b.connect||r.interfaces)}<p class="caption">${esc(display(r.visual.caption))}</p><details class="more"><summary>展开用途、原理与来源</summary>${field('位置',r.location)}${field('为什么需要',r.why)}${field('原理',r.principle)}${field('一个问题',b.question)}${field('解释',b.answer)}${field('容易混淆',r.misconception)}${field('来源定位',provenance)}${field('图片来源与边界',r.visual.sourceEvidence?.limits||r.visual.sourceEvidence?.limitations)}${field('原物料条目（原BOM整行）',r.procurementAsWritten?.originalBOMRow?.replace(/<br\s*\/?>/gi,' / '))}${field('原表名称',r.procurementAsWritten?.name)}${field('原表采购数量',r.procurementAsWritten?.quantity)}${field('原表货号',r.procurementAsWritten?.partNumber)}${field('原表单价 / 总价',r.procurementAsWritten?[r.procurementAsWritten.unitPrice,r.procurementAsWritten.totalPrice]:null)}${field('原资料更正',r.visual.identityCorrection)}<div class="links">${native}${refs}</div></details></div></article>`}
function searchText(r){const s=JSON.stringify([r.id,r.name,r.groupName,r.role,r.location,r.principle,r.beginner,r.procurementAsWritten,r.sourceFile,r.images.map(x=>x.sourceBasename)]);return (s+' '+display(s)).toLowerCase()}
function render(){const q=$('query').value.trim().toLowerCase(),g=$('group').value,k=$('kind').value,t=$('type').value;const visible=rows.filter(r=>(!g||r.group===g)&&(!k||r.visual.kind===k)&&(!t||r.recordType===t)&&(!q||searchText(r).includes(q)));$('grid').innerHTML=visible.map(card).join('');$('status').textContent=`显示 ${visible.length} / ${rows.length} 条说明`;window.atlasReview={recordCount:rows.length,visible:visible.length,imageReferences:rows.reduce((a,r)=>a+r.images.length,0),allHaveImages:rows.every(r=>r.images.length),uniqueImages:new Set(rows.flatMap(r=>r.images.map(x=>x.localPath))).size}}
for(const id of['query','group','kind','type'])$(id).addEventListener('input',render);
$('grid').addEventListener('click',e=>{let target=e.target;if(target.dataset.zoom){const r=byid.get(target.dataset.zoom),im=r.images[Number(target.dataset.image)];$('large').src=im.localPath;$('large').alt=display(r.name);$('lightbox-title').textContent=display(r.name+' · '+r.visual.label);$('lightbox').showModal()}if(target.dataset.jump){e.preventDefault();for(const id of['query','group','kind','type'])$(id).value='';render();location.hash=target.dataset.jump;document.getElementById(target.dataset.jump)?.scrollIntoView({block:'start'})}});$('close').onclick=()=>$('lightbox').close();$('lightbox').addEventListener('click',e=>{if(e.target===$('lightbox'))$('lightbox').close()});render();if(location.hash){requestAnimationFrame(()=>document.getElementById(decodeURIComponent(location.hash.slice(1)))?.scrollIntoView({block:'start'}))}
</script></html>'''


def stage(partner, report, rows, readiness, independent=False):
    ack = load(readiness)
    if independent:
        assert ack.get('mode') == 'root_independent_snapshot'
        assert ack.get('acceptedForOwnStaticSnapshot') is True
        assert ack.get('partnerFrozenClaimed') is False and ack.get('humanApprovalClaimed') is False
        assert ack.get('independentVisualReviewEvidence'), 'Actual independent review evidence required'
        for evidence in ack['independentVisualReviewEvidence']:
            assert sha(Path(evidence['path'])) == evidence['sha256'], 'Independent review evidence changed'
        if report.get('independentStockPatch'):
            assert ack.get('stockPatchSha256') == report['independentStockPatch']['sha256']
    else:
        assert ack.get('ready') is True, 'Partner readiness acknowledgement is required'
        assert ack.get('reviewedAllImages') is True, 'All-image final review acknowledgement required'
    assert ack.get('partsSha256') == report['partsSha256'], 'parts.json differs from acknowledged snapshot'
    assert ack.get('customPartsSha256') == report['customPartsSha256'], 'custom-parts.json differs from acknowledged snapshot'
    assert not report['missingIds'] and not report['errors'], 'Source image coverage is incomplete'
    assert all(x['visual']['kind'] in KIND_LABELS for x in rows), 'Unknown image evidence class'
    target = HERE/'staged/部件说明图册'
    assert not target.exists(), 'Do not replace an already staged snapshot; archive it explicitly first'
    (target/'images').mkdir(parents=True)
    copies = {}
    for row in rows:
        for ref in row['images']:
            src = partner/ref['origin']
            assert sha(src) == ref['sha256'], 'Source image changed after read audit'
            dest = 'images/'+ref['sha256']+src.suffix.lower()
            if dest not in copies:
                shutil.copy2(src, target/dest)
                assert sha(target/dest) == ref['sha256']
                copies[dest] = ref['sha256']
            ref['localPath'] = dest
    exchange = bind_exchange_sources(rows, HERE.parents[1]/'outputs/启明火箭')
    data = {'title': '启明火箭 · 零件说明图册', 'records': rows, 'exchangeSourceIndex': exchange,
            'sourceSnapshot': {k: report[k] for k in ['checkedAtUTC', 'partsSha256', 'customPartsSha256']},
            'counts': report['counts'], 'sameSourceImagesDeduplicatedByBytes': True}
    save(target/'图册数据.json', data)
    shutil.copy2(partner/'work/rocket/parts.json', target/'来源-base-parts.json')
    assert sha(target/'来源-base-parts.json') == report['partsSha256']
    save(target/'来源-effective-parts.json', report['effectiveParts'])
    shutil.copy2(partner/'work/rocket/custom-parts.json', target/'来源-custom-parts.json')
    assert sha(target/'来源-custom-parts.json') == report['customPartsSha256']
    if report.get('independentStockPatch'):
        shutil.copy2(report['independentStockPatch']['path'], target/'来源-原料图补丁.json')
    payload = json.dumps(data, ensure_ascii=False).replace('</', '<\\/')
    (target/'部件说明图册.html').write_text(HTML.replace('__DATA__', payload))
    shutil.copy2(readiness, target/('本方独立复核依据.json' if independent else '伙伴最终复核确认.json'))
    save(target/'资产清单.json', {'files': [{'path': str(p.relative_to(target)), 'bytes': p.stat().st_size,
                                          'sha256': sha(p)} for p in sorted(target.rglob('*')) if p.is_file()],
                                'counts': report['counts'], 'sourceJSONFrozenSha256': data['sourceSnapshot']})
    (target/'阅读我.md').write_text('# 启明火箭零件说明图册\n\n双击“部件说明图册.html”离线打开。必须保留同目录 images 和数据文件。将本文件夹放在启明火箭项目的 library 下，整箭跳转与项目返回链接即可使用。图册没有网络请求或外部字体。\n\n说明覆盖 172 条物料与 34 条定制件；不是独立装机数量。原 CAD、原 STL、原手册局部、原料示意和功能示意在每条说明上分别标明。球阀的原阀体和阀柄保留分图，不会伪造装配相对位置。\n\n在整箭中打开同源原件，只证明原件名称在原 CAD 中的对应关系，不表示所有采购材料或地面部件都处在箭上的同一安装位置。\n\n开放资料来源：Half Cat Rocketry。说明与图片按实际独立审查证据冻结在本快照中，不声称人类验收或伙伴整个项目冻结。原始 sourceRecord 完整保留，采购原文定位与原字段另有可读数据；公开图卡可编辑源的字体发布副本由来源树另行提供，不在此静态图册内塞入原packed系统字体。\n')
    return str(target)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--partner-root', type=Path, default=DEFAULT_PARTNER)
    parser.add_argument('--build', action='store_true')
    parser.add_argument('--readiness', type=Path)
    parser.add_argument('--stock-patch', type=Path)
    parser.add_argument('--independent-review', type=Path)
    args = parser.parse_args()
    report, rows = audit_partner(args.partner_root, args.stock_patch)
    save(HERE/'current-inventory.json', report)
    save(HERE/'proposed-atlas-data.json', {'records': rows})
    if args.build:
        assert args.readiness or args.independent_review, 'Actual partner or independent review evidence is required'
        target = stage(args.partner_root, report, rows, args.independent_review or args.readiness,
                       independent=bool(args.independent_review))
        print(json.dumps({'staged': target, 'counts': report['counts']}, ensure_ascii=False))
    else:
        print(json.dumps({'counts': report['counts'], 'missingIds': report['missingIds'],
                          'errors': report['errors'], 'assetCopiesPerformed': False}, ensure_ascii=False))


if __name__ == '__main__':
    main()
