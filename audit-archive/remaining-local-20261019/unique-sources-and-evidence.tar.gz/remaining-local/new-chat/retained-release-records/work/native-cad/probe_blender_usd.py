import bpy,json
from pathlib import Path
for o in list(bpy.data.objects):bpy.data.objects.remove(o,do_unlink=True)
log={}
class SourcePathHook(bpy.types.USDHook):
    bl_idname='source_path_probe'
    bl_label='Original USD Path Probe'
    @staticmethod
    def on_import(context):
        log['context_attributes']=dir(context)
        if hasattr(context,'get_prim_map'):
            mapping=context.get_prim_map()
            log['prim_map_type']=str(type(mapping))
            log['prim_map']={str(k):[{'type':str(type(x)),'name':getattr(x,'name',None)} for x in v] for k,v in mapping.items()}
            for path,ids in mapping.items():
                for x in ids:
                    try:x['source_usd_path']=str(path)
                    except Exception:pass
        return True
bpy.utils.register_class(SourcePathHook)
r=bpy.ops.wm.usd_import(filepath=str(Path('work/native-cad/fin.usdc').resolve()),merge_parent_xform=False,
    apply_unit_conversion_scale=False,support_scene_instancing=True,create_collection=True,
    import_visible_only=False,import_cameras=False,import_lights=False,import_volumes=False,
    import_skeletons=False,import_blendshapes=False,import_subdivision=False,
    property_import_mode='ALL',validate_meshes=False)
log['objects']=[{'name':o.name,'type':o.type,'parent':o.parent.name if o.parent else None,
 'source_usd_path':o.get('source_usd_path'), 'mesh_path':o.data.get('source_usd_path') if o.type=='MESH' else None,
 'matrix_world':[list(r) for r in o.matrix_world]} for o in bpy.context.scene.objects]
Path('work/native-cad/blender-usd-capability.json').write_text(json.dumps(log,ensure_ascii=False,indent=2))
print('USD_IMPORT_CAPABILITY='+json.dumps(log,ensure_ascii=False))
