import hashlib,json,zipfile
from pathlib import Path
r=Path(__file__).resolve().parent
out=r/'supplement-library';out.mkdir(exist_ok=True)
source_root=Path('/Users/qianqiming/Desktop/火箭设计 中文版')
sha=lambda b:hashlib.sha256(b).hexdigest()
native=json.loads((r/'native-source-readiness.json').read_text())['records']
unmatched=json.loads((r/'vehicle.name-source-map.json').read_text())['source_files_not_name_matched']
rows=[]
for name in unmatched:
 if not name.endswith('.SLDPRT'):continue
 n=next(x for x in native if x['revision_group']=='main-R01' and Path(x['relative_path']).name==name)
 rows.append({'id':f'S{len(rows)+1:02d}','format':'USD_FROM_NATIVE','source_filename':name,'source_archive':n['archive'],'source_member':n['relative_path'],'source_sha256':n['source_sha256'],'source_archive_sha256':n['source_archive_sha256'],'input_path':str(r/n['usd_relative']),'input_sha256':n['usd_sha256'],'original_units':'USD declared 0.0254 metres per unit; source converter wrapper retained','metres_per_native_unit':0.0254,'unit_is_physical':True,'revision_group':'main-R01'})
n=next(x for x in native if x['revision_group']=='HCR-5105')
rows.append({'id':f'S{len(rows)+1:02d}','format':'USD_FROM_NATIVE','source_filename':Path(n['relative_path']).name,'source_archive':n['archive'],'source_member':n['relative_path'],'source_sha256':n['source_sha256'],'source_archive_sha256':n['source_archive_sha256'],'input_path':str(r/n['usd_relative']),'input_sha256':n['usd_sha256'],'original_units':'USD declared 0.0254 metres per unit; source converter wrapper retained','metres_per_native_unit':0.0254,'unit_is_physical':True,'revision_group':'HCR-5105'})
archive_rel='英文原件/Printed Components - R01.zip';archive=source_root/archive_rel
archive_hash=sha(archive.read_bytes())
sources=out/'stl-sources';sources.mkdir(exist_ok=True)
with zipfile.ZipFile(archive) as z:
 for member in z.namelist():
  name=Path(member).name
  if not(name.startswith('BRKT-EGSE-') or name.startswith('CVR-ANT-')) or not name.endswith('.STL'):continue
  raw=z.read(member);p=sources/name;p.write_bytes(raw)
  rows.append({'id':f'S{len(rows)+1:02d}','format':'BINARY_STL','source_filename':name,'source_archive':archive_rel,'source_member':member,'source_sha256':sha(raw),'source_archive_sha256':archive_hash,'input_path':str(p),'input_sha256':sha(raw),'original_units':'STL has no declared units; retain original numerical coordinates; display scale is not physical','metres_per_native_unit':None,'unit_is_physical':False,'revision_group':'printed-R01'})
assert len(rows)==10
for row in rows:assert sha(Path(row['input_path']).read_bytes())==row['input_sha256']
(out/'manifest.json').write_text(json.dumps({'scope':'10 independent supplied source geometries; not a vehicle assembly, no inferred design','items':rows},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'checkpoint':'manifest_ready','items':len(rows),'native':sum(x['format']=='USD_FROM_NATIVE' for x in rows),'stl':sum(x['format']=='BINARY_STL' for x in rows),'path':str(out/'manifest.json')},indent=2))
