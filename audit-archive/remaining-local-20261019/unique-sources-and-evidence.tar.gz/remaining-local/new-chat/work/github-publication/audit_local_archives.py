"""Stream-verify every packed byte without extracting or mutating release inputs."""
from pathlib import Path,PurePosixPath
import hashlib,json,datetime,tarfile
from verify_release import sha,safe_path
base=Path(__file__).resolve().parent;assets=base/'release-assets';manifest=json.loads((assets/'release-manifest.json').read_text());entries=json.loads((assets/'assets.json').read_text())['assets'];expected={r['path']:r for r in manifest['files']};expected_links={r['path']:r['target'] for r in manifest['symlinks']};seen=set();links={};checks=[]
checksums={name:digest for digest,name in (line.split(None,1) for line in (assets/'SHA256SUMS').read_text().splitlines() if line.strip())}
for name in ['assets.json','release-manifest.json']:assert sha(assets/name)==checksums[name]
for entry in entries:
 p=assets/entry['name'];assert p.stat().st_size==entry['bytes'] and sha(p)==entry['sha256'] and sha(p)==checksums[p.name];n=0;size=0
 with tarfile.open(p,'r|gz') as tar:
  for member in tar:
   safe_path(base/'archive-path-audit-nonexistent-root',member.name)
   if member.issym():
    assert member.name in expected_links and member.linkname==expected_links[member.name] and member.name not in links
    t=PurePosixPath(member.name).parent/PurePosixPath(member.linkname)
    assert not PurePosixPath(member.linkname).is_absolute()
    # Resolve only in the virtual root; no extraction or link creation occurs.
    assert (base/'archive-path-audit-nonexistent-root'/str(t)).resolve().is_relative_to((base/'archive-path-audit-nonexistent-root').resolve())
    links[member.name]=member.linkname;continue
   assert member.isfile() and member.name in expected and member.name not in seen,member.name
   row=expected[member.name];assert member.size==row['bytes'] and row['layer']==entry['layer']
   f=tar.extractfile(member);assert f;h=hashlib.sha256();read=0
   while data:=f.read(4*1024*1024):h.update(data);read+=len(data)
   assert read==row['bytes'] and h.hexdigest()==row['sha256'],member.name
   seen.add(member.name);n+=1;size+=read
 assert n==entry['file_count'];checks.append({'name':p.name,'files_checked':n,'logical_bytes_checked':size,'archive_sha256':entry['sha256'],'layer':entry['layer']});print('ARCHIVE_AUDIT_CHECKPOINT',p.name,n,flush=True)
assert seen==set(expected) and links==expected_links
out={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'all_local_archives_streamed_and_sha256_verified','files_checked':len(seen),'logical_bytes_checked':sum(r['bytes'] for r in expected.values()),'symlinks_checked':len(links),'assets_checked':len(checks),'manifest_sha256':sha(assets/'release-manifest.json'),'checks':checks,'is_actual_github_download':False,'is_full_restore_execution':False,'no_extraction_or_public_input_mutation':True}
(base/'local-archive-stream-audit.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps(out,ensure_ascii=False))
