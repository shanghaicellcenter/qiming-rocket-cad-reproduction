import {launch} from '../../outputs/启明火箭/source/vendor/machine/scripts/lib/browser.mjs';
import fs from 'node:fs';import path from 'node:path';import {pathToFileURL} from 'node:url';
const root=path.resolve('outputs/启明火箭/library/exchange-source');
const {browser,page}=await launch({width:1600,height:1100});
const errors=[],external=[];
page.on('pageerror',e=>errors.push(String(e)));page.on('console',m=>{if(m.type()==='error')errors.push(m.text())});
page.on('request',r=>{if(/^https?:/i.test(r.url()))external.push(r.url())});
await page.goto(pathToFileURL(path.join(root,'交换格式来源图册.html')).href,{waitUntil:'load'});
await page.screenshot({path:path.join(root,'review/gallery-first-screen.png')});
const initial=await page.evaluate(()=>({title:document.title,stepcards:document.querySelectorAll('#stepgrid .card').length,images:document.images.length,oldNameVisible:/mojave|sphinx|莫哈韦|斯芬克斯/i.test(document.body.innerText),text:document.body.innerText.slice(0,350)}));
await page.locator('#search').fill('HCR-5105');
const search=await page.locator('#count').textContent();
await page.locator('#search').fill('');
const links=await page.locator('a[href]').evaluateAll(as=>as.map(a=>({href:a.href,label:a.innerText})));const missing=[];
for(const link of links){if(link.href.startsWith('file:')&&!fs.existsSync(decodeURIComponent(new URL(link.href).pathname)))missing.push(link)}
const dxf=[];
for(const id of ['DXF-001','DXF-002','DXF-003']){
 await page.goto(pathToFileURL(path.join(root,'dxf',id+'-model.svg')).href,{waitUntil:'load'});
 await page.screenshot({path:path.join(root,'review',id+'-source.png')});dxf.push({id,screenshot:'review/'+id+'-source.png'});
}
await page.goto(pathToFileURL(path.join(root,'dxf/DXF-002-paper.svg')).href,{waitUntil:'load'});await page.screenshot({path:path.join(root,'review/DXF-002-paper-source.png')});
const report={initial,patchSearch:search,localLinks:links.length,missingLinks:missing,externalRequests:external,pageErrors:errors,dxfViews:dxf};
fs.writeFileSync(path.join(root,'review/gallery-browser-review.json'),JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));await browser.close();
