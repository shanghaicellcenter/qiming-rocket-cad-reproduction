from pathlib import Path
import json,re,hashlib
R=Path('/Users/qianqiming/Documents/Codex/2026-10-19/new-chat');p=R/'work/virtual-assembly/narration-draft.json';d=json.loads(p.read_text());hist=p.with_name('narration-source-audit-wording-history.json')
if not hist.exists():hist.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
changes={
'01':('贮箱：上部燃料，下部氧化剂','这根长筒里，燃料在上部，氧化剂在下部，中间的活塞把两者隔开。这样，一根筒体里就有了两个彼此分开的储存空间。','上部燃料／下部氧化剂，活塞隔开'),
'03':('上端燃料阀：电驱动与阀体相连','上端这一只是燃料阀。电驱动部件通过连接件带动阀体，支架把两者固定在一起；画面展示的是这些部件之间的关系。','电驱动 → 连接件 → 阀体'),
'04':('下端氧化剂阀：另一条通路','下端这一只是氧化剂阀，和上端燃料阀负责不同的通路。两只阀外形相近，却各有自己的位置和连接，不能把它们混为一个。','两只阀负责不同通路，位置各自独立'),
'05':('外侧管路：把上下部件联系起来','燃料的出口在贮箱上端，推力室却在下方。沿筒体外侧的长管把两处联系起来，接头则把管路与相邻部件连接起来。','外侧长管联系上端出口与下方组件'),
'06':('翼面：与气流相互作用','先看红色的翼面。火箭相对空气运动时，翼面会受到空气的作用；这些作用还要通过连接处，传到支架和箭体结构。','翼面受空气作用，连接结构传递作用力'),
'07':('长支架：连接翼面与箭体','第二组里，留意翼面旁边的细长支架。它的截面像一个直角，一边连接尾翼，另一边联系贮箱和下方推力室结构。','直角截面的长支架，把部件联系起来'),
'08':('隔套：圆筒与平支架之间','圆筒表面是弯的，支架接触面却是平的。两者之间的隔套填补了形状差别；这段会放大这个小件，看清它所在的位置。','隔套近景：弧形筒面与平支架之间'),
'09':('四组尾翼：一起看环绕分布','四组尾翼归位后，可以一起看它们围绕箭体的分布。不过，判断能否稳定飞行，还要结合质量分布和空气作用，不能只看有几片翼。','四向分布；稳定性也取决于质量与气动条件')}
for s in d['stages']:
 if s['stage_id'] in changes:
  a,b,c=changes[s['stage_id']];s.update(title_zh=a,narration_zh=b,short_screen_note_zh=c,han_character_count=len(re.findall('[\u4e00-\u9fff]',b)))
  if s['stage_id'] in ['01','03','04','05']:s['novice_source_crosscheck']='Supplied guide §2.3.2–2.3.3; fuel upper / oxidizer lower; actual fuel/oxidizer native subtree identities preserved.'
  if s['stage_id'] in ['06','07','08','09']:s['novice_source_crosscheck']='Supplied guide §2.3.5; actual stage SLDPRT identities include angle, fin and SPCR-400SD; only source-static spatial relationships shown.'
d['status']='Source roles rechecked; novice wording revision; previous FireRed voice ineligible for final movie.'
d['total_han_character_count']=sum(len(re.findall('[\u4e00-\u9fff]',s['narration_zh'])) for s in [d['intro'],*d['stages'],d['outro']])
p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');(R/'outputs/virtual-assembly/逐段讲稿与来源.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'han':d['total_han_character_count'],'changed':list(changes)},ensure_ascii=False))
