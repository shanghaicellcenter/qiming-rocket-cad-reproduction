"""Reconcile original file identities with conversion evidence, without inferring parts."""
from pathlib import Path
from collections import Counter
import csv, json

ROOT=Path('/Users/qianqiming/Documents/Codex/2026-10-19/new-chat')
W=ROOT/'work/native-cad'
OUT=ROOT/'outputs/mojave-machine/research'
coverage=json.loads((OUT/'coverage.json').read_text())
native=json.loads((W/'native-source-readiness.json').read_text())
stl=json.loads((W/'all-stl-source-audit.json').read_text())
names=json.loads((W/'vehicle.name-source-map.json').read_text())
native_by={(r['archive'],r['relative_path']):r for r in native['records']}
stl_by={(r['archive'],r['zip_member']):r for r in stl['records']}
for r in coverage['records']:
    key=(r['archive'],r['relative_path'])
    r['status']=['源文件身份已登记']
    r['assembly_instance_count']=None
    if key in native_by:
        n=native_by[key]
        r.update({
            'native_conversion':'passed_nonempty',
            'source_sha256':n['source_sha256'],
            'usd_relative':'../native-cad/'+n['usd_relative'],
            'usd_sha256':n['usd_sha256'],
            'revision_group':n['revision_group'],
            'tessellation_lod':3,
            'source_simplification':n['source_simplification'],
            'visual_acceptance':'pending_separate_browser_and_blender_review',
        })
        r['status'].append('原生CAD已转换为非空USD')
        file_name=Path(r['relative_path']).name
        paths=names['file_to_prim_paths'].get(file_name,[])
        r['vehicle_name_matched_occurrence_nodes']=len(paths)
        r['vehicle_source_name_match']=bool(paths)
        if paths:r['status'].append('整箭USD中存在唯一名称匹配节点；不是物理数量判定')
        elif file_name=='Mojave Sphinx Vehicle Assembly.SLDASM':
            r['status'].append('整箭源输入已转换；顶层显示名随输出文件名生成')
        else:r['status'].append('独立原件USD已保留；不强加到主装配')
    elif key in stl_by:
        s=stl_by[key]
        r.update({'source_sha256':s['sha256'],'source_triangles':s['triangles'],
            'stl_parse':'passed_binary_triangle_stream','source_units':'undeclared_in_STL',
            'stl_relative':'../native-cad/source-stl/'+str(Path(s['local_stl']).relative_to(W/'source-stl'))})
        r['status'].append('原STL全部三角面已解析、原字节已保留')
    elif r['format']=='STEP':
        r['status'].append('原交换格式已登记；未单独重读，不断言与同名原生CAD形体等同')
    elif r['format'] in ('SLDDRW','DXF'):
        r['status'].append('二维源记录；未将文件数换算成三维零件数')
coverage.update({
    'schema_version':2,
    'basis':'Original archive+member identity, verified native USD conversion, SHA256, full source STL binary parsing; visual checks tracked independently.',
    'scope_note':'134 native CAD records converted nonempty, all36 original STL byte streams parsed. Main vehicle and independent native source library are separate. Conversion success is not a claim of complete physical construction or all source configurations.',
})
coverage['summary']={
    'cad_file_record_count':len(coverage['records']),
    'format_counts':dict(sorted(Counter(r['format'] for r in coverage['records']).items())),
    'main_R01_native_records':133,'independent_patch_native_records':1,
    'native_cad_records_converted_nonempty':len(native_by),
    'original_stl_records_parsed':len(stl_by),
    'original_stl_total_triangles':stl['total_triangles'],
    'vehicle_source_name_matched_files':125,
    'vehicle_source_name_unmatched_files':8,
    'vehicle_mesh_occurrences':688,'vehicle_component_kind_nodes':635,
    'vehicle_mesh_triangles_lod3':7070568,
    'part_instance_count':None,
    'part_instance_count_status':'Mesh occurrences, CAD component nodes, source files and BOM rows have different meanings; no physical part count is asserted.',
    'assembly_mates_status':'Original geometry hierarchy and local transforms retained; mates/constraints/physics not imported or validated.',
    'browser_assembly_acceptance':'pending',
    'older_10_STL_atlas':'independently verified 10 original geometries /70064 triangles; retained as a separate older inspection page',
}
coverage['field_definitions']['native_conversion']='CLI success plus nonempty USD mesh audit, source hash unchanged and output SHA256 checked.'
coverage['field_definitions']['vehicle_name_matched_occurrence_nodes']='Source identity name matching only. It does not assert physical parts or all source configurations.'
coverage['field_definitions']['status']='Source existence, geometric conversion and visual/browser acceptance remain distinct.'
(W/'coverage-reconciled.json').write_text(json.dumps(coverage,ensure_ascii=False,indent=2)+'\n')
with (W/'coverage-reconciled.csv').open('w',newline='',encoding='utf-8-sig') as f:
    keys=['archive','relative_path','format','source_sha256','native_conversion','source_triangles','revision_group','usd_relative','usd_sha256','status']
    writer=csv.DictWriter(f,fieldnames=keys,extrasaction='ignore');writer.writeheader()
    for r in coverage['records']:
        writer.writerow({**r,'status':'；'.join(r['status'])})
print(json.dumps(coverage['summary'],ensure_ascii=False))
