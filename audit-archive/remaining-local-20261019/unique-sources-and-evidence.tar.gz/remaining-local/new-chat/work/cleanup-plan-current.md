# 本地生成副本清理计划（只准备，尚未删除）

当前已列明35个精确候选根，合计7,800,007,806逻辑字节（7.26GiB），不沿符号链接计数。这里不是保证能释放的磁盘空间：APFS共享块/克隆可能使实际df回收量不同。最终必须报df前后实测差。

GitHub公开仓库：https://github.com/shanghaicellcenter/qiming-rocket-cad-reproduction；commit `82c2a2a255b66556cead58ec3444f81f1757ae68`，tag `v1.0.0`。当前仍为上传过程快照，清理资格为false；不以本地分包校验代替实际公开下载恢复。下载、播放与重建继续由根任务执行，本计划不阻塞它们。

保留桌面原始392资料、整个ni、skill-repos、.codex/.agents与Blender/公共运行时；Spark共享模型/TTS/reader环境也不在本地清理范围。103精确跨项目输入的ni独立副本已本次逐项重核SHA全部通过，这项解除仅适用于列出的103路径。另8来源卡本地独立打包的审查记录继续保留，不推广为其他依赖解除。

保留实际新clone `/Users/qianqiming/Documents/Codex/2026-10-19/qiming-github-verify-20261019/project` 的`.git`与194个tracked文件；只保留这一小源码仓库，旧上传repo-stage可在该clone再次核验后移除。禁止整删新clone的outputs目录，因为其中也有Git tracked源码。下载包、展开的大型未tracked模型、恢复媒体与rebuilt目录只能按Release清单精确排除tracked路径后清理；未知文件保留。

先将1667份小文本/脚本/QA与清单（当前17,542,048字节）保存在 `/Users/qianqiming/Documents/Codex/2026-10-19/new-chat/retained-release-records`，保留新验证root的reports、owner与sandbox证据。最终公开URL/附件API摘要/实际下载SHA/恢复验收记录必须补齐后再动大目录。两张当前真实预览图已在小Git仓库中，不需要保留所有渲染备份。

本次lsof实际GH上传PID为[]，仍打开分包；Python预览服务PID12387仍服务58926端口。待其正常完成/由owner关闭该任务预览服务，再重新检查活句柄；不得杀共享Chrome、Codex或无关Python。外部兄弟项目回指本项目的symlink为0。剩余4个代码命中分别是3个sourceImage历史溯源字段和一个拒读sandbox哨兵，P087/P072独立复制已再次核实，未见浏览代码把sourceImage当运行时图片输入。

候选精确路径、每项字节数、103副本核对及验收门槛见cleanup-plan-current.json。准备脚本没有删除/移动/kill功能，不修改public树。最终实际操作需再次运行read-only预检，保留小记录后，按精确allowlist执行；不使用针对整个工作区或verifyroot的通配删除。
