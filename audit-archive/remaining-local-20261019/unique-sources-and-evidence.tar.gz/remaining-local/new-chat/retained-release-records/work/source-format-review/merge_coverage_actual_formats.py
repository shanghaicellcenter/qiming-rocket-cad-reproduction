"""Merge executed source-format evidence into canonical coverage, retain source identities.
Only explicit JSON/CSV/history targets. Does not write any HTML or root prose.
"""
from pathlib import Path
import json,csv,hashlib,datetime,copy,io,os
P=Path('/Users/qianqiming/Documents/Codex/2026-10-19/new-chat')
ROOT=P/'outputs/启明火箭';RESEARCH=ROOT/'research';NATIVE=ROOT/'native-cad';EX=NATIVE/'exchange-source';GALLERY=ROOT/'library/exchange-source'
COVERAGE_JSON_PATH=RESEARCH/'coverage.json';COVERAGE_CSV_PATH=RESEARCH/'coverage.csv';RECONCILED_PATH=NATIVE/'coverage-reconciled.json'
HISTORY_PATH=RESEARCH/'history/coverage-before-exchange-format-read-20261019.json'
CHECK_PATH=RESEARCH/'coverage-actual-format-merge-check.json'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def identity(row):return row['archive'],row['relative_path'],row['format']
def rel(path,base=RESEARCH):return os.path.relpath(path,base)
before_hashes={p.name:sha(p) for p in [COVERAGE_JSON_PATH,COVERAGE_CSV_PATH,RECONCILED_PATH]}
coverage=json.loads(COVERAGE_JSON_PATH.read_text());original=copy.deepcopy(coverage);assert len(coverage['records'])==221
before_identities=[identity(x) for x in coverage['records']]
before_non_targets=[copy.deepcopy(x) for x in coverage['records'] if x['format'] not in ['STEP','DXF','SLDDRW']]
old_summary=copy.deepcopy(coverage['summary'])
csv_before=list(csv.DictReader(io.StringIO(COVERAGE_CSV_PATH.read_text(encoding='utf-8-sig'))));assert [identity(r) for r in csv_before]==before_identities
manifest=json.loads((EX/'source-format-manifest.json').read_text());progress=json.loads((EX/'progress.json').read_text());dx=json.loads((GALLERY/'dxf/dxf-index.json').read_text());draw=json.loads((EX/'drawings-native/native-drawing-read-results.json').read_text())
source_map={(x['archive'],x['zip_member'],x['format']):x for x in manifest['records']}
result_map={x['record_id']:x for x in progress['results']};dx_map={x['id']:x for x in dx['records']}
source_root=Path('/Users/qianqiming/Desktop/火箭设计 中文版')
draw_map={(str(Path(x['archive']).relative_to(source_root)),x['zip_member'],'SLDDRW'):x for x in draw['records']}
changed=[]
for row in coverage['records']:
 fmt=row['format']
 if fmt not in ['STEP','DXF','SLDDRW']:continue
 key=identity(row)
 if fmt in ['STEP','DXF']:
  src=source_map[key];rid=src['record_id'];read=result_map[rid]
  source_path=EX/src['source_extracted_relative'];assert sha(source_path)==src['source_sha256'];assert read['source_bytes_unchanged']
  row.update(source_sha256=src['source_sha256'],source_archive_sha256=src['source_archive_sha256'],source_bytes_unchanged=True,format_record_id=rid,source_relative=rel(source_path),format_read_report_relative=rel(EX/'usd'/(rid+'.review.json')),reader_return_code=read['converter_return_code'],reader_output_exists=read['output_exists'],reader_output_bytes=read['output_bytes'],format_preview_gallery=rel(GALLERY/'交换格式来源图册.html'))
  if fmt=='STEP':
   assert read['converter_return_code']==0 and read['usd_audit']['nonempty_mesh_count']>0
   usd=EX/'usd'/(rid+'.usdc');assert sha(usd)==read['output_sha256']
   row.update(exchange_conversion='passed_nonempty_mesh',format_read='reader_passed_nonempty_step_mesh',reader_error_code=None,reader_error_name=None,usd_relative=rel(usd),usd_sha256=read['output_sha256'],source_triangles=read['usd_audit']['triangles'],source_mesh_occurrences=read['usd_audit']['nonempty_mesh_count'],source_units='authored_0.0254_metres_per_source_unit',usd_meters_per_unit=read['usd_audit']['meters_per_unit'],usd_up_axis=read['usd_audit']['up_axis'],source_bbox_metres=read['usd_audit']['bbox_metres'],converted_mesh_payload_and_transform_sha256=read['usd_audit']['converted_mesh_payload_and_transform_sha256'],geometry_fingerprint_scope=read['usd_audit']['fingerprint_scope'],format_preview_record_id=rid,format_preview_images=[rel(GALLERY/'images'/(rid+'-'+view+'.png')) for view in ['front','side','oblique']],format_preview_image_count=3,format_visual_acceptance='passed_saved_blend_reopen_geometry_transform_checks_and_four_actual_contactsheet_review_rounds',format_editable_library_relative=rel(GALLERY/'STEP来源库.blend'),spatial_comparison_relative=rel(GALLERY/'step-native-spatial-comparison.json'),status=['源文件身份已登记','原STEP实际读取成功，非空USD已保留，源SHA前后一致','独立来源库与三个角度图片已审看；未替换主R01装配','与原生来源仅作候选空间/三角化抽样对照，不断言参数CAD等价'])
  else:
   assert read['converter_return_code']==1 and not read['output_exists'];parsed=dx_map[rid];spaces=parsed['spaces']
   row.update(format_read='reader_failed_but_direct_ascii_dxf_entity_parse_passed',reader_error_code=-10005,reader_error_name='A3D_LOAD_INVALID_FILE_FORMAT',dxf_parse='passed_original_ascii_group_records_and_entity_geometry',dxf_insunits_code=parsed['insunits_code'],source_units=parsed['declared_units'],dxf_metres_per_unit=parsed['metres_per_unit'],dxf_source_entity_count=parsed['entity_count'],dxf_source_entity_counts=parsed['entity_counts'],dxf_layers=parsed['layers'],dxf_model_geometry_entity_count=spaces['model']['geometry_entity_count'],dxf_paper_geometry_entity_count=spaces.get('paper',{}).get('geometry_entity_count',0),dxf_model_bbox_native=spaces['model']['xy_geometry_bbox_native'],dxf_entities_relative=rel(GALLERY/'dxf'/(rid+'.entities.json')),format_preview_record_id=rid,format_preview_images=[rel(GALLERY/'dxf'/s['svg']) for s in spaces.values()],format_preview_image_count=len(spaces),format_visual_acceptance='passed_actual_model_and_paper_space_browser_image_review_source_text_attachment_checked',pdf_visual_evidence_not_native_read=True,status=['源文件身份已登记','现有三维reader实际失败：return1 / -10005；未生成USD','原DXF ASCII组码与二维实体实际解析成功，声明单位英寸','模型空间与纸空间分别呈现；重复实体/视口不另算物理零件','源图已实看；MTEXT字形与字距为浏览器近似，原锚点和组码保留'])
   row['dxf_model_view_relative']=rel(GALLERY/'dxf'/spaces['model']['svg'])
   if 'paper' in spaces:row['dxf_paper_view_relative']=rel(GALLERY/'dxf'/spaces['paper']['svg'])
 else:
  read=draw_map[key];rid=read['id'];assert read['return_code']==1 and not read['output_exists'] and read['source_bytes_unchanged']
  source_path=EX/'drawings-native/source'/rid/read['filename'];assert sha(source_path)==read['source_sha256']
  row.update(source_sha256=read['source_sha256'],source_archive_sha256=read['archive_sha256'],source_bytes_unchanged=True,format_record_id=rid,source_relative=rel(source_path),format_read='native_drawing_reader_failed_no_output',native_drawing_read='failed_no_native_geometry_output',reader_return_code=1,reader_error_code=-10007,reader_error_name='A3D_LOAD_CANNOT_LOAD_MODEL',reader_output_exists=False,reader_output_bytes=0,format_read_report_relative=rel(EX/'drawings-native/native-drawing-read-results.json'),format_stdout_relative=rel(EX/'drawings-native/results'/(rid+'.stdout.log')),format_stderr_relative=rel(EX/'drawings-native/results'/(rid+'.stderr.log')),pdf_visual_evidence_not_native_read=True,native_drawing_read_mode=read['reader_mode'],status=['源文件身份已登记','原生SLDDRW已逐件实际尝试：return1 / -10007','现有reader未生成USD；不宣称原生图纸读通','源PDF视觉证据单独记录，不计为SLDDRW原生读取成功'])
 changed.append(key)
assert len(changed)==51
coverage['schema_version']=3
coverage['basis']='Original archive+member identity with verified native USD conversion, source STL binary parsing, executed STEP reads, direct DXF entity parsing, and per-file SLDDRW reader attempts; visual checks tracked separately.'
coverage['scope_note']='221 original CAD file identities retained:134 native CAD and35 STEP records converted nonempty,36 original STL streams parsed,3 original DXF files directly parsed after reader failures,13 SLDDRW actual reader attempts failed. Source document counts are not physical parts. Existing170-record510-image main preview statistics remain unchanged; STEP/DXF previews are independent.'
coverage['field_definitions'].update(format_read='Executed source-format result. Reader failure is distinguished from successful direct DXF entity parsing and separate PDF visual evidence.',format_read_report_relative='Evidence file path relative to this coverage JSON directory.',format_preview_gallery='Independent exchange-source gallery; not merged with the original170-record main gallery.',format_preview_images='Actual source-derived PNG/SVG paths relative to this coverage JSON directory.',reader_output_exists='Actual output of this reader call; false for failed DXF/SLDDRW attempts.',source_relative='Extracted original source bytes, relative to this coverage JSON directory; exact source archive/member identity remains unchanged.',native_drawing_read='Per-original-SLDDRW executed attempt, distinct from visual review of exported source PDF pages.')
summary=coverage['summary'];summary.update(step_records_actually_read=35,step_records_converted_nonempty=35,step_independent_preview_records=35,step_independent_preview_images=105,step_independent_source_triangles=140854,dxf_records_actually_reader_attempted=3,dxf_reader_successes=0,dxf_records_direct_entity_parsed=3,dxf_model_source_views=3,dxf_paper_space_views=1,dxf_independent_preview_views=4,slddrw_records_actually_reader_attempted=13,slddrw_native_reader_successes=0,slddrw_native_reader_failed_no_output=13,all_formats_actual_checked_source_records=221,all_formats_records_with_source_sha256=221,all_formats_successful_source_mesh_or_entity_records=208,all_formats_source_mesh_or_entity_counts_note='134 native CAD +35 STEP nonempty display-mesh records +36 parsed original STL +3 parsed DXF =208 successful geometry/entity source records;13 native drawings remain reader failures. This is not a physical-part count.',source_format_actual_read_summary_relative=rel(EX/'actual-read-summary.json'),independent_exchange_gallery=rel(GALLERY/'交换格式来源图册.html'))
assert summary['source_preview_records']==170 and summary['source_preview_images']==510
assert [identity(x) for x in coverage['records']]==before_identities
assert [x for x in coverage['records'] if x['format'] not in ['STEP','DXF','SLDDRW']]==before_non_targets
assert all(len(x.get('source_sha256',''))==64 for x in coverage['records'])
assert not any('未单独重读' in str(x['status']) for x in coverage['records'] if x['format'] in ['STEP','DXF','SLDDRW'])
history={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reason':'Historical state before merging the executed35STEP/3DXF/13SLDDRW evidence. Historical statuses are superseded by canonical research/coverage.json.', 'original_coverage_sha256':before_hashes['coverage.json'],'original_csv_sha256':before_hashes['coverage.csv'],'original_summary':old_summary,'superseded_record_count':51,'superseded_records':[x for x in original['records'] if x['format'] in ['STEP','DXF','SLDDRW']]}
if HISTORY_PATH.exists():
 existing=json.loads(HISTORY_PATH.read_text());assert existing['original_coverage_sha256']==history['original_coverage_sha256'],'Refusing to overwrite another historical snapshot'
else:HISTORY_PATH.write_text(json.dumps(history,ensure_ascii=False,indent=2))

# JSON/CSV are generated from exactly the same ordered identities.
fields=list(csv_before[0].keys())
new_fields=['source_archive_sha256','format_record_id','source_relative','format_read','exchange_conversion','native_drawing_read','reader_return_code','reader_error_code','reader_error_name','reader_output_exists','reader_output_bytes','source_bytes_unchanged','format_read_report_relative','format_stdout_relative','format_stderr_relative','source_mesh_occurrences','source_units','usd_meters_per_unit','usd_up_axis','converted_mesh_payload_and_transform_sha256','format_preview_gallery','format_preview_record_id','format_preview_images','format_preview_image_count','format_visual_acceptance','format_editable_library_relative','spatial_comparison_relative','dxf_parse','dxf_insunits_code','dxf_metres_per_unit','dxf_source_entity_count','dxf_source_entity_counts','dxf_layers','dxf_model_geometry_entity_count','dxf_paper_geometry_entity_count','dxf_entities_relative','dxf_model_view_relative','dxf_paper_view_relative','pdf_visual_evidence_not_native_read']
fields += [k for k in new_fields if k not in fields]
def cell(k,v):
 if v is None:return ''
 if k=='status':return '；'.join(v)
 if isinstance(v,(list,dict)):return json.dumps(v,ensure_ascii=False,separators=(',',':'))
 if isinstance(v,bool):return 'true' if v else 'false'
 return str(v)
buffer=io.StringIO(newline='');writer=csv.DictWriter(buffer,fieldnames=fields);writer.writeheader()
for row in coverage['records']:writer.writerow({k:cell(k,row.get(k)) for k in fields})

# Validate all evidence-relative links recursively, excluding ZIP member identity paths.
link_records=[]
def collect_links(obj,label='coverage'):
 if isinstance(obj,dict):
  for k,v in obj.items():
   if k=='field_definitions':continue
   if (k.endswith('_relative') or k in ['preview_gallery','format_preview_gallery','independent_exchange_gallery']) and isinstance(v,str):link_records.append((label+'.'+k,v))
   elif k=='format_preview_images' and isinstance(v,list):
    for value in v:link_records.append((label+'.'+k,value))
   elif k!='relative_path':collect_links(v,label+'.'+k)
 elif isinstance(obj,list):
  for i,v in enumerate(obj):collect_links(v,label+'['+str(i)+']')
collect_links(coverage)
missing=[]
for label,value in link_records:
 target=RESEARCH/value.split('#',1)[0]
 if not target.exists():missing.append({'field':label,'value':value})
assert not missing,missing

reconciled=json.loads(RECONCILED_PATH.read_text());native_summary_before=copy.deepcopy(reconciled['summary']);native_records_before=copy.deepcopy(reconciled['records'])
reconciled['actual_exchange_format_update']={'summary_relative':'exchange-source/actual-read-summary.json','canonical_current_coverage_relative':'../research/coverage.json','note':'Native134-count summary and historical per-record snapshot retained unchanged. Later35STEP/3DXF/13SLDDRW actual-format evidence is in the linked canonical coverage; original snapshot statuses are historical.'}
assert reconciled['summary']==native_summary_before and reconciled['records']==native_records_before
for label,value in [('actual_summary',reconciled['actual_exchange_format_update']['summary_relative']),('canonical_coverage',reconciled['actual_exchange_format_update']['canonical_current_coverage_relative'])]:assert (NATIVE/value).exists()
assert all(sha(p)==before_hashes[p.name] for p in [COVERAGE_JSON_PATH,COVERAGE_CSV_PATH,RECONCILED_PATH]),'Concurrent edit detected; refusing overwrite'
for target_path,text_value in [(COVERAGE_JSON_PATH,json.dumps(coverage,ensure_ascii=False,indent=2)+'\n'),(COVERAGE_CSV_PATH,'\ufeff'+buffer.getvalue()),(RECONCILED_PATH,json.dumps(reconciled,ensure_ascii=False,indent=2)+'\n')]:
 temporary_path=target_path.with_suffix(target_path.suffix+'.format-merge-tmp');temporary_path.write_text(text_value,encoding='utf-8',newline='');temporary_path.replace(target_path)
after_json=json.loads(COVERAGE_JSON_PATH.read_text());after_csv=list(csv.DictReader(io.StringIO(COVERAGE_CSV_PATH.read_text(encoding='utf-8-sig'))))
assert len(after_json['records'])==len(after_csv)==221
assert [identity(x) for x in after_json['records']]==[identity(x) for x in after_csv]==before_identities
for row_json,row_csv in zip(after_json['records'],after_csv):
 for key in fields:assert cell(key,row_json.get(key))==row_csv[key],(identity(row_json),key)
checks={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_identity_order_preserved':True,'record_count_json':221,'record_count_csv':221,'target_records_updated':51,'non_target_records_unchanged':170,'all_csv_json_cells_consistent':True,'all221_source_sha256_present':True,'all_relative_evidence_links_resolved':len(link_records)+2,'missing_links':[],'main_preview_records_unchanged':170,'main_preview_images_unchanged':510,'native_reconciled134_summary_and_all_existing_records_unchanged':True,'history_relative':rel(HISTORY_PATH),'files':{str(p.relative_to(ROOT)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in [COVERAGE_JSON_PATH,COVERAGE_CSV_PATH,RECONCILED_PATH,HISTORY_PATH]}}
CHECK_PATH.write_text(json.dumps(checks,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(checks,ensure_ascii=False,indent=2))
