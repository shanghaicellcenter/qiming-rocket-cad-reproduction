from pathlib import Path
import json
root=Path(__file__).resolve().parents[1]
assert (root/'owner.json').is_file()
rows=[]
for p in ['/Users/qianqiming/Documents/Codex/2026-10-19/new-chat/outputs/启明火箭/打开项目.html','/Users/qianqiming/Documents/Codex/2026-10-19/ni/work/rocket/parts.json','/Users/qianqiming/Desktop/火箭设计 中文版','/Users/qianqiming/Desktop/skill-repos/scenario-labs--blender-expert-skills/scenario-blender-animation/SKILL.md']:
 try:
  path=Path(p)
  if path.is_dir():list(path.iterdir())
  else:path.read_bytes()
 except PermissionError:rows.append({'path':p,'denied_with_PermissionError':True})
 else:raise AssertionError('Original input was not denied: '+p)
report={'new_root_own_file_access_allowed':True,'original_inputs_actually_denied':rows,'passed':len(rows)==4,'remote_download_claimed':False}
(root/'reports/isolation-probe.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(report,ensure_ascii=False))
