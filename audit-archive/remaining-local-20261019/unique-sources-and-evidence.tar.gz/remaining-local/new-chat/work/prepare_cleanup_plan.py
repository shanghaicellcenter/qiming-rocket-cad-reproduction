"""Read-only cleanup preparation. No delete, unlink, move, kill or network action."""
from pathlib import Path
import os,stat,json,datetime,subprocess,hashlib
ROOT=Path(__file__).resolve().parents[1]
VERIFY=ROOT.parent/'qiming-github-verify-20261019'
REPORT=ROOT/'work/cleanup-inventory-evidence.json'
def measure(path):
 stack=[path];files=dirs=logical=allocated=0;links=[];large=[];errors=[]
 while stack:
  p=stack.pop()
  try:s=p.lstat()
  except OSError as e:errors.append({'path':str(p),'error':type(e).__name__});continue
  if stat.S_ISLNK(s.st_mode):
   links.append({'path':str(p),'raw_target':os.readlink(p),'resolved_target_for_protection_only':str(p.resolve(strict=False))});continue
  if stat.S_ISDIR(s.st_mode):
   dirs+=1
   try:
    with os.scandir(p) as it:stack.extend(Path(e.path) for e in it)
   except OSError as e:errors.append({'path':str(p),'error':type(e).__name__})
  elif stat.S_ISREG(s.st_mode):
   files+=1;logical+=s.st_size;allocated+=getattr(s,'st_blocks',0)*512
   if s.st_size>=20*1024*1024:large.append({'path':str(p),'bytes':s.st_size})
 return {'logical_bytes_without_following_symlinks':logical,'allocated_blocks_bytes_not_unique_apfs':allocated,'regular_files':files,'directories':dirs,'symlinks':links,'large_files_20MiB_plus':sorted(large,key=lambda x:-x['bytes']),'read_errors':errors}
rows=[]
for base in [ROOT/'outputs',ROOT/'work',VERIFY]:
 if base.exists():
  for p in sorted(base.iterdir()):rows.append({'path':str(p),'parent_scope':str(base),**measure(p)})
# Extra detail for mixed publication folder, where Git checkout must survive.
pub=ROOT/'work/github-publication'
publication=[{'path':str(p),**measure(p)} for p in sorted(pub.iterdir())] if pub.exists() else []
# Process evidence deliberately excludes arguments/environment, which can carry secrets.
process=[];current={'pid':None,'command':None,'fd':None}
proc=subprocess.run(['lsof','-nP','-Fpcfn'],capture_output=True,text=True)
for line in proc.stdout.splitlines():
 if not line:continue
 k,v=line[0],line[1:]
 if k=='p':current={'pid':int(v),'command':None,'fd':None}
 elif k=='c':current['command']=v
 elif k=='f':current['fd']=v
 elif k=='n' and any(v==str(p) or v.startswith(str(p)+'/') for p in [ROOT,VERIFY]):process.append({**current,'path':v})
# Inventory external symlinks only; do not follow any target during traversal.
external_links=[];program_refs=[];skip={'.git','node_modules','.venv','venv','__pycache__','.cache'}
for sibling in ROOT.parent.iterdir():
 if sibling==ROOT or sibling==VERIFY or sibling.is_symlink() or not sibling.is_dir():continue
 stack=[sibling]
 while stack:
  p=stack.pop()
  try:
   with os.scandir(p) as it:
    for e in it:
     q=Path(e.path)
     if e.is_symlink():
      target=q.resolve(strict=False)
      if target==ROOT or target.is_relative_to(ROOT):external_links.append({'path':str(q),'raw_target':os.readlink(q),'resolved_target':str(target)})
     elif e.is_dir(follow_symlinks=False):
      if e.name not in skip:stack.append(q)
     elif e.is_file(follow_symlinks=False) and q.suffix.lower() in {'.py','.js','.mjs','.sh','.toml'} and e.stat(follow_symlinks=False).st_size<=2*1024*1024:
      try:lines=q.read_text(errors='replace').splitlines()
      except OSError:continue
      hits=[i+1 for i,line in enumerate(lines) if (str(ROOT) in line or '../new-chat/' in line) and not line.lstrip().startswith(('#','//'))]
      if hits:program_refs.append({'path':str(q),'line_numbers':hits,'classification':'Potential source/runtime reference; historical tools may intentionally retain old provenance. Requires contextual review before deleting referenced targets.'})
  except OSError:pass
migration_path=ROOT/'work/cross-project-release-review/migration-review.json';migration=json.loads(migration_path.read_text())
data={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope_root':str(ROOT),'verification_root':str(VERIFY),'readonly':True,'symlinks_never_followed_for_bytes':True,'root_children':rows,'publication_children':publication,'active_open_paths':process,'lsof_returncode':proc.returncode,'lsof_error_line_count':len(proc.stderr.splitlines()),'external_sibling_symlinks_targeting_our_root':external_links,'external_sibling_program_reference_hits':program_refs,'independent_cross_project_release':{k:migration[k] for k in ['created_utc','all103_source_and_independent_local_copy_sha_match_original_csv','all103_distinct_file_identity_no_symlink_or_other_project_realpath','content_bytes','dependency_release_recommendation','local_packing_not_public_font_clearance']},'known_precise_released_source_paths':[r['originalSource'] for r in migration['source_checks']],'df_before_plan':subprocess.check_output(['df','-k',str(ROOT)],text=True)}
REPORT.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
print('Evidence',REPORT)
for r in rows:print(r['logical_bytes_without_following_symlinks'],r['regular_files'],r['path'])
print('Publication subpaths')
for r in publication:
 if r['logical_bytes_without_following_symlinks']>=10000000 or r['symlinks']:print(r['logical_bytes_without_following_symlinks'],r['regular_files'],r['path'])
print('Active matched paths',len(process),'external symlinks',len(external_links),'external program source references',len(program_refs))
for r in process:print('OPEN',r['pid'],r['command'],r['fd'],r['path'])
for r in program_refs:print('REF',r['path'],r['line_numbers'])
