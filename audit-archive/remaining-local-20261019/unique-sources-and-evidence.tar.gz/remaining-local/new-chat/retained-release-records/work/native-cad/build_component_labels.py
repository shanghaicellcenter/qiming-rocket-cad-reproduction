from pathlib import Path
from collections import Counter
from datetime import datetime, timezone
import json

ROOT=Path('/Users/qianqiming/Documents/Codex/2026-10-19/new-chat')
source=json.loads((ROOT/'work/native-cad/source-assembly-map.json').read_text())
records=source['native_source_catalog']
ALLOWED={'整箭','箭体','头锥','尾翼','电子舱','回收','内部组件','连接件','紧固件','辅助工具'}
# Identity translations only, in the exact ZIP inventory order. Source basenames
# remain the authoritative keys; Chinese labels are never used as identifiers.
translations=[
('下段箭体管','箭体'),
('上段箭体管','箭体'),
('管短节','连接件'),
('舵机摇臂','内部组件'),
('带螺母肩部吊环螺栓','连接件'),
('U形螺栓','紧固件'),
('球阀手柄','内部组件'),
('球阀本体','内部组件'),
('螺纹管接头','连接件'),
('管短节','连接件'),
('燃料管路软管','连接件'),
('带接头软管','连接件'),
('氧化剂管路软管','连接件'),
('扩口管接头','连接件'),
('扩口管接头','连接件'),
('扩口管接头','连接件'),
('扩口管接头','连接件'),
('管接头','连接件'),
('管短节','连接件'),
('管接头','连接件'),
('管接头','连接件'),
('管接头','连接件'),
('管接头','连接件'),
('管接头','连接件'),
('管接头','连接件'),
('管接头','连接件'),
('管接头','连接件'),
('管接头','连接件'),
('电池座','电子舱'),
('螺纹止回阀','内部组件'),
('环形弹簧','连接件'),
('椭圆螺纹连接环','连接件'),
('角形连接件','连接件'),
('开槽大扁头螺钉','紧固件'),
('反向外卡环','紧固件'),
('连接螺母','紧固件'),
('十字盘头机螺钉','紧固件'),
('装夹螺柱','紧固件'),
('内六角薄头螺钉','紧固件'),
('六角螺母','紧固件'),
('六角螺母','紧固件'),
('开口弹簧锁紧垫圈','紧固件'),
('内六角圆头螺钉','紧固件'),
('内六角圆头螺钉','紧固件'),
('六角头螺钉','紧固件'),
('内六角圆柱头螺钉','紧固件'),
('内六角圆头螺钉','紧固件'),
('密封垫圈','连接件'),
('自保持垫圈','紧固件'),
('十字盘头机螺钉','紧固件'),
('垫圈','紧固件'),
('开口弹簧锁紧垫圈','紧固件'),
('螺纹杆','紧固件'),
('盖形螺母','紧固件'),
('盘头螺钉','紧固件'),
('无螺纹隔套','连接件'),
('内外螺纹六角支柱','连接件'),
('滑动轴套','连接件'),
('O形圈','连接件'),
('快插管接头','连接件'),
('垫片','连接件'),
('O形圈','连接件'),
('O形圈','连接件'),
('偏置焊接螺母','紧固件'),
('垫圈','紧固件'),
('六角螺母','紧固件'),
('快脱管','连接件'),
('带法兰圆头螺钉','紧固件'),
('垫圈','紧固件'),
('垫圈','紧固件'),
('弯曲杆件','连接件'),
('电池','电子舱'),
('尾翼支架整流端件','尾翼'),
('电子舱装配','电子舱'),
('电子舱电池座','电子舱'),
('电子舱隔板定心环','电子舱'),
('电子舱半联接套','电子舱'),
('电子舱托板安装件','电子舱'),
('电子舱开关带','电子舱'),
('电子舱托板','电子舱'),
('燃料贮箱封头','内部组件'),
('氧化剂贮箱封头','内部组件'),
('回收与电子舱隔板','回收'),
('推力室安装支架','内部组件'),
('燃烧室','内部组件'),
(None,'辅助工具'),
('DS3225 舵机','内部组件'),
(None,'内部组件'),
('标准尾翼','尾翼'),
('推力室法兰板','内部组件'),
('点火筒标准管接头装配','内部组件'),
('Estes 点火器','内部组件'),
('喷注器','内部组件'),
('贮箱接口环','内部组件'),
('箭体装配','箭体'),
('电子舱托板装配','电子舱'),
('尾翼支架装配','尾翼'),
('燃料贮箱封头子装配','内部组件'),
('螺母保持环子装配','内部组件'),
('氧化剂贮箱封头子装配','内部组件'),
('推进组件装配','内部组件'),
('贮箱装配','内部组件'),
('推力室装配','内部组件'),
('整箭装配','整箭'),
('头锥装配','头锥'),
('头锥第一段','头锥'),
('头锥第二段','头锥'),
('头锥连接肩','头锥'),
('头锥顶端','头锥'),
('螺母保持环','内部组件'),
('喷管','内部组件'),
('箭体钻孔用牺牲垫件','辅助工具'),
('推进剂活塞','内部组件'),
('快脱接头公头','连接件'),
('快脱接头母头','连接件'),
('快脱接头卡夹','连接件'),
('减速伞（质量/体积模型）','回收'),
('主伞（质量/体积模型）','回收'),
('减速伞保护件（质量/体积模型）','回收'),
('主伞保护件（质量/体积模型）','回收'),
('缓冲绳（质量/体积模型）','回收'),
('导轨按钮A件','箭体'),
('导轨按钮B件','箭体'),
('舵机驱动球阀装配','内部组件'),
('舵机驱动球阀手柄连接件','连接件'),
('舵机驱动球阀安装件','连接件'),
('尾翼支架隔套','尾翼'),
('贮箱管','内部组件'),
('喉部嵌件','内部组件'),
('下段箭体孔槽模板','辅助工具'),
('上段箭体孔位模板','辅助工具'),
('尾翼支架后侧模板','辅助工具'),
('尾翼支架前侧模板','辅助工具'),
]
assert len(records)==len(translations)==133, (len(records),len(translations))
# Guard order-dependent translation against a changed source catalog.
assert records[0]['filename'].startswith('20545T38-AF-LWR ')
assert records[73]['filename'].startswith('AVBY-ASSM ')
assert records[103]['filename']=='Mojave Sphinx Vehicle Assembly.SLDASM'
assert records[-1]['filename'].startswith('TMPLT-FIN-BRKT-1X1-FWD.')
by_basename={}; untranslated=[]
for record,(label,category) in zip(records,translations):
 assert category in ALLOWED
 name=record['filename']
 fallback=label is None
 if fallback:label=name;untranslated.append(name)
 data={'label_zh':label,'category':category,'source_basename':name,'source_archive':record['archive'],'zip_member':record['zip_member'],'archive_version':'R01','label_basis':'source identity only' if not fallback else 'source basename retained; no uncertain expansion'}
 if 'Mass Volume' in name:data['source_name_note']='原文件名明确含 Mass Volume；标签不将其升级为真实细节模型。'
 if 'Avbavy' in name or 'Subassambly' in name:data['source_spelling_note']='原英文拼写按文件名保留；中文标签不改变来源身份。'
 by_basename[name]=data
assert len(by_basename)==133
patches=[]
for p in source['source_release_structure']['patch_records']:
 if p['format']!='SLDPRT':continue
 name=Path(p['zip_member']).name
 patches.append({'label_zh':'燃料贮箱封头（独立修订包原件）','category':'内部组件','source_basename':name,'source_archive':p['archive'],'zip_member':p['zip_member'],'archive_version':'HCR-5105 独立追加修订包','merge_status':'单独来源，不与R01部件合并；主装配是否引用未确认','label_basis':'source identity only; no modification details extracted'})
assert len(patches)==1
result={'schema_version':1,'generated_utc':datetime.now(timezone.utc).isoformat(),'purpose':'中文身份导航标签；只依据原文件名翻译，不解释功能设计、规格、材料、参数或操作，不新增部件。','main_archive':source['source_release_structure']['main_cad_archive'],'main_archive_version':'R01','main_record_count':len(by_basename),'category_values':sorted(ALLOWED),'main_category_counts':dict(Counter(v['category'] for v in by_basename.values())),'identity_key_rule':'主R01字典使用精确basename；跨归档身份必须使用source_archive + zip_member，不能以中文标签、stem近似或同名合并。','duplicate_label_rule':'不同原文件允许相同中文标签；必须始终保留原名和来源，不把相同中文标签视作同一零件或实例。','categorization_limit':'类别只是检视导航分组，不是已解析的装配父子关系、功能验证或完整复现证明。','untranslated_source_basenames':untranslated,'by_basename':by_basename,'independent_patch_records':patches,'assembly_relationships':None,'not_a_parameter_table':True}
path=ROOT/'work/native-cad/component-labels.json';path.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'main_records':len(by_basename),'patch_records':len(patches),'categories':result['main_category_counts'],'source_names_retained_as_labels':untranslated,'out':str(path)},ensure_ascii=False,indent=2))
