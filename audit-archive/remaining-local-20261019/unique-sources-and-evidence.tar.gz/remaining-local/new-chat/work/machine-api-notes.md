# Machine Skill 实现核对笔记

范围：采用用户指定 `/Users/qianqiming/Desktop/skill-repos/AirsupHQ--machine-skill` 的真实 API，制作非功能数字展示。可见外观、展示级组件、剖切、展开、标注、镜头和影片属于本笔记范围；不提供可制造推进/高压细节、连接图、工作参数或操作仿真。不移植任何 rocket 示例的动力、喷注、点火内容。

## 已读与核对

- `SKILL.md` 全文；`kit/lab-kit.js` 全部 1499 行；`examples/turbofan.html` 的页面头、完整专属机器脚本和内联 kit。
- 用内容比较确认 turbofan 内联 kit 与当前 `kit/lab-kit.js` **逐字节一致**，1499 行，SHA256 `6b6bf13e2f146eb725547538ce9700b0926b63885528cf8ed5f7b85cadb7f236`，因此无需把相同源码再打印一次。参考的是该示例的嵌套组、登记、材质和影片结构，不复用它的工作模型。
- `scripts/shot.mjs`、`record.mjs`、`inline.mjs` 全文，以及它们直接依赖的 `scripts/lib/browser.mjs`、`serve.mjs`、`guard.mjs` 和 `pinkscan.mjs`。
- 初始 API 核查仅做本地阅读和解析；随后按父任务指令准备本地运行时，结果见末节。未运行项目主页面或项目影片。

## 1. 最小正确页面

复制 `kit/template.html` 到任务输出位置，修改标题、description、`lang="zh-CN"`，保留 importmap 与两段 module script。第一段在标记间放 kit；第二段写展示场景。执行 `node <skill-root>/scripts/inline.mjs <page.html>` 可把 kit 放入第一段。

```js
const { THREE, Lab, MAT, GEO, setCaps, fmt } = window.LabKit;
setCaps('metal');                  // 必须在创建展示材质前调用
const lab = new Lab({
  prompt: '查看展示模型的外观与组件', no: 1,
  title: '数字展品', sub: '非功能展示', size: 1,
  theme: 'paper', autoOrbit: false,
  pills: ['三维展品', '组件说明', '展示影片'],
  view: { az: 35, el: 14, dist: 2.2, target: [0, .3, 0], fov: 30 },
  cut: { a: [0,0,1], b: [0,1,0], center: [0,.3,0], reach: .8 },
});
lab.mesh(GEO.rbox(.25,.5,.2,.015), MAT.paint({color:0xeeeeea}), {
  name:'展示块', pos:[0,.25,0], explode:[.3,0,0],
  label:'展示块', at:[0,.1,0],
});
lab.how('仅用于观察外观、层级和部件名称。');
// hero/slider/onTick 都不是 start() 的必需项；无运行仿真时可以完全省略。
lab.film('main', { len:8,
  shots:[{t:0,az:25,el:16,dist:2.2,target:[0,.3,0]},
         {t:8,az:55,el:20,dist:2.2,target:[0,.3,0]}],
  events:[{t:0,beat:['01','观察外观。','非功能展示。']},
          {t:3,set:{cut:1,labels:1}},
          {t:6,set:{cut:0,labels:0,explode:1}}],
});
// 中文按钮覆盖须在 start 之前安装（见下）。
lab.start();
```

上例为通用展示 API 示意，不是项目主页面。kit 坐标为 Y 向上；`Lab.size` 决定缩放 `k=2.4/size`，不自动推导物体尺寸。任务采用展示比例时须隐藏 `.lab-scale`，否则 kit 会显示 m/cm/mm，造成“真实制造比例”的错误暗示。

**内联不等于离线：** `inline.mjs` 只内联 `kit/lab-kit.js`；模板和 turbofan 的 importmap 仍从 jsDelivr 请求 `three@0.170.0` 及 `three/addons/`，Google Fonts 也外链。若项目需要离线交付，必须使用已存在的本地 THREE 及完整 addons，并更新 importmap；只改 three 主库地址不够。本次未下载或检查本地 THREE 资源。

## 2. 任意 THREE 网格、组和统计

真实签名：

```js
lab.add(obj, o = {})
// o: {name,parent,explode:[dx,dy,dz],delay,xray:'shell',
//     label,at:[x,y,z],value:()=>string,side,count,shadow,intro}

lab.mesh(geometry, material, o = {})
// mesh 额外读取 {pos:[x,y,z],rot:[rx,ry,rz],scale:number|[x,y,z],add:false}

lab.place(obj,x,y,z)               // 更新已登记obj的基础位置
lab.label(obj,text,o={})           // at 为 obj 自身局部坐标，value 可选
lab.onTick((sdt,lab,realDt)=>{})
lab.partCount()
lab.setView({az,el,dist,target,fov,frameX})
```

可直接构建任意闭合 `THREE.BufferGeometry`、`THREE.ExtrudeGeometry` 或从展示模型加载的 `THREE.Mesh`，**用 MAT 的材质**，设置 obj.position/rotation 后 `lab.add(obj,{...})`。`lab.add` 不读取 `pos/rot/scale`，这些选项只由 `lab.mesh` 处理。

`lab.add` 接受 `THREE.Group` 并递归设置内部 mesh 的阴影。`parent` 默认为 `lab.machine`；`explode` 是父组局部坐标中的展示向量。每个登记项保存 `{obj,name,base,off,delay,count,xray,intro,order}`，可通过 `lab.parts` 获取。

**嵌套注意：** 组和其子项都登记时会重复计数；turbofan 的父 Engine 用 `{count:0}`，各子项另外登记。展示组件最好用共同的自定义 ID 元数据组织；凡需单独展开/标签的部件分别登记，纯装饰重复件可合并，但要清楚记录合并前后数量。`count` 可以手工覆盖统计，因此它不是独立验证的真实物料清单；不可用任意 count 宣称“全部真实零件已复现”。

**每帧写回位置与 visible：** `_update()` 在 tick 回调之后执行：

```js
p.obj.position.copy(p.base)
  .addScaledVector(p.off, ee)
  .addScaledVector(far, 1-ai);
p.obj.visible = ai > .001 || A === 0;
```

所以直接修改已登记 obj.position 或 `.visible=false` 会被覆盖。移动基础位置应调用 `lab.place`；隐藏外壳可建立**未登记的包装 Group**（`lab.machine.add(wrapper)`），再 `lab.add(mesh,{parent:wrapper,...})` 登记子项，由 wrapper.visible 控制隐藏。不要再 `lab.add(wrapper)`，否则 wrapper.visible 也会被写回。这只解决展示隐藏，未添加选择功能。

**选择/库存：** kit 没有现成零件树、搜索、点击选择高亮或“所有零件覆盖率”API；需任务自己建立组件清单、`userData.componentId`、外侧列表、THREE.Raycaster 和高亮状态。来源明确/展示简化/资料缺失应在清单中区分，避免把未见内部结构画成已证实。

## 3. 几何与材质 API

与外观展示相关且已核对的 GEO：

```js
GEO.lathe(points, seg=96, {crease=32,phi0=0,phiLen=2*Math.PI}={})
// points = [[r,y],...]，闭合截面，绕 +Y
GEO.shell(points, thickness, seg=96, inward=true)
GEO.tube(rOut,rIn,h,seg=96,y0=-h/2)
GEO.disc(r,h,ch=Math.min(r,h)*.08,seg=96,rIn=0)
GEO.rbox(w,h,d,r=Math.min(w,h,d)*.08,s=4)
GEO.extrude(shape,depth,bevel=depth*.06)
GEO.merge(geometryList)
GEO.ring(geometry,n,axis='z',phase=0)
GEO.bolts(n,R,size,h,{y=0,socket=false,phase=0}={})
```

`GEO.merge` 将几何转换为 non-indexed 后调用 THREE BufferGeometryUtils 合并；传入几何的 attribute 集合必须兼容。`GEO.ring` 是合并几何，不是独立可选中的 mesh 集合。只有展示确需逐件选择时，应实例化独立 mesh 并给稳定 ID。

MAT 每个预设创建可剖切 `MeshPhysicalMaterial`，支持材质字段及 `finish/rep/cap/noCap/capRough`。外观用 `steel`、`steelDark`、`stainless`、`chrome`、`aluminium`、`aluminiumMachined`、`paint`、`satin`、`plastic`、`rubber`、`carbon`、`glass` 等即可。`finish` 实际支持 turned、brushed、cast、carbon、knurl、smudge。

自建 THREE 材质不会自动加入 capPatch；为自定义几何优先用 MAT，或导出的 `mat(options)`。`setCaps('metal')` 令后续材质截面沿用展示材质颜色；默认截面是红色。剖切盖是 shader 对闭合实体背面的视觉处理，**没有生成可导出的实体布尔截面几何**。不是工程 CAD 检验。

`GEO.lathe` 的部分 `phiLen` 不会额外补角度起止面的实体封口；`GEO.spring` 实际使用开放的 TubeGeometry，未像 `GEO.pipe` 一样补端盖。不能依据技能文案笼统声称所有构造函数一定封闭。对需剖切的展示部件，应检查实际网格封闭与法线；避免把开放装饰当完整实体。

## 4. 模式行为与隐患

- `lab.toggle('explode',true)`：向目标 1 缓动，各登记项按 delay 沿 off 平移。**没有碰撞/间隙审计**，必须视觉检查装配、展开和中间轨迹。它是展示展开，不是拆装流程。
- `lab.toggle('cut',true)`：全局裁剪平面按 `Lab({cut:{a,b,center,reach,offset}})` 从外侧扫入。a/b 是切除方向；相同方向作半切，两个方向作交集切除。仅 MAT 生成的材质具备对应裁剪和盖面 patch。
- `lab.toggle('xray',true)`：仅 `xray:'shell'` 的对象变为透明边缘壳。实现会直接修改这些 mesh 的原始材质 transparent/opacity/depthWrite；若与内部部件共享同一材质实例，会连带改变内部部件。**为 xray 外壳创建独立材质实例。**
- `lab.toggle('labels',true)`：把局部锚点投到屏幕，左右分列并向下排开。源码只做单向向下避让，**没有保证底边不越界/不与外侧正文撞位**，大量标签需分组显示和中文长名检查。
- `lab.toggle('slow',true)`：`timeScale` 从1向0.08变化，影响 tick 的 sdt；不减慢爆炸/剖切模式本身的缓动。
- `lab.toggle('run',true)`：paused 使 tick 的 sdt=0；模式缓动仍进行，默认自动镜头仍可能转动。若只展示模型，按钮应写“暂停演示”，并设 `autoOrbit:false`。
- 不调用 `lab.breakIt` 就没有 break 按钮。源码仍注册 B 键并能进入 broken 状态，但未设 handler 时没有项目行为；本任务应在自定义模式键处理中移除 B，或明确忽略它。勿添加任何工作故障或发射操作。
- 材质裁剪使用模块级 CUT/LAB_PLANES/ALL_MATS，共享全局状态；**一个页面一个 Lab** 最稳妥。

## 5. 中文 UI 完整覆盖

Lab options 的 prompt/title/sub/pills 和 `lab.hero` 的 label/unit/state/sub、`lab.slider` 的 label/ends、`lab.label` 的 text/value、`lab.how` 正文、film 的 beat 都可直接中文。

仍有硬编码英文：

- `_modes()`：Pause、Explode、Cut away、X-ray、Slow、Labels、Space；
- `_syncButtons()` 每次把运行按钮重新写成 Run/Pause，**只在 start 后改一次文字不够**；
- `_initDOM()`：How it is computed、No.；
- `_buildHUD()`：Building、of N parts、triangles、materials；
- `autoFilm()`：默认整套英文旁白字幕及“真实物理”主张；
- `.lab-scale` 的 m/cm/mm（展示比例应隐藏）。

推荐在任务代码中子类化 Lab 或包装上述方法，不改安装技能源码。`_modes` / `_syncButtons` 都先调原函数保留事件，再仅替换 button.firstChild.textContent 并保留 kbd；下次同步仍会中文。`_buildHUD` 调原方法后，若 `_building`，替换 label/unit/sub 的英文；或自定义影片省略 assemble 窗口避免虚构“构建真实部件”过程。`lab.$('.lab-how summary').textContent='展品说明'`，修改 `.lab-no`，加中文系统字体栈与 `lang='zh-CN'`。本任务不要显示真实工作参数 hero；若需要主数字，可从展示清单计算“已展示组件数”等有证据的数字。

## 6. 自定义影片、实际确定性限制

```js
lab.film(name, {len,assemble:[start,end],shots,events})
// shots: {t,az,el,dist,target:[x,y,z],fov,frameX,ease:'io'|...}
// events: {t,beat:['01','中文主句','中文补句'],
//          set:{cut:1,labels:1},snap:{...},
//          slider:{id,to,dur},cursor:{to:[fx,fy],dur,hide,click},
//          do(lab){...}}
```

本任务应自行写非功能展示影片，勿用原默认 autoFilm 的“运行/工作参数/故障”故事。可只用镜头、切面、外壳显示、组件聚焦、展示展开和来源标注。`shots` 最少两项，按 t 升序，`events` 也升序。

film 模式由 URL `?film=1&shot=main&ss=1.5` 启用，`lab.start()` 只初始化，不启动真实时间循环。协议：

```js
window.__film.ready
window.__film.len
window.__film.loaded()             // loading<=0 且 fonts.status==='loaded'
window.__film.start()              // ft=0; render(0)
window.__film.step(dt)
window.__film.seek(t)              // 只 while(ft<t) 前进，不支持后退
```

**源码比注释的保证窄：** `start()` 不清空 `_fired`、状态、控制值或项目自定义状态；`seek()` 不支持向后。一次加载内必须升序截图，回到较早时间应重新加载页面。不要反复 start 后声称得到相同初始状态。跨加载的确定性还取决于项目回调不使用未固定随机数、真实时间或异步状态。

## 7. 截图、录制与依赖实况

最初只读解析结果：Node `v22.16.0`，`ffmpeg` 在 `/opt/homebrew/bin/ffmpeg`；从原技能的 `scripts/lib/browser.mjs` 解析 **playwright 与 playwright-core 均失败**。原始脚本不能直接导入浏览器依赖；后续复制版已加本地适配并通过通用GPU测试，见末节。脚本 ESM import 需要它所在目录层级可解析的包；仅当前 shell 能找到别处 Playwright 不足以证明原脚本能导入。

`shot.mjs` 命令：

```sh
node <root>/scripts/shot.mjs page.html work/whole.png --w 1920 --h 1080
node <root>/scripts/shot.mjs page.html work/cut.png --js "lab.toggle('cut',true); lab.toggle('labels',true)" --then 2.5
node <root>/scripts/shot.mjs page.html work/explode.png --js "lab.toggle('explode',true)"
node <root>/scripts/shot.mjs page.html work/joint.png --js "lab.setView({az:70,el:8,dist:.8,target:[0,.3,0]})"
node <root>/scripts/shot.mjs page.html work/film --film 1,4,8,12 --shot main
```

脚本用 HTTP 临时服务加载本地文件；默认服务根为页面文件夹的上一级，可 `--root DIR`。非影片截图等待 `window.__lab.renderer`、fonts.ready、默认4.5秒；`--js` 在 `const lab=window.__lab` 的 eval 作用域执行，默认再等2.5秒。输出 fps（1秒 requestAnimationFrame计数）、parts、tris、materials、calls。它不是 GPU 性能剖析器。

`--steps file.json` 可同一页连续切多个展示态：`[{"js":"...","wait":3,"out":"..."}]`。影片 still 输出实际为 `<prefix>_<t.toFixed(1)>.jpg`，不是 PNG；时间需升序。没有自动裁图/接触点审计，近景要靠 setView，后续查看每张图片。

```sh
node <root>/scripts/record.mjs page.html outputs/show.mp4 --shot main --w 1920 --h 1080 --fps 30 --ss 1.5
```

record 支持 `--from/--to`、`--stills`、`--blur`、`--root`。默认 30fps、1920×1080、1.5倍绘制像素、blur1；PNG帧经ffmpeg编码 libx264/crf15/yuv420p。完成后运行 pinkscan。ffmpeg 与 ffprobe 可由环境变量 FFMPEG/FFPROBE 指定。`--music` 可传既有本地文件；FreePD 或 https 路径会联网，**本次未调用，离线任务不要加这些选项**。

browser.mjs 先 import playwright，再 fallback playwright-core；使用其 Chromium 默认路径。macOS 指定 ANGLE Metal，Linux 指定 Vulkan；不是通用软件渲染回退。没有匹配 Chromium 或 GPU 后端不工作时，需先验证运行时，不能把“脚本已写”当“GPU截图已通过”。

## 8. GPU 与视觉 QA 的真实边界

- browser 捕获 pageerror/console warning/error 到日志，但日志出现错误不会自行令 shot 退出非零；交付时要读日志。
- `guardPage` 包装每次 screenshot：先 PNG 检查，整片洋红持续出现重试8次后抛错；25%以上粉色会重试，若重复一致或到重试上限，仍可作为真实粉色场景接受；path 写入为临时文件后原子改名。JPEG请求会检查PNG后再抓JPEG，二者不是同一缓冲。
- record 检测 `webglcontextlost`，遇到退出3；结束时 `pinkscan` 将整片视频缩至64×36扫描，粉帧退出6。它不能发现缺零件、比例不对、接头悬空、普通穿插、UI溢出、坏法线或错误来源。
- 要执行技能要求的至少4轮 review，每轮包括整机、带标签剖切、展开、两个接点近景和影片关键帧，实际打开查看每张图，记录问题与修复。图像生成与审查记录要对应，不能只写“review passed”。
- 另检查：桌面/390宽中文布局；组件清单与场景对象 ID 覆盖；选中与隐藏状态；展开中间状态；真实闭合性与法线；材质区分；阴影接触；剖切盖视觉效果；片头/片尾；完整解码与尺寸/时长/帧数。
- 技能建议约700k三角形、200mesh，交互目标>30fps；这是目标而非本次实测。`lab.tris/matCount` 在 start 时计算，之后动态新增、ghost或后期修改不会自动重算。

## 来源定位

- `kit/lab-kit.js`：Lab 608；_initDOM 640；hero 677；slider 694；_modes 714；_syncButtons 732；add 876；mesh 886；place 895；label 898；_update 915；partCount 942；_buildHUD 943；_updateCut 965；_updateXray 982；setView 854；start 1070；film 1108；autoFilm 1109；_initFilm 1147；_filmStep 1167（本次以 rg 核对）。
- `scripts/inline.mjs`：仅替换 lab-kit 标记块。
- `scripts/shot.mjs`、`record.mjs`：本笔记参数与协议取自真实实现。

## 后续运行时准备结果

`work/machine-runtime/README.md` 和 `runtime-status.json` 给出实际路径与范围。复用现有 THREE0.170.0、esbuild0.27.7、bundled Playwright1.62.1；隔离 npm 下载尝试已停止并确认writer不再live，没有全局安装。复制 scripts/kit/LICENSE 到 `outputs/mojave-machine/source/vendor/machine`，只在复制的 browser.mjs 加依赖/浏览器路径 fallback，附 PATCHES.md 与 THREE LICENSE，原技能仓库未修改。

通用 esbuild.transformSync smoke 成功；完整 kit 已成功打成824658字节本地 IIFE（含THREE/addons），可供最终HTML内联。原 Playwright 期待的 Chromium1234缺失，复制适配器改用现有Chrome155的独立headless临时profile。通用WebGL2测试实际成功，渲染器为ANGLE Metal / Apple M4，截图 `work/machine-runtime/webgl-smoke.png` 已打开确认绿色清屏正确。这个测试只验证浏览器/GPU通路，不证明主模型、材质或影片通过QA。
