import {chromium} from '/Users/qianqiming/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs';
import fs from 'node:fs/promises';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';

const root=path.resolve('work/atlas-integration'),stage=path.resolve(process.env.ATLAS_DIR||'outputs/启明火箭/library/部件说明图册'),out=path.resolve(process.env.ATLAS_QA_DIR||'work/atlas-integration/step-link-repair/browser-review');
await fs.mkdir(out,{recursive:true});
const html=path.join(stage,'部件说明图册.html'),data=JSON.parse(await fs.readFile(path.join(stage,'图册数据.json'),'utf8'));
const browser=await chromium.launch({headless:true,executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'});
const page=await browser.newPage({viewport:{width:1440,height:1100},deviceScaleFactor:1});
const external=[],errors=[],checks=[];
page.context().on('request',r=>{if(!['file:','data:','blob:'].includes(new URL(r.url()).protocol))external.push(r.url())});
page.on('pageerror',e=>errors.push(e.message));
page.context().on('page',p=>p.on('pageerror',e=>errors.push(e.message)));
const check=(name,value,detail)=>{checks.push({name,pass:!!value,detail});if(!value)throw new Error(name+' failed '+JSON.stringify(detail))};
await page.goto(pathToFileURL(html).href,{waitUntil:'load'});
await page.waitForFunction(()=>window.atlasReview?.recordCount===206);
const decode=await page.evaluate(async()=>{const imgs=[...document.querySelectorAll('.pictures img')];for(const i of imgs)i.loading='eager';const results=await Promise.all(imgs.map(async i=>{try{await i.decode();return {src:i.getAttribute('src'),ok:i.naturalWidth>0,width:i.naturalWidth,height:i.naturalHeight}}catch(e){return{src:i.getAttribute('src'),ok:false,error:String(e)}}}));return {count:results.length,unique:new Set(results.map(r=>r.src)).size,failed:results.filter(r=>!r.ok)}});
check('all208ImageReferencesDecode',decode.count===208&&decode.unique===188&&decode.failed.length===0,decode);
check('all206FullSourceRecords',data.records.every(x=>x.sourceRecord&&x.sourceRecord.id===x.id));
const [base,custom]=await Promise.all(['来源-base-parts.json','来源-custom-parts.json'].map(n=>fs.readFile(path.join(stage,n),'utf8').then(JSON.parse)));
const byid=new Map([...base,...custom].map(x=>[x.id,x]));
check('sourceRecordsPreserveEveryOriginalField',data.records.every(r=>JSON.stringify(r.sourceRecord)===JSON.stringify(byid.get(r.id))));
check('all172BOMRowsAndQuantitiesPreserved',data.records.filter(r=>r.recordType==='bom').length===172&&data.records.filter(r=>r.recordType==='bom').every(r=>r.procurementAsWritten?.originalBOMRow&&r.procurementAsWritten.quantity!==undefined));
await page.screenshot({path:path.join(out,'desktop-all.png'),fullPage:false});
for(const [query,expectedId]of[['A2-11','A2-11'],['7392T17-7392T173','A1-04']]){
 await page.locator('#query').fill(query);check('search '+query,await page.locator('.card').count()===1&&await page.locator('.card').first().getAttribute('id')===expectedId);
}
const sourceFile=base.find(x=>x.id==='A1-14').visual.sourceBasename;
await page.locator('#query').fill(sourceFile);check('searchExactOriginalFilename',await page.locator('.card#A1-14').count()===1,sourceFile);
await page.locator('#query').fill('绝不存在的零件xyz');check('searchNoResult',await page.locator('.card').count()===0);
await page.locator('#query').fill('');
for(const [selector,value,expected]of[['#kind','raw_stock_illustration',17],['#type','bom',172],['#type','custom',34],['#group','A1',data.records.filter(r=>r.group==='A1').length]]){
 for(const id of['#kind','#type','#group'])await page.locator(id).selectOption('');
 await page.locator(selector).selectOption(value);check('filter '+selector+' '+value,await page.locator('.card').count()===expected,expected);
}
for(const id of['#kind','#type','#group'])await page.locator(id).selectOption('');
await page.locator('#query').fill('A1-04');await page.locator('#A1-04 summary').click();
check('rawBOMLineVisibleInFoldout',await page.locator('#A1-04').getByText('原物料条目（原BOM整行）',{exact:true}).isVisible());
check('procurementQuantityVisibleInFoldout',await page.locator('#A1-04').getByText('原表采购数量',{exact:true}).isVisible());
check('sourceConflictVisible',await page.locator('#A1-04').innerText().then(t=>t.includes('1/2')&&t.includes('1/4')));
await page.screenshot({path:path.join(out,'desktop-procurement-and-conflict.png'),fullPage:false});
await page.locator('#query').fill('A2-11');await page.locator('#A2-11 img').click();await page.waitForFunction(()=>document.querySelector('#lightbox').open);
check('imageModalOpens',await page.locator('#large').evaluate(async i=>{await i.decode();return i.naturalWidth===1600}));
await page.screenshot({path:path.join(out,'desktop-image-modal.png'),fullPage:false});await page.locator('#close').click();
check('imageModalCloses',await page.locator('#lightbox').evaluate(d=>!d.open));
await page.locator('#query').fill('');
const links=await page.locator('a[href*="整箭原件检视.html?part="]').evaluateAll(as=>as.map(a=>({href:a.getAttribute('href'),name:decodeURIComponent(a.getAttribute('href').split('part=')[1])})));
check('nativeDeepLinksAreExactSourceFilenames',links.length===97&&links.every(l=>/\.(sldprt|sldasm)$/i.test(l.name)),{count:links.length,unique:new Set(links.map(x=>x.name)).size});
const stepExpected=data.records.flatMap(r=>r.images.filter(im=>im.sourceLink?.format==='STEP').map(im=>({recordId:r.id,...im.sourceLink})));
const stepLinks=await page.locator('a[data-source-format="STEP"]').evaluateAll(as=>as.map(a=>({href:a.getAttribute('href'),id:a.getAttribute('data-source-id'),label:a.textContent})));
check('STEPLinksPreserveExactExchangeFormat',stepExpected.length===10&&new Set(stepExpected.map(x=>x.basename)).size===8&&stepLinks.length===10&&stepLinks.every(l=>l.label==='查看对应 STEP 来源'&&/交换格式来源图册\.html#STEP-\d{3}$/.test(l.href)),stepLinks);
const stepClicks=[],captured=new Set();
for(const expected of stepExpected){
 await page.locator('#query').fill(expected.recordId);
 await page.locator(`#${expected.recordId} summary`).click();
 if(expected.recordId==='A1-18')await page.locator('#A1-18').screenshot({path:path.join(out,'step-entry-A1-18.png')});
 const [popup]=await Promise.all([page.waitForEvent('popup'),page.locator(`#${expected.recordId} a[data-source-format="STEP"]`).click()]);
 await popup.waitForLoadState('load');await popup.setViewportSize({width:1440,height:1100});
 const actual=await popup.evaluate(()=>{const id=decodeURIComponent(location.hash.slice(1)),target=document.getElementById(id),cards=[...document.querySelectorAll('#stepgrid .card')];return{id,uniqueIds:new Set(cards.map(c=>c.id)).size,count:cards.length,sourceFilename:target?.dataset.sourceFilename,rawHref:target?.querySelector('a[href$=".STEP"]')?.getAttribute('href'),rect:target?{top:target.getBoundingClientRect().top,bottom:target.getBoundingClientRect().bottom}:null}});
 const originalURL=new URL(actual.rawHref,popup.url());
 const originalBytes=await fs.readFile(originalURL);
 const originalSHA=createHash('sha256').update(originalBytes).digest('hex');
 const passed=actual.id===expected.indexId&&actual.sourceFilename===expected.basename&&actual.count===35&&actual.uniqueIds===35&&actual.rect.top>=0&&actual.rect.top<1100&&decodeURIComponent(originalURL.pathname.split('/').at(-1))===expected.basename&&originalSHA===expected.originalSourceSha256;
 stepClicks.push({recordId:expected.recordId,expected,actual,originalURL:originalURL.href,originalSHA256:originalSHA,pass:passed});
 if(!passed)throw new Error('STEP click route failed '+JSON.stringify(stepClicks.at(-1)));
 await popup.locator(`#${expected.indexId} img`).evaluateAll(imgs=>Promise.all(imgs.map(i=>i.decode())));
 if(!captured.has(expected.indexId)){await popup.locator(`#${expected.indexId}`).screenshot({path:path.join(out,`step-${expected.indexId}-${expected.recordId}.png`)});captured.add(expected.indexId)}
 await popup.close();
}
check('all10STEPClicksReachCorrectAnchorAndOriginalFile',stepClicks.length===10&&stepClicks.every(x=>x.pass),stepClicks);
check('noSTEPSourceUsesNativePartFallback',links.every(l=>!/\.(step|stp)$/i.test(l.name))&&stepClicks.every(x=>!x.expected.href.includes('?part=')));
await page.locator('#query').fill('');
await page.setViewportSize({width:390,height:844});await page.locator('#query').fill('C1-34');
check('mobileNoHorizontalOverflow',await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
await page.screenshot({path:path.join(out,'mobile-card.png'),fullPage:false});
await page.locator('#C1-34 img').click();await page.waitForFunction(()=>document.querySelector('#lightbox').open);
check('mobileModalFitsWidth',await page.locator('#lightbox').evaluate(d=>{const r=d.getBoundingClientRect();return r.left>=0&&r.right<=innerWidth}));
await page.screenshot({path:path.join(out,'mobile-modal.png'),fullPage:false});
await page.locator('#close').click();await page.locator('#C1-34 summary').click();
check('mobileLongRawBOMWraps',await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
check('noExternalNetworkRequests',external.length===0,external);check('noPageErrors',errors.length===0,errors);
await browser.close();
const bytes=await fs.readFile(html);const report={reviewedAtUTC:new Date().toISOString(),html,htmlSha256:createHash('sha256').update(bytes).digest('hex'),checks,decode,nativeDeepLinks:links,stepSourceClicks:stepClicks,externalRequests:external,pageErrors:errors,allPassed:checks.every(c=>c.pass),scope:'Actual isolated headless Chromium local-file QA of final installed atlas. 97 native links retain exact native filenames. 10 STEP links are actually clicked through to 8 distinct indexed exchange sources, with exact anchor/source filename and original STEP byte SHA checks. Full native model interaction is separately validated by root.',sourceRecordLossless:true};
await fs.writeFile(path.join(out,'browser-review.json'),JSON.stringify(report,null,2));
process.stdout.write(JSON.stringify({checks:checks.length,allPassed:report.allPassed,decode,nativeLinks:links.length,externalRequests:external.length,pageErrors:errors.length,htmlSha256:report.htmlSha256})+'\n');
