"""Convert only the supplied native patch part into a separate passive USD."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import time
import zipfile
ROOT=Path.home()/'codex-mojave-cad-review-20261019'
PATCH=ROOT/'patches/HCR-5105'
PATCH.mkdir(parents=True,exist_ok=True)
archive=ROOT/'patch-source.zip'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
archive_sha=sha(archive)
with zipfile.ZipFile(archive) as z:
    candidates=[i for i in z.infolist() if Path(i.filename).suffix.upper()=='.SLDPRT' and not i.filename.startswith('__MACOSX/')]
    if len(candidates)!=1:raise SystemExit('Expected precisely one supplied native patch part')
    info=candidates[0]
    if Path(info.filename).name!=info.filename:raise SystemExit('Unexpected patch archive hierarchy')
    source_dir=PATCH/'source'
    source_dir.mkdir(exist_ok=True)
    source=source_dir/info.filename
    data=z.read(info)
    source.write_bytes(data)
    source_hash=hashlib.sha256(data).hexdigest()
(PATCH/'source-manifest.json').write_text(json.dumps({'revision_group':'HCR-5105','source_archive_sha256':archive_sha,'source_basename':source.name,'source_sha256':source_hash,'source_bytes':len(data),'scope':'Separate supplied revision; never replace the R01 part'},indent=2)+'\n')
output=PATCH/(source.stem+'.usdc')
cmd=[str(ROOT/'venv/bin/usd-convert-cad'),'-i',str(source),'-o',str(output),'--tess-lod','3','--instancing-style','reference','--composition-style','none','--filter-style','hide','--load-hidden']
started=time.monotonic()
with output.with_suffix('.stdout.log').open('w') as out,output.with_suffix('.stderr.log').open('w') as err:
    result=subprocess.run(cmd,cwd=source_dir,stdout=out,stderr=err)
logs=output.with_suffix('.stdout.log').read_text(errors='replace')+'\n'+output.with_suffix('.stderr.log').read_text(errors='replace')
license_error=bool(re.search(r'(?:license|licensing|entitlement).{0,80}(?:error|fail|denied|invalid|missing|expired)|A3D_LICENSE',logs,re.I))
report={'revision_group':'HCR-5105','source':str(source),'source_basename':source.name,'source_archive_sha256':archive_sha,'input_sha256_before':source_hash,'input_sha256_after':sha(source),'command':cmd,'return_code':result.returncode,'licensing_error_detected':license_error,'missing_reference_lines':[l for l in logs.splitlines() if re.search(r'missing|not.found|unresolved|reference.*fail|cannot.*(?:open|load)|could not.*(?:open|load)',l,re.I)],'output':str(output),'output_exists':output.exists(),'wall_seconds':round(time.monotonic()-started,3),'scope':'Faithful passive geometry of a supplied revision, no constraints/physics/solver/new design'}
report['input_unchanged']=source_hash==report['input_sha256_after']
if output.exists():report.update({'output_sha256':sha(output),'output_bytes':output.stat().st_size})
output.with_suffix('.conversion.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
if result.returncode!=0 or license_error or not report['input_unchanged']:raise SystemExit(2)
audit=subprocess.run([str(ROOT/'venv/bin/python'),str(ROOT/'validate_usd.py'),str(output)],capture_output=True,text=True)
output.with_suffix('.audit.stdout.log').write_text(audit.stdout)
output.with_suffix('.audit.stderr.log').write_text(audit.stderr)
print(audit.stdout)
if audit.returncode:raise SystemExit(audit.returncode)
