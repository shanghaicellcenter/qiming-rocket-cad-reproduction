"""Extract ONLY an explicit allowlist of ten inert exterior/avionics STLs.
Source archives remain read only. No propulsion/pressure/pyrotechnic data is read.
"""
from pathlib import Path
import zipfile, hashlib, struct, json
import numpy as np

ROOT=Path('/Users/qianqiming/Documents/Codex/2026-10-19/new-chat')
ARCHIVE=Path('/Users/qianqiming/Desktop/火箭设计 中文版/英文原件/Printed Components - R01.zip')
DEST=ROOT/'work/safe-stl'
DEST.mkdir(parents=True,exist_ok=True)
PARTS=[
 ('nose-section-1','NSCN-SC1-4X250R Nose Cone, Section 1, Mojave Sphinx.STL','鼻锥第一段','nose','white'),
 ('nose-section-2','NSCN-SC2-4X250R Nose Cone, Section 2, Mojave Sphinx.STL','鼻锥第二段','nose','white'),
 ('nose-shoulder','NSCN-SLDR-4X250R-8X832HNC Nose Cone Shoulder, Mojave Sphinx.STL','鼻锥连接肩','nose','white'),
 ('nose-tip','NSCN-TIP-4X250R-250HNC Nose Cone Tip, Mojave Sphinx.STL','鼻锥尖端','nose','red'),
 ('avbay-battery-holder','AVBY-BH-2X9V-250R-M4C Battery Holder, Avbay, Mojave Sphinx.STL','电子舱电池托架','avbay','polymer'),
 ('avbay-centering-ring','AVBY-CR-4R Bulkhead Centering Ring, Avbay, Mojave Sphinx.STL','电子舱定心环','avbay','polymer'),
 ('avbay-coupler-half','AVBY-HF-3994 Avbay Coupler, Half, Mojave Sphinx.STL','电子舱半段连接壳','avbay','polymer'),
 ('avbay-sled-mount','AVBY-MT-250R-M4C Mount, Avbay Sled, Mojave Sphinx.STL','电子舱托板安装座','avbay','polymer'),
 ('avbay-switchband','AVBY-SB-4160 Switchband, Avbay, Mojave Sphinx.STL','电子舱开关环','avbay','red'),
 ('fin-bracket-tip','AERO-100X100X0125 Aerodynamic Fin Bracket Tip, for 1.00 X 1.00 X .125 Aluminum Angle, Mojave Sphinx.STL','尾翼支架外部端盖','exterior','metal'),
]
z=zipfile.ZipFile(ARCHIVE)
entries=[]
for pid,name,label,family,mat in PARTS:
    member='Printed Components - R01/STL/'+name
    data=z.read(member)
    n=struct.unpack_from('<I',data,80)[0]
    assert len(data)==84+n*50, f'Unexpected non-binary or truncated STL: {member}'
    dtype=np.dtype([('normal','<f4',3),('vertices','<f4',(3,3)),('attribute','<u2')])
    tris=np.frombuffer(data,dtype=dtype,offset=84,count=n)['vertices']
    verts=tris.reshape(-1,3)
    lo=verts.min(axis=0).astype(float);hi=verts.max(axis=0).astype(float)
    local=DEST/(pid+'.stl');local.write_bytes(data)
    entries.append({'id':pid,'source_name':name,'label_zh':label,'family':family,'display_material':mat,
      'archive':str(ARCHIVE),'zip_member':member,'sha256':hashlib.sha256(data).hexdigest(),'source_bytes':len(data),
      'geometry_format':'native binary STL','conversion':'none; byte-identical allowlisted extraction',
      'source_geometry_status':'original triangulation; no repair, remesh, simplification, topology reconstruction or parameter substitution',
      'unit_status':'STL does not declare units; no unit conversion performed',
      'unit_inference':'likely millimetres; unverified and not used as an engineering claim',
      'native_bbox_min':lo.tolist(),'native_bbox_max':hi.tolist(),'native_bbox_size':(hi-lo).tolist(),
      'triangles':int(n),'raw_triangle_vertices':int(n*3),'local_stl':str(local),
      'safe_scope':'non-pressure exterior or passive avionics structure; geometry viewing only',
      'assembly_placement_status':'component-local source coordinates; authoritative assembly transforms unavailable in STL'})
index={'schema_version':1,'title':'Safe original geometry index — ten passive exterior/avionics components',
  'source_archive_untouched':True,'all_entries_allowlisted':True,'geometry_count':len(entries),
  'total_triangles':sum(e['triangles'] for e in entries),
  'not_a_complete_project_reproduction':True,'no_operational_simulation':True,'installed_new_dependencies':False,
  'unsupported_sources':[{'name':'FIN-STD-250T-4X250C Fin, Standard, Mojave Sphinx.SLDPRT',
       'status':'not imported; no native STL or STEP found; fin bracket tip is a different component'},
    {'name':'Upper/lower airframe and avionics sled SLDPRT',
       'status':'not imported; no exact local SLDPRT conversion runtime verified'}],
  'blender_runtime':'/Applications/Blender 5.2.app/Contents/MacOS/Blender',
  'blender_version_observed':'5.2.2 LTS','parts':entries}
out=ROOT/'work/safe-geometry-index.json';out.write_text(json.dumps(index,ensure_ascii=False,indent=2))
print(json.dumps({'index':str(out),'geometry_count':len(entries),'total_triangles':index['total_triangles'],'ids':[e['id'] for e in entries]},ensure_ascii=False))
