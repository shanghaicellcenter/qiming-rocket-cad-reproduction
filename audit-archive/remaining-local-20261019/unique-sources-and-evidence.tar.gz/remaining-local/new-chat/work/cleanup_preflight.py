"""Read-only preflight; optional copying of small receipts. No delete/move/kill."""
from pathlib import Path
import os,stat,json,hashlib,argparse,subprocess,datetime,shutil
P=argparse.ArgumentParser(description=__doc__);P.add_argument('--plan',type=Path,default=Path(__file__).with_name('cleanup-plan-current.json'));P.add_argument('--acceptance-report',type=Path);P.add_argument('--copy-receipts',action='store_true');a=P.parse_args();plan=json.loads(a.plan.read_text());root=a.plan.resolve().parents[1];fp=Path(plan['known_path_fingerprints']['path']);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert sha(fp)==plan['known_path_fingerprints']['sha256'];known=json.loads(fp.read_text());changes=[]
for group in known['candidates']:
 base=Path(group['root']);assert base==root/'outputs/mojave-machine' or base.is_relative_to(root/'outputs') or base.is_relative_to(root/'work')
 old={x['relative_path']:x for x in group['items']};current={};stack=[base]
 while stack:
  p=stack.pop()
  try:s=p.lstat()
  except FileNotFoundError:continue
  kind='symlink' if stat.S_ISLNK(s.st_mode) else 'directory' if stat.S_ISDIR(s.st_mode) else 'file' if stat.S_ISREG(s.st_mode) else 'other'
  r={'relative_path':p.relative_to(base).as_posix(),'kind':kind,'device':s.st_dev,'inode':s.st_ino,'mtime_ns':s.st_mtime_ns,'bytes':s.st_size if kind=='file' else 0}
  if kind=='symlink':r['raw_target']=os.readlink(p)
  current[r['relative_path']]=r
  if kind=='directory':stack.extend(p.iterdir())
 for name in sorted(set(old)|set(current)):
  # Directory mtime changes are covered by the actual child set below.
  x=old.get(name);y=current.get(name)
  if x and y and x['kind']==y['kind']=='directory':x={k:v for k,v in x.items() if k!='mtime_ns'};y={k:v for k,v in y.items() if k!='mtime_ns'}
  if x!=y:changes.append({'root':str(base),'relative_path':name,'change':'new' if x is None else 'missing' if y is None else 'changed'})
# Capture fresh open handles without argv/env. Parent directory cwd remains kept.
active=[];r={'pid':None,'command':None,'fd':None};out=subprocess.run(['lsof','-nP','-Fpcfn'],capture_output=True,text=True);candidate_paths=[x['root'] for x in known['candidates']]
for line in out.stdout.splitlines():
 if not line:continue
 k,v=line[0],line[1:]
 if k=='p':r={'pid':int(v),'command':None,'fd':None}
 elif k=='c':r['command']=v
 elif k=='f':r['fd']=v
 elif k=='n' and any(v==x or v.startswith(x+'/') for x in candidate_paths):active.append({**r,'path':v})
owner=json.loads((root/'work/output-preview-server.json').read_text());listen=subprocess.run(['lsof','-nP','-a','-p',str(owner['pid']),'-iTCP:'+str(owner['port']),'-sTCP:LISTEN','-Fpnc'],capture_output=True,text=True);preview_listening=bool(listen.stdout.strip())
copy_checks=[]
for r in plan['process_and_reference_evidence']['independent_copy_checks']:
 p=Path(r['independent_local_path_to_keep']);ok=p.is_file() and not p.is_symlink() and sha(p)==r['sha256'];copy_checks.append({'path':str(p),'passed':ok})
clone=Path(plan['retained_git_checkout']['root']);head=subprocess.check_output(['git','-C',str(clone),'rev-parse','HEAD'],text=True).strip();head_ok=head==plan['commit'];accepted={}
if a.acceptance_report:accepted=json.loads(a.acceptance_report.read_text())
acceptance_claimed=accepted.get('cleanup_eligible') is True and accepted.get('actual_download_performed') is True
# A claimant alone is not recreated proof. Parent owns the actual media/browser/
# rebuild reports and must review them; this helper never turns it into deletion.
receipt_copies=[]
if a.copy_receipts:
 dest=Path(plan['retained_receipts_plan']['destination']);assert dest.parent==root;dest.mkdir(exist_ok=True)
 for r in plan['retained_receipts_plan']['files']:
  p=Path(r['source'])
  if not p.exists():receipt_copies.append({'source':str(p),'status':'missing_do_not_infer_preserved'});continue
  assert not p.is_symlink() and p.is_file() and p.is_relative_to(root)
  q=dest/r['relative_target'];assert q.is_relative_to(dest);q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q);h=sha(q);assert h==sha(p);receipt_copies.append({'source':str(p),'target':str(q),'bytes':q.stat().st_size,'sha256':h,'matches_plan_snapshot':h==r['sha256_snapshot']})
 for name in ['cleanup-plan-current.json','cleanup-plan-current.md','cleanup-known-path-fingerprints.json','cleanup-inventory-evidence.json','cleanup_preflight.py','prepare_cleanup_plan.py','build_cleanup_plan.py','stage_cleanup.py','cleanup-final-acceptance.schema.json','cleanup-stage-current.json','desktop392-protection-check.json']:
  p=root/'work'/name;q=dest/'cleanup-plan'/name;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
 (dest/'preserved-receipts-manifest.json').write_text(json.dumps({'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':receipt_copies},ensure_ascii=False,indent=2)+'\n')
report={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'read_only_except_optional_receipt_copies':True,'deletion_supported':False,'deletions_performed':0,'current_open_candidate_paths':active,'task_preview_server_still_listening':preview_listening,'candidate_known_path_changes':changes,'lsof_error_lines':len(out.stderr.splitlines()),'all103_independent_copies_current_sha_passed':all(x['passed'] for x in copy_checks),'retained_clone_head_matches':head_ok,'actual_acceptance_receipt_supplied':bool(a.acceptance_report),'acceptance_receipt_claims_download_and_cleanup_eligible':acceptance_claimed,'requires_parent_actual_report_review':True,'currently_clear_of_local_safety_blockers':not active and not preview_listening and not changes and not out.stderr.strip() and all(x['passed'] for x in copy_checks) and head_ok,'receipt_files_copied':len(receipt_copies),'df_current':subprocess.check_output(['df','-k',str(root)],text=True)}
(root/'work/cleanup-preflight-current.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k not in {'candidate_known_path_changes','current_open_candidate_paths','df_current'}},ensure_ascii=False,indent=2));print('active',len(active),'changes',len(changes),'No deletion function exists.')
