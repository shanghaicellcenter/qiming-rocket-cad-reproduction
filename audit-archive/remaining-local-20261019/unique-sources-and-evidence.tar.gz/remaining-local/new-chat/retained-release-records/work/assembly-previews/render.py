"""Render each actual source SLDASM conversion independently; never crop another assembly.
USD import settings and USDHook follow the audited local Blender 5.2 helper.
Only presentation camera/workbench settings are added; no blend or new geometry is saved.
"""
import bpy,sys,json,hashlib,time,math,argparse,gc
import numpy as np
from pathlib import Path
from mathutils import Vector
from bpy_extras.object_utils import world_to_camera_view
from pxr import Usd,UsdGeom

ap=argparse.ArgumentParser();ap.add_argument('--jobs',required=True);ap.add_argument('--ids',default='');args=ap.parse_args(sys.argv[sys.argv.index('--')+1:])
jobs=json.loads(Path(args.jobs).read_text());out=Path(jobs['output_dir']);out.mkdir(parents=True,exist_ok=True)
selected=set(args.ids.split(',')) if args.ids else set()

def log(phase,**kw):print('ASSEMBLY_PREVIEW='+json.dumps({'phase':phase,**kw},ensure_ascii=False),flush=True)
def sha(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
    return h.hexdigest()
def matrix(m):return [[float(v) for v in row] for row in m]

class SourcePreviewUSDHook(bpy.types.USDHook):
    bl_idname='source_assembly_preview_provenance';bl_label='Original assembly source path'
    @staticmethod
    def on_import(context):
        for p,ids in context.get_prim_map().items():
            for data in ids:
                try:data['source_usd_path']=str(p)
                except Exception:pass
        return True
bpy.utils.register_class(SourcePreviewUSDHook)

def clear():
    for o in list(bpy.data.objects):bpy.data.objects.remove(o,do_unlink=True)
    bpy.data.orphans_purge(do_recursive=True)
    gc.collect()

def signature(objects):
    h=hashlib.sha256();done={}
    for o in sorted(objects,key=lambda o:o.get('source_usd_path',o.name)):
        p=o.get('source_usd_path',o.name);h.update(p.encode());h.update(np.asarray(o.matrix_local,dtype=np.float64).tobytes());h.update(np.asarray(o.matrix_world,dtype=np.float64).tobytes())
        if o.type!='MESH':continue
        me=o.data
        if me.as_pointer() not in done:
            g=hashlib.sha256()
            for collection,field,count,dtype in [(me.vertices,'co',len(me.vertices)*3,np.float32),(me.polygons,'loop_total',len(me.polygons),np.int32),(me.loops,'vertex_index',len(me.loops),np.int32)]:
                a=np.empty(count,dtype=dtype);collection.foreach_get(field,a);g.update(a.tobytes());del a
            done[me.as_pointer()]=g.hexdigest()
        h.update(done[me.as_pointer()].encode())
    return h.hexdigest()

def bbox(objects):
    pts=[o.matrix_world@Vector(c) for o in objects for c in o.bound_box]
    if not pts:raise RuntimeError('No source points in render selection')
    lo=Vector(tuple(min(p[i] for p in pts) for i in range(3)));hi=Vector(tuple(max(p[i] for p in pts) for i in range(3)))
    return lo,hi,pts

def configure():
    sc=bpy.context.scene
    sc.render.engine='BLENDER_WORKBENCH';sc.render.resolution_x=jobs['render_width'];sc.render.resolution_y=jobs['render_height'];sc.render.resolution_percentage=100
    sc.render.image_settings.file_format='PNG';sc.render.image_settings.color_mode='RGBA';sc.render.image_settings.color_depth='8';sc.render.image_settings.compression=65
    sc.render.film_transparent=True
    sc.view_settings.view_transform='Standard';sc.view_settings.look='None';sc.view_settings.exposure=0;sc.view_settings.gamma=1
    sh=sc.display.shading;sh.light='STUDIO';sh.color_type='MATERIAL';sh.show_shadows=True;sh.show_cavity=True;sh.cavity_type='BOTH';sh.curvature_ridge_factor=1.4;sh.curvature_valley_factor=1.2;sh.cavity_ridge_factor=1.2;sh.cavity_valley_factor=1.0
    sh.show_object_outline=True;sh.object_outline_color=(.045,.055,.065);sh.show_specular_highlight=True
    if hasattr(sh,'show_backface_culling'):sh.show_backface_culling=False
    sc.display.render_aa='16'
    return sc

def run(row):
    clear();started=time.time();usd=Path(row['source_usd']);assert sha(usd)==row['source_usd_sha256'];stage=Usd.Stage.Open(str(usd));assert stage
    vis={};placeholders=[]
    for p in stage.Traverse():
        if p.IsA(UsdGeom.Imageable):vis[str(p.GetPath())]=str(UsdGeom.Imageable(p).ComputeVisibility())
        name=p.GetDisplayName();compact=''.join(c.lower() for c in name if c.isalnum())
        if 'massvolume' in compact:placeholders.append({'path':str(p.GetPath()),'display_name':name,'status':'source mass/volume placeholder; not reconstructed interior'})
    settings={'filepath':str(usd),'scale':1.0,'set_frame_range':False,'import_cameras':False,'import_lights':False,'import_curves':True,'import_volumes':False,'import_shapes':True,'import_meshes':True,'import_skeletons':False,'import_blendshapes':False,'import_points':False,'import_materials':True,'import_subdivision':False,'support_scene_instancing':True,'import_visible_only':False,'create_collection':True,'read_mesh_uvs':True,'read_mesh_colors':True,'read_mesh_attributes':True,'import_guide':True,'import_proxy':True,'import_render':True,'import_usd_preview':True,'property_import_mode':'ALL','validate_meshes':False,'create_world_material':False,'import_defined_only':False,'merge_parent_xform':False,'apply_unit_conversion_scale':False}
    bpy.ops.wm.usd_import(**settings);bpy.context.view_layer.update();objects=list(bpy.context.scene.objects);meshes=[o for o in objects if o.type=='MESH'];assert len(meshes)==row['expected_mesh_count'],(row['id'],len(meshes),row['expected_mesh_count'])
    triangles=0
    for o in meshes:
        o.data.calc_loop_triangles();triangles+=len(o.data.loop_triangles)
        # Apply source-computed visibility explicitly per mesh, including ancestor visibility.
        o.hide_render=vis.get(o.get('source_usd_path'))=='invisible'
    assert triangles==row['expected_triangles'],(row['id'],triangles,row['expected_triangles'])
    before=signature(objects);visible=[o for o in meshes if not o.hide_render];lo,hi,pts=bbox(visible);all_lo,all_hi,_=bbox(meshes)
    center=(lo+hi)*.5;span=max(hi-lo);assert span>0
    sc=configure();sc.unit_settings.system='METRIC';sc.unit_settings.scale_length=row['source_unit_metres']
    cdata=bpy.data.cameras.new('PRESENTATION_CAMERA_NOT_SOURCE');cam=bpy.data.objects.new('PRESENTATION_CAMERA_NOT_SOURCE',cdata);sc.collection.objects.link(cam);sc.camera=cam;cdata.type='ORTHO';cdata.clip_start=max(1e-6,span*1e-5);cdata.clip_end=max(1000,span*100)
    directions={'front':(0,-1,0),'side':(1,0,0),'oblique':(1.6,-2.6,1.4)};renders=[]
    for view in row['views']:
        direction=Vector(directions[view['id']]).normalized();cam.location=center+direction*span*4;cam.rotation_euler=(center-cam.location).to_track_quat('-Z','Y').to_euler();bpy.context.view_layer.update()
        right=cam.rotation_euler.to_matrix()@Vector((1,0,0));up=cam.rotation_euler.to_matrix()@Vector((0,1,0));rel=[p-center for p in pts]
        width=max(p.dot(right) for p in rel)-min(p.dot(right) for p in rel);height=max(p.dot(up) for p in rel)-min(p.dot(up) for p in rel);cdata.ortho_scale=max(width,height*sc.render.resolution_x/sc.render.resolution_y,span*.01)*1.16
        bpy.context.view_layer.update();projected=[world_to_camera_view(sc,cam,p) for p in pts];screenlo=[min(p[i] for p in projected) for i in range(3)];screenhi=[max(p[i] for p in projected) for i in range(3)]
        assert min(screenlo[:2])>.025 and max(screenhi[:2])<.975,(row['id'],view['id'],screenlo,screenhi)
        dest=out/view['filename'];sc.render.filepath=str(dest);bpy.ops.render.render(write_still=True)
        render={'view':view['id'],'image':view['filename'],'image_sha256':sha(dest),'bytes':dest.stat().st_size,'resolution':[sc.render.resolution_x,sc.render.resolution_y],
            'camera':{'type':'ORTHO','location_native':list(cam.location),'rotation_euler':list(cam.rotation_euler),'target_native':list(center),'ortho_scale_native':cdata.ortho_scale,'direction':list(direction),'clip_start':cdata.clip_start,'clip_end':cdata.clip_end},
            'projected_bounds':[screenlo,screenhi],'geometric_crop_check':'passed','pixel_crop_check':'pending post-render PNG audit'}
        renders.append(render);log('rendered',source_id=row['id'],view=view['id'],image=dest.name)
    after=signature(objects);assert before==after,'Source geometry or transforms changed during render'
    result={**row,'status':'rendered; pixel and visual review pending','blender_version':bpy.app.version_string,'source_usd_hash_rechecked':True,'source_geometry_transform_sha256_before':before,'source_geometry_transform_sha256_after':after,'source_geometry_transforms_unchanged':before==after,
        'source_native_units_retained':True,'source_visibility_respected':True,'source_mesh_count':len(meshes),'visible_mesh_count':len(visible),'hidden_mesh_count':len(meshes)-len(visible),'triangles':triangles,
        'visible_bbox_blender_native':{'min':list(lo),'max':list(hi)},'all_source_bbox_blender_native':{'min':list(all_lo),'max':list(all_hi)},'source_mass_volume_placeholders':placeholders,
        'render_engine':'BLENDER_WORKBENCH','view_transform':'Standard','shading_note':'Studio geometry preview; source material display colors under workbench light, no physical material certification. No geometry added, repaired, thickened or simplified.',
        'source_axis_note':'Blender USD importer adapts declared Y-up stage to Blender Z-up; no unit scale baked into mesh or source transforms.',
        'renders':renders,'elapsed_seconds':time.time()-started}
    (out/(row['id']+'.audit.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2));log('source complete',source_id=row['id'],mesh_count=len(meshes),triangles=triangles,seconds=result['elapsed_seconds'])
    del stage,objects,meshes,visible,pts;clear()

def main():
    log('version',blender=bpy.app.version_string)
    assert bpy.app.version[:2]>=(5,2),'This audited USD path requires Blender 5.2 or later'
    for row in jobs['rows']:
        if selected and row['id'] not in selected:continue
        run(row)
    log('batch complete')
main()
