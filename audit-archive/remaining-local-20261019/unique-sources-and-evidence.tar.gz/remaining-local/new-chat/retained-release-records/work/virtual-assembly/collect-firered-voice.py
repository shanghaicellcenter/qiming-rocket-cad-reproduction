"""Own FireRed artifacts only; publish true durations before ASR completion."""
from pathlib import Path
import json,subprocess,hashlib,wave
folder=Path(__file__).resolve().parent;destdir=folder/'audio-firered';destdir.mkdir(exist_ok=True);manifest_path=folder/'narration-audio-manifest.json';manifest=json.loads(manifest_path.read_text());jobs=json.loads((folder/'formal-jobs.json').read_text())
code='''from pathlib import Path
import json
p=Path('/home/qianqiming/codex-mojave-assembly-voice-20261019/firered')
def read(n,default=None):
 f=p/n;return json.loads(f.read_text()) if f.exists() else default
rows=read('results.json',[])
for r in rows:r['asr']=read('tracks/'+r['id']+'/asr.json')
print(json.dumps({'rows':rows,'status':read('status.json'),'config':read('config.json'),'observation':read('service-observation.json')},ensure_ascii=False))
'''
r=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=8','spark','python3','-'],input=code,text=True,capture_output=True,check=True);data=json.loads(r.stdout);(folder/'firered-remote-status.json').write_text(json.dumps(data,ensure_ascii=False,indent=2));rows=[]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for job in jobs:
    source=next((s for s in data['rows'] if s['id']==job['id']),None)
    if not source:
        rows.append({'id':job['id'],'text':job['text'],'engine':'FireRedTTS3','status':'pending FireRed generation','audio_local_path':None,'wav_path':None,'duration_seconds':None,'audio_sha256':None,'subtitle_sentences':None});continue
    assert source['text']==job['text'];assert source['audio'].startswith('/home/qianqiming/codex-mojave-assembly-voice-20261019/firered/')
    target=destdir/(job['id']+'.wav')
    if not target.exists() or sha(target)!=source['audio_sha256']:subprocess.run(['scp','-q','spark:'+source['audio'],str(target)],check=True)
    assert sha(target)==source['audio_sha256']
    with wave.open(str(target)) as f:
        assert f.getnchannels()==1 and f.getsampwidth()==2 and f.getframerate()==source['sample_rate'];duration=f.getnframes()/f.getframerate();assert abs(duration-source['duration_seconds'])<1/f.getframerate();pcm={'channels':1,'sample_width_bytes':2,'sample_rate':f.getframerate(),'sample_frames':f.getnframes(),'decoded_duration_seconds':duration}
    unitdir=destdir/'units';unitdir.mkdir(exist_ok=True)
    for unit in source['units']:
        unitlocal=unitdir/f"{job['id']}-{unit['index']:02d}.wav"
        if not unitlocal.exists() or sha(unitlocal)!=unit['audio_sha256']:subprocess.run(['scp','-q','spark:'+unit['file'],str(unitlocal)],check=True)
        assert sha(unitlocal)==unit['audio_sha256'];unit['local_wav_path']=str(unitlocal.resolve())
    asr=source.pop('asr',None);row={**source,'audio_local_path':str(target.resolve()),'wav_path':str(target.resolve()),'pcm_validation':pcm,'status':'generated; independent acoustic ASR pending','actual_listening':'pending parent perceptual review','generation_unit_boundaries_are_not_forced_acoustic_alignment':True}
    if asr:row.update({'independent_asr':asr,'subtitle_sentences':asr.get('subtitle_sentences',[]),'status':'independent ASR ready for difference review; listening pending'})
    else:row['subtitle_sentences']=None
    (destdir/(job['id']+'.json')).write_text(json.dumps(row,ensure_ascii=False,indent=2));rows.append(row)
manifest.update({'engine':'Existing local FireRedTTS3 queued service at Spark loopback7860','status':'FireRed generation and independent ASR in progress; all17 same synthetic reference; subjective listening pending','tracks':rows,'remote_batch_status':data['status'],'reference':data['config'],'service_observation':data['observation'],'generated_track_count':sum(r['wav_path'] is not None for r in rows),'asr_checked_track_count':sum('independent_asr' in r for r in rows),'asr_normalized_exact_count':sum(r.get('independent_asr',{}).get('normalized_exact_match',False) for r in rows),'total_actual_audio_duration_seconds':sum(r.get('duration_seconds') or 0 for r in rows),'speed_or_pitch_modified':False,'drama3_mixed_into_final_audio':False})
if rows[0]['wav_path']:manifest['sample_audio']=rows[0]['wav_path'];manifest['sample_content_check']='FireRed intro generated; independent ASR pending' if 'independent_asr' not in rows[0] else 'See intro independent_asr; naturalness listening pending'
if (folder/'voice-reference-rejected.flag').exists():
    manifest.update({'status':'voice_human_rejected_reference_not_final','eligible_for_final_movie':False,'usage':'timing reference only','subjective_human_feedback':'Unnatural and overly electronic; reference rejected by human listener','full_asr_intentionally_not_run_after_rejection':True})
    for row in manifest['tracks']:row.update({'eligible_for_final_movie':False,'usage':'timing reference only; voice human rejected'})
manifest_path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2));print(json.dumps({k:manifest[k] for k in ['engine','generated_track_count','asr_checked_track_count','total_actual_audio_duration_seconds','remote_batch_status']},ensure_ascii=False))
