"""Stage only the task-owned, fully verified download/rebuild duplicates.
No deletion or process termination. Preserve the primary Git checkout and reports.
"""
from pathlib import Path, PurePosixPath
import datetime, hashlib, json, os, runpy, shutil, stat, subprocess, uuid

ROOT=Path(__file__).resolve().parents[1]
V=ROOT.parent/'qiming-github-verify-20261019'
P=V/'project'
H=runpy.run_path(str(ROOT/'work/stage_cleanup.py'))
check,sha,save,plain,handles=(H[x] for x in ['check','sha','save','plain_ancestors','open_handles'])
plan=json.loads((ROOT/'work/cleanup-plan-current.json').read_text())
journal=V/'reports/generated-copy-stage.json'
report={'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'mode':'STAGE_ONLY','deletions_performed':0,'moves':[]}

def snap(base):
 rows=H['snapshot'](base)
 check(all(r['kind'] in ('file','directory','symlink') for r in rows.values()),'Special file in generated scope')
 return rows

def safe_relative(raw):
 p=PurePosixPath(raw)
 check(not p.is_absolute() and '..' not in p.parts and str(p)==raw,'Invalid manifest path')
 return Path(raw)

def total(rows):
 return sum(x['bytes'] for x in rows.values() if x['kind']=='file')

try:
 plain(V,True)
 owner=json.loads((V/'owner.json').read_text())
 check(owner['owner_thread']=='01a153fe-9f58-7093-b50c-8c9b05ddfd0d' and owner['root']==str(V) and owner['only_task_generated_copy_eligible_for_eventual_cleanup'] is True,'Verification directory owner mismatch')
 report['acceptance']=H['validate_acceptance'](V/'reports/final-acceptance.json')
 report['retained_clone_before']=H['clone_proof'](plan)
 report['protected_inputs_before']=H['check_103_and_desktop'](plan)
 tracked=set(plan['retained_git_checkout']['tracked_files'])
 tracked_hash={x:sha(P/x) for x in tracked}
 manifest=json.loads((V/'assets/release-manifest.json').read_text())
 check(sha(V/'assets/release-manifest.json')==H['EXPECTED_MANIFEST'],'Downloaded manifest changed')
 receipt=json.loads((V/'reports/actual-download-receipt.json').read_text())
 asset_map={x['name']:x for x in receipt['assets']}
 check(len(asset_map)==10 and {x.name for x in (V/'assets').iterdir()}==set(asset_map),'Unexpected asset download directory entries')
 for name,x in asset_map.items():
  p=V/'assets'/name
  check(p.is_file() and not p.is_symlink() and p.stat().st_size==x['bytes'] and sha(p)==x['sha256'],'Downloaded asset changed: '+name)
 partial=V/'partial-gh-download-20261019T190627Z'
 check({x.name for x in partial.iterdir()}<=set(asset_map),'Unknown partial transport artifact')
 for p in partial.iterdir():
  check(p.is_file() and not p.is_symlink() and 0<=p.stat().st_size<=asset_map[p.name]['bytes'],'Unexpected partial download entry')
 runtime=V/'runtime-links/node_modules'
 runtime_targets={
  'three':'/Users/qianqiming/Desktop/skill-repos/cclank--cell-architecture-studio/node_modules/stats-gl/node_modules/three',
  'esbuild':'/Users/qianqiming/Desktop/skill-repos/cclank--cell-architecture-studio/node_modules/esbuild'}
 check({x.name for x in runtime.iterdir()}==set(runtime_targets),'Unknown runtime link')
 for name,target in runtime_targets.items():
  check((runtime/name).is_symlink() and os.readlink(runtime/name)==target and Path(target).is_dir(),'Runtime link mismatch')

 # Retain the actual newly rebuilt QA images, not another editable model copy.
 frames=sorted((P/'rebuild/virtual-assembly').rglob('*.png'))
 check(len(frames)==22,'Expected exactly22 newly rebuilt diagnostic frames')
 frame_rows=[]
 for p in frames:
  check(not p.is_symlink(),'Frame is a symlink')
  dest=V/'reports/blender/actual-frames'/p.relative_to(P/'rebuild/virtual-assembly')
  dest.parent.mkdir(parents=True,exist_ok=True)
  check(not dest.exists(),'Retained frame already exists; do not overwrite')
  shutil.copy2(p,dest)
  check(sha(p)==sha(dest),'Diagnostic frame copy differs')
  frame_rows.append({'original':str(p),'retained':str(dest),'bytes':dest.stat().st_size,'sha256':sha(dest)})
 save(V/'reports/blender/actual-frames-retention.json',{'copied_actual_images':22,'files':frame_rows})

 whole=[V/x for x in ['assets','restored-lecture','frontend-rebuild','runtime-links','partial-gh-download-20261019T190627Z','project/rebuilt','project/rebuild/virtual-assembly']]
 for p in whole:
  plain(p,True)
  check(p.is_dir() and p.is_relative_to(V) and p not in (V,P,V/'reports'),'Invalid owned generated root')
  check(not any((P/x).is_relative_to(p) for x in tracked),'Generated root contains retained tracked source')
  check(not any(p!=q and p.is_relative_to(q) for q in whole),'Nested whole roots')
 file_sources=[]
 for row in manifest['files']:
  rel=safe_relative(row['path']);p=P/rel
  if str(rel) in tracked:continue
  check(not any(p.is_relative_to(q) for q in whole),'Manifest overlaps whole generated root')
  plain(p)
  check(p.is_file() and not p.is_symlink() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],'Expanded untracked payload changed: '+str(rel))
  file_sources.append(p)
 check(len(file_sources)==3673,'Expanded untracked payload count differs')
 link_sources=[]
 for row in manifest['symlinks']:
  p=P/safe_relative(row['path']);plain(p)
  check(row['path'] not in tracked and p.is_symlink() and os.readlink(p)==row['target'],'Expanded alias differs')
  link_sources.append(p)
 check(len(link_sources)==2,'Expected2 manifest aliases')
 # A transport range probe is a redundant prefix, with its JSON result retained.
 probe=V/'reports/direct-public-range-probe.bin'
 if probe.exists():
  check(probe.is_file() and not probe.is_symlink() and probe.stat().st_size==2097152,'Unexpected range probe')
  with (V/'assets/qiming-visual-006-of-006.tar.gz').open('rb') as f:
   check(hashlib.sha256(f.read(probe.stat().st_size)).hexdigest()==sha(probe),'Range probe is not the verified archive prefix')
  file_sources.append(probe)
 sources=whole+file_sources+link_sources
 check(not handles(sources),'Generated verification copies still have active handles')
 groups=[{'source':str(p),'items':list(snap(p).values())} for p in sources]
 report['whole_roots']=[str(p) for p in whole]
 report['expanded_untracked_manifest_files']=3673
 report['manifest_aliases']=2
 report['logical_bytes_staged']=sum(total({str(i):r for i,r in enumerate(g['items'])}) for g in groups)
 report['known_entries']=sum(len(g['items']) for g in groups)
 parent=V/'.generated-validation-quarantine'
 check(not parent.exists(),'Unexpected pre-existing generated quarantine')
 parent.mkdir();save(parent/'owner.json',{'owner_thread':owner['owner_thread'],'verification_root':str(V),'purpose':'Stage task-owned verified duplicates, preserve reports and primary Git checkout'})
 q=parent/(datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'-'+uuid.uuid4().hex[:8]);q.mkdir()
 report['quarantine']=str(q)
 fingerprints=V/'reports/generated-copy-fingerprints.json'
 save(fingerprints,{'groups':groups,'tracked_original_sha256':tracked_hash})
 report['fingerprint_file']=str(fingerprints);report['fingerprint_sha256']=sha(fingerprints)
 save(journal,report)
 for group in groups:
  p=Path(group['source']);H['match_fingerprints']({'items':group['items']},p)
  dest=q/p.relative_to(V);dest.parent.mkdir(parents=True,exist_ok=True)
  check(not dest.exists() and not dest.is_symlink(),'Staging destination exists')
  os.rename(p,dest)
  report['moves'].append({'source':str(p),'destination':str(dest),'known_entries':len(group['items'])})
  if len(report['moves'])%100==0:save(journal,report)
 report['post_stage_known_entries_checked']=sum(H['match_fingerprints']({'items':g['items']},q/Path(g['source']).relative_to(V)) for g in groups)
 report['post_stage_retained_clone']=H['clone_proof'](plan)
 check(all(sha(P/x)==h for x,h in tracked_hash.items()),'Tracked source bytes changed')
 report['post_stage_tracked194_exact_sha256']=True
 report['post_stage_protected_inputs']=H['check_103_and_desktop'](plan)
 report['post_stage_open_handles']=handles([q])
 check(not report['post_stage_open_handles'],'Quarantine has active handles')
 check(all(Path(t).is_dir() for t in runtime_targets.values()),'Protected runtime target disappeared')
 report['protected_runtime_symlink_targets_exist']=True
 report['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 report['post_stage_passed']=True
 report['result']='Task-owned generated copies staged only. Independent review required before removing exact unique quarantine child.'
except Exception as exc:
 report['error']=str(exc);report['post_stage_passed']=False
finally:
 save(journal,report)
 print(json.dumps({k:v for k,v in report.items() if k not in ('moves','acceptance')},ensure_ascii=False,indent=2))
if not report.get('post_stage_passed'):raise SystemExit(1)
