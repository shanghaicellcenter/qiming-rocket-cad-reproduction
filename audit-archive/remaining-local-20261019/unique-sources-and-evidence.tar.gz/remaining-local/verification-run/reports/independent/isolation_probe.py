from pathlib import Path
import json,datetime
r=Path(__file__).resolve().parents[2]
rows=[]
for source in [Path('/Users/qianqiming/Documents/Codex/2026-10-19/new-chat/outputs/启明火箭/打开项目.html'),Path('/Users/qianqiming/Documents/Codex/2026-10-19/ni/work/rocket/parts.json'),Path('/Users/qianqiming/Desktop/火箭设计 中文版'),Path('/Users/qianqiming/Desktop/skill-repos/scenario-labs--blender-expert-skills/scenario-blender-animation/SKILL.md')]:
 try:
  if source.suffix:source.open('rb').read(1)
  else:list(source.iterdir())
  denied=False
 except PermissionError:denied=True
 rows.append({'path':str(source),'denied_with_PermissionError':denied})
allowed=(r/'reports/acceptance-contract.json').is_file() and bool((r/'reports/acceptance-contract.json').read_bytes())
d={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'new_root_own_file_access_allowed':allowed,'original_inputs_actually_denied':rows,'passed':allowed and all(x['denied_with_PermissionError'] for x in rows),'remote_download_acceptance_claimed':False}
Path(__file__).with_name('isolation-probe.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(d,ensure_ascii=False))
if not d['passed']:raise SystemExit(1)
