from pathlib import Path
from PIL import Image,ImageOps,ImageDraw
root=Path('/Users/qianqiming/Documents/Codex/2026-10-19/new-chat/outputs/mojave-machine/source-components/renders')
groups=[('13_nose_component_review.png',['02_nose-section-1.png','03_nose-section-2.png','04_nose-shoulder.png','05_nose-tip.png'],2,600,500),
        ('14_avionics_exterior_review.png',['06_avbay-battery-holder.png','07_avbay-centering-ring.png','08_avbay-coupler-half.png','09_avbay-sled-mount.png','10_avbay-switchband.png','11_fin-bracket-tip.png'],3,500,417)]
for name,files,cols,w,h in groups:
    rows=(len(files)+cols-1)//cols
    sheet=Image.new('RGB',(w*cols,(h+28)*rows),(16,22,27))
    draw=ImageDraw.Draw(sheet)
    for i,file in enumerate(files):
        im=Image.open(root/file).convert('RGB')
        tile=ImageOps.contain(im,(w,h))
        x=(i%cols)*w+(w-tile.width)//2;y=(i//cols)*(h+28)
        sheet.paste(tile,(x,y))
        draw.text(((i%cols)*w+12,y+h+7),file.removesuffix('.png'),fill=(215,225,230))
    sheet.save(root/name)
    print(root/name)
